#!/usr/bin/env python3
import types
import functools


# from jaraco.functools 3.3
def method_cache(method, cache_wrapper=None):
    """
    Wrap lru_cache to support storing the cache data in the object instances.

    Abstracts the common paradigm where the method explicitly saves an
    underscore-prefixed protected property on first call and returns that
    subsequently.

    >>> class MyClass:
    ...     calls = 0
    ...
    ...     @method_cache
    ...     def method(self, value):
    ...         self.calls += 1
    ...         return value

    >>> a = MyClass()
    >>> a.method(3)
    3
    >>> for x in range(75):
    ...     res = a.method(x)
    >>> a.calls
    75

    Note that the apparent behavior will be exactly like that of lru_cache
    except that the cache is stored on each instance, so values in one
    instance will not flush values from another, and when an instance is
    deleted, so are the cached values for that instance.

    >>> b = MyClass()
    >>> for x in range(35):
    ...     res = b.method(x)
    >>> b.calls
    35
    >>> a.method(0)
    0
    >>> a.calls
    75

    Note that if method had been decorated with ``functools.lru_cache()``,
    a.calls would have been 76 (due to the cached value of 0 having been
    flushed by the 'b' instance).

    Clear the cache with ``.cache_clear()``

    >>> a.method.cache_clear()

    Same for a method that hasn't yet been called.

    >>> c = MyClass()
    >>> c.method.cache_clear()

    Another cache wrapper may be supplied:

    >>> cache = functools.lru_cache(maxsize=2)
    >>> MyClass.method2 = method_cache(lambda self: 3, cache_wrapper=cache)
    >>> a = MyClass()
    >>> a.method2()
    3

    Caution - do not subsequently wrap the method with another decorator, such
    as ``@property``, which changes the semantics of the function.

    See also
    http://code.activestate.com/recipes/577452-a-memoize-decorator-for-instance-methods/
    for another implementation and additional justification.
    """
    cache_wrapper = cache_wrapper or functools.lru_cache()

    def wrapper(self, *args, **kwargs):
        # it's the first call, replace the method with a cached, bound method
        bound_method = types.MethodType(method, self)
        cached_method = cache_wrapper(bound_method)
        setattr(self, method.__name__, cached_method)
        return cached_method(*args, **kwargs)

    # Support cache clear even before cache has been created.
    wrapper.cache_clear = lambda: None

    return wrapper


# From jaraco.functools 3.3
def pass_none(func):
    """
    Wrap func so it's not called if its first param is None

    >>> print_text = pass_none(print)
    >>> print_text('text')
    text
    >>> print_text(None)
    """

    @functools.wraps(func)
    def wrapper(param, *args, **kwargs):
        if param is not None:
            return func(param, *args, **kwargs)

    return wrapper

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/_functools.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 248 2025-06-01 01:29:52.279978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/__init__.cpython-312.pyc
795362d838d547bd01b49ff8a073c19388c5f8ad5881613a8a7bbe50064b6d55  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 97 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000000a0  74 75 70 74 6f 6f 6c 73  2f 5f 76 65 6e 64 6f 72  |tuptools/_vendor|
000000b0  2f 69 6d 70 6f 72 74 6c  69 62 5f 6d 65 74 61 64  |/importlib_metad|
000000c0  61 74 61 2f 63 6f 6d 70  61 74 2f 5f 5f 69 6e 69  |ata/compat/__ini|
000000d0  74 5f 5f 2e 70 79 da 08  3c 6d 6f 64 75 6c 65 3e  |t__.py..<module>|
000000e0  72 05 00 00 00 01 00 00  00 73 05 00 00 00 f1 03  |r........s......|
000000f0  01 01 01 72 03 00 00 00                           |...r....|
000000f8
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py311.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.3K 2025-06-01 01:29:52.439978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py311.cpython-312.pyc
f2410e4d5d4f7d163dab3530187c6f4b22327ec8462000f2d0fcddd519166e90  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py311.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 60 02 00 00  |..........8h`...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 54 00  00 00 97 00 64 00 64 01  |......T.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 02 84 00  |l.Z.d.d.l.Z.d...|
00000050  5a 04 65 02 6a 0a 00 00  00 00 00 00 00 00 00 00  |Z.e.j...........|
00000060  00 00 00 00 00 00 00 00  64 03 6b 02 00 00 72 03  |........d.k...r.|
00000070  65 04 5a 06 79 01 64 04  84 00 5a 06 79 01 29 05  |e.Z.y.d...Z.y.).|
00000080  e9 00 00 00 00 4e 63 01  00 00 00 00 00 00 00 00  |.....Nc.........|
00000090  00 00 00 03 00 00 00 03  00 00 00 f3 40 00 00 00  |............@...|
000000a0  87 00 97 00 64 01 64 02  9c 01 88 00 66 01 64 03  |....d.d.....f.d.|
000000b0  84 0a 7d 01 74 01 00 00  00 00 00 00 00 00 6a 02  |..}.t.........j.|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000d0  00 00 7c 01 ac 04 ab 01  00 00 00 00 00 00 53 00  |..|...........S.|
000000e0  29 05 61 17 01 00 00 0a  20 20 20 20 57 6f 72 6b  |).a.....    Work|
000000f0  61 72 6f 75 6e 64 20 66  6f 72 20 68 74 74 70 73  |around for https|
00000100  3a 2f 2f 67 69 74 68 75  62 2e 63 6f 6d 2f 70 79  |://github.com/py|
00000110  74 68 6f 6e 2f 63 70 79  74 68 6f 6e 2f 69 73 73  |thon/cpython/iss|
00000120  75 65 73 2f 38 34 35 33  38 0a 20 20 20 20 74 6f  |ues/84538.    to|
00000130  20 61 64 64 20 62 61 63  6b 77 61 72 64 20 63 6f  | add backward co|
00000140  6d 70 61 74 69 62 69 6c  69 74 79 20 66 6f 72 20  |mpatibility for |
00000150  77 61 6c 6b 5f 75 70 3d  54 72 75 65 2e 0a 20 20  |walk_up=True..  |
00000160  20 20 41 6e 20 65 78 61  6d 70 6c 65 20 61 66 66  |  An example aff|
00000170  65 63 74 65 64 20 70 61  63 6b 61 67 65 20 69 73  |ected package is|
00000180  20 64 61 73 6b 2d 6c 61  62 65 78 74 65 6e 73 69  | dask-labextensi|
00000190  6f 6e 2c 20 77 68 69 63  68 20 75 73 65 73 0a 20  |on, which uses. |
000001a0  20 20 20 6a 75 70 79 74  65 72 2d 70 61 63 6b 61  |   jupyter-packa|
000001b0  67 69 6e 67 20 74 6f 20  69 6e 73 74 61 6c 6c 20  |ging to install |
000001c0  4a 75 70 79 74 65 72 4c  61 62 20 6a 61 76 61 73  |JupyterLab javas|
000001d0  63 72 69 70 74 20 66 69  6c 65 73 20 6f 75 74 73  |cript files outs|
000001e0  69 64 65 0a 20 20 20 20  6f 66 20 73 69 74 65 2d  |ide.    of site-|
000001f0  70 61 63 6b 61 67 65 73  2e 0a 20 20 20 20 46 29  |packages..    F)|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py311.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py39.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.7K 2025-06-01 01:29:52.603978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py39.cpython-312.pyc
fe959639654fb5e02f81ea536ab78e78711ac15ca1e0e38af43d396bd59f55b9  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py39.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 4e 04 00 00  |..........8hN...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 60 00  00 00 97 00 64 00 5a 00  |......`.....d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 6d 03 5a 03 6d 04  |d.d.l.m.Z.m.Z.m.|
00000040  5a 04 01 00 65 02 72 09  64 03 64 04 6c 05 6d 06  |Z...e.r.d.d.l.m.|
00000050  5a 06 6d 07 5a 07 01 00  6e 04 65 03 78 01 5a 06  |Z.m.Z...n.e.x.Z.|
00000060  5a 07 64 05 65 06 64 06  65 04 65 08 19 00 00 00  |Z.d.e.d.e.e.....|
00000070  66 04 64 07 84 04 5a 09  64 08 65 07 64 06 65 0a  |f.d...Z.d.e.d.e.|
00000080  66 04 64 09 84 04 5a 0b  79 0a 29 0b 7a 29 0a 43  |f.d...Z.y.).z).C|
00000090  6f 6d 70 61 74 69 62 69  6c 69 74 79 20 6c 61 79  |ompatibility lay|
000000a0  65 72 20 77 69 74 68 20  50 79 74 68 6f 6e 20 33  |er with Python 3|
000000b0  2e 38 2f 33 2e 39 0a e9  00 00 00 00 29 03 da 0d  |.8/3.9......)...|
000000c0  54 59 50 45 5f 43 48 45  43 4b 49 4e 47 da 03 41  |TYPE_CHECKING..A|
000000d0  6e 79 da 08 4f 70 74 69  6f 6e 61 6c e9 02 00 00  |ny..Optional....|
000000e0  00 29 02 da 0c 44 69 73  74 72 69 62 75 74 69 6f  |.)...Distributio|
000000f0  6e da 0a 45 6e 74 72 79  50 6f 69 6e 74 da 04 64  |n..EntryPoint..d|
00000100  69 73 74 da 06 72 65 74  75 72 6e 63 01 00 00 00  |ist..returnc....|
00000110  00 00 00 00 00 00 00 00  08 00 00 00 03 00 00 00  |................|
00000120  f3 a0 00 00 00 97 00 09  00 7c 00 6a 00 00 00 00  |.........|.j....|
00000130  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 53  |...............S|
00000140  00 23 00 74 02 00 00 00  00 00 00 00 00 24 00 72  |.#.t.........$.r|
00000150  36 01 00 64 01 64 02 6c  02 6d 03 7d 01 01 00 7c  |6..d.d.l.m.}...||
00000160  01 6a 09 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
00000170  00 00 00 00 00 74 0b 00  00 00 00 00 00 00 00 7c  |.....t.........||
00000180  00 64 03 64 04 ab 03 00  00 00 00 00 00 78 01 73  |.d.d.........x.s|
00000190  0f 01 00 7c 00 6a 0c 00  00 00 00 00 00 00 00 00  |...|.j..........|
000001a0  00 00 00 00 00 00 00 00  00 64 05 19 00 00 00 ab  |.........d......|
000001b0  01 00 00 00 00 00 00 63  02 59 00 53 00 77 00 78  |.......c.Y.S.w.x|
000001c0  03 59 00 77 01 29 06 7a  5d 0a 20 20 20 20 48 6f  |.Y.w.).z].    Ho|
000001d0  6e 6f 72 20 6e 61 6d 65  20 6e 6f 72 6d 61 6c 69  |nor name normali|
000001e0  7a 61 74 69 6f 6e 20 66  6f 72 20 64 69 73 74 72  |zation for distr|
000001f0  69 62 75 74 69 6f 6e 73  20 74 68 61 74 20 64 6f  |ibutions that do|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/compat/__pycache__/py39.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 52K 2025-06-01 01:29:50.867978113 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/__init__.cpython-312.pyc
db2d81212f553524639f4f49643a2481b947e57ca12d7f59fa96aafe45b5fb7d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 06 84 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 01 f3 3e 03  00 00 97 00 64 00 64 01  |......>.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 05 5a 05  64 00 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 02 6c 07 5a 07  64 00 64 02 6c 08 5a 08  |d.d.l.Z.d.d.l.Z.|
00000070  64 00 64 02 6c 09 5a 09  64 00 64 02 6c 0a 5a 0a  |d.d.l.Z.d.d.l.Z.|
00000080  64 00 64 02 6c 0b 5a 0b  64 00 64 02 6c 0c 5a 0c  |d.d.l.Z.d.d.l.Z.|
00000090  64 00 64 02 6c 0d 5a 0d  64 00 64 02 6c 0e 5a 0e  |d.d.l.Z.d.d.l.Z.|
000000a0  64 00 64 02 6c 0f 5a 0f  64 00 64 02 6c 10 5a 10  |d.d.l.Z.d.d.l.Z.|
000000b0  64 00 64 02 6c 11 5a 11  64 03 64 04 6c 12 6d 13  |d.d.l.Z.d.d.l.m.|
000000c0  5a 13 01 00 64 03 64 05  6c 14 6d 15 5a 15 6d 16  |Z...d.d.l.m.Z.m.|
000000d0  5a 16 01 00 64 03 64 06  6c 17 6d 18 5a 18 6d 19  |Z...d.d.l.m.Z.m.|
000000e0  5a 19 01 00 64 03 64 07  6c 1a 6d 1b 5a 1b 6d 1c  |Z...d.d.l.m.Z.m.|
000000f0  5a 1c 01 00 64 03 64 08  6c 1d 6d 1e 5a 1e 6d 1f  |Z...d.d.l.m.Z.m.|
00000100  5a 1f 01 00 64 03 64 09  6c 20 6d 21 5a 21 6d 22  |Z...d.d.l m!Z!m"|
00000110  5a 22 01 00 64 03 64 0a  6c 13 6d 23 5a 23 6d 24  |Z"..d.d.l.m#Z#m$|
00000120  5a 24 01 00 64 00 64 0b  6c 25 6d 26 5a 26 01 00  |Z$..d.d.l%m&Z&..|
00000130  64 00 64 0c 6c 27 6d 28  5a 28 01 00 64 00 64 0d  |d.d.l'm(Z(..d.d.|
00000140  6c 29 6d 2a 5a 2a 01 00  64 00 64 0e 6c 0f 6d 2b  |l)m*Z*..d.d.l.m+|
00000150  5a 2b 01 00 64 00 64 0f  6c 2c 6d 2d 5a 2d 6d 2e  |Z+..d.d.l,m-Z-m.|
00000160  5a 2e 6d 2f 5a 2f 6d 30  5a 30 6d 31 5a 31 6d 32  |Z.m/Z/m0Z0m1Z1m2|
00000170  5a 32 6d 33 5a 33 6d 34  5a 34 01 00 67 00 64 10  |Z2m3Z3m4Z4..g.d.|
00000180  a2 01 5a 35 02 00 47 00  64 11 84 00 64 12 65 36  |..Z5..G.d...d.e6|
00000190  ab 03 00 00 00 00 00 00  5a 37 02 00 47 00 64 13  |........Z7..G.d.|
000001a0  84 00 64 14 ab 02 00 00  00 00 00 00 5a 38 02 00  |..d.........Z8..|
000001b0  47 00 64 15 84 00 64 16  ab 02 00 00 00 00 00 00  |G.d...d.........|
000001c0  5a 39 02 00 47 00 64 17  84 00 64 18 65 3a ab 03  |Z9..G.d...d.e:..|
000001d0  00 00 00 00 00 00 5a 3b  02 00 47 00 64 19 84 00  |......Z;..G.d...|
000001e0  64 1a 65 0b 6a 78 00 00  00 00 00 00 00 00 00 00  |d.e.jx..........|
000001f0  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_adapters.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.8K 2025-06-01 01:29:51.027978113 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_adapters.cpython-312.pyc
16da803cd1322372206f7f1a86dcfe3cd5737f9704c7b01f43da6c67dd40443a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_adapters.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 0d 09 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 66 00  00 00 97 00 64 00 64 01  |......f.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 03 64 02 64 03  6c 04 6d 05 5a 05 01 00  |l.Z.d.d.l.m.Z...|
00000050  02 00 47 00 64 04 84 00  64 05 65 03 6a 0c 00 00  |..G.d...d.e.j...|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000070  6a 0e 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000080  00 00 00 00 ab 03 00 00  00 00 00 00 5a 07 79 01  |............Z.y.|
00000090  29 06 e9 00 00 00 00 4e  e9 01 00 00 00 29 01 da  |)......N.....)..|
000000a0  0a 46 6f 6c 64 65 64 43  61 73 65 63 00 00 00 00  |.FoldedCasec....|
000000b0  00 00 00 00 00 00 00 00  07 00 00 00 00 00 00 00  |................|
000000c0  f3 a0 00 00 00 87 00 97  00 65 00 5a 01 64 00 5a  |.........e.Z.d.Z|
000000d0  02 02 00 65 03 02 00 65  04 65 05 67 00 64 01 a2  |...e...e.e.g.d..|
000000e0  01 ab 02 00 00 00 00 00  00 ab 01 00 00 00 00 00  |................|
000000f0  00 5a 06 09 00 64 02 65  07 6a 10 00 00 00 00 00  |.Z...d.e.j......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 6a 12 00  |.............j..|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000120  00 66 02 88 00 66 01 64  03 84 0c 5a 0a 64 04 84  |.f...f.d...Z.d..|
00000130  00 5a 0b 88 00 66 01 64  05 84 08 5a 0c 88 00 66  |.Z...f.d...Z...f|
00000140  01 64 06 84 08 5a 0d 64  07 84 00 5a 0e 65 0f 64  |.d...Z.d...Z.e.d|
00000150  08 84 00 ab 00 00 00 00  00 00 00 5a 10 88 00 78  |...........Z...x|
00000160  01 5a 11 53 00 29 09 da  07 4d 65 73 73 61 67 65  |.Z.S.)...Message|
00000170  29 0a da 0a 43 6c 61 73  73 69 66 69 65 72 7a 0e  |)...Classifierz.|
00000180  4f 62 73 6f 6c 65 74 65  73 2d 44 69 73 74 da 08  |Obsoletes-Dist..|
00000190  50 6c 61 74 66 6f 72 6d  7a 0b 50 72 6f 6a 65 63  |Platformz.Projec|
000001a0  74 2d 55 52 4c 7a 0d 50  72 6f 76 69 64 65 73 2d  |t-URLz.Provides-|
000001b0  44 69 73 74 7a 0e 50 72  6f 76 69 64 65 73 2d 45  |Distz.Provides-E|
000001c0  78 74 72 61 7a 0d 52 65  71 75 69 72 65 73 2d 44  |xtraz.Requires-D|
000001d0  69 73 74 7a 11 52 65 71  75 69 72 65 73 2d 45 78  |istz.Requires-Ex|
000001e0  74 65 72 6e 61 6c 7a 12  53 75 70 70 6f 72 74 65  |ternalz.Supporte|
000001f0  64 2d 50 6c 61 74 66 6f  72 6d da 07 44 79 6e 61  |d-Platform..Dyna|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_adapters.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_collections.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.0K 2025-06-01 01:29:51.187978113 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_collections.cpython-312.pyc
9b3b5bf92ff49077aed23e994572239633826ab37c2fbe67d67c1439e2027b0c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_collections.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 e7 02 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 6e 00  00 00 97 00 64 00 64 01  |......n.....d.d.|
00000030  6c 00 5a 00 02 00 47 00  64 02 84 00 64 03 65 00  |l.Z...G.d...d.e.|
00000040  6a 02 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000050  00 00 00 00 ab 03 00 00  00 00 00 00 5a 02 02 00  |............Z...|
00000060  47 00 64 04 84 00 64 05  02 00 65 00 6a 06 00 00  |G.d...d...e.j...|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000080  64 05 64 06 ab 02 00 00  00 00 00 00 ab 03 00 00  |d.d.............|
00000090  00 00 00 00 5a 04 79 01  29 07 e9 00 00 00 00 4e  |....Z.y.)......N|
000000a0  63 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |c...............|
000000b0  00 00 00 00 00 f3 28 00  00 00 87 00 97 00 65 00  |......(.......e.|
000000c0  5a 01 64 00 5a 02 64 01  5a 03 88 00 66 01 64 02  |Z.d.Z.d.Z...f.d.|
000000d0  84 08 5a 04 64 03 84 00  5a 05 88 00 78 01 5a 06  |..Z.d...Z...x.Z.|
000000e0  53 00 29 04 da 14 46 72  65 65 7a 61 62 6c 65 44  |S.)...FreezableD|
000000f0  65 66 61 75 6c 74 44 69  63 74 61 21 01 00 00 0a  |efaultDicta!....|
00000100  20 20 20 20 4f 66 74 65  6e 20 69 74 20 69 73 20  |    Often it is |
00000110  64 65 73 69 72 61 62 6c  65 20 74 6f 20 70 72 65  |desirable to pre|
00000120  76 65 6e 74 20 74 68 65  20 6d 75 74 61 74 69 6f  |vent the mutatio|
00000130  6e 20 6f 66 0a 20 20 20  20 61 20 64 65 66 61 75  |n of.    a defau|
00000140  6c 74 20 64 69 63 74 20  61 66 74 65 72 20 69 74  |lt dict after it|
00000150  73 20 69 6e 69 74 69 61  6c 20 63 6f 6e 73 74 72  |s initial constr|
00000160  75 63 74 69 6f 6e 2c 20  73 75 63 68 0a 20 20 20  |uction, such.   |
00000170  20 61 73 20 74 6f 20 70  72 65 76 65 6e 74 20 6d  | as to prevent m|
00000180  75 74 61 74 69 6f 6e 20  64 75 72 69 6e 67 20 69  |utation during i|
00000190  74 65 72 61 74 69 6f 6e  2e 0a 0a 20 20 20 20 3e  |teration...    >|
000001a0  3e 3e 20 64 64 20 3d 20  46 72 65 65 7a 61 62 6c  |>> dd = Freezabl|
000001b0  65 44 65 66 61 75 6c 74  44 69 63 74 28 6c 69 73  |eDefaultDict(lis|
000001c0  74 29 0a 20 20 20 20 3e  3e 3e 20 64 64 5b 30 5d  |t).    >>> dd[0]|
000001d0  2e 61 70 70 65 6e 64 28  27 31 27 29 0a 20 20 20  |.append('1').   |
000001e0  20 3e 3e 3e 20 64 64 2e  66 72 65 65 7a 65 28 29  | >>> dd.freeze()|
000001f0  0a 20 20 20 20 3e 3e 3e  20 64 64 5b 31 5d 0a 20  |.    >>> dd[1]. |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_collections.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_compat.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.3K 2025-06-01 01:29:51.343978113 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_compat.cpython-312.pyc
2c50022fb8264c7eb81eaddee00f3957aba5b7b6f0697f2be69150306fb9d96b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_compat.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 22 05 00 00  |..........8h"...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 42 00  00 00 97 00 64 00 64 01  |......B.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 02 64 03  |l.Z.d.d.l.Z.d.d.|
00000040  67 02 5a 02 64 04 84 00  5a 03 64 05 84 00 5a 04  |g.Z.d...Z.d...Z.|
00000050  02 00 47 00 64 06 84 00  64 03 ab 02 00 00 00 00  |..G.d...d.......|
00000060  00 00 5a 05 64 07 84 00  5a 06 79 01 29 08 e9 00  |..Z.d...Z.y.)...|
00000070  00 00 00 4e da 07 69 6e  73 74 61 6c 6c da 0a 4e  |...N..install..N|
00000080  75 6c 6c 46 69 6e 64 65  72 63 01 00 00 00 00 00  |ullFinderc......|
00000090  00 00 00 00 00 00 04 00  00 00 03 00 00 00 f3 62  |...............b|
000000a0  00 00 00 97 00 74 00 00  00 00 00 00 00 00 00 6a  |.....t.........j|
000000b0  02 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  00 00 00 6a 05 00 00 00  00 00 00 00 00 00 00 00  |...j............|
000000d0  00 00 00 00 00 00 00 02  00 7c 00 ab 00 00 00 00  |.........|......|
000000e0  00 00 00 ab 01 00 00 00  00 00 00 01 00 74 07 00  |.............t..|
000000f0  00 00 00 00 00 00 00 ab  00 00 00 00 00 00 00 01  |................|
00000100  00 7c 00 53 00 29 01 7a  d2 0a 20 20 20 20 43 6c  |.|.S.).z..    Cl|
00000110  61 73 73 20 64 65 63 6f  72 61 74 6f 72 20 66 6f  |ass decorator fo|
00000120  72 20 69 6e 73 74 61 6c  6c 61 74 69 6f 6e 20 6f  |r installation o|
00000130  6e 20 73 79 73 2e 6d 65  74 61 5f 70 61 74 68 2e  |n sys.meta_path.|
00000140  0a 0a 20 20 20 20 41 64  64 73 20 74 68 65 20 62  |..    Adds the b|
00000150  61 63 6b 70 6f 72 74 20  44 69 73 74 72 69 62 75  |ackport Distribu|
00000160  74 69 6f 6e 46 69 6e 64  65 72 20 74 6f 20 73 79  |tionFinder to sy|
00000170  73 2e 6d 65 74 61 5f 70  61 74 68 20 61 6e 64 0a  |s.meta_path and.|
00000180  20 20 20 20 61 74 74 65  6d 70 74 73 20 74 6f 20  |    attempts to |
00000190  64 69 73 61 62 6c 65 20  74 68 65 20 66 69 6e 64  |disable the find|
000001a0  65 72 20 66 75 6e 63 74  69 6f 6e 61 6c 69 74 79  |er functionality|
000001b0  20 6f 66 20 74 68 65 20  73 74 64 6c 69 62 0a 20  | of the stdlib. |
000001c0  20 20 20 44 69 73 74 72  69 62 75 74 69 6f 6e 46  |   DistributionF|
000001d0  69 6e 64 65 72 2e 0a 20  20 20 20 29 04 da 03 73  |inder..    )...s|
000001e0  79 73 da 09 6d 65 74 61  5f 70 61 74 68 da 06 61  |ys..meta_path..a|
000001f0  70 70 65 6e 64 da 15 64  69 73 61 62 6c 65 5f 73  |ppend..disable_s|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_compat.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_functools.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.5K 2025-06-01 01:29:51.499978113 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_functools.cpython-312.pyc
cd6079a256704e96e65b8064d19e57d6b2255ecdacf36d06850d0c83da4b2705  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_functools.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 4f 0b 00 00  |..........8hO...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 22 00  00 00 97 00 64 00 64 01  |......".....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 04 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  84 01 5a 02 64 03 84 00  5a 03 79 01 29 05 e9 00  |..Z.d...Z.y.)...|
00000050  00 00 00 4e 63 02 00 00  00 00 00 00 00 00 00 00  |...Nc...........|
00000060  00 02 00 00 00 03 00 00  00 f3 56 00 00 00 87 00  |..........V.....|
00000070  87 01 97 00 89 01 78 01  73 14 01 00 74 01 00 00  |......x.s...t...|
00000080  00 00 00 00 00 00 6a 02  00 00 00 00 00 00 00 00  |......j.........|
00000090  00 00 00 00 00 00 00 00  00 00 ab 00 00 00 00 00  |................|
000000a0  00 00 8a 01 88 01 88 00  66 02 64 01 84 08 7d 02  |........f.d...}.|
000000b0  64 02 84 00 7c 02 5f 02  00 00 00 00 00 00 00 00  |d...|._.........|
000000c0  7c 02 53 00 29 03 61 56  07 00 00 0a 20 20 20 20  ||.S.).aV....    |
000000d0  57 72 61 70 20 6c 72 75  5f 63 61 63 68 65 20 74  |Wrap lru_cache t|
000000e0  6f 20 73 75 70 70 6f 72  74 20 73 74 6f 72 69 6e  |o support storin|
000000f0  67 20 74 68 65 20 63 61  63 68 65 20 64 61 74 61  |g the cache data|
00000100  20 69 6e 20 74 68 65 20  6f 62 6a 65 63 74 20 69  | in the object i|
00000110  6e 73 74 61 6e 63 65 73  2e 0a 0a 20 20 20 20 41  |nstances...    A|
00000120  62 73 74 72 61 63 74 73  20 74 68 65 20 63 6f 6d  |bstracts the com|
00000130  6d 6f 6e 20 70 61 72 61  64 69 67 6d 20 77 68 65  |mon paradigm whe|
00000140  72 65 20 74 68 65 20 6d  65 74 68 6f 64 20 65 78  |re the method ex|
00000150  70 6c 69 63 69 74 6c 79  20 73 61 76 65 73 20 61  |plicitly saves a|
00000160  6e 0a 20 20 20 20 75 6e  64 65 72 73 63 6f 72 65  |n.    underscore|
00000170  2d 70 72 65 66 69 78 65  64 20 70 72 6f 74 65 63  |-prefixed protec|
00000180  74 65 64 20 70 72 6f 70  65 72 74 79 20 6f 6e 20  |ted property on |
00000190  66 69 72 73 74 20 63 61  6c 6c 20 61 6e 64 20 72  |first call and r|
000001a0  65 74 75 72 6e 73 20 74  68 61 74 0a 20 20 20 20  |eturns that.    |
000001b0  73 75 62 73 65 71 75 65  6e 74 6c 79 2e 0a 0a 20  |subsequently... |
000001c0  20 20 20 3e 3e 3e 20 63  6c 61 73 73 20 4d 79 43  |   >>> class MyC|
000001d0  6c 61 73 73 3a 0a 20 20  20 20 2e 2e 2e 20 20 20  |lass:.    ...   |
000001e0  20 20 63 61 6c 6c 73 20  3d 20 30 0a 20 20 20 20  |  calls = 0.    |
000001f0  2e 2e 2e 0a 20 20 20 20  2e 2e 2e 20 20 20 20 20  |....    ...     |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_functools.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_itertools.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.4K 2025-06-01 01:29:51.643978113 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_itertools.cpython-312.pyc
768a169c027524791f6b00e1bd17b6a3cba2c372bb0dc60a347d01249569b0e4  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_itertools.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 14 08 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 26 00  00 00 97 00 64 00 64 01  |......&.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 05 64 03 84 01 5a 02  |l.m.Z...d.d...Z.|
00000040  65 03 65 04 66 02 66 01  64 04 84 01 5a 05 79 02  |e.e.f.f.d...Z.y.|
00000050  29 06 e9 00 00 00 00 29  01 da 0b 66 69 6c 74 65  |)......)...filte|
00000060  72 66 61 6c 73 65 4e 63  02 00 00 00 00 00 00 00  |rfalseNc........|
00000070  00 00 00 00 04 00 00 00  23 00 00 00 f3 cc 00 00  |........#.......|
00000080  00 4b 00 01 00 97 00 74  01 00 00 00 00 00 00 00  |.K.....t........|
00000090  00 ab 00 00 00 00 00 00  00 7d 02 7c 02 6a 02 00  |.........}.|.j..|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  00 7d 03 7c 01 80 28 74  05 00 00 00 00 00 00 00  |.}.|..(t........|
000000c0  00 7c 02 6a 06 00 00 00  00 00 00 00 00 00 00 00  |.|.j............|
000000d0  00 00 00 00 00 00 00 7c  00 ab 02 00 00 00 00 00  |.......|........|
000000e0  00 44 00 5d 0e 00 00 7d  04 02 00 7c 03 7c 04 ab  |.D.]...}...|.|..|
000000f0  01 00 00 00 00 00 00 01  00 7c 04 96 01 97 01 01  |.........|......|
00000100  00 8c 10 04 00 79 01 7c  00 44 00 5d 1b 00 00 7d  |.....y.|.D.]...}|
00000110  04 02 00 7c 01 7c 04 ab  01 00 00 00 00 00 00 7d  |...|.|.........}|
00000120  05 7c 05 7c 02 76 01 73  01 8c 10 02 00 7c 03 7c  |.|.|.v.s.....|.||
00000130  05 ab 01 00 00 00 00 00  00 01 00 7c 04 96 01 97  |...........|....|
00000140  01 01 00 8c 1d 04 00 79  01 ad 03 77 01 29 02 7a  |.......y...w.).z|
00000150  48 4c 69 73 74 20 75 6e  69 71 75 65 20 65 6c 65  |HList unique ele|
00000160  6d 65 6e 74 73 2c 20 70  72 65 73 65 72 76 69 6e  |ments, preservin|
00000170  67 20 6f 72 64 65 72 2e  20 52 65 6d 65 6d 62 65  |g order. Remembe|
00000180  72 20 61 6c 6c 20 65 6c  65 6d 65 6e 74 73 20 65  |r all elements e|
00000190  76 65 72 20 73 65 65 6e  2e 4e 29 04 da 03 73 65  |ver seen.N)...se|
000001a0  74 da 03 61 64 64 72 03  00 00 00 da 0c 5f 5f 63  |t..addr......__c|
000001b0  6f 6e 74 61 69 6e 73 5f  5f 29 06 da 08 69 74 65  |ontains__)...ite|
000001c0  72 61 62 6c 65 da 03 6b  65 79 da 04 73 65 65 6e  |rable..key..seen|
000001d0  da 08 73 65 65 6e 5f 61  64 64 da 07 65 6c 65 6d  |..seen_add..elem|
000001e0  65 6e 74 da 01 6b 73 06  00 00 00 20 20 20 20 20  |ent..ks....     |
000001f0  20 fa 92 2f 64 61 74 61  2f 64 61 74 61 2f 63 6f  | ../data/data/co|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_itertools.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_meta.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.7K 2025-06-01 01:29:51.795978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_meta.cpython-312.pyc
59e1cae624529e48a16316076208634622b57aae82b099a089d10d709f6a5664  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_meta.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 09 07 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 88 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 03 6c 03 6d 04  5a 04 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 03 6d 05 5a 05 6d 06  5a 06 6d 07 5a 07 6d 08  |l.m.Z.m.Z.m.Z.m.|
00000060  5a 08 6d 09 5a 09 6d 0a  5a 0a 6d 0b 5a 0b 6d 0c  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 0c 01 00 02 00 65 0a  64 05 ab 01 00 00 00 00  |Z.....e.d.......|
00000080  00 00 5a 0d 02 00 47 00  64 06 84 00 64 07 65 04  |..Z...G.d...d.e.|
00000090  ab 03 00 00 00 00 00 00  5a 0e 02 00 47 00 64 08  |........Z...G.d.|
000000a0  84 00 64 09 65 04 ab 03  00 00 00 00 00 00 5a 0f  |..d.e.........Z.|
000000b0  79 02 29 0a e9 00 00 00  00 29 01 da 0b 61 6e 6e  |y.)......)...ann|
000000c0  6f 74 61 74 69 6f 6e 73  4e 29 01 da 08 50 72 6f  |otationsN)...Pro|
000000d0  74 6f 63 6f 6c 29 08 da  03 41 6e 79 da 04 44 69  |tocol)...Any..Di|
000000e0  63 74 da 08 49 74 65 72  61 74 6f 72 da 04 4c 69  |ct..Iterator..Li|
000000f0  73 74 da 08 4f 70 74 69  6f 6e 61 6c da 07 54 79  |st..Optional..Ty|
00000100  70 65 56 61 72 da 05 55  6e 69 6f 6e da 08 6f 76  |peVar..Union..ov|
00000110  65 72 6c 6f 61 64 da 02  5f 54 63 00 00 00 00 00  |erload.._Tc.....|
00000120  00 00 00 00 00 00 00 04  00 00 00 00 00 00 01 f3  |................|
00000130  a2 00 00 00 97 00 65 00  5a 01 64 00 5a 02 64 0b  |......e.Z.d.Z.d.|
00000140  64 01 84 04 5a 03 64 0c  64 02 84 04 5a 04 64 0d  |d...Z.d.d...Z.d.|
00000150  64 03 84 04 5a 05 64 0e  64 04 84 04 5a 06 65 07  |d...Z.d.d...Z.e.|
00000160  09 00 64 0f 09 00 09 00  09 00 09 00 09 00 64 10  |..d...........d.|
00000170  64 06 84 05 ab 00 00 00  00 00 00 00 5a 08 65 07  |d...........Z.e.|
00000180  64 11 64 07 84 04 ab 00  00 00 00 00 00 00 5a 08  |d.d...........Z.|
00000190  65 07 09 00 64 0f 09 00  09 00 09 00 09 00 09 00  |e...d...........|
000001a0  64 12 64 08 84 05 ab 00  00 00 00 00 00 00 5a 09  |d.d...........Z.|
000001b0  65 07 64 13 64 09 84 04  ab 00 00 00 00 00 00 00  |e.d.d...........|
000001c0  5a 09 65 0a 64 14 64 0a  84 04 ab 00 00 00 00 00  |Z.e.d.d.........|
000001d0  00 00 5a 0b 79 05 29 15  da 0f 50 61 63 6b 61 67  |..Z.y.)...Packag|
000001e0  65 4d 65 74 61 64 61 74  61 63 01 00 00 00 00 00  |eMetadatac......|
000001f0  00 00 00 00 00 00 00 00  00 00 03 00 00 01 f3 04  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_meta.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_text.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.9K 2025-06-01 01:29:51.959978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_text.cpython-312.pyc
b3bbe89e5705ef27484f3116af1cc89d60d91449f0d5db96538f2900f32e6725  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_text.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 76 08 00 00  |..........8hv...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 2e 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 02 64 03  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  02 00 47 00 64 04 84 00  64 05 65 03 ab 03 00 00  |..G.d...d.e.....|
00000050  00 00 00 00 5a 04 79 01  29 06 e9 00 00 00 00 4e  |....Z.y.)......N|
00000060  e9 01 00 00 00 29 01 da  0c 6d 65 74 68 6f 64 5f  |.....)...method_|
00000070  63 61 63 68 65 63 00 00  00 00 00 00 00 00 00 00  |cachec..........|
00000080  00 00 03 00 00 00 00 00  00 00 f3 68 00 00 00 87  |...........h....|
00000090  00 97 00 65 00 5a 01 64  00 5a 02 64 01 5a 03 64  |...e.Z.d.Z.d.Z.d|
000000a0  02 84 00 5a 04 64 03 84  00 5a 05 64 04 84 00 5a  |...Z.d...Z.d...Z|
000000b0  06 64 05 84 00 5a 07 64  06 84 00 5a 08 88 00 66  |.d...Z.d...Z...f|
000000c0  01 64 07 84 08 5a 09 64  08 84 00 5a 0a 65 0b 88  |.d...Z.d...Z.e..|
000000d0  00 66 01 64 09 84 08 ab  00 00 00 00 00 00 00 5a  |.f.d...........Z|
000000e0  0c 64 0a 84 00 5a 0d 64  0c 64 0b 84 01 5a 0e 88  |.d...Z.d.d...Z..|
000000f0  00 78 01 5a 0f 53 00 29  0d da 0a 46 6f 6c 64 65  |.x.Z.S.)...Folde|
00000100  64 43 61 73 65 61 7b 04  00 00 0a 20 20 20 20 41  |dCasea{....    A|
00000110  20 63 61 73 65 20 69 6e  73 65 6e 73 69 74 69 76  | case insensitiv|
00000120  65 20 73 74 72 69 6e 67  20 63 6c 61 73 73 3b 20  |e string class; |
00000130  62 65 68 61 76 65 73 20  6a 75 73 74 20 6c 69 6b  |behaves just lik|
00000140  65 20 73 74 72 0a 20 20  20 20 65 78 63 65 70 74  |e str.    except|
00000150  20 63 6f 6d 70 61 72 65  73 20 65 71 75 61 6c 20  | compares equal |
00000160  77 68 65 6e 20 74 68 65  20 6f 6e 6c 79 20 76 61  |when the only va|
00000170  72 69 61 74 69 6f 6e 20  69 73 20 63 61 73 65 2e  |riation is case.|
00000180  0a 0a 20 20 20 20 3e 3e  3e 20 73 20 3d 20 46 6f  |..    >>> s = Fo|
00000190  6c 64 65 64 43 61 73 65  28 27 68 65 6c 6c 6f 20  |ldedCase('hello |
000001a0  77 6f 72 6c 64 27 29 0a  0a 20 20 20 20 3e 3e 3e  |world')..    >>>|
000001b0  20 73 20 3d 3d 20 27 48  65 6c 6c 6f 20 57 6f 72  | s == 'Hello Wor|
000001c0  6c 64 27 0a 20 20 20 20  54 72 75 65 0a 0a 20 20  |ld'.    True..  |
000001d0  20 20 3e 3e 3e 20 27 48  65 6c 6c 6f 20 57 6f 72  |  >>> 'Hello Wor|
000001e0  6c 64 27 20 3d 3d 20 73  0a 20 20 20 20 54 72 75  |ld' == s.    Tru|
000001f0  65 0a 0a 20 20 20 20 3e  3e 3e 20 73 20 21 3d 20  |e..    >>> s != |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/_text.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/diagnose.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.3K 2025-06-01 01:29:52.123978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/diagnose.cpython-312.pyc
e07d1a92b88b142966e3064816808454945b9e94045a90a22fa41248ba0e8154  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/diagnose.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 7b 01 00 00  |..........8h{...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 3e 00  00 00 97 00 64 00 64 01  |......>.....d.d.|
00000030  6c 00 5a 00 64 02 64 03  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 04 84 00 5a 03 64 05  84 00 5a 04 65 05 64 06  |d...Z.d...Z.e.d.|
00000050  6b 28 00 00 72 08 02 00  65 04 ab 00 00 00 00 00  |k(..r...e.......|
00000060  00 00 01 00 79 01 79 01  29 07 e9 00 00 00 00 4e  |....y.y.)......N|
00000070  e9 01 00 00 00 29 01 da  0c 44 69 73 74 72 69 62  |.....)...Distrib|
00000080  75 74 69 6f 6e 63 01 00  00 00 00 00 00 00 00 00  |utionc..........|
00000090  00 00 06 00 00 00 03 00  00 00 f3 d4 00 00 00 97  |................|
000000a0  00 74 01 00 00 00 00 00  00 00 00 64 01 7c 00 ab  |.t.........d.|..|
000000b0  02 00 00 00 00 00 00 01  00 74 03 00 00 00 00 00  |.........t......|
000000c0  00 00 00 74 05 00 00 00  00 00 00 00 00 6a 06 00  |...t.........j..|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  00 7c 00 67 01 ac 02 ab  01 00 00 00 00 00 00 ab  |.|.g............|
000000f0  01 00 00 00 00 00 00 7d  01 7c 01 73 01 79 00 74  |.......}.|.s.y.t|
00000100  01 00 00 00 00 00 00 00  00 64 03 74 09 00 00 00  |.........d.t....|
00000110  00 00 00 00 00 7c 01 ab  01 00 00 00 00 00 00 64  |.....|.........d|
00000120  04 64 05 ac 06 ab 04 00  00 00 00 00 00 01 00 74  |.d.............t|
00000130  01 00 00 00 00 00 00 00  00 64 07 6a 0b 00 00 00  |.........d.j....|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 64  |...............d|
00000150  08 84 00 7c 01 44 00 ab  00 00 00 00 00 00 00 ab  |...|.D..........|
00000160  01 00 00 00 00 00 00 ab  01 00 00 00 00 00 00 01  |................|
00000170  00 79 00 29 09 4e da 0a  49 6e 73 70 65 63 74 69  |.y.).N..Inspecti|
00000180  6e 67 a9 01 da 04 70 61  74 68 da 05 46 6f 75 6e  |ng....path..Foun|
00000190  64 7a 09 70 61 63 6b 61  67 65 73 3a da 01 20 29  |dz.packages:.. )|
000001a0  01 da 03 65 6e 64 7a 02  2c 20 63 01 00 00 00 00  |...endz., c.....|
000001b0  00 00 00 00 00 00 00 02  00 00 00 33 00 00 00 f3  |...........3....|
000001c0  34 00 00 00 4b 00 01 00  97 00 7c 00 5d 10 00 00  |4...K.....|.]...|
000001d0  7d 01 7c 01 6a 00 00 00  00 00 00 00 00 00 00 00  |}.|.j...........|
000001e0  00 00 00 00 00 00 00 00  96 01 97 01 01 00 8c 12  |................|
000001f0  04 00 79 00 ad 03 77 01  a9 01 4e 29 01 da 04 6e  |..y...w...N)...n|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/importlib_metadata/__pycache__/diagnose.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 237 2025-06-01 01:29:52.999978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/__init__.cpython-312.pyc
95d8902d164e2c148b7ed0da97ad18b7315f019d537d6992c3498cd56b6564e7  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 8c 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000000a0  74 75 70 74 6f 6f 6c 73  2f 5f 76 65 6e 64 6f 72  |tuptools/_vendor|
000000b0  2f 69 6e 66 6c 65 63 74  2f 63 6f 6d 70 61 74 2f  |/inflect/compat/|
000000c0  5f 5f 69 6e 69 74 5f 5f  2e 70 79 da 08 3c 6d 6f  |__init__.py..<mo|
000000d0  64 75 6c 65 3e 72 05 00  00 00 01 00 00 00 73 05  |dule>r........s.|
000000e0  00 00 00 f1 03 01 01 01  72 03 00 00 00           |........r....|
000000ed
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/py38.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 400 2025-06-01 01:29:53.155978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/py38.cpython-312.pyc
59f0aff97d10200b33a818d869f2065f4923454d822a84b1170e24ce9c1df54d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/py38.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 a0 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 44 00  00 00 97 00 64 00 64 01  |......D.....d.d.|
00000030  6c 00 5a 00 65 00 6a 02  00 00 00 00 00 00 00 00  |l.Z.e.j.........|
00000040  00 00 00 00 00 00 00 00  00 00 64 02 6b 44 00 00  |..........d.kD..|
00000050  72 07 64 00 64 03 6c 02  6d 03 5a 03 01 00 79 01  |r.d.d.l.m.Z...y.|
00000060  64 00 64 03 6c 04 6d 03  5a 03 01 00 79 01 29 04  |d.d.l.m.Z...y.).|
00000070  e9 00 00 00 00 4e 29 02  e9 03 00 00 00 e9 09 00  |.....N).........|
00000080  00 00 29 01 da 09 41 6e  6e 6f 74 61 74 65 64 29  |..)...Annotated)|
00000090  05 da 03 73 79 73 da 0c  76 65 72 73 69 6f 6e 5f  |...sys..version_|
000000a0  69 6e 66 6f da 06 74 79  70 69 6e 67 72 05 00 00  |info..typingr...|
000000b0  00 da 11 74 79 70 69 6e  67 5f 65 78 74 65 6e 73  |...typing_extens|
000000c0  69 6f 6e 73 a9 00 f3 00  00 00 00 fa 88 2f 64 61  |ions........./da|
000000d0  74 61 2f 64 61 74 61 2f  63 6f 6d 2e 74 65 72 6d  |ta/data/com.term|
000000e0  75 78 2f 66 69 6c 65 73  2f 68 6f 6d 65 2f 52 41  |ux/files/home/RA|
000000f0  46 41 45 4c 49 41 2f 48  43 50 4d 2f 43 4f 52 45  |FAELIA/HCPM/CORE|
00000100  2f 76 65 6e 76 5f 72 61  66 61 65 6c 69 61 2f 6c  |/venv_rafaelia/l|
00000110  69 62 2f 70 79 74 68 6f  6e 33 2e 31 32 2f 73 69  |ib/python3.12/si|
00000120  74 65 2d 70 61 63 6b 61  67 65 73 2f 73 65 74 75  |te-packages/setu|
00000130  70 74 6f 6f 6c 73 2f 5f  76 65 6e 64 6f 72 2f 69  |ptools/_vendor/i|
00000140  6e 66 6c 65 63 74 2f 63  6f 6d 70 61 74 2f 70 79  |nflect/compat/py|
00000150  33 38 2e 70 79 da 08 3c  6d 6f 64 75 6c 65 3e 72  |38.py..<module>r|
00000160  0d 00 00 00 01 00 00 00  73 1e 00 00 00 f0 03 01  |........s.......|
00000170  01 01 db 00 0a f0 06 00  04 07 d7 03 13 d1 03 13  |................|
00000180  90 66 d2 03 1c de 04 20  e6 04 2b 72 0b 00 00 00  |.f..... ..+r....|
00000190
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/compat/__pycache__/py38.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 111K 2025-06-01 01:29:52.843978112 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/__pycache__/__init__.cpython-312.pyc
5e242757c4c495ffcc0f0b665c95065ef09b4c4fab46efdb374ff24695d21afc  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 74 95 01 00  |..........8ht...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 11 00 00  |................|
00000020  00 00 00 00 01 f3 c6 1e  00 00 97 00 55 00 64 00  |............U.d.|
00000030  5a 00 64 01 64 02 6c 01  6d 02 5a 02 01 00 64 01  |Z.d.d.l.m.Z...d.|
00000040  64 03 6c 03 5a 03 64 01  64 03 6c 04 5a 04 64 01  |d.l.Z.d.d.l.Z.d.|
00000050  64 03 6c 05 5a 05 64 01  64 03 6c 06 5a 06 64 01  |d.l.Z.d.d.l.Z.d.|
00000060  64 03 6c 07 5a 07 64 01  64 03 6c 08 5a 08 64 01  |d.l.Z.d.d.l.Z.d.|
00000070  64 04 6c 09 6d 0a 5a 0a  01 00 64 01 64 05 6c 0b  |d.l.m.Z...d.d.l.|
00000080  6d 0c 5a 0c 6d 0d 5a 0d  6d 0e 5a 0e 6d 0f 5a 0f  |m.Z.m.Z.m.Z.m.Z.|
00000090  6d 10 5a 10 6d 11 5a 11  6d 12 5a 12 6d 13 5a 13  |m.Z.m.Z.m.Z.m.Z.|
000000a0  6d 14 5a 14 6d 15 5a 15  6d 16 5a 16 6d 17 5a 17  |m.Z.m.Z.m.Z.m.Z.|
000000b0  6d 18 5a 18 01 00 64 01  64 06 6c 19 6d 1a 5a 1a  |m.Z...d.d.l.m.Z.|
000000c0  01 00 64 01 64 07 6c 1b  6d 1c 5a 1c 01 00 64 08  |..d.d.l.m.Z...d.|
000000d0  64 09 6c 1d 6d 1e 5a 1e  01 00 02 00 47 00 64 0a  |d.l.m.Z.....G.d.|
000000e0  84 00 64 0b 65 1f ab 03  00 00 00 00 00 00 5a 20  |..d.e.........Z |
000000f0  02 00 47 00 64 0c 84 00  64 0d 65 1f ab 03 00 00  |..G.d...d.e.....|
00000100  00 00 00 00 5a 21 02 00  47 00 64 0e 84 00 64 0f  |....Z!..G.d...d.|
00000110  65 1f ab 03 00 00 00 00  00 00 5a 22 02 00 47 00  |e.........Z"..G.|
00000120  64 10 84 00 64 11 65 1f  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000130  5a 23 02 00 47 00 64 12  84 00 64 13 65 1f ab 03  |Z#..G.d...d.e...|
00000140  00 00 00 00 00 00 5a 24  02 00 47 00 64 14 84 00  |......Z$..G.d...|
00000150  64 15 65 1f ab 03 00 00  00 00 00 00 5a 25 02 00  |d.e.........Z%..|
00000160  47 00 64 16 84 00 64 17  65 1f ab 03 00 00 00 00  |G.d...d.e.......|
00000170  00 00 5a 26 90 01 64 75  64 19 84 04 5a 27 90 01  |..Z&..dud...Z'..|
00000180  64 76 90 01 64 77 64 1a  84 05 5a 28 90 01 64 78  |dv..dwd...Z(..dx|
00000190  64 1c 84 04 5a 29 09 00  90 01 64 79 09 00 09 00  |d...Z)....dy....|
000001a0  09 00 09 00 09 00 09 00  09 00 90 01 64 7a 64 1e  |............dzd.|
000001b0  84 05 5a 2a 64 1f 64 20  64 21 64 22 64 23 64 24  |..Z*d.d d!d"d#d$|
000001c0  64 25 64 26 64 27 9c 08  5a 2b 69 00 64 28 64 29  |d%d&d'..Z+i.d(d)|
000001d0  93 01 64 2a 64 2b 93 01  64 2c 64 2d 93 01 64 2e  |..d*d+..d,d-..d.|
000001e0  64 2f 93 01 64 30 64 31  93 01 64 32 64 33 93 01  |d/..d0d1..d2d3..|
000001f0  64 34 64 35 93 01 64 36  64 37 93 01 64 38 64 39  |d4d5..d6d7..d8d9|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/inflect/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/collections/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 39K 2025-06-01 01:29:53.495978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/collections/__pycache__/__init__.cpython-312.pyc
5c980545d9edc25cf73c7f8aadd93e54ff7eb13ddb8193c17aa770dce1abe3e5  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/collections/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 10 68 00 00  |..........8h.h..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 01 f3 b6 03  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 03  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 04 5a 04  64 00 64 02 6c 05 5a 05  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 06 5a 06  64 00 64 02 6c 07 5a 07  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 02 6c 08 5a 08  64 00 64 02 6c 09 5a 09  |d.d.l.Z.d.d.l.Z.|
00000070  64 00 64 03 6c 02 6d 0a  5a 0a 6d 0b 5a 0b 6d 0c  |d.d.l.m.Z.m.Z.m.|
00000080  5a 0c 01 00 64 00 64 04  6c 0d 6d 0e 5a 0e 6d 0f  |Z...d.d.l.m.Z.m.|
00000090  5a 0f 6d 10 5a 10 6d 11  5a 11 6d 12 5a 12 6d 13  |Z.m.Z.m.Z.m.Z.m.|
000000a0  5a 13 6d 14 5a 14 01 00  64 00 64 02 6c 15 5a 16  |Z.m.Z...d.d.l.Z.|
000000b0  65 0e 72 1d 64 00 64 05  6c 17 6d 18 5a 18 01 00  |e.r.d.d.l.m.Z...|
000000c0  64 00 64 06 6c 19 6d 1a  5a 1a 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000d0  6c 1b 6d 1c 5a 1c 01 00  02 00 65 12 64 08 65 18  |l.m.Z.....e.d.e.|
000000e0  ac 09 ab 02 00 00 00 00  00 00 5a 1d 6e 08 02 00  |..........Z.n...|
000000f0  65 12 64 08 ab 01 00 00  00 00 00 00 5a 1d 02 00  |e.d.........Z...|
00000100  65 12 64 0a ab 01 00 00  00 00 00 00 5a 1e 02 00  |e.d.........Z...|
00000110  65 12 64 0b ab 01 00 00  00 00 00 00 5a 1f 65 13  |e.d.........Z.e.|
00000120  65 10 65 0a 65 0b 65 09  6a 40 00 00 00 00 00 00  |e.e.e.e.j@......|
00000130  00 00 00 00 00 00 00 00  00 00 00 00 66 04 19 00  |............f...|
00000140  00 00 5a 21 64 39 64 0c  84 04 5a 22 02 00 47 00  |..Z!d9d...Z"..G.|
00000150  64 0d 84 00 64 0e 65 03  6a 46 00 00 00 00 00 00  |d...d.e.jF......|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 6a 18 00 00  |............j...|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000180  ab 03 00 00 00 00 00 00  5a 24 02 00 47 00 64 0f  |........Z$..G.d.|
00000190  84 00 64 10 65 24 ab 03  00 00 00 00 00 00 5a 25  |..d.e$........Z%|
000001a0  64 11 84 00 5a 26 02 00  47 00 64 12 84 00 64 13  |d...Z&..G.d...d.|
000001b0  65 11 65 1d 65 1f 66 02  19 00 00 00 ab 03 00 00  |e.e.e.f.........|
000001c0  00 00 00 00 5a 27 64 14  84 00 5a 28 65 28 64 15  |....Z'd...Z(e(d.|
000001d0  66 02 64 16 84 01 5a 29  02 00 47 00 64 17 84 00  |f.d...Z)..G.d...|
000001e0  64 18 65 2a ab 03 00 00  00 00 00 00 5a 2b 02 00  |d.e*........Z+..|
000001f0  47 00 64 19 84 00 64 1a  65 2b ab 03 00 00 00 00  |G.d...d.e+......|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/collections/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/functools/__init__.py
-rwxrwxrwx. 1 u0_a292 u0_a292 17K 2025-06-02 22:55:15.170164467 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/functools/__init__.py
4d7e0209d62bfcab39d9ba859175e53e77fbeb147e2547c26a35bf6bab6f361e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/functools/__init__.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----