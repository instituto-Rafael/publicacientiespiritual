#!/usr/bin/env python3
"""Tests for the 'setuptools' package"""

import os
import re
import sys
from zipfile import ZipFile

import pytest
from packaging.version import Version

import setuptools
import setuptools.depends as dep
import setuptools.dist
from setuptools.depends import Require

import distutils.cmd
import distutils.core
from distutils.core import Extension
from distutils.errors import DistutilsSetupError


@pytest.fixture(autouse=True)
def isolated_dir(tmpdir_cwd):
    return


def makeSetup(**args):
    """Return distribution from 'setup(**args)', without executing commands"""

    distutils.core._setup_stop_after = "commandline"

    # Don't let system command line leak into tests!
    args.setdefault('script_args', ['install'])

    try:
        return setuptools.setup(**args)
    finally:
        distutils.core._setup_stop_after = None


needs_bytecode = pytest.mark.skipif(
    not hasattr(dep, 'get_module_constant'),
    reason="bytecode support not available",
)


class TestDepends:
    def testExtractConst(self):
        if not hasattr(dep, 'extract_constant'):
            # skip on non-bytecode platforms
            return

        def f1():
            global x, y, z
            x = "test"
            y = z  # pyright: ignore[reportUnboundVariable] # Explicitly testing for this runtime issue

        fc = f1.__code__

        # unrecognized name
        assert dep.extract_constant(fc, 'q', -1) is None

        # constant assigned
        assert dep.extract_constant(fc, 'x', -1) == "test"

        # expression assigned
        assert dep.extract_constant(fc, 'y', -1) == -1

        # recognized name, not assigned
        assert dep.extract_constant(fc, 'z', -1) is None

    def testFindModule(self):
        with pytest.raises(ImportError):
            dep.find_module('no-such.-thing')
        with pytest.raises(ImportError):
            dep.find_module('setuptools.non-existent')
        f, _p, _i = dep.find_module('setuptools.tests')
        f.close()

    @needs_bytecode
    def testModuleExtract(self):
        from json import __version__

        assert dep.get_module_constant('json', '__version__') == __version__
        assert dep.get_module_constant('sys', 'version') == sys.version
        assert (
            dep.get_module_constant('setuptools.tests.test_setuptools', '__doc__')
            == __doc__
        )

    @needs_bytecode
    def testRequire(self):
        req = Require('Json', '1.0.3', 'json')

        assert req.name == 'Json'
        assert req.module == 'json'
        assert req.requested_version == Version('1.0.3')
        assert req.attribute == '__version__'
        assert req.full_name() == 'Json-1.0.3'

        from json import __version__

        assert str(req.get_version()) == __version__
        assert req.version_ok('1.0.9')
        assert not req.version_ok('0.9.1')
        assert not req.version_ok('unknown')

        assert req.is_present()
        assert req.is_current()

        req = Require('Do-what-I-mean', '1.0', 'd-w-i-m')
        assert not req.is_present()
        assert not req.is_current()

    @needs_bytecode
    def test_require_present(self):
        # In #1896, this test was failing for months with the only
        # complaint coming from test runners (not end users).
        # TODO: Evaluate if this code is needed at all.
        req = Require('Tests', None, 'tests', homepage="http://example.com")
        assert req.format is None
        assert req.attribute is None
        assert req.requested_version is None
        assert req.full_name() == 'Tests'
        assert req.homepage == 'http://example.com'

        from setuptools.tests import __path__

        paths = [os.path.dirname(p) for p in __path__]
        assert req.is_present(paths)
        assert req.is_current(paths)


class TestDistro:
    def setup_method(self, method):
        self.e1 = Extension('bar.ext', ['bar.c'])
        self.e2 = Extension('c.y', ['y.c'])

        self.dist = makeSetup(
            packages=['a', 'a.b', 'a.b.c', 'b', 'c'],
            py_modules=['b.d', 'x'],
            ext_modules=(self.e1, self.e2),
            package_dir={},
        )

    def testDistroType(self):
        assert isinstance(self.dist, setuptools.dist.Distribution)

    def testExcludePackage(self):
        self.dist.exclude_package('a')
        assert self.dist.packages == ['b', 'c']

        self.dist.exclude_package('b')
        assert self.dist.packages == ['c']
        assert self.dist.py_modules == ['x']
        assert self.dist.ext_modules == [self.e1, self.e2]

        self.dist.exclude_package('c')
        assert self.dist.packages == []
        assert self.dist.py_modules == ['x']
        assert self.dist.ext_modules == [self.e1]

        # test removals from unspecified options
        makeSetup().exclude_package('x')

    def testIncludeExclude(self):
        # remove an extension
        self.dist.exclude(ext_modules=[self.e1])
        assert self.dist.ext_modules == [self.e2]

        # add it back in
        self.dist.include(ext_modules=[self.e1])
        assert self.dist.ext_modules == [self.e2, self.e1]

        # should not add duplicate
        self.dist.include(ext_modules=[self.e1])
        assert self.dist.ext_modules == [self.e2, self.e1]

    def testExcludePackages(self):
        self.dist.exclude(packages=['c', 'b', 'a'])
        assert self.dist.packages == []
        assert self.dist.py_modules == ['x']
        assert self.dist.ext_modules == [self.e1]

    def testEmpty(self):
        dist = makeSetup()
        dist.include(packages=['a'], py_modules=['b'], ext_modules=[self.e2])
        dist = makeSetup()
        dist.exclude(packages=['a'], py_modules=['b'], ext_modules=[self.e2])

    def testContents(self):
        assert self.dist.has_contents_for('a')
        self.dist.exclude_package('a')
        assert not self.dist.has_contents_for('a')

        assert self.dist.has_contents_for('b')
        self.dist.exclude_package('b')
        assert not self.dist.has_contents_for('b')

        assert self.dist.has_contents_for('c')
        self.dist.exclude_package('c')
        assert not self.dist.has_contents_for('c')

    def testInvalidIncludeExclude(self):
        with pytest.raises(DistutilsSetupError):
            self.dist.include(nonexistent_option='x')
        with pytest.raises(DistutilsSetupError):
            self.dist.exclude(nonexistent_option='x')
        with pytest.raises(DistutilsSetupError):
            self.dist.include(packages={'x': 'y'})
        with pytest.raises(DistutilsSetupError):
            self.dist.exclude(packages={'x': 'y'})
        with pytest.raises(DistutilsSetupError):
            self.dist.include(ext_modules={'x': 'y'})
        with pytest.raises(DistutilsSetupError):
            self.dist.exclude(ext_modules={'x': 'y'})

        with pytest.raises(DistutilsSetupError):
            self.dist.include(package_dir=['q'])
        with pytest.raises(DistutilsSetupError):
            self.dist.exclude(package_dir=['q'])


@pytest.fixture
def example_source(tmpdir):
    tmpdir.mkdir('foo')
    (tmpdir / 'foo/bar.py').write('')
    (tmpdir / 'readme.txt').write('')
    return tmpdir


def test_findall(example_source):
    found = list(setuptools.findall(str(example_source)))
    expected = ['readme.txt', 'foo/bar.py']
    expected = [example_source.join(fn) for fn in expected]
    assert found == expected


def test_findall_curdir(example_source):
    with example_source.as_cwd():
        found = list(setuptools.findall())
    expected = ['readme.txt', os.path.join('foo', 'bar.py')]
    assert found == expected


@pytest.fixture
def can_symlink(tmpdir):
    """
    Skip if cannot create a symbolic link
    """
    link_fn = 'link'
    target_fn = 'target'
    try:
        os.symlink(target_fn, link_fn)
    except (OSError, NotImplementedError, AttributeError):
        pytest.skip("Cannot create symbolic links")
    os.remove(link_fn)


@pytest.mark.usefixtures("can_symlink")
def test_findall_missing_symlink(tmpdir):
    with tmpdir.as_cwd():
        os.symlink('foo', 'bar')
        found = list(setuptools.findall())
        assert found == []


@pytest.mark.xfail(reason="unable to exclude tests; #4475 #3260")
def test_its_own_wheel_does_not_contain_tests(setuptools_wheel):
    with ZipFile(setuptools_wheel) as zipfile:
        contents = [f.replace(os.sep, '/') for f in zipfile.namelist()]

    for member in contents:
        assert '/tests/' not in member


def test_wheel_includes_cli_scripts(setuptools_wheel):
    with ZipFile(setuptools_wheel) as zipfile:
        contents = [f.replace(os.sep, '/') for f in zipfile.namelist()]

    assert any('cli-64.exe' in member for member in contents)


def test_wheel_includes_vendored_metadata(setuptools_wheel):
    with ZipFile(setuptools_wheel) as zipfile:
        contents = [f.replace(os.sep, '/') for f in zipfile.namelist()]

    assert any(
        re.search(r'_vendor/.*\.dist-info/METADATA', member) for member in contents
    )

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/test_setuptools.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 227 2025-06-01 01:30:20.883978092 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/__init__.cpython-312.pyc
37831913fc796c79cfb10184369eb8f787bad2f4e0dc68afc68fef1087e2b73f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 82 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000000a0  74 75 70 74 6f 6f 6c 73  2f 74 65 73 74 73 2f 63  |tuptools/tests/c|
000000b0  6f 6d 70 61 74 2f 5f 5f  69 6e 69 74 5f 5f 2e 70  |ompat/__init__.p|
000000c0  79 da 08 3c 6d 6f 64 75  6c 65 3e 72 05 00 00 00  |y..<module>r....|
000000d0  01 00 00 00 73 05 00 00  00 f1 03 01 01 01 72 03  |....s.........r.|
000000e0  00 00 00                                          |...|
000000e3
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/py39.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 394 2025-06-01 01:30:21.027978092 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/py39.cpython-312.pyc
84b94d2c478a95bc4106a3894128a62970c4da6529cf4ef0319011f22b527428  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/py39.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 87 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |................|
00000020  00 00 00 00 00 f3 38 00  00 00 97 00 64 00 64 01  |......8.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 01 00 02 00 65 02  |l.m.Z.m.Z.....e.|
00000040  64 02 ab 01 00 00 00 00  00 00 78 01 73 08 01 00  |d.........x.s...|
00000050  02 00 65 01 64 03 ab 01  00 00 00 00 00 00 5a 03  |..e.d.........Z.|
00000060  79 04 29 05 e9 00 00 00  00 29 02 da 11 66 72 6f  |y.)......)...fro|
00000070  6d 5f 74 65 73 74 5f 73  75 70 70 6f 72 74 da 0a  |m_test_support..|
00000080  74 72 79 5f 69 6d 70 6f  72 74 da 09 6f 73 5f 68  |try_import..os_h|
00000090  65 6c 70 65 72 da 0b 63  61 6e 5f 73 79 6d 6c 69  |elper..can_symli|
000000a0  6e 6b 4e 29 04 da 13 6a  61 72 61 63 6f 2e 74 65  |nkN)...jaraco.te|
000000b0  73 74 2e 63 70 79 74 68  6f 6e 72 03 00 00 00 72  |st.cpythonr....r|
000000c0  04 00 00 00 72 05 00 00  00 a9 00 f3 00 00 00 00  |....r...........|
000000d0  fa 7e 2f 64 61 74 61 2f  64 61 74 61 2f 63 6f 6d  |.~/data/data/com|
000000e0  2e 74 65 72 6d 75 78 2f  66 69 6c 65 73 2f 68 6f  |.termux/files/ho|
000000f0  6d 65 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |me/RAFAELIA/HCPM|
00000100  2f 43 4f 52 45 2f 76 65  6e 76 5f 72 61 66 61 65  |/CORE/venv_rafae|
00000110  6c 69 61 2f 6c 69 62 2f  70 79 74 68 6f 6e 33 2e  |lia/lib/python3.|
00000120  31 32 2f 73 69 74 65 2d  70 61 63 6b 61 67 65 73  |12/site-packages|
00000130  2f 73 65 74 75 70 74 6f  6f 6c 73 2f 74 65 73 74  |/setuptools/test|
00000140  73 2f 63 6f 6d 70 61 74  2f 70 79 33 39 2e 70 79  |s/compat/py39.py|
00000150  da 08 3c 6d 6f 64 75 6c  65 3e 72 0b 00 00 00 01  |..<module>r.....|
00000160  00 00 00 73 1d 00 00 00  f0 03 01 01 01 df 00 3d  |...s...........=|
00000170  e1 0c 16 90 7b d3 0c 23  d2 0c 47 d1 27 38 b8 1d  |....{..#..G.'8..|
00000180  d3 27 47 81 09 72 09 00  00 00                    |.'G..r....|
0000018a
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/compat/__pycache__/py39.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/config/test_apply_pyprojecttoml.py
-rwxrwxrwx. 1 u0_a292 u0_a292 29K 2025-06-02 22:55:15.894164466 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/config/test_apply_pyprojecttoml.py
8e72c3cf350468031073bb09e2a94d739cb39f52f040dbb98e50c7aebd694354  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/config/test_apply_pyprojecttoml.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----