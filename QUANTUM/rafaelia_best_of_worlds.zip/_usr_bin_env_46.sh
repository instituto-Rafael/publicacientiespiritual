#!/usr/bin/env python3
"""distutils.command.sdist

Implements the Distutils 'sdist' command (create a source distribution)."""

from __future__ import annotations

import os
import sys
from collections.abc import Callable
from distutils import archive_util, dir_util, file_util
from distutils._log import log
from glob import glob
from itertools import filterfalse
from typing import ClassVar

from ..core import Command
from ..errors import DistutilsOptionError, DistutilsTemplateError
from ..filelist import FileList
from ..text_file import TextFile
from ..util import convert_path


def show_formats():
    """Print all possible values for the 'formats' option (used by
    the "--help-formats" command-line option).
    """
    from ..archive_util import ARCHIVE_FORMATS
    from ..fancy_getopt import FancyGetopt

    formats = sorted(
        ("formats=" + format, None, ARCHIVE_FORMATS[format][2])
        for format in ARCHIVE_FORMATS.keys()
    )
    FancyGetopt(formats).print_help("List of available source distribution formats:")


class sdist(Command):
    description = "create a source distribution (tarball, zip file, etc.)"

    def checking_metadata(self) -> bool:
        """Callable used for the check sub-command.

        Placed here so user_options can view it"""
        return self.metadata_check

    user_options = [
        ('template=', 't', "name of manifest template file [default: MANIFEST.in]"),
        ('manifest=', 'm', "name of manifest file [default: MANIFEST]"),
        (
            'use-defaults',
            None,
            "include the default file set in the manifest "
            "[default; disable with --no-defaults]",
        ),
        ('no-defaults', None, "don't include the default file set"),
        (
            'prune',
            None,
            "specifically exclude files/directories that should not be "
            "distributed (build tree, RCS/CVS dirs, etc.) "
            "[default; disable with --no-prune]",
        ),
        ('no-prune', None, "don't automatically exclude anything"),
        (
            'manifest-only',
            'o',
            "just regenerate the manifest and then stop (implies --force-manifest)",
        ),
        (
            'force-manifest',
            'f',
            "forcibly regenerate the manifest and carry on as usual. "
            "Deprecated: now the manifest is always regenerated.",
        ),
        ('formats=', None, "formats for source distribution (comma-separated list)"),
        (
            'keep-temp',
            'k',
            "keep the distribution tree around after creating " + "archive file(s)",
        ),
        (
            'dist-dir=',
            'd',
            "directory to put the source distribution archive(s) in [default: dist]",
        ),
        (
            'metadata-check',
            None,
            "Ensure that all required elements of meta-data "
            "are supplied. Warn if any missing. [default]",
        ),
        (
            'owner=',
            'u',
            "Owner name used when creating a tar file [default: current user]",
        ),
        (
            'group=',
            'g',
            "Group name used when creating a tar file [default: current group]",
        ),
    ]

    boolean_options: ClassVar[list[str]] = [
        'use-defaults',
        'prune',
        'manifest-only',
        'force-manifest',
        'keep-temp',
        'metadata-check',
    ]

    help_options: ClassVar[list[tuple[str, str | None, str, Callable[[], object]]]] = [
        ('help-formats', None, "list available distribution formats", show_formats),
    ]

    negative_opt: ClassVar[dict[str, str]] = {
        'no-defaults': 'use-defaults',
        'no-prune': 'prune',
    }

    sub_commands = [('check', checking_metadata)]

    READMES: ClassVar[tuple[str, ...]] = ('README', 'README.txt', 'README.rst')

    def initialize_options(self):
        # 'template' and 'manifest' are, respectively, the names of
        # the manifest template and manifest file.
        self.template = None
        self.manifest = None

        # 'use_defaults': if true, we will include the default file set
        # in the manifest
        self.use_defaults = True
        self.prune = True

        self.manifest_only = False
        self.force_manifest = False

        self.formats = ['gztar']
        self.keep_temp = False
        self.dist_dir = None

        self.archive_files = None
        self.metadata_check = True
        self.owner = None
        self.group = None

    def finalize_options(self) -> None:
        if self.manifest is None:
            self.manifest = "MANIFEST"
        if self.template is None:
            self.template = "MANIFEST.in"

        self.ensure_string_list('formats')

        bad_format = archive_util.check_archive_formats(self.formats)
        if bad_format:
            raise DistutilsOptionError(f"unknown archive format '{bad_format}'")

        if self.dist_dir is None:
            self.dist_dir = "dist"

    def run(self) -> None:
        # 'filelist' contains the list of files that will make up the
        # manifest
        self.filelist = FileList()

        # Run sub commands
        for cmd_name in self.get_sub_commands():
            self.run_command(cmd_name)

        # Do whatever it takes to get the list of files to process
        # (process the manifest template, read an existing manifest,
        # whatever).  File list is accumulated in 'self.filelist'.
        self.get_file_list()

        # If user just wanted us to regenerate the manifest, stop now.
        if self.manifest_only:
            return

        # Otherwise, go ahead and create the source distribution tarball,
        # or zipfile, or whatever.
        self.make_distribution()

    def get_file_list(self) -> None:
        """Figure out the list of files to include in the source
        distribution, and put it in 'self.filelist'.  This might involve
        reading the manifest template (and writing the manifest), or just
        reading the manifest, or just using the default file set -- it all
        depends on the user's options.
        """
        # new behavior when using a template:
        # the file list is recalculated every time because
        # even if MANIFEST.in or setup.py are not changed
        # the user might have added some files in the tree that
        # need to be included.
        #
        #  This makes --force the default and only behavior with templates.
        template_exists = os.path.isfile(self.template)
        if not template_exists and self._manifest_is_not_generated():
            self.read_manifest()
            self.filelist.sort()
            self.filelist.remove_duplicates()
            return

        if not template_exists:
            self.warn(
                ("manifest template '%s' does not exist " + "(using default file list)")
                % self.template
            )
        self.filelist.findall()

        if self.use_defaults:
            self.add_defaults()

        if template_exists:
            self.read_template()

        if self.prune:
            self.prune_file_list()

        self.filelist.sort()
        self.filelist.remove_duplicates()
        self.write_manifest()

    def add_defaults(self) -> None:
        """Add all the default files to self.filelist:
          - README or README.txt
          - setup.py
          - tests/test*.py and test/test*.py
          - all pure Python modules mentioned in setup script
          - all files pointed by package_data (build_py)
          - all files defined in data_files.
          - all files defined as scripts.
          - all C sources listed as part of extensions or C libraries
            in the setup script (doesn't catch C headers!)
        Warns if (README or README.txt) or setup.py are missing; everything
        else is optional.
        """
        self._add_defaults_standards()
        self._add_defaults_optional()
        self._add_defaults_python()
        self._add_defaults_data_files()
        self._add_defaults_ext()
        self._add_defaults_c_libs()
        self._add_defaults_scripts()

    @staticmethod
    def _cs_path_exists(fspath):
        """
        Case-sensitive path existence check

        >>> sdist._cs_path_exists(__file__)
        True
        >>> sdist._cs_path_exists(__file__.upper())
        False
        """
        if not os.path.exists(fspath):
            return False
        # make absolute so we always have a directory
        abspath = os.path.abspath(fspath)
        directory, filename = os.path.split(abspath)
        return filename in os.listdir(directory)

    def _add_defaults_standards(self):
        standards = [self.READMES, self.distribution.script_name]
        for fn in standards:
            if isinstance(fn, tuple):
                alts = fn
                got_it = False
                for fn in alts:
                    if self._cs_path_exists(fn):
                        got_it = True
                        self.filelist.append(fn)
                        break

                if not got_it:
                    self.warn(
                        "standard file not found: should have one of " + ', '.join(alts)
                    )
            else:
                if self._cs_path_exists(fn):
                    self.filelist.append(fn)
                else:
                    self.warn(f"standard file '{fn}' not found")

    def _add_defaults_optional(self):
        optional = ['tests/test*.py', 'test/test*.py', 'setup.cfg']
        for pattern in optional:
            files = filter(os.path.isfile, glob(pattern))
            self.filelist.extend(files)

    def _add_defaults_python(self):
        # build_py is used to get:
        #  - python modules
        #  - files defined in package_data
        build_py = self.get_finalized_command('build_py')

        # getting python files
        if self.distribution.has_pure_modules():
            self.filelist.extend(build_py.get_source_files())

        # getting package_data files
        # (computed in build_py.data_files by build_py.finalize_options)
        for _pkg, src_dir, _build_dir, filenames in build_py.data_files:
            for filename in filenames:
                self.filelist.append(os.path.join(src_dir, filename))

    def _add_defaults_data_files(self):
        # getting distribution.data_files
        if self.distribution.has_data_files():
            for item in self.distribution.data_files:
                if isinstance(item, str):
                    # plain file
                    item = convert_path(item)
                    if os.path.isfile(item):
                        self.filelist.append(item)
                else:
                    # a (dirname, filenames) tuple
                    dirname, filenames = item
                    for f in filenames:
                        f = convert_path(f)
                        if os.path.isfile(f):
                            self.filelist.append(f)

    def _add_defaults_ext(self):
        if self.distribution.has_ext_modules():
            build_ext = self.get_finalized_command('build_ext')
            self.filelist.extend(build_ext.get_source_files())

    def _add_defaults_c_libs(self):
        if self.distribution.has_c_libraries():
            build_clib = self.get_finalized_command('build_clib')
            self.filelist.extend(build_clib.get_source_files())

    def _add_defaults_scripts(self):
        if self.distribution.has_scripts():
            build_scripts = self.get_finalized_command('build_scripts')
            self.filelist.extend(build_scripts.get_source_files())

    def read_template(self) -> None:
        """Read and parse manifest template file named by self.template.

        (usually "MANIFEST.in") The parsing and processing is done by
        'self.filelist', which updates itself accordingly.
        """
        log.info("reading manifest template '%s'", self.template)
        template = TextFile(
            self.template,
            strip_comments=True,
            skip_blanks=True,
            join_lines=True,
            lstrip_ws=True,
            rstrip_ws=True,
            collapse_join=True,
        )

        try:
            while True:
                line = template.readline()
                if line is None:  # end of file
                    break

                try:
                    self.filelist.process_template_line(line)
                # the call above can raise a DistutilsTemplateError for
                # malformed lines, or a ValueError from the lower-level
                # convert_path function
                except (DistutilsTemplateError, ValueError) as msg:
                    self.warn(
                        f"{template.filename}, line {int(template.current_line)}: {msg}"
                    )
        finally:
            template.close()

    def prune_file_list(self) -> None:
        """Prune off branches that might slip into the file list as created
        by 'read_template()', but really don't belong there:
          * the build tree (typically "build")
          * the release tree itself (only an issue if we ran "sdist"
            previously with --keep-temp, or it aborted)
          * any RCS, CVS, .svn, .hg, .git, .bzr, _darcs directories
        """
        build = self.get_finalized_command('build')
        base_dir = self.distribution.get_fullname()

        self.filelist.exclude_pattern(None, prefix=os.fspath(build.build_base))
        self.filelist.exclude_pattern(None, prefix=base_dir)

        if sys.platform == 'win32':
            seps = r'/|\\'
        else:
            seps = '/'

        vcs_dirs = ['RCS', 'CVS', r'\.svn', r'\.hg', r'\.git', r'\.bzr', '_darcs']
        vcs_ptrn = r'(^|{})({})({}).*'.format(seps, '|'.join(vcs_dirs), seps)
        self.filelist.exclude_pattern(vcs_ptrn, is_regex=True)

    def write_manifest(self) -> None:
        """Write the file list in 'self.filelist' (presumably as filled in
        by 'add_defaults()' and 'read_template()') to the manifest file
        named by 'self.manifest'.
        """
        if self._manifest_is_not_generated():
            log.info(
                f"not writing to manually maintained manifest file '{self.manifest}'"
            )
            return

        content = self.filelist.files[:]
        content.insert(0, '# file GENERATED by distutils, do NOT edit')
        self.execute(
            file_util.write_file,
            (self.manifest, content),
            f"writing manifest file '{self.manifest}'",
        )

    def _manifest_is_not_generated(self):
        # check for special comment used in 3.1.3 and higher
        if not os.path.isfile(self.manifest):
            return False

        with open(self.manifest, encoding='utf-8') as fp:
            first_line = next(fp)
        return first_line != '# file GENERATED by distutils, do NOT edit\n'

    def read_manifest(self) -> None:
        """Read the manifest file (named by 'self.manifest') and use it to
        fill in 'self.filelist', the list of files to include in the source
        distribution.
        """
        log.info("reading manifest file '%s'", self.manifest)
        with open(self.manifest, encoding='utf-8') as lines:
            self.filelist.extend(
                # ignore comments and blank lines
                filter(None, filterfalse(is_comment, map(str.strip, lines)))
            )

    def make_release_tree(self, base_dir, files) -> None:
        """Create the directory tree that will become the source
        distribution archive.  All directories implied by the filenames in
        'files' are created under 'base_dir', and then we hard link or copy
        (if hard linking is unavailable) those files into place.
        Essentially, this duplicates the developer's source tree, but in a
        directory named after the distribution, containing only the files
        to be distributed.
        """
        # Create all the directories under 'base_dir' necessary to
        # put 'files' there; the 'mkpath()' is just so we don't die
        # if the manifest happens to be empty.
        self.mkpath(base_dir)
        dir_util.create_tree(base_dir, files, dry_run=self.dry_run)

        # And walk over the list of files, either making a hard link (if
        # os.link exists) to each one that doesn't already exist in its
        # corresponding location under 'base_dir', or copying each file
        # that's out-of-date in 'base_dir'.  (Usually, all files will be
        # out-of-date, because by default we blow away 'base_dir' when
        # we're done making the distribution archives.)

        if hasattr(os, 'link'):  # can make hard links on this system
            link = 'hard'
            msg = f"making hard links in {base_dir}..."
        else:  # nope, have to copy
            link = None
            msg = f"copying files to {base_dir}..."

        if not files:
            log.warning("no files to distribute -- empty manifest?")
        else:
            log.info(msg)
        for file in files:
            if not os.path.isfile(file):
                log.warning("'%s' not a regular file -- skipping", file)
            else:
                dest = os.path.join(base_dir, file)
                self.copy_file(file, dest, link=link)

        self.distribution.metadata.write_pkg_info(base_dir)

    def make_distribution(self) -> None:
        """Create the source distribution(s).  First, we create the release
        tree with 'make_release_tree()'; then, we create all required
        archive files (according to 'self.formats') from the release tree.
        Finally, we clean up by blowing away the release tree (unless
        'self.keep_temp' is true).  The list of archive files created is
        stored so it can be retrieved later by 'get_archive_files()'.
        """
        # Don't warn about missing meta-data here -- should be (and is!)
        # done elsewhere.
        base_dir = self.distribution.get_fullname()
        base_name = os.path.join(self.dist_dir, base_dir)

        self.make_release_tree(base_dir, self.filelist.files)
        archive_files = []  # remember names of files we create
        # tar archive must be created last to avoid overwrite and remove
        if 'tar' in self.formats:
            self.formats.append(self.formats.pop(self.formats.index('tar')))

        for fmt in self.formats:
            file = self.make_archive(
                base_name, fmt, base_dir=base_dir, owner=self.owner, group=self.group
            )
            archive_files.append(file)
            self.distribution.dist_files.append(('sdist', '', file))

        self.archive_files = archive_files

        if not self.keep_temp:
            dir_util.remove_tree(base_dir, dry_run=self.dry_run)

    def get_archive_files(self):
        """Return the list of archive files created when the command
        was run, or None if the command hasn't run yet.
        """
        return self.archive_files


def is_comment(line: str) -> bool:
    return line.startswith('#')

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/sdist.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 544 2025-06-01 01:29:37.143978123 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/__init__.cpython-312.pyc
f7c10ca1e62747e109dfc2270639ff572cb68325e99acded30b814fc3b427c79  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 82 01 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 10 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  67 00 64 01 a2 01 5a 01  79 02 29 03 7a 5c 64 69  |g.d...Z.y.).z\di|
00000040  73 74 75 74 69 6c 73 2e  63 6f 6d 6d 61 6e 64 0a  |stutils.command.|
00000050  0a 50 61 63 6b 61 67 65  20 63 6f 6e 74 61 69 6e  |.Package contain|
00000060  69 6e 67 20 69 6d 70 6c  65 6d 65 6e 74 61 74 69  |ing implementati|
00000070  6f 6e 20 6f 66 20 61 6c  6c 20 74 68 65 20 73 74  |on of all the st|
00000080  61 6e 64 61 72 64 20 44  69 73 74 75 74 69 6c 73  |andard Distutils|
00000090  0a 63 6f 6d 6d 61 6e 64  73 2e 29 10 da 05 62 75  |.commands.)...bu|
000000a0  69 6c 64 da 08 62 75 69  6c 64 5f 70 79 da 09 62  |ild..build_py..b|
000000b0  75 69 6c 64 5f 65 78 74  da 0a 62 75 69 6c 64 5f  |uild_ext..build_|
000000c0  63 6c 69 62 da 0d 62 75  69 6c 64 5f 73 63 72 69  |clib..build_scri|
000000d0  70 74 73 da 05 63 6c 65  61 6e da 07 69 6e 73 74  |pts..clean..inst|
000000e0  61 6c 6c da 0b 69 6e 73  74 61 6c 6c 5f 6c 69 62  |all..install_lib|
000000f0  da 0f 69 6e 73 74 61 6c  6c 5f 68 65 61 64 65 72  |..install_header|
00000100  73 da 0f 69 6e 73 74 61  6c 6c 5f 73 63 72 69 70  |s..install_scrip|
00000110  74 73 da 0c 69 6e 73 74  61 6c 6c 5f 64 61 74 61  |ts..install_data|
00000120  da 05 73 64 69 73 74 da  05 62 64 69 73 74 da 0a  |..sdist..bdist..|
00000130  62 64 69 73 74 5f 64 75  6d 62 da 09 62 64 69 73  |bdist_dumb..bdis|
00000140  74 5f 72 70 6d da 05 63  68 65 63 6b 4e 29 02 da  |t_rpm..checkN)..|
00000150  07 5f 5f 64 6f 63 5f 5f  da 07 5f 5f 61 6c 6c 5f  |.__doc__..__all_|
00000160  5f a9 00 f3 00 00 00 00  fa 88 2f 64 61 74 61 2f  |_........./data/|
00000170  64 61 74 61 2f 63 6f 6d  2e 74 65 72 6d 75 78 2f  |data/com.termux/|
00000180  66 69 6c 65 73 2f 68 6f  6d 65 2f 52 41 46 41 45  |files/home/RAFAE|
00000190  4c 49 41 2f 48 43 50 4d  2f 43 4f 52 45 2f 76 65  |LIA/HCPM/CORE/ve|
000001a0  6e 76 5f 72 61 66 61 65  6c 69 61 2f 6c 69 62 2f  |nv_rafaelia/lib/|
000001b0  70 79 74 68 6f 6e 33 2e  31 32 2f 73 69 74 65 2d  |python3.12/site-|
000001c0  70 61 63 6b 61 67 65 73  2f 73 65 74 75 70 74 6f  |packages/setupto|
000001d0  6f 6c 73 2f 5f 64 69 73  74 75 74 69 6c 73 2f 63  |ols/_distutils/c|
000001e0  6f 6d 6d 61 6e 64 2f 5f  5f 69 6e 69 74 5f 5f 2e  |ommand/__init__.|
000001f0  70 79 da 08 3c 6d 6f 64  75 6c 65 3e 72 17 00 00  |py..<module>r...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/_framework_compat.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.6K 2025-06-01 01:29:37.307978123 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/_framework_compat.cpython-312.pyc
28c891b22477141d639f2746c8d1bf4092340d62cf2b1a52d4dd30067e5b7f58  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/_framework_compat.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 49 06 00 00  |..........8hI...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0c 00 00  |................|
00000020  00 00 00 00 00 f3 ac 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  65 01 6a 0c 00 00 00 00  |d.d.l.Z.e.j.....|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 03  |..............d.|
00000070  84 00 ab 00 00 00 00 00  00 00 5a 07 02 00 65 08  |..........Z...e.|
00000080  02 00 65 08 64 04 64 05  64 06 64 07 64 08 64 09  |..e.d.d.d.d.d.d.|
00000090  64 0a 64 0b ac 0c ab 08  00 00 00 00 00 00 ac 0d  |d.d.............|
000000a0  ab 01 00 00 00 00 00 00  5a 09 65 01 6a 0c 00 00  |........Z.e.j...|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  64 0e 84 00 ab 00 00 00  00 00 00 00 5a 0a 64 0f  |d...........Z.d.|
000000d0  84 00 5a 0b 79 02 29 10  7a 36 0a 42 61 63 6b 77  |..Z.y.).z6.Backw|
000000e0  61 72 64 20 63 6f 6d 70  61 74 69 62 69 6c 69 74  |ard compatibilit|
000000f0  79 20 66 6f 72 20 68 6f  6d 65 62 72 65 77 20 62  |y for homebrew b|
00000100  75 69 6c 64 73 20 6f 6e  20 6d 61 63 4f 53 2e 0a  |uilds on macOS..|
00000110  e9 00 00 00 00 4e 63 00  00 00 00 00 00 00 00 00  |.....Nc.........|
00000120  00 00 00 04 00 00 00 03  00 00 00 f3 5e 01 00 00  |............^...|
00000130  97 00 64 01 74 00 00 00  00 00 00 00 00 00 6a 02  |..d.t.........j.|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  00 00 63 02 78 02 6b 02  00 00 78 01 72 05 01 00  |..c.x.k...x.r...|
00000160  64 02 6b 02 00 00 6e 02  63 02 01 00 7d 00 74 00  |d.k...n.c...}.t.|
00000170  00 00 00 00 00 00 00 00  6a 04 00 00 00 00 00 00  |........j.......|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 64 03 6b 28  |............d.k(|
00000190  00 00 78 01 72 10 01 00  74 00 00 00 00 00 00 00  |..x.r...t.......|
000001a0  00 00 6a 06 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
000001b0  00 00 00 00 00 00 7d 01  64 04 74 09 00 00 00 00  |......}.d.t.....|
000001c0  00 00 00 00 6a 0a 00 00  00 00 00 00 00 00 00 00  |....j...........|
000001d0  00 00 00 00 00 00 00 00  64 05 ab 01 00 00 00 00  |........d.......|
000001e0  00 00 76 00 7d 02 74 00  00 00 00 00 00 00 00 00  |..v.}.t.........|
000001f0  6a 0c 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/_framework_compat.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.4K 2025-06-01 01:29:37.467978123 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist.cpython-312.pyc
0be83ea8de8b42d07daa288b7f11175fee34e887e0406e7e41754282f04a1d2b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 de 16 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 01 f3 c6 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 04  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 6d 09 5a 09 01 00  64 06 64 07 6c 0a 6d 0b  |Z.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 06 64 08  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 01 00 64 06 64 09  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  65 08 72 07 64 01 64 0a  6c 11 6d 12 5a 12 01 00  |e.r.d.d.l.m.Z...|
000000a0  6e 03 64 0b 84 00 5a 12  64 0c 84 00 5a 13 02 00  |n.d...Z.d...Z...|
000000b0  47 00 64 0d 84 00 64 0e  65 14 65 15 65 16 65 15  |G.d...d.e.e.e.e.|
000000c0  65 15 66 02 19 00 00 00  66 02 19 00 00 00 ab 03  |e.f.....f.......|
000000d0  00 00 00 00 00 00 5a 17  02 00 47 00 64 0f 84 00  |......Z...G.d...|
000000e0  64 10 65 0b ab 03 00 00  00 00 00 00 5a 18 79 03  |d.e.........Z.y.|
000000f0  29 11 7a 69 64 69 73 74  75 74 69 6c 73 2e 63 6f  |).zidistutils.co|
00000100  6d 6d 61 6e 64 2e 62 64  69 73 74 0a 0a 49 6d 70  |mmand.bdist..Imp|
00000110  6c 65 6d 65 6e 74 73 20  74 68 65 20 44 69 73 74  |lements the Dist|
00000120  75 74 69 6c 73 20 27 62  64 69 73 74 27 20 63 6f  |utils 'bdist' co|
00000130  6d 6d 61 6e 64 20 28 63  72 65 61 74 65 20 61 20  |mmand (create a |
00000140  62 75 69 6c 74 20 5b 62  69 6e 61 72 79 5d 0a 64  |built [binary].d|
00000150  69 73 74 72 69 62 75 74  69 6f 6e 29 2e e9 00 00  |istribution)....|
00000160  00 00 29 01 da 0b 61 6e  6e 6f 74 61 74 69 6f 6e  |..)...annotation|
00000170  73 4e 29 01 da 08 43 61  6c 6c 61 62 6c 65 29 02  |sN)...Callable).|
00000180  da 0d 54 59 50 45 5f 43  48 45 43 4b 49 4e 47 da  |..TYPE_CHECKING.|
00000190  08 43 6c 61 73 73 56 61  72 e9 02 00 00 00 29 01  |.ClassVar.....).|
000001a0  da 07 43 6f 6d 6d 61 6e  64 29 02 da 14 44 69 73  |..Command)...Dis|
000001b0  74 75 74 69 6c 73 4f 70  74 69 6f 6e 45 72 72 6f  |tutilsOptionErro|
000001c0  72 da 16 44 69 73 74 75  74 69 6c 73 50 6c 61 74  |r..DistutilsPlat|
000001d0  66 6f 72 6d 45 72 72 6f  72 29 01 da 0c 67 65 74  |formError)...get|
000001e0  5f 70 6c 61 74 66 6f 72  6d 29 01 da 0a 64 65 70  |_platform)...dep|
000001f0  72 65 63 61 74 65 64 63  01 00 00 00 00 00 00 00  |recatedc........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_dumb.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.5K 2025-06-01 01:29:37.631978123 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_dumb.cpython-312.pyc
7ad054d155bd51b47cbbb5875d38101134d9ff4ec55e11e63ad266c456b04ad0  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_dumb.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 17 12 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 7e 00  00 00 97 00 64 00 5a 00  |......~.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 05 64 06 6c 06 6d 07  5a 07 01 00 64 05 64 07  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 6d 0a  5a 0a 01 00 64 05 64 08  |l.m.Z.m.Z...d.d.|
00000070  6c 0b 6d 0c 5a 0c 01 00  64 05 64 09 6c 0d 6d 0e  |l.m.Z...d.d.l.m.|
00000080  5a 0e 01 00 64 05 64 0a  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  02 00 47 00 64 0b 84 00  64 0c 65 07 ab 03 00 00  |..G.d...d.e.....|
000000a0  00 00 00 00 5a 11 79 02  29 0d 7a b7 64 69 73 74  |....Z.y.).z.dist|
000000b0  75 74 69 6c 73 2e 63 6f  6d 6d 61 6e 64 2e 62 64  |utils.command.bd|
000000c0  69 73 74 5f 64 75 6d 62  0a 0a 49 6d 70 6c 65 6d  |ist_dumb..Implem|
000000d0  65 6e 74 73 20 74 68 65  20 44 69 73 74 75 74 69  |ents the Distuti|
000000e0  6c 73 20 27 62 64 69 73  74 5f 64 75 6d 62 27 20  |ls 'bdist_dumb' |
000000f0  63 6f 6d 6d 61 6e 64 20  28 63 72 65 61 74 65 20  |command (create |
00000100  61 20 22 64 75 6d 62 22  20 62 75 69 6c 74 0a 64  |a "dumb" built.d|
00000110  69 73 74 72 69 62 75 74  69 6f 6e 20 2d 2d 20 69  |istribution -- i|
00000120  2e 65 2e 2c 20 6a 75 73  74 20 61 6e 20 61 72 63  |.e., just an arc|
00000130  68 69 76 65 20 74 6f 20  62 65 20 75 6e 70 61 63  |hive to be unpac|
00000140  6b 65 64 20 75 6e 64 65  72 20 24 70 72 65 66 69  |ked under $prefi|
00000150  78 20 6f 72 0a 24 65 78  65 63 5f 70 72 65 66 69  |x or.$exec_prefi|
00000160  78 29 2e e9 00 00 00 00  4e 29 01 da 03 6c 6f 67  |x)......N)...log|
00000170  29 01 da 08 43 6c 61 73  73 56 61 72 e9 02 00 00  |)...ClassVar....|
00000180  00 29 01 da 07 43 6f 6d  6d 61 6e 64 29 02 da 0f  |.)...Command)...|
00000190  65 6e 73 75 72 65 5f 72  65 6c 61 74 69 76 65 da  |ensure_relative.|
000001a0  0b 72 65 6d 6f 76 65 5f  74 72 65 65 29 01 da 16  |.remove_tree)...|
000001b0  44 69 73 74 75 74 69 6c  73 50 6c 61 74 66 6f 72  |DistutilsPlatfor|
000001c0  6d 45 72 72 6f 72 29 01  da 12 67 65 74 5f 70 79  |mError)...get_py|
000001d0  74 68 6f 6e 5f 76 65 72  73 69 6f 6e 29 01 da 0c  |thon_version)...|
000001e0  67 65 74 5f 70 6c 61 74  66 6f 72 6d 63 00 00 00  |get_platformc...|
000001f0  00 00 00 00 00 00 00 00  00 09 00 00 00 00 00 00  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_dumb.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_rpm.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 22K 2025-06-01 01:29:37.799978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_rpm.cpython-312.pyc
53c5cb9b7c6355f9514c7213e88aa1c6baf8143c9abf673207478c27e7770aee  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_rpm.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 19 55 00 00  |..........8h.U..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 96 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 05 64 06 6c 08 6d 09  5a 09 01 00 64 05 64 07  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 01 00  64 05 64 08 6c 0c 6d 0d  |l.m.Z...d.d.l.m.|
00000080  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 6d 10 5a 10 01 00  |Z.m.Z.m.Z.m.Z...|
00000090  64 05 64 09 6c 11 6d 12  5a 12 01 00 64 05 64 0a  |d.d.l.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 01 00  02 00 47 00 64 0b 84 00  |l.m.Z.....G.d...|
000000b0  64 0c 65 09 ab 03 00 00  00 00 00 00 5a 15 79 02  |d.e.........Z.y.|
000000c0  29 0d 7a 77 64 69 73 74  75 74 69 6c 73 2e 63 6f  |).zwdistutils.co|
000000d0  6d 6d 61 6e 64 2e 62 64  69 73 74 5f 72 70 6d 0a  |mmand.bdist_rpm.|
000000e0  0a 49 6d 70 6c 65 6d 65  6e 74 73 20 74 68 65 20  |.Implements the |
000000f0  44 69 73 74 75 74 69 6c  73 20 27 62 64 69 73 74  |Distutils 'bdist|
00000100  5f 72 70 6d 27 20 63 6f  6d 6d 61 6e 64 20 28 63  |_rpm' command (c|
00000110  72 65 61 74 65 20 52 50  4d 20 73 6f 75 72 63 65  |reate RPM source|
00000120  20 61 6e 64 20 62 69 6e  61 72 79 0a 64 69 73 74  | and binary.dist|
00000130  72 69 62 75 74 69 6f 6e  73 29 2e e9 00 00 00 00  |ributions)......|
00000140  4e 29 01 da 03 6c 6f 67  29 01 da 08 43 6c 61 73  |N)...log)...Clas|
00000150  73 56 61 72 e9 02 00 00  00 29 01 da 07 43 6f 6d  |sVar.....)...Com|
00000160  6d 61 6e 64 29 01 da 05  44 45 42 55 47 29 04 da  |mand)...DEBUG)..|
00000170  12 44 69 73 74 75 74 69  6c 73 45 78 65 63 45 72  |.DistutilsExecEr|
00000180  72 6f 72 da 12 44 69 73  74 75 74 69 6c 73 46 69  |ror..DistutilsFi|
00000190  6c 65 45 72 72 6f 72 da  14 44 69 73 74 75 74 69  |leError..Distuti|
000001a0  6c 73 4f 70 74 69 6f 6e  45 72 72 6f 72 da 16 44  |lsOptionError..D|
000001b0  69 73 74 75 74 69 6c 73  50 6c 61 74 66 6f 72 6d  |istutilsPlatform|
000001c0  45 72 72 6f 72 29 01 da  0a 77 72 69 74 65 5f 66  |Error)...write_f|
000001d0  69 6c 65 29 01 da 12 67  65 74 5f 70 79 74 68 6f  |ile)...get_pytho|
000001e0  6e 5f 76 65 72 73 69 6f  6e 63 00 00 00 00 00 00  |n_versionc......|
000001f0  00 00 00 00 00 00 04 00  00 00 00 00 00 00 f3 8e  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/bdist_rpm.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.2K 2025-06-01 01:29:37.951978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build.cpython-312.pyc
6db806aece37e39536ff62c3282eb3db762983a63b98217d331c673f80c07247  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 23 17 00 00  |..........8h#...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 8a 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 01 64 04  6c 06 6d 07 5a 07 01 00  |l.Z.d.d.l.m.Z...|
00000060  64 01 64 05 6c 08 6d 09  5a 09 01 00 64 06 64 07  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 01 00  64 06 64 08 6c 0c 6d 0d  |l.m.Z...d.d.l.m.|
00000080  5a 0d 01 00 64 06 64 09  6c 0e 6d 0f 5a 0f 01 00  |Z...d.d.l.m.Z...|
00000090  64 06 64 0a 6c 10 6d 11  5a 11 01 00 02 00 47 00  |d.d.l.m.Z.....G.|
000000a0  64 0b 84 00 64 0c 65 0d  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000b0  5a 12 79 03 29 0d 7a 42  64 69 73 74 75 74 69 6c  |Z.y.).zBdistutil|
000000c0  73 2e 63 6f 6d 6d 61 6e  64 2e 62 75 69 6c 64 0a  |s.command.build.|
000000d0  0a 49 6d 70 6c 65 6d 65  6e 74 73 20 74 68 65 20  |.Implements the |
000000e0  44 69 73 74 75 74 69 6c  73 20 27 62 75 69 6c 64  |Distutils 'build|
000000f0  27 20 63 6f 6d 6d 61 6e  64 2e e9 00 00 00 00 29  |' command......)|
00000100  01 da 0b 61 6e 6e 6f 74  61 74 69 6f 6e 73 4e 29  |...annotationsN)|
00000110  01 da 08 43 61 6c 6c 61  62 6c 65 29 01 da 08 43  |...Callable)...C|
00000120  6c 61 73 73 56 61 72 e9  02 00 00 00 29 01 da 0e  |lassVar.....)...|
00000130  73 68 6f 77 5f 63 6f 6d  70 69 6c 65 72 73 29 01  |show_compilers).|
00000140  da 07 43 6f 6d 6d 61 6e  64 29 01 da 14 44 69 73  |..Command)...Dis|
00000150  74 75 74 69 6c 73 4f 70  74 69 6f 6e 45 72 72 6f  |tutilsOptionErro|
00000160  72 29 01 da 0c 67 65 74  5f 70 6c 61 74 66 6f 72  |r)...get_platfor|
00000170  6d 63 00 00 00 00 00 00  00 00 00 00 00 00 0c 00  |mc..............|
00000180  00 00 00 00 00 01 f3 ba  00 00 00 97 00 65 00 5a  |.............e.Z|
00000190  01 64 00 5a 02 55 00 64  01 5a 03 64 02 64 03 64  |.d.Z.U.d.Z.d.d.d|
000001a0  04 64 05 64 06 64 07 64  08 64 09 64 0a 02 00 65  |.d.d.d.d.d.d...e|
000001b0  04 ab 00 00 00 00 00 00  00 9b 00 64 0b 9d 03 66  |...........d...f|
000001c0  03 64 0c 64 0d 64 0e 64  0f 64 10 67 0c 5a 05 64  |.d.d.d.d.d.g.Z.d|
000001d0  11 64 12 67 02 5a 06 64  13 65 07 64 14 3c 00 00  |.d.g.Z.d.e.d.<..|
000001e0  00 64 15 64 16 64 17 65  08 66 04 67 01 5a 09 64  |.d.d.d.e.f.g.Z.d|
000001f0  18 65 07 64 19 3c 00 00  00 64 1a 84 00 5a 0a 64  |.e.d.<...d...Z.d|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_clib.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.5K 2025-06-01 01:29:38.111978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_clib.cpython-312.pyc
33280630059ebf2e8bfd7bed93709a1a0b982897f59d5b7d3059cec109f3e240  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_clib.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 61 1e 00 00  |..........8ha...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 8a 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 04  6c 04 6d 05 5a 05 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 01 64 05 6c 06 6d 07  5a 07 01 00 64 01 64 06  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 07 64 08 6c 0a 6d 0b  |l.m.Z...d.d.l.m.|
00000070  5a 0b 6d 0c 5a 0c 01 00  64 07 64 09 6c 0d 6d 0e  |Z.m.Z...d.d.l.m.|
00000080  5a 0e 01 00 64 07 64 0a  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  64 07 64 0b 6c 11 6d 12  5a 12 01 00 02 00 47 00  |d.d.l.m.Z.....G.|
000000a0  64 0c 84 00 64 0d 65 0e  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000b0  5a 13 79 03 29 0e 7a b4  64 69 73 74 75 74 69 6c  |Z.y.).z.distutil|
000000c0  73 2e 63 6f 6d 6d 61 6e  64 2e 62 75 69 6c 64 5f  |s.command.build_|
000000d0  63 6c 69 62 0a 0a 49 6d  70 6c 65 6d 65 6e 74 73  |clib..Implements|
000000e0  20 74 68 65 20 44 69 73  74 75 74 69 6c 73 20 27  | the Distutils '|
000000f0  62 75 69 6c 64 5f 63 6c  69 62 27 20 63 6f 6d 6d  |build_clib' comm|
00000100  61 6e 64 2c 20 74 6f 20  62 75 69 6c 64 20 61 20  |and, to build a |
00000110  43 2f 43 2b 2b 20 6c 69  62 72 61 72 79 0a 74 68  |C/C++ library.th|
00000120  61 74 20 69 73 20 69 6e  63 6c 75 64 65 64 20 69  |at is included i|
00000130  6e 20 74 68 65 20 6d 6f  64 75 6c 65 20 64 69 73  |n the module dis|
00000140  74 72 69 62 75 74 69 6f  6e 20 61 6e 64 20 6e 65  |tribution and ne|
00000150  65 64 65 64 20 62 79 20  61 6e 20 65 78 74 65 6e  |eded by an exten|
00000160  73 69 6f 6e 0a 6d 6f 64  75 6c 65 2e e9 00 00 00  |sion.module.....|
00000170  00 29 01 da 0b 61 6e 6e  6f 74 61 74 69 6f 6e 73  |.)...annotations|
00000180  4e 29 01 da 08 43 61 6c  6c 61 62 6c 65 29 01 da  |N)...Callable)..|
00000190  03 6c 6f 67 29 01 da 08  43 6c 61 73 73 56 61 72  |.log)...ClassVar|
000001a0  e9 02 00 00 00 29 02 da  0c 6e 65 77 5f 63 6f 6d  |.....)...new_com|
000001b0  70 69 6c 65 72 da 0e 73  68 6f 77 5f 63 6f 6d 70  |piler..show_comp|
000001c0  69 6c 65 72 73 29 01 da  07 43 6f 6d 6d 61 6e 64  |ilers)...Command|
000001d0  29 01 da 13 44 69 73 74  75 74 69 6c 73 53 65 74  |)...DistutilsSet|
000001e0  75 70 45 72 72 6f 72 29  01 da 12 63 75 73 74 6f  |upError)...custo|
000001f0  6d 69 7a 65 5f 63 6f 6d  70 69 6c 65 72 63 00 00  |mize_compilerc..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_clib.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_ext.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 30K 2025-06-01 01:29:38.287978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_ext.cpython-312.pyc
c15a0631140ad0fa397302418019d97b9676e3e7aa5a00fea6667d28ba1281e3  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_ext.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 c6 7f 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 1a 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 01 64 03  6c 06 5a 06 64 01 64 04  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 6d 08 5a 08 01 00  64 01 64 05 6c 09 6d 0a  |l.m.Z...d.d.l.m.|
00000070  5a 0a 01 00 64 01 64 06  6c 0b 6d 0c 5a 0c 01 00  |Z...d.d.l.m.Z...|
00000080  64 01 64 07 6c 0d 6d 0e  5a 0e 01 00 64 08 64 09  |d.d.l.m.Z...d.d.|
00000090  6c 0f 6d 10 5a 10 01 00  64 08 64 0a 6c 11 6d 12  |l.m.Z...d.d.l.m.|
000000a0  5a 12 6d 13 5a 13 01 00  64 08 64 0b 6c 14 6d 15  |Z.m.Z...d.d.l.m.|
000000b0  5a 15 01 00 64 08 64 0c  6c 16 6d 17 5a 17 6d 18  |Z...d.d.l.m.Z.m.|
000000c0  5a 18 6d 19 5a 19 6d 1a  5a 1a 6d 1b 5a 1b 6d 1c  |Z.m.Z.m.Z.m.Z.m.|
000000d0  5a 1c 01 00 64 08 64 0d  6c 1d 6d 1e 5a 1e 01 00  |Z...d.d.l.m.Z...|
000000e0  64 08 64 0e 6c 1f 6d 20  5a 20 6d 21 5a 21 6d 22  |d.d.l.m Z m!Z!m"|
000000f0  5a 22 01 00 64 08 64 0f  6c 23 6d 24 5a 24 6d 25  |Z"..d.d.l#m$Z$m%|
00000100  5a 25 6d 26 5a 26 01 00  02 00 65 05 6a 4e 00 00  |Z%m&Z&....e.jN..|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000120  64 10 ab 01 00 00 00 00  00 00 5a 28 02 00 47 00  |d.........Z(..G.|
00000130  64 11 84 00 64 12 65 15  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000140  5a 29 79 03 29 13 7a b6  64 69 73 74 75 74 69 6c  |Z)y.).z.distutil|
00000150  73 2e 63 6f 6d 6d 61 6e  64 2e 62 75 69 6c 64 5f  |s.command.build_|
00000160  65 78 74 0a 0a 49 6d 70  6c 65 6d 65 6e 74 73 20  |ext..Implements |
00000170  74 68 65 20 44 69 73 74  75 74 69 6c 73 20 27 62  |the Distutils 'b|
00000180  75 69 6c 64 5f 65 78 74  27 20 63 6f 6d 6d 61 6e  |uild_ext' comman|
00000190  64 2c 20 66 6f 72 20 62  75 69 6c 64 69 6e 67 20  |d, for building |
000001a0  65 78 74 65 6e 73 69 6f  6e 0a 6d 6f 64 75 6c 65  |extension.module|
000001b0  73 20 28 63 75 72 72 65  6e 74 6c 79 20 6c 69 6d  |s (currently lim|
000001c0  69 74 65 64 20 74 6f 20  43 20 65 78 74 65 6e 73  |ited to C extens|
000001d0  69 6f 6e 73 2c 20 73 68  6f 75 6c 64 20 61 63 63  |ions, should acc|
000001e0  6f 6d 6d 6f 64 61 74 65  20 43 2b 2b 0a 65 78 74  |ommodate C++.ext|
000001f0  65 6e 73 69 6f 6e 73 20  41 53 41 50 29 2e e9 00  |ensions ASAP)...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_ext.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_py.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 16K 2025-06-01 01:29:38.459978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_py.cpython-312.pyc
5f8c5933502f8f22124663112aa35ac6c822756f464d97ccd2dbb4d59783763e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_py.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 38 41 00 00  |..........8h8A..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 7e 00  00 00 97 00 64 00 5a 00  |......~.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 03  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 04 5a 04  64 01 64 02 6c 05 5a 05  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 03 6c 06 6d 07  5a 07 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 05 64 06 6c 0a 6d 0b  |l.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 05 64 07  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 01 00 64 05 64 08  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  02 00 47 00 64 09 84 00  64 0a 65 0b ab 03 00 00  |..G.d...d.e.....|
000000a0  00 00 00 00 5a 11 79 02  29 0b 7a 48 64 69 73 74  |....Z.y.).zHdist|
000000b0  75 74 69 6c 73 2e 63 6f  6d 6d 61 6e 64 2e 62 75  |utils.command.bu|
000000c0  69 6c 64 5f 70 79 0a 0a  49 6d 70 6c 65 6d 65 6e  |ild_py..Implemen|
000000d0  74 73 20 74 68 65 20 44  69 73 74 75 74 69 6c 73  |ts the Distutils|
000000e0  20 27 62 75 69 6c 64 5f  70 79 27 20 63 6f 6d 6d  | 'build_py' comm|
000000f0  61 6e 64 2e e9 00 00 00  00 4e 29 01 da 03 6c 6f  |and......N)...lo|
00000100  67 29 01 da 08 43 6c 61  73 73 56 61 72 e9 02 00  |g)...ClassVar...|
00000110  00 00 29 01 da 07 43 6f  6d 6d 61 6e 64 29 02 da  |..)...Command)..|
00000120  12 44 69 73 74 75 74 69  6c 73 46 69 6c 65 45 72  |.DistutilsFileEr|
00000130  72 6f 72 da 14 44 69 73  74 75 74 69 6c 73 4f 70  |ror..DistutilsOp|
00000140  74 69 6f 6e 45 72 72 6f  72 29 01 da 0c 63 6f 6e  |tionError)...con|
00000150  76 65 72 74 5f 70 61 74  68 63 00 00 00 00 00 00  |vert_pathc......|
00000160  00 00 00 00 00 00 06 00  00 00 00 00 00 00 f3 ea  |................|
00000170  00 00 00 97 00 65 00 5a  01 64 00 5a 02 55 00 64  |.....e.Z.d.Z.U.d|
00000180  01 5a 03 67 00 64 02 a2  01 5a 04 64 03 64 04 67  |.Z.g.d...Z.d.d.g|
00000190  02 5a 05 65 06 65 07 65  08 19 00 00 00 19 00 00  |.Z.e.e.e........|
000001a0  00 65 09 64 05 3c 00 00  00 64 06 64 03 69 01 5a  |.e.d.<...d.d.i.Z|
000001b0  0a 65 06 65 0b 65 08 65  08 66 02 19 00 00 00 19  |.e.e.e.e.f......|
000001c0  00 00 00 65 09 64 07 3c  00 00 00 64 08 84 00 5a  |...e.d.<...d...Z|
000001d0  0c 64 1e 64 0b 84 04 5a  0d 64 1e 64 0c 84 04 5a  |.d.d...Z.d.d...Z|
000001e0  0e 64 0d 84 00 5a 0f 64  0e 84 00 5a 10 64 1e 64  |.d...Z.d...Z.d.d|
000001f0  0f 84 04 5a 11 64 10 84  00 5a 12 64 11 84 00 5a  |...Z.d...Z.d...Z|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_py.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_scripts.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.7K 2025-06-01 01:29:38.623978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_scripts.cpython-312.pyc
0de507ab510e592c419912fb6d0e2646d4489807b070e9756dc945adb1eb55a1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_scripts.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 0f 14 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 a8 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 01 64 05 6c 08 6d 09  5a 09 01 00 64 06 64 07  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 01 00  64 06 64 08 6c 0c 6d 0d  |l.m.Z...d.d.l.m.|
00000080  5a 0d 01 00 64 06 64 09  6c 0e 6d 0f 5a 0f 01 00  |Z...d.d.l.m.Z...|
00000090  02 00 65 02 6a 20 00 00  00 00 00 00 00 00 00 00  |..e.j ..........|
000000a0  00 00 00 00 00 00 00 00  64 0a ab 01 00 00 00 00  |........d.......|
000000b0  00 00 5a 11 09 00 65 11  5a 12 02 00 47 00 64 0b  |..Z...e.Z...G.d.|
000000c0  84 00 64 0c 65 0d ab 03  00 00 00 00 00 00 5a 13  |..d.e.........Z.|
000000d0  79 02 29 0d 7a 52 64 69  73 74 75 74 69 6c 73 2e  |y.).zRdistutils.|
000000e0  63 6f 6d 6d 61 6e 64 2e  62 75 69 6c 64 5f 73 63  |command.build_sc|
000000f0  72 69 70 74 73 0a 0a 49  6d 70 6c 65 6d 65 6e 74  |ripts..Implement|
00000100  73 20 74 68 65 20 44 69  73 74 75 74 69 6c 73 20  |s the Distutils |
00000110  27 62 75 69 6c 64 5f 73  63 72 69 70 74 73 27 20  |'build_scripts' |
00000120  63 6f 6d 6d 61 6e 64 2e  e9 00 00 00 00 4e 29 01  |command......N).|
00000130  da 03 6c 6f 67 29 01 da  07 53 54 5f 4d 4f 44 45  |..log)...ST_MODE|
00000140  29 01 da 08 43 6c 61 73  73 56 61 72 e9 02 00 00  |)...ClassVar....|
00000150  00 29 01 da 05 6e 65 77  65 72 29 01 da 07 43 6f  |.)...newer)...Co|
00000160  6d 6d 61 6e 64 29 01 da  0c 63 6f 6e 76 65 72 74  |mmand)...convert|
00000170  5f 70 61 74 68 7a 1c 5e  23 21 2e 2a 70 79 74 68  |_pathz.^#!.*pyth|
00000180  6f 6e 5b 30 2d 39 2e 5d  2a 28 5b 20 09 5d 2e 2a  |on[0-9.]*([ .].*|
00000190  29 3f 24 63 00 00 00 00  00 00 00 00 00 00 00 00  |)?$c............|
000001a0  06 00 00 00 00 00 00 00  f3 98 00 00 00 97 00 65  |...............e|
000001b0  00 5a 01 64 00 5a 02 55  00 64 01 5a 03 67 00 64  |.Z.d.Z.U.d.Z.g.d|
000001c0  02 a2 01 5a 04 65 05 65  06 65 07 65 08 65 08 65  |...Z.e.e.e.e.e.e|
000001d0  08 66 03 19 00 00 00 19  00 00 00 19 00 00 00 65  |.f.............e|
000001e0  09 64 03 3c 00 00 00 64  04 67 01 5a 0a 65 05 65  |.d.<...d.g.Z.e.e|
000001f0  06 65 08 19 00 00 00 19  00 00 00 65 09 64 05 3c  |.e.........e.d.<|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/build_scripts.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/check.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.1K 2025-06-01 01:29:38.783978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/check.cpython-312.pyc
06fc76cf15f8f1971a09d1b516897b407403c04cdd6ae779dc72a2e51afcb97d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/check.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 52 13 00 00  |..........8hR...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 f6 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 04 64 05  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 04 64 06 6c 06 6d 07  5a 07 01 00 02 00 65 01  |d.d.l.m.Z.....e.|
00000060  6a 10 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000070  00 00 00 00 65 09 ab 01  00 00 00 00 00 00 35 00  |....e.........5.|
00000080  01 00 64 01 64 02 6c 0a  5a 0b 64 01 64 02 6c 0c  |..d.d.l.Z.d.d.l.|
00000090  5a 0b 64 01 64 02 6c 0d  5a 0b 64 01 64 02 6c 0e  |Z.d.d.l.Z.d.d.l.|
000000a0  5a 0b 02 00 47 00 64 07  84 00 64 08 65 0b 6a 1e  |Z...G.d...d.e.j.|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  00 00 6a 20 00 00 00 00  00 00 00 00 00 00 00 00  |..j ............|
000000d0  00 00 00 00 00 00 ab 03  00 00 00 00 00 00 5a 11  |..............Z.|
000000e0  64 02 64 02 64 02 ab 02  00 00 00 00 00 00 01 00  |d.d.d...........|
000000f0  02 00 47 00 64 09 84 00  64 0a 65 05 ab 03 00 00  |..G.d...d.e.....|
00000100  00 00 00 00 5a 12 79 02  23 00 31 00 73 01 77 02  |....Z.y.#.1.s.w.|
00000110  01 00 59 00 01 00 01 00  8c 15 78 03 59 00 77 01  |..Y.......x.Y.w.|
00000120  29 0b 7a 43 64 69 73 74  75 74 69 6c 73 2e 63 6f  |).zCdistutils.co|
00000130  6d 6d 61 6e 64 2e 63 68  65 63 6b 0a 0a 49 6d 70  |mmand.check..Imp|
00000140  6c 65 6d 65 6e 74 73 20  74 68 65 20 44 69 73 74  |lements the Dist|
00000150  75 74 69 6c 73 20 27 63  68 65 63 6b 27 20 63 6f  |utils 'check' co|
00000160  6d 6d 61 6e 64 2e 0a e9  00 00 00 00 4e 29 01 da  |mmand.......N)..|
00000170  08 43 6c 61 73 73 56 61  72 e9 02 00 00 00 29 01  |.ClassVar.....).|
00000180  da 07 43 6f 6d 6d 61 6e  64 29 01 da 13 44 69 73  |..Command)...Dis|
00000190  74 75 74 69 6c 73 53 65  74 75 70 45 72 72 6f 72  |tutilsSetupError|
000001a0  63 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |c...............|
000001b0  00 00 00 00 00 f3 2e 00  00 00 87 00 97 00 65 00  |..............e.|
000001c0  5a 01 64 00 5a 02 09 00  09 00 09 00 09 00 64 03  |Z.d.Z.........d.|
000001d0  88 00 66 01 64 01 84 09  5a 03 64 02 84 00 5a 04  |..f.d...Z.d...Z.|
000001e0  88 00 78 01 5a 05 53 00  29 04 da 0e 53 69 6c 65  |..x.Z.S.)...Sile|
000001f0  6e 74 52 65 70 6f 72 74  65 72 63 08 00 00 00 00  |ntReporterc.....|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/check.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/clean.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.1K 2025-06-01 01:29:38.931978122 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/clean.cpython-312.pyc
298c47aa70e1a3efe27d11f7705134ce9ee5ffd58fcf6f797b39d5194270b457  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/command/__pycache__/clean.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 54 0a 00 00  |..........8hT...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 56 00  00 00 97 00 64 00 5a 00  |......V.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 05 64 06 6c 06 6d 07  5a 07 01 00 64 05 64 07  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  02 00 47 00 64 08 84 00  |l.m.Z.....G.d...|
00000070  64 09 65 07 ab 03 00 00  00 00 00 00 5a 0a 79 02  |d.e.........Z.y.|
00000080  29 0a 7a 42 64 69 73 74  75 74 69 6c 73 2e 63 6f  |).zBdistutils.co|
00000090  6d 6d 61 6e 64 2e 63 6c  65 61 6e 0a 0a 49 6d 70  |mmand.clean..Imp|
000000a0  6c 65 6d 65 6e 74 73 20  74 68 65 20 44 69 73 74  |lements the Dist|
000000b0  75 74 69 6c 73 20 27 63  6c 65 61 6e 27 20 63 6f  |utils 'clean' co|
000000c0  6d 6d 61 6e 64 2e e9 00  00 00 00 4e 29 01 da 03  |mmand......N)...|
000000d0  6c 6f 67 29 01 da 08 43  6c 61 73 73 56 61 72 e9  |log)...ClassVar.|
000000e0  02 00 00 00 29 01 da 07  43 6f 6d 6d 61 6e 64 29  |....)...Command)|
000000f0  01 da 0b 72 65 6d 6f 76  65 5f 74 72 65 65 63 00  |...remove_treec.|
00000100  00 00 00 00 00 00 00 00  00 00 00 03 00 00 00 00  |................|
00000110  00 00 00 f3 48 00 00 00  97 00 65 00 5a 01 64 00  |....H.....e.Z.d.|