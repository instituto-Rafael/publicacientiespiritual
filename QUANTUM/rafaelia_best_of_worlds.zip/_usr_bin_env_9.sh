#!/usr/bin/env python3
# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

from __future__ import annotations

import logging
import platform
import re
import struct
import subprocess
import sys
import sysconfig
from importlib.machinery import EXTENSION_SUFFIXES
from typing import (
    Iterable,
    Iterator,
    Sequence,
    Tuple,
    cast,
)

from . import _manylinux, _musllinux

logger = logging.getLogger(__name__)

PythonVersion = Sequence[int]
AppleVersion = Tuple[int, int]

INTERPRETER_SHORT_NAMES: dict[str, str] = {
    "python": "py",  # Generic.
    "cpython": "cp",
    "pypy": "pp",
    "ironpython": "ip",
    "jython": "jy",
}


_32_BIT_INTERPRETER = struct.calcsize("P") == 4


class Tag:
    """
    A representation of the tag triple for a wheel.

    Instances are considered immutable and thus are hashable. Equality checking
    is also supported.
    """

    __slots__ = ["_abi", "_hash", "_interpreter", "_platform"]

    def __init__(self, interpreter: str, abi: str, platform: str) -> None:
        self._interpreter = interpreter.lower()
        self._abi = abi.lower()
        self._platform = platform.lower()
        # The __hash__ of every single element in a Set[Tag] will be evaluated each time
        # that a set calls its `.disjoint()` method, which may be called hundreds of
        # times when scanning a page of links for packages with tags matching that
        # Set[Tag]. Pre-computing the value here produces significant speedups for
        # downstream consumers.
        self._hash = hash((self._interpreter, self._abi, self._platform))

    @property
    def interpreter(self) -> str:
        return self._interpreter

    @property
    def abi(self) -> str:
        return self._abi

    @property
    def platform(self) -> str:
        return self._platform

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Tag):
            return NotImplemented

        return (
            (self._hash == other._hash)  # Short-circuit ASAP for perf reasons.
            and (self._platform == other._platform)
            and (self._abi == other._abi)
            and (self._interpreter == other._interpreter)
        )

    def __hash__(self) -> int:
        return self._hash

    def __str__(self) -> str:
        return f"{self._interpreter}-{self._abi}-{self._platform}"

    def __repr__(self) -> str:
        return f"<{self} @ {id(self)}>"


def parse_tag(tag: str) -> frozenset[Tag]:
    """
    Parses the provided tag (e.g. `py3-none-any`) into a frozenset of Tag instances.

    Returning a set is required due to the possibility that the tag is a
    compressed tag set.
    """
    tags = set()
    interpreters, abis, platforms = tag.split("-")
    for interpreter in interpreters.split("."):
        for abi in abis.split("."):
            for platform_ in platforms.split("."):
                tags.add(Tag(interpreter, abi, platform_))
    return frozenset(tags)


def _get_config_var(name: str, warn: bool = False) -> int | str | None:
    value: int | str | None = sysconfig.get_config_var(name)
    if value is None and warn:
        logger.debug(
            "Config variable '%s' is unset, Python ABI tag may be incorrect", name
        )
    return value


def _normalize_string(string: str) -> str:
    return string.replace(".", "_").replace("-", "_").replace(" ", "_")


def _is_threaded_cpython(abis: list[str]) -> bool:
    """
    Determine if the ABI corresponds to a threaded (`--disable-gil`) build.

    The threaded builds are indicated by a "t" in the abiflags.
    """
    if len(abis) == 0:
        return False
    # expect e.g., cp313
    m = re.match(r"cp\d+(.*)", abis[0])
    if not m:
        return False
    abiflags = m.group(1)
    return "t" in abiflags


def _abi3_applies(python_version: PythonVersion, threading: bool) -> bool:
    """
    Determine if the Python version supports abi3.

    PEP 384 was first implemented in Python 3.2. The threaded (`--disable-gil`)
    builds do not support abi3.
    """
    return len(python_version) > 1 and tuple(python_version) >= (3, 2) and not threading


def _cpython_abis(py_version: PythonVersion, warn: bool = False) -> list[str]:
    py_version = tuple(py_version)  # To allow for version comparison.
    abis = []
    version = _version_nodot(py_version[:2])
    threading = debug = pymalloc = ucs4 = ""
    with_debug = _get_config_var("Py_DEBUG", warn)
    has_refcount = hasattr(sys, "gettotalrefcount")
    # Windows doesn't set Py_DEBUG, so checking for support of debug-compiled
    # extension modules is the best option.
    # https://github.com/pypa/pip/issues/3383#issuecomment-173267692
    has_ext = "_d.pyd" in EXTENSION_SUFFIXES
    if with_debug or (with_debug is None and (has_refcount or has_ext)):
        debug = "d"
    if py_version >= (3, 13) and _get_config_var("Py_GIL_DISABLED", warn):
        threading = "t"
    if py_version < (3, 8):
        with_pymalloc = _get_config_var("WITH_PYMALLOC", warn)
        if with_pymalloc or with_pymalloc is None:
            pymalloc = "m"
        if py_version < (3, 3):
            unicode_size = _get_config_var("Py_UNICODE_SIZE", warn)
            if unicode_size == 4 or (
                unicode_size is None and sys.maxunicode == 0x10FFFF
            ):
                ucs4 = "u"
    elif debug:
        # Debug builds can also load "normal" extension modules.
        # We can also assume no UCS-4 or pymalloc requirement.
        abis.append(f"cp{version}{threading}")
    abis.insert(0, f"cp{version}{threading}{debug}{pymalloc}{ucs4}")
    return abis


def cpython_tags(
    python_version: PythonVersion | None = None,
    abis: Iterable[str] | None = None,
    platforms: Iterable[str] | None = None,
    *,
    warn: bool = False,
) -> Iterator[Tag]:
    """
    Yields the tags for a CPython interpreter.

    The tags consist of:
    - cp<python_version>-<abi>-<platform>
    - cp<python_version>-abi3-<platform>
    - cp<python_version>-none-<platform>
    - cp<less than python_version>-abi3-<platform>  # Older Python versions down to 3.2.

    If python_version only specifies a major version then user-provided ABIs and
    the 'none' ABItag will be used.

    If 'abi3' or 'none' are specified in 'abis' then they will be yielded at
    their normal position and not at the beginning.
    """
    if not python_version:
        python_version = sys.version_info[:2]

    interpreter = f"cp{_version_nodot(python_version[:2])}"

    if abis is None:
        if len(python_version) > 1:
            abis = _cpython_abis(python_version, warn)
        else:
            abis = []
    abis = list(abis)
    # 'abi3' and 'none' are explicitly handled later.
    for explicit_abi in ("abi3", "none"):
        try:
            abis.remove(explicit_abi)
        except ValueError:
            pass

    platforms = list(platforms or platform_tags())
    for abi in abis:
        for platform_ in platforms:
            yield Tag(interpreter, abi, platform_)

    threading = _is_threaded_cpython(abis)
    use_abi3 = _abi3_applies(python_version, threading)
    if use_abi3:
        yield from (Tag(interpreter, "abi3", platform_) for platform_ in platforms)
    yield from (Tag(interpreter, "none", platform_) for platform_ in platforms)

    if use_abi3:
        for minor_version in range(python_version[1] - 1, 1, -1):
            for platform_ in platforms:
                version = _version_nodot((python_version[0], minor_version))
                interpreter = f"cp{version}"
                yield Tag(interpreter, "abi3", platform_)


def _generic_abi() -> list[str]:
    """
    Return the ABI tag based on EXT_SUFFIX.
    """
    # The following are examples of `EXT_SUFFIX`.
    # We want to keep the parts which are related to the ABI and remove the
    # parts which are related to the platform:
    # - linux:   '.cpython-310-x86_64-linux-gnu.so' => cp310
    # - mac:     '.cpython-310-darwin.so'           => cp310
    # - win:     '.cp310-win_amd64.pyd'             => cp310
    # - win:     '.pyd'                             => cp37 (uses _cpython_abis())
    # - pypy:    '.pypy38-pp73-x86_64-linux-gnu.so' => pypy38_pp73
    # - graalpy: '.graalpy-38-native-x86_64-darwin.dylib'
    #                                               => graalpy_38_native

    ext_suffix = _get_config_var("EXT_SUFFIX", warn=True)
    if not isinstance(ext_suffix, str) or ext_suffix[0] != ".":
        raise SystemError("invalid sysconfig.get_config_var('EXT_SUFFIX')")
    parts = ext_suffix.split(".")
    if len(parts) < 3:
        # CPython3.7 and earlier uses ".pyd" on Windows.
        return _cpython_abis(sys.version_info[:2])
    soabi = parts[1]
    if soabi.startswith("cpython"):
        # non-windows
        abi = "cp" + soabi.split("-")[1]
    elif soabi.startswith("cp"):
        # windows
        abi = soabi.split("-")[0]
    elif soabi.startswith("pypy"):
        abi = "-".join(soabi.split("-")[:2])
    elif soabi.startswith("graalpy"):
        abi = "-".join(soabi.split("-")[:3])
    elif soabi:
        # pyston, ironpython, others?
        abi = soabi
    else:
        return []
    return [_normalize_string(abi)]


def generic_tags(
    interpreter: str | None = None,
    abis: Iterable[str] | None = None,
    platforms: Iterable[str] | None = None,
    *,
    warn: bool = False,
) -> Iterator[Tag]:
    """
    Yields the tags for a generic interpreter.

    The tags consist of:
    - <interpreter>-<abi>-<platform>

    The "none" ABI will be added if it was not explicitly provided.
    """
    if not interpreter:
        interp_name = interpreter_name()
        interp_version = interpreter_version(warn=warn)
        interpreter = "".join([interp_name, interp_version])
    if abis is None:
        abis = _generic_abi()
    else:
        abis = list(abis)
    platforms = list(platforms or platform_tags())
    if "none" not in abis:
        abis.append("none")
    for abi in abis:
        for platform_ in platforms:
            yield Tag(interpreter, abi, platform_)


def _py_interpreter_range(py_version: PythonVersion) -> Iterator[str]:
    """
    Yields Python versions in descending order.

    After the latest version, the major-only version will be yielded, and then
    all previous versions of that major version.
    """
    if len(py_version) > 1:
        yield f"py{_version_nodot(py_version[:2])}"
    yield f"py{py_version[0]}"
    if len(py_version) > 1:
        for minor in range(py_version[1] - 1, -1, -1):
            yield f"py{_version_nodot((py_version[0], minor))}"


def compatible_tags(
    python_version: PythonVersion | None = None,
    interpreter: str | None = None,
    platforms: Iterable[str] | None = None,
) -> Iterator[Tag]:
    """
    Yields the sequence of tags that are compatible with a specific version of Python.

    The tags consist of:
    - py*-none-<platform>
    - <interpreter>-none-any  # ... if `interpreter` is provided.
    - py*-none-any
    """
    if not python_version:
        python_version = sys.version_info[:2]
    platforms = list(platforms or platform_tags())
    for version in _py_interpreter_range(python_version):
        for platform_ in platforms:
            yield Tag(version, "none", platform_)
    if interpreter:
        yield Tag(interpreter, "none", "any")
    for version in _py_interpreter_range(python_version):
        yield Tag(version, "none", "any")


def _mac_arch(arch: str, is_32bit: bool = _32_BIT_INTERPRETER) -> str:
    if not is_32bit:
        return arch

    if arch.startswith("ppc"):
        return "ppc"

    return "i386"


def _mac_binary_formats(version: AppleVersion, cpu_arch: str) -> list[str]:
    formats = [cpu_arch]
    if cpu_arch == "x86_64":
        if version < (10, 4):
            return []
        formats.extend(["intel", "fat64", "fat32"])

    elif cpu_arch == "i386":
        if version < (10, 4):
            return []
        formats.extend(["intel", "fat32", "fat"])

    elif cpu_arch == "ppc64":
        # TODO: Need to care about 32-bit PPC for ppc64 through 10.2?
        if version > (10, 5) or version < (10, 4):
            return []
        formats.append("fat64")

    elif cpu_arch == "ppc":
        if version > (10, 6):
            return []
        formats.extend(["fat32", "fat"])

    if cpu_arch in {"arm64", "x86_64"}:
        formats.append("universal2")

    if cpu_arch in {"x86_64", "i386", "ppc64", "ppc", "intel"}:
        formats.append("universal")

    return formats


def mac_platforms(
    version: AppleVersion | None = None, arch: str | None = None
) -> Iterator[str]:
    """
    Yields the platform tags for a macOS system.

    The `version` parameter is a two-item tuple specifying the macOS version to
    generate platform tags for. The `arch` parameter is the CPU architecture to
    generate platform tags for. Both parameters default to the appropriate value
    for the current system.
    """
    version_str, _, cpu_arch = platform.mac_ver()
    if version is None:
        version = cast("AppleVersion", tuple(map(int, version_str.split(".")[:2])))
        if version == (10, 16):
            # When built against an older macOS SDK, Python will report macOS 10.16
            # instead of the real version.
            version_str = subprocess.run(
                [
                    sys.executable,
                    "-sS",
                    "-c",
                    "import platform; print(platform.mac_ver()[0])",
                ],
                check=True,
                env={"SYSTEM_VERSION_COMPAT": "0"},
                stdout=subprocess.PIPE,
                text=True,
            ).stdout
            version = cast("AppleVersion", tuple(map(int, version_str.split(".")[:2])))
    else:
        version = version
    if arch is None:
        arch = _mac_arch(cpu_arch)
    else:
        arch = arch

    if (10, 0) <= version and version < (11, 0):
        # Prior to Mac OS 11, each yearly release of Mac OS bumped the
        # "minor" version number.  The major version was always 10.
        major_version = 10
        for minor_version in range(version[1], -1, -1):
            compat_version = major_version, minor_version
            binary_formats = _mac_binary_formats(compat_version, arch)
            for binary_format in binary_formats:
                yield f"macosx_{major_version}_{minor_version}_{binary_format}"

    if version >= (11, 0):
        # Starting with Mac OS 11, each yearly release bumps the major version
        # number.   The minor versions are now the midyear updates.
        minor_version = 0
        for major_version in range(version[0], 10, -1):
            compat_version = major_version, minor_version
            binary_formats = _mac_binary_formats(compat_version, arch)
            for binary_format in binary_formats:
                yield f"macosx_{major_version}_{minor_version}_{binary_format}"

    if version >= (11, 0):
        # Mac OS 11 on x86_64 is compatible with binaries from previous releases.
        # Arm64 support was introduced in 11.0, so no Arm binaries from previous
        # releases exist.
        #
        # However, the "universal2" binary format can have a
        # macOS version earlier than 11.0 when the x86_64 part of the binary supports
        # that version of macOS.
        major_version = 10
        if arch == "x86_64":
            for minor_version in range(16, 3, -1):
                compat_version = major_version, minor_version
                binary_formats = _mac_binary_formats(compat_version, arch)
                for binary_format in binary_formats:
                    yield f"macosx_{major_version}_{minor_version}_{binary_format}"
        else:
            for minor_version in range(16, 3, -1):
                compat_version = major_version, minor_version
                binary_format = "universal2"
                yield f"macosx_{major_version}_{minor_version}_{binary_format}"


def ios_platforms(
    version: AppleVersion | None = None, multiarch: str | None = None
) -> Iterator[str]:
    """
    Yields the platform tags for an iOS system.

    :param version: A two-item tuple specifying the iOS version to generate
        platform tags for. Defaults to the current iOS version.
    :param multiarch: The CPU architecture+ABI to generate platform tags for -
        (the value used by `sys.implementation._multiarch` e.g.,
        `arm64_iphoneos` or `x84_64_iphonesimulator`). Defaults to the current
        multiarch value.
    """
    if version is None:
        # if iOS is the current platform, ios_ver *must* be defined. However,
        # it won't exist for CPython versions before 3.13, which causes a mypy
        # error.
        _, release, _, _ = platform.ios_ver()  # type: ignore[attr-defined, unused-ignore]
        version = cast("AppleVersion", tuple(map(int, release.split(".")[:2])))

    if multiarch is None:
        multiarch = sys.implementation._multiarch
    multiarch = multiarch.replace("-", "_")

    ios_platform_template = "ios_{major}_{minor}_{multiarch}"

    # Consider any iOS major.minor version from the version requested, down to
    # 12.0. 12.0 is the first iOS version that is known to have enough features
    # to support CPython. Consider every possible minor release up to X.9. There
    # highest the minor has ever gone is 8 (14.8 and 15.8) but having some extra
    # candidates that won't ever match doesn't really hurt, and it saves us from
    # having to keep an explicit list of known iOS versions in the code. Return
    # the results descending order of version number.

    # If the requested major version is less than 12, there won't be any matches.
    if version[0] < 12:
        return

    # Consider the actual X.Y version that was requested.
    yield ios_platform_template.format(
        major=version[0], minor=version[1], multiarch=multiarch
    )

    # Consider every minor version from X.0 to the minor version prior to the
    # version requested by the platform.
    for minor in range(version[1] - 1, -1, -1):
        yield ios_platform_template.format(
            major=version[0], minor=minor, multiarch=multiarch
        )

    for major in range(version[0] - 1, 11, -1):
        for minor in range(9, -1, -1):
            yield ios_platform_template.format(
                major=major, minor=minor, multiarch=multiarch
            )


def android_platforms(
    api_level: int | None = None, abi: str | None = None
) -> Iterator[str]:
    """
    Yields the :attr:`~Tag.platform` tags for Android. If this function is invoked on
    non-Android platforms, the ``api_level`` and ``abi`` arguments are required.

    :param int api_level: The maximum `API level
        <https://developer.android.com/tools/releases/platforms>`__ to return. Defaults
        to the current system's version, as returned by ``platform.android_ver``.
    :param str abi: The `Android ABI <https://developer.android.com/ndk/guides/abis>`__,
        e.g. ``arm64_v8a``. Defaults to the current system's ABI , as returned by
        ``sysconfig.get_platform``. Hyphens and periods will be replaced with
        underscores.
    """
    if platform.system() != "Android" and (api_level is None or abi is None):
        raise TypeError(
            "on non-Android platforms, the api_level and abi arguments are required"
        )

    if api_level is None:
        # Python 3.13 was the first version to return platform.system() == "Android",
        # and also the first version to define platform.android_ver().
        api_level = platform.android_ver().api_level  # type: ignore[attr-defined]

    if abi is None:
        abi = sysconfig.get_platform().split("-")[-1]
    abi = _normalize_string(abi)

    # 16 is the minimum API level known to have enough features to support CPython
    # without major patching. Yield every API level from the maximum down to the
    # minimum, inclusive.
    min_api_level = 16
    for ver in range(api_level, min_api_level - 1, -1):
        yield f"android_{ver}_{abi}"


def _linux_platforms(is_32bit: bool = _32_BIT_INTERPRETER) -> Iterator[str]:
    linux = _normalize_string(sysconfig.get_platform())
    if not linux.startswith("linux_"):
        # we should never be here, just yield the sysconfig one and return
        yield linux
        return
    if is_32bit:
        if linux == "linux_x86_64":
            linux = "linux_i686"
        elif linux == "linux_aarch64":
            linux = "linux_armv8l"
    _, arch = linux.split("_", 1)
    archs = {"armv8l": ["armv8l", "armv7l"]}.get(arch, [arch])
    yield from _manylinux.platform_tags(archs)
    yield from _musllinux.platform_tags(archs)
    for arch in archs:
        yield f"linux_{arch}"


def _generic_platforms() -> Iterator[str]:
    yield _normalize_string(sysconfig.get_platform())


def platform_tags() -> Iterator[str]:
    """
    Provides the platform tags for this installation.
    """
    if platform.system() == "Darwin":
        return mac_platforms()
    elif platform.system() == "iOS":
        return ios_platforms()
    elif platform.system() == "Android":
        return android_platforms()
    elif platform.system() == "Linux":
        return _linux_platforms()
    else:
        return _generic_platforms()


def interpreter_name() -> str:
    """
    Returns the name of the running interpreter.

    Some implementations have a reserved, two-letter abbreviation which will
    be returned when appropriate.
    """
    name = sys.implementation.name
    return INTERPRETER_SHORT_NAMES.get(name) or name


def interpreter_version(*, warn: bool = False) -> str:
    """
    Returns the version of the running interpreter.
    """
    version = _get_config_var("py_version_nodot", warn=warn)
    if version:
        version = str(version)
    else:
        version = _version_nodot(sys.version_info[:2])
    return version


def _version_nodot(version: PythonVersion) -> str:
    return "".join(map(str, version))


def sys_tags(*, warn: bool = False) -> Iterator[Tag]:
    """
    Returns the sequence of tag triples for the running interpreter.

    The order of the sequence corresponds to priority order for the
    interpreter, from most to least important.
    """

    interp_name = interpreter_name()
    if interp_name == "cp":
        yield from cpython_tags(warn=warn)
    else:
        yield from generic_tags()

    if interp_name == "pp":
        interp = "pp3"
    elif interp_name == "cp":
        interp = "cp" + interpreter_version(warn=warn)
    else:
        interp = None
    yield from compatible_tags(interpreter=interp)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/tags.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.1K 2025-06-01 01:28:43.655978161 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/__init__.cpython-312.pyc
382c8d690b5adc99685d7986c356186ead1f3d3a1cfc640f43405bb233b1e28f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 5f 16 00 00  |.........x3h_...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 9c 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 03 6c 03 6d 04  5a 04 6d 05 5a 05 01 00  |d.d.l.m.Z.m.Z...|
00000050  64 00 64 04 6c 06 6d 07  5a 07 6d 08 5a 08 01 00  |d.d.l.m.Z.m.Z...|
00000060  67 00 64 05 a2 01 5a 09  02 00 65 02 6a 14 00 00  |g.d...Z...e.j...|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000080  64 06 ab 01 00 00 00 00  00 00 5a 0b 02 00 65 04  |d.........Z...e.|
00000090  64 07 65 0c ab 02 00 00  00 00 00 00 5a 0d 02 00  |d.e.........Z...|
000000a0  47 00 64 08 84 00 64 09  65 0e ab 03 00 00 00 00  |G.d...d.e.......|
000000b0  00 00 5a 0f 09 00 09 00  09 00 09 00 64 0b 64 0a  |..Z.........d.d.|
000000c0  84 04 5a 10 79 02 29 0c  e9 00 00 00 00 29 01 da  |..Z.y.)......)..|
000000d0  0b 61 6e 6e 6f 74 61 74  69 6f 6e 73 4e 29 02 da  |.annotationsN)..|
000000e0  07 4e 65 77 54 79 70 65  da 04 63 61 73 74 29 02  |.NewType..cast).|
000000f0  da 0a 45 58 43 45 50 54  49 4f 4e 53 da 08 4c 49  |..EXCEPTIONS..LI|
00000100  43 45 4e 53 45 53 29 03  da 18 49 6e 76 61 6c 69  |CENSES)...Invali|
00000110  64 4c 69 63 65 6e 73 65  45 78 70 72 65 73 73 69  |dLicenseExpressi|
00000120  6f 6e da 1b 4e 6f 72 6d  61 6c 69 7a 65 64 4c 69  |on..NormalizedLi|
00000130  63 65 6e 73 65 45 78 70  72 65 73 73 69 6f 6e da  |censeExpression.|
00000140  1f 63 61 6e 6f 6e 69 63  61 6c 69 7a 65 5f 6c 69  |.canonicalize_li|
00000150  63 65 6e 73 65 5f 65 78  70 72 65 73 73 69 6f 6e  |cense_expression|
00000160  7a 10 5e 5b 41 2d 5a 61  2d 7a 30 2d 39 2e 2d 5d  |z.^[A-Za-z0-9.-]|
00000170  2a 24 72 09 00 00 00 63  00 00 00 00 00 00 00 00  |*$r....c........|
00000180  00 00 00 00 01 00 00 00  00 00 00 01 f3 10 00 00  |................|
00000190  00 97 00 65 00 5a 01 64  00 5a 02 64 01 5a 03 79  |...e.Z.d.Z.d.Z.y|
000001a0  02 29 03 72 08 00 00 00  7a f5 52 61 69 73 65 64  |.).r....z.Raised|
000001b0  20 77 68 65 6e 20 61 20  6c 69 63 65 6e 73 65 2d  | when a license-|
000001c0  65 78 70 72 65 73 73 69  6f 6e 20 73 74 72 69 6e  |expression strin|
000001d0  67 20 69 73 20 69 6e 76  61 6c 69 64 0a 0a 20 20  |g is invalid..  |
000001e0  20 20 3e 3e 3e 20 63 61  6e 6f 6e 69 63 61 6c 69  |  >>> canonicali|
000001f0  7a 65 5f 6c 69 63 65 6e  73 65 5f 65 78 70 72 65  |ze_license_expre|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/_spdx.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 47K 2025-06-01 01:28:43.847978161 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/_spdx.cpython-312.pyc
db09a76c608d935b3fdd34ab71ef2d735b7cb4b6a4b0c09be1dbca2be5d58185  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/_spdx.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  53 05 35 68 25 bd 00 00  |........S.5h%...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 01 f3 2e 2d  00 00 97 00 55 00 64 00  |.......-....U.d.|
00000030  64 01 6c 00 6d 01 5a 01  01 00 64 00 64 02 6c 02  |d.l.m.Z...d.d.l.|
00000040  6d 03 5a 03 01 00 02 00  47 00 64 03 84 00 64 04  |m.Z.....G.d...d.|
00000050  65 03 ab 03 00 00 00 00  00 00 5a 04 02 00 47 00  |e.........Z...G.|
00000060  64 05 84 00 64 06 65 03  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000070  5a 05 64 07 5a 06 69 00  64 08 64 09 64 0a 64 0b  |Z.d.Z.i.d.d.d.d.|
00000080  9c 02 93 01 64 0c 64 0d  64 0a 64 0b 9c 02 93 01  |....d.d.d.d.....|
00000090  64 0e 64 0f 64 0a 64 0b  9c 02 93 01 64 10 64 11  |d.d.d.d.....d.d.|
000000a0  64 0a 64 0b 9c 02 93 01  64 12 64 13 64 0a 64 0b  |d.d.....d.d.d.d.|
000000b0  9c 02 93 01 64 14 64 15  64 0a 64 0b 9c 02 93 01  |....d.d.d.d.....|
000000c0  64 16 64 17 64 0a 64 0b  9c 02 93 01 64 18 64 19  |d.d.d.d.....d.d.|
000000d0  64 0a 64 0b 9c 02 93 01  64 1a 64 1b 64 0a 64 0b  |d.d.....d.d.d.d.|
000000e0  9c 02 93 01 64 1c 64 1d  64 0a 64 0b 9c 02 93 01  |....d.d.d.d.....|
000000f0  64 1e 64 1f 64 0a 64 0b  9c 02 93 01 64 20 64 21  |d.d.d.d.....d d!|
00000100  64 0a 64 0b 9c 02 93 01  64 22 64 23 64 0a 64 0b  |d.d.....d"d#d.d.|
00000110  9c 02 93 01 64 24 64 25  64 0a 64 0b 9c 02 93 01  |....d$d%d.d.....|
00000120  64 26 64 27 64 0a 64 0b  9c 02 93 01 64 28 64 29  |d&d'd.d.....d(d)|
00000130  64 0a 64 0b 9c 02 93 01  64 2a 64 2b 64 2c 64 0b  |d.d.....d*d+d,d.|
00000140  9c 02 93 01 69 00 64 2d  64 2e 64 0a 64 0b 9c 02  |....i.d-d.d.d...|
00000150  93 01 64 2f 64 30 64 0a  64 0b 9c 02 93 01 64 31  |..d/d0d.d.....d1|
00000160  64 32 64 2c 64 0b 9c 02  93 01 64 33 64 34 64 0a  |d2d,d.....d3d4d.|
00000170  64 0b 9c 02 93 01 64 35  64 36 64 0a 64 0b 9c 02  |d.....d5d6d.d...|
00000180  93 01 64 37 64 38 64 0a  64 0b 9c 02 93 01 64 39  |..d7d8d.d.....d9|
00000190  64 3a 64 0a 64 0b 9c 02  93 01 64 3b 64 3c 64 0a  |d:d.d.....d;d<d.|
000001a0  64 0b 9c 02 93 01 64 3d  64 3e 64 0a 64 0b 9c 02  |d.....d=d>d.d...|
000001b0  93 01 64 3f 64 40 64 0a  64 0b 9c 02 93 01 64 41  |..d?d@d.d.....dA|
000001c0  64 42 64 0a 64 0b 9c 02  93 01 64 43 64 44 64 0a  |dBd.d.....dCdDd.|
000001d0  64 0b 9c 02 93 01 64 45  64 46 64 0a 64 0b 9c 02  |d.....dEdFd.d...|
000001e0  93 01 64 47 64 48 64 0a  64 0b 9c 02 93 01 64 49  |..dGdHd.d.....dI|
000001f0  64 4a 64 0a 64 0b 9c 02  93 01 64 4b 64 4c 64 0a  |dJd.d.....dKdLd.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/licenses/__pycache__/_spdx.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 590 2025-06-01 01:28:41.399978163 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/__init__.cpython-312.pyc
6ca23d978f7d111837a23c8b20db38fab687520a83457d1b05c055b247a959dd  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  53 05 35 68 05 02 00 00  |........S.5h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 2a 00  00 00 97 00 64 00 5a 00  |......*.....d.Z.|
00000030  64 01 5a 01 64 02 5a 02  64 03 5a 03 64 04 5a 04  |d.Z.d.Z.d.Z.d.Z.|
00000040  64 05 5a 05 64 06 5a 06  64 07 65 04 9b 00 9d 02  |d.Z.d.Z.d.e.....|
00000050  5a 07 79 08 29 09 da 09  70 61 63 6b 61 67 69 6e  |Z.y.)...packagin|
00000060  67 7a 22 43 6f 72 65 20  75 74 69 6c 69 74 69 65  |gz"Core utilitie|
00000070  73 20 66 6f 72 20 50 79  74 68 6f 6e 20 70 61 63  |s for Python pac|
00000080  6b 61 67 65 73 7a 21 68  74 74 70 73 3a 2f 2f 67  |kagesz!https://g|
00000090  69 74 68 75 62 2e 63 6f  6d 2f 70 79 70 61 2f 70  |ithub.com/pypa/p|
000000a0  61 63 6b 61 67 69 6e 67  7a 04 32 35 2e 30 7a 29  |ackagingz.25.0z)|
000000b0  44 6f 6e 61 6c 64 20 53  74 75 66 66 74 20 61 6e  |Donald Stufft an|
000000c0  64 20 69 6e 64 69 76 69  64 75 61 6c 20 63 6f 6e  |d individual con|
000000d0  74 72 69 62 75 74 6f 72  73 7a 10 64 6f 6e 61 6c  |tributorsz.donal|
000000e0  64 40 73 74 75 66 66 74  2e 69 6f 7a 1a 42 53 44  |d@stufft.ioz.BSD|
000000f0  2d 32 2d 43 6c 61 75 73  65 20 6f 72 20 41 70 61  |-2-Clause or Apa|
00000100  63 68 65 2d 32 2e 30 7a  05 32 30 31 34 20 4e 29  |che-2.0z.2014 N)|
00000110  08 da 09 5f 5f 74 69 74  6c 65 5f 5f da 0b 5f 5f  |...__title__..__|
00000120  73 75 6d 6d 61 72 79 5f  5f da 07 5f 5f 75 72 69  |summary__..__uri|
00000130  5f 5f da 0b 5f 5f 76 65  72 73 69 6f 6e 5f 5f da  |__..__version__.|
00000140  0a 5f 5f 61 75 74 68 6f  72 5f 5f da 09 5f 5f 65  |.__author__..__e|
00000150  6d 61 69 6c 5f 5f da 0b  5f 5f 6c 69 63 65 6e 73  |mail__..__licens|
00000160  65 5f 5f da 0d 5f 5f 63  6f 70 79 72 69 67 68 74  |e__..__copyright|
00000170  5f 5f a9 00 f3 00 00 00  00 fa 80 2f 64 61 74 61  |__........./data|
00000180  2f 64 61 74 61 2f 63 6f  6d 2e 74 65 72 6d 75 78  |/data/com.termux|
00000190  2f 66 69 6c 65 73 2f 68  6f 6d 65 2f 52 41 46 41  |/files/home/RAFA|
000001a0  45 4c 49 41 2f 48 43 50  4d 2f 43 4f 52 45 2f 76  |ELIA/HCPM/CORE/v|
000001b0  65 6e 76 5f 72 61 66 61  65 6c 69 61 2f 6c 69 62  |env_rafaelia/lib|
000001c0  2f 70 79 74 68 6f 6e 33  2e 31 32 2f 73 69 74 65  |/python3.12/site|
000001d0  2d 70 61 63 6b 61 67 65  73 2f 70 69 70 2f 5f 76  |-packages/pip/_v|
000001e0  65 6e 64 6f 72 2f 70 61  63 6b 61 67 69 6e 67 2f  |endor/packaging/|
000001f0  5f 5f 69 6e 69 74 5f 5f  2e 70 79 da 08 3c 6d 6f  |__init__.py..<mo|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_elffile.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.0K 2025-06-01 01:28:41.555978163 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_elffile.cpython-312.pyc
97d37b5bcd4448edfb4c045c8b281cdca817866cba66533da1cafd7f68ee8079  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_elffile.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 d6 0c 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 e0 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 01 64 04  6c 06 6d 07 5a 07 01 00  |l.Z.d.d.l.m.Z...|
00000060  02 00 47 00 64 05 84 00  64 06 65 08 ab 03 00 00  |..G.d...d.e.....|
00000070  00 00 00 00 5a 09 02 00  47 00 64 07 84 00 64 08  |....Z...G.d...d.|
00000080  65 03 6a 14 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000090  00 00 00 00 00 00 ab 03  00 00 00 00 00 00 5a 0b  |..............Z.|
000000a0  02 00 47 00 64 09 84 00  64 0a 65 03 6a 14 00 00  |..G.d...d.e.j...|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  ab 03 00 00 00 00 00 00  5a 0c 02 00 47 00 64 0b  |........Z...G.d.|
000000d0  84 00 64 0c 65 03 6a 14  00 00 00 00 00 00 00 00  |..d.e.j.........|
000000e0  00 00 00 00 00 00 00 00  00 00 ab 03 00 00 00 00  |................|
000000f0  00 00 5a 0d 02 00 47 00  64 0d 84 00 64 0e ab 02  |..Z...G.d...d...|
00000100  00 00 00 00 00 00 5a 0e  79 03 29 0f 61 3b 01 00  |......Z.y.).a;..|
00000110  00 0a 45 4c 46 20 66 69  6c 65 20 70 61 72 73 65  |..ELF file parse|
00000120  72 2e 0a 0a 54 68 69 73  20 70 72 6f 76 69 64 65  |r...This provide|
00000130  73 20 61 20 63 6c 61 73  73 20 60 60 45 4c 46 46  |s a class ``ELFF|
00000140  69 6c 65 60 60 20 74 68  61 74 20 70 61 72 73 65  |ile`` that parse|
00000150  73 20 61 6e 20 45 4c 46  20 65 78 65 63 75 74 61  |s an ELF executa|
00000160  62 6c 65 20 69 6e 20 61  20 73 69 6d 69 6c 61 72  |ble in a similar|
00000170  0a 69 6e 74 65 72 66 61  63 65 20 74 6f 20 60 60  |.interface to ``|
00000180  5a 69 70 46 69 6c 65 60  60 2e 20 4f 6e 6c 79 20  |ZipFile``. Only |
00000190  74 68 65 20 72 65 61 64  20 69 6e 74 65 72 66 61  |the read interfa|
000001a0  63 65 20 69 73 20 69 6d  70 6c 65 6d 65 6e 74 65  |ce is implemente|
000001b0  64 2e 0a 0a 42 61 73 65  64 20 6f 6e 3a 20 68 74  |d...Based on: ht|
000001c0  74 70 73 3a 2f 2f 67 69  73 74 2e 67 69 74 68 75  |tps://gist.githu|
000001d0  62 2e 63 6f 6d 2f 6c 79  73 73 64 6f 64 2f 66 35  |b.com/lyssdod/f5|
000001e0  31 35 37 39 61 65 38 64  39 33 63 38 36 35 37 61  |1579ae8d93c8657a|
000001f0  35 35 36 34 61 65 66 63  32 66 66 62 63 61 0a 45  |5564aefc2ffbca.E|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_elffile.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_manylinux.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.6K 2025-06-01 01:28:41.719978163 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_manylinux.cpython-312.pyc
9b93ff4dee9f6fe5bee8c8d071055364496fbf3a4e1a6d2ce5bf73a04fd9afe9  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_manylinux.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 7c 25 00 00  |.........x3h|%..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 6c 01  00 00 97 00 55 00 64 00  |......l.....U.d.|
00000030  64 01 6c 00 6d 01 5a 01  01 00 64 00 64 02 6c 02  |d.l.m.Z...d.d.l.|
00000040  5a 02 64 00 64 02 6c 03  5a 03 64 00 64 02 6c 04  |Z.d.d.l.Z.d.d.l.|
00000050  5a 04 64 00 64 02 6c 05  5a 05 64 00 64 02 6c 06  |Z.d.d.l.Z.d.d.l.|
00000060  5a 06 64 00 64 02 6c 07  5a 07 64 00 64 02 6c 08  |Z.d.d.l.Z.d.d.l.|
00000070  5a 08 64 00 64 03 6c 09  6d 0a 5a 0a 6d 0b 5a 0b  |Z.d.d.l.m.Z.m.Z.|
00000080  6d 0c 5a 0c 6d 0d 5a 0d  01 00 64 04 64 05 6c 0e  |m.Z.m.Z...d.d.l.|
00000090  6d 0f 5a 0f 6d 10 5a 10  6d 11 5a 11 6d 12 5a 12  |m.Z.m.Z.m.Z.m.Z.|
000000a0  01 00 64 06 5a 13 64 07  5a 14 64 08 5a 15 65 03  |..d.Z.d.Z.d.Z.e.|
000000b0  6a 2c 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j,..............|
000000c0  00 00 00 00 64 1d 64 09  84 04 ab 00 00 00 00 00  |....d.d.........|
000000d0  00 00 5a 17 64 1e 64 0a  84 04 5a 18 64 1e 64 0b  |..Z.d.d...Z.d.d.|
000000e0  84 04 5a 19 64 1f 64 0c  84 04 5a 1a 02 00 65 02  |..Z.d.d...Z...e.|
000000f0  6a 36 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j6..............|
00000100  00 00 00 00 64 0d 84 00  ab 01 00 00 00 00 00 00  |....d...........|
00000110  5a 1c 64 0e 65 1d 64 0f  3c 00 00 00 02 00 47 00  |Z.d.e.d.<.....G.|
00000120  64 10 84 00 64 11 65 0c  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000130  5a 1e 64 20 64 12 84 04  5a 1f 64 20 64 13 84 04  |Z.d d...Z.d d...|
00000140  5a 20 64 20 64 14 84 04  5a 21 64 21 64 15 84 04  |Z d d...Z!d!d...|
00000150  5a 22 65 04 6a 46 00 00  00 00 00 00 00 00 00 00  |Z"e.jF..........|
00000160  00 00 00 00 00 00 00 00  64 22 64 16 84 04 ab 00  |........d"d.....|
00000170  00 00 00 00 00 00 5a 24  64 23 64 17 84 04 5a 25  |......Z$d#d...Z%|
00000180  64 18 64 19 64 1a 64 1b  9c 03 5a 26 64 24 64 1c  |d.d.d.d...Z&d$d.|
00000190  84 04 5a 27 79 02 29 25  e9 00 00 00 00 29 01 da  |..Z'y.)%.....)..|
000001a0  0b 61 6e 6e 6f 74 61 74  69 6f 6e 73 4e 29 04 da  |.annotationsN)..|
000001b0  09 47 65 6e 65 72 61 74  6f 72 da 08 49 74 65 72  |.Generator..Iter|
000001c0  61 74 6f 72 da 0a 4e 61  6d 65 64 54 75 70 6c 65  |ator..NamedTuple|
000001d0  da 08 53 65 71 75 65 6e  63 65 e9 01 00 00 00 29  |..Sequence.....)|
000001e0  04 da 07 45 49 43 6c 61  73 73 da 06 45 49 44 61  |...EIClass..EIDa|
000001f0  74 61 da 07 45 4c 46 46  69 6c 65 da 08 45 4d 61  |ta..ELFFile..EMa|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_manylinux.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_musllinux.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.5K 2025-06-01 01:28:41.871978162 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_musllinux.cpython-312.pyc
b78abd8b8eeda8b7ecb0a307f847f431b1ec2eccaf5ade33c65d27cd89b02bf4  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_musllinux.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 86 0a 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0a 00 00  |................|
00000020  00 00 00 00 01 f3 d6 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 01 64 03  6c 06 5a 06 64 01 64 04  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 6d 08 5a 08 6d 09  5a 09 6d 0a 5a 0a 01 00  |l.m.Z.m.Z.m.Z...|
00000070  64 05 64 06 6c 0b 6d 0c  5a 0c 01 00 02 00 47 00  |d.d.l.m.Z.....G.|
00000080  64 07 84 00 64 08 65 09  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000090  5a 0d 64 19 64 09 84 04  5a 0e 65 03 6a 1e 00 00  |Z.d.d...Z.e.j...|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  64 1a 64 0a 84 04 ab 00  00 00 00 00 00 00 5a 10  |d.d...........Z.|
000000c0  64 1b 64 0b 84 04 5a 11  65 12 64 0c 6b 28 00 00  |d.d...Z.e.d.k(..|
000000d0  72 96 64 01 64 03 6c 13  5a 13 02 00 65 13 6a 28  |r.d.d.l.Z...e.j(|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000f0  00 00 ab 00 00 00 00 00  00 00 5a 15 65 15 6a 2d  |..........Z.e.j-|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000110  00 00 64 0d ab 01 00 00  00 00 00 00 73 07 4a 00  |..d.........s.J.|
00000120  64 0e ab 00 00 00 00 00  00 00 82 01 02 00 65 17  |d.............e.|
00000130  64 0f 65 15 ab 02 00 00  00 00 00 00 01 00 02 00  |d.e.............|
00000140  65 17 64 10 02 00 65 10  65 06 6a 30 00 00 00 00  |e.d...e.e.j0....|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 01  |................|
00000160  00 00 00 00 00 00 ab 02  00 00 00 00 00 00 01 00  |................|
00000170  02 00 65 17 64 11 64 12  ac 13 ab 02 00 00 00 00  |..e.d.d.........|
00000180  00 00 01 00 02 00 65 11  02 00 65 04 6a 32 00 00  |......e...e.j2..|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  64 14 64 15 65 15 6a 35  00 00 00 00 00 00 00 00  |d.d.e.j5........|
000001b0  00 00 00 00 00 00 00 00  00 00 64 16 64 05 ab 02  |..........d.d...|
000001c0  00 00 00 00 00 00 64 17  19 00 00 00 ab 03 00 00  |......d.........|
000001d0  00 00 00 00 ab 01 00 00  00 00 00 00 44 00 5d 0c  |............D.].|
000001e0  00 00 5a 1b 02 00 65 17  65 1b 64 18 ac 13 ab 02  |..Z...e.e.d.....|
000001f0  00 00 00 00 00 00 01 00  8c 0e 04 00 79 03 79 03  |............y.y.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_musllinux.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_parser.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 14K 2025-06-01 01:28:42.023978162 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_parser.cpython-312.pyc
615be6116ddfceac4cac9332df1a3a4e2287dbb4cc44eb2279d5c3f15948a94c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_parser.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ed 27 00 00  |.........x3h.'..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 98 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 04  6c 04 6d 05 5a 05 6d 06  |l.Z.d.d.l.m.Z.m.|
00000050  5a 06 6d 07 5a 07 6d 08  5a 08 01 00 64 05 64 06  |Z.m.Z.m.Z...d.d.|
00000060  6c 09 6d 0a 5a 0a 6d 0b  5a 0b 01 00 02 00 47 00  |l.m.Z.m.Z.....G.|
00000070  64 07 84 00 64 08 ab 02  00 00 00 00 00 00 5a 0c  |d...d.........Z.|
00000080  02 00 47 00 64 09 84 00  64 0a 65 0c ab 03 00 00  |..G.d...d.e.....|
00000090  00 00 00 00 5a 0d 02 00  47 00 64 0b 84 00 64 0c  |....Z...G.d...d.|
000000a0  65 0c ab 03 00 00 00 00  00 00 5a 0e 02 00 47 00  |e.........Z...G.|
000000b0  64 0d 84 00 64 0e 65 0c  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000c0  5a 0f 65 08 65 0d 65 0e  66 02 19 00 00 00 5a 10  |Z.e.e.e.f.....Z.|
000000d0  65 07 65 10 65 0f 65 10  66 03 19 00 00 00 5a 11  |e.e.e.e.f.....Z.|
000000e0  65 08 65 11 65 06 64 0f  19 00 00 00 66 02 19 00  |e.e.e.d.....f...|
000000f0  00 00 5a 12 65 06 65 08  64 10 65 12 65 13 66 03  |..Z.e.e.d.e.e.f.|
00000100  19 00 00 00 19 00 00 00  5a 14 02 00 47 00 64 11  |........Z...G.d.|
00000110  84 00 64 12 65 05 ab 03  00 00 00 00 00 00 5a 15  |..d.e.........Z.|
00000120  64 24 64 13 84 04 5a 16  64 25 64 14 84 04 5a 17  |d$d...Z.d%d...Z.|
00000130  09 00 09 00 09 00 09 00  64 26 64 15 84 04 5a 18  |........d&d...Z.|
00000140  09 00 09 00 09 00 09 00  09 00 09 00 09 00 09 00  |................|
00000150  64 27 64 16 84 04 5a 19  64 28 64 17 84 04 5a 1a  |d'd...Z.d(d...Z.|
00000160  64 28 64 18 84 04 5a 1b  64 29 64 19 84 04 5a 1c  |d(d...Z.d)d...Z.|
00000170  64 29 64 1a 84 04 5a 1d  64 2a 64 1b 84 04 5a 1e  |d)d...Z.d*d...Z.|
00000180  64 2b 64 1c 84 04 5a 1f  64 2b 64 1d 84 04 5a 20  |d+d...Z.d+d...Z |
00000190  64 2c 64 1e 84 04 5a 21  64 2d 64 1f 84 04 5a 22  |d,d...Z!d-d...Z"|
000001a0  64 2e 64 20 84 04 5a 23  64 2f 64 21 84 04 5a 24  |d.d ..Z#d/d!..Z$|
000001b0  64 30 64 22 84 04 5a 25  64 31 64 23 84 04 5a 26  |d0d"..Z%d1d#..Z&|
000001c0  79 03 29 32 7a 98 48 61  6e 64 77 72 69 74 74 65  |y.)2z.Handwritte|
000001d0  6e 20 70 61 72 73 65 72  20 6f 66 20 64 65 70 65  |n parser of depe|
000001e0  6e 64 65 6e 63 79 20 73  70 65 63 69 66 69 65 72  |ndency specifier|
000001f0  73 2e 0a 0a 54 68 65 20  64 6f 63 73 74 72 69 6e  |s...The docstrin|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_parser.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_structures.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.2K 2025-06-01 01:28:42.183978162 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_structures.cpython-312.pyc
53dc1962a4f8154c16d0c561009d29476cf8d2873bb2936a5da4238ca5d68f98  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_structures.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 97 05 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 48 00  00 00 97 00 02 00 47 00  |......H.......G.|
00000030  64 00 84 00 64 01 ab 02  00 00 00 00 00 00 5a 00  |d...d.........Z.|
00000040  02 00 65 00 ab 00 00 00  00 00 00 00 5a 01 02 00  |..e.........Z...|
00000050  47 00 64 02 84 00 64 03  ab 02 00 00 00 00 00 00  |G.d...d.........|
00000060  5a 02 02 00 65 02 ab 00  00 00 00 00 00 00 5a 03  |Z...e.........Z.|
00000070  79 04 29 05 63 00 00 00  00 00 00 00 00 00 00 00  |y.).c...........|
00000080  00 04 00 00 00 00 00 00  00 f3 84 00 00 00 97 00  |................|
00000090  65 00 5a 01 64 00 5a 02  64 01 65 03 66 02 64 02  |e.Z.d.Z.d.e.f.d.|
000000a0  84 04 5a 04 64 01 65 05  66 02 64 03 84 04 5a 06  |..Z.d.e.f.d...Z.|
000000b0  64 04 65 07 64 01 65 08  66 04 64 05 84 04 5a 09  |d.e.d.e.f.d...Z.|
000000c0  64 04 65 07 64 01 65 08  66 04 64 06 84 04 5a 0a  |d.e.d.e.f.d...Z.|
000000d0  64 04 65 07 64 01 65 08  66 04 64 07 84 04 5a 0b  |d.e.d.e.f.d...Z.|
000000e0  64 04 65 07 64 01 65 08  66 04 64 08 84 04 5a 0c  |d.e.d.e.f.d...Z.|
000000f0  64 04 65 07 64 01 65 08  66 04 64 09 84 04 5a 0d  |d.e.d.e.f.d...Z.|
00000100  64 0a 65 07 64 01 64 0b  66 04 64 0c 84 04 5a 0e  |d.e.d.d.f.d...Z.|
00000110  79 0d 29 0e da 0c 49 6e  66 69 6e 69 74 79 54 79  |y.)...InfinityTy|
00000120  70 65 da 06 72 65 74 75  72 6e 63 01 00 00 00 00  |pe..returnc.....|
00000130  00 00 00 00 00 00 00 00  00 00 00 03 00 00 00 f3  |................|
00000140  04 00 00 00 97 00 79 01  29 02 4e da 08 49 6e 66  |......y.).N..Inf|
00000150  69 6e 69 74 79 a9 00 a9  01 da 04 73 65 6c 66 73  |inity......selfs|
00000160  01 00 00 00 20 fa 83 2f  64 61 74 61 2f 64 61 74  |.... ../data/dat|
00000170  61 2f 63 6f 6d 2e 74 65  72 6d 75 78 2f 66 69 6c  |a/com.termux/fil|
00000180  65 73 2f 68 6f 6d 65 2f  52 41 46 41 45 4c 49 41  |es/home/RAFAELIA|
00000190  2f 48 43 50 4d 2f 43 4f  52 45 2f 76 65 6e 76 5f  |/HCPM/CORE/venv_|
000001a0  72 61 66 61 65 6c 69 61  2f 6c 69 62 2f 70 79 74  |rafaelia/lib/pyt|
000001b0  68 6f 6e 33 2e 31 32 2f  73 69 74 65 2d 70 61 63  |hon3.12/site-pac|
000001c0  6b 61 67 65 73 2f 70 69  70 2f 5f 76 65 6e 64 6f  |kages/pip/_vendo|
000001d0  72 2f 70 61 63 6b 61 67  69 6e 67 2f 5f 73 74 72  |r/packaging/_str|
000001e0  75 63 74 75 72 65 73 2e  70 79 da 08 5f 5f 72 65  |uctures.py..__re|
000001f0  70 72 5f 5f 7a 15 49 6e  66 69 6e 69 74 79 54 79  |pr__z.InfinityTy|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_structures.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_tokenizer.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.8K 2025-06-01 01:28:42.339978162 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_tokenizer.cpython-312.pyc
44b0d1db5ed24fd9ed4f41c1fca9372274966983cba0fb7173c65daa31e792f2  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__pycache__/_tokenizer.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 be 14 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 01 f3 fc 01  00 00 97 00 55 00 64 00  |............U.d.|
00000030  64 01 6c 00 6d 01 5a 01  01 00 64 00 64 02 6c 02  |d.l.m.Z...d.d.l.|
00000040  5a 02 64 00 64 02 6c 03  5a 03 64 00 64 03 6c 04  |Z.d.d.l.Z.d.d.l.|
00000050  6d 05 5a 05 01 00 64 00  64 04 6c 06 6d 07 5a 07  |m.Z...d.d.l.m.Z.|