#!/bin/bash
# ∴ VERBO_DIMENSÃO ∆ Verbos como Universos Paralelos ∴

DIMENSAO=$(cat entrada.txt | tr -d '\r' | head -n1 | awk '{print tolower($1)}')
SAIDA="saida.txt"
DIMDIR="dimensoes/$DIMENSAO"

mkdir -p "$DIMDIR"
touch "$DIMDIR/verbum.db"

echo "[DIMENSÃO] Dimensão '$DIMENSAO' criada." > "$SAIDA"
echo "Adicione verbos nessa dimensão usando:" >> "$SAIDA"
echo "echo 'verbo: comando' >> $DIMDIR/verbum.db" >> "$SAIDA"

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSÃO.sh -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSAO.sh
-rwxrwxrwx. 1 u0_a292 u0_a292 331 2025-06-10 05:24:58.763988497 -0300 /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSAO.sh
1f3cf28286fb4f1f55fcf1dbd40f20f87bb956befb297ced615b384b3343b2c0  /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSAO.sh
MIME: text/x-shellscript
----- INÍCIO DO CONTEÚDO (extensão: .sh) -----