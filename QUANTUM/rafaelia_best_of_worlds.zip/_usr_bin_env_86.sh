#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name="rafaelia",
    version="0.1.0",
    description="Núcleo simbiótico RAFAELIA",
    author="Rafael Melo Reis",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/setup.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/MANIFEST.in
-rwxrwxrwx. 1 u0_a292 u0_a292 27 2025-05-29 14:37:23.910754072 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/MANIFEST.in
22854932a65f48f2ba55697b30842c61e08f362d8e3c621d72a55c7ee50fa57c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/MANIFEST.in
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----
recursive-include src *.py
----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/MANIFEST.in -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 350 2025-06-01 01:30:23.747978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc
1a2adc7afd4b707838c37846d7dbbc5db41e11558bca7fdaac219b879d2315df  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  53 9b 38 68 3f 00 00 00  |........S.8h?...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 0a 00  00 00 97 00 64 00 84 00  |............d...|
00000030  5a 00 79 01 29 02 63 00  00 00 00 00 00 00 00 00  |Z.y.).c.........|
00000040  00 00 00 03 00 00 00 03  00 00 00 f3 1a 00 00 00  |................|
00000050  97 00 74 01 00 00 00 00  00 00 00 00 64 01 ab 01  |..t.........d...|
00000060  00 00 00 00 00 00 01 00  79 00 29 02 4e 75 27 00  |........y.).Nu'.|
00000070  00 00 52 41 46 41 45 4c  49 41 20 61 74 69 76 61  |..RAFAELIA ativa|
00000080  64 61 20 63 6f 6d 20 6e  c3 ba 63 6c 65 6f 20 63  |da com n..cleo c|
00000090  6f 67 6e 69 74 69 76 6f  21 29 01 da 05 70 72 69  |ognitivo!)...pri|
000000a0  6e 74 a9 00 f3 00 00 00  00 fa 52 2f 64 61 74 61  |nt........R/data|
000000b0  2f 64 61 74 61 2f 63 6f  6d 2e 74 65 72 6d 75 78  |/data/com.termux|
000000c0  2f 66 69 6c 65 73 2f 68  6f 6d 65 2f 52 41 46 41  |/files/home/RAFA|
000000d0  45 4c 49 41 2f 48 43 50  4d 2f 43 4f 52 45 2f 62  |ELIA/HCPM/CORE/b|
000000e0  75 69 6c 64 2f 6c 69 62  2f 72 61 66 61 65 6c 69  |uild/lib/rafaeli|
000000f0  61 2f 5f 5f 69 6e 69 74  5f 5f 2e 70 79 da 06 61  |a/__init__.py..a|
00000100  74 69 76 61 72 72 07 00  00 00 01 00 00 00 73 0a  |tivarr........s.|
00000110  00 00 00 80 00 8c 65 d0  14 3d d5 0e 3e 72 05 00  |......e..=..>r..|
00000120  00 00 4e 29 01 72 07 00  00 00 72 04 00 00 00 72  |..N).r....r....r|
00000130  05 00 00 00 72 06 00 00  00 da 08 3c 6d 6f 64 75  |....r......<modu|
00000140  6c 65 3e 72 08 00 00 00  01 00 00 00 73 08 00 00  |le>r........s...|
00000150  00 f0 03 01 01 01 db 00  3e 72 05 00 00 00        |........>r....|
0000015e
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/core_logic.py
-rwxrwxrwx. 1 u0_a292 u0_a292 489 2025-06-02 22:55:15.950164466 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/core_logic.py
2c6405361149e078f7f7875fef1aa82b8889262db883f9d02b7108307f5750fc  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/core_logic.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----