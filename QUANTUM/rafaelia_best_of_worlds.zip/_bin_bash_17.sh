#!/bin/bash
# ∴ PROTO_VERBUM ∆ Encarnação de novos verbos

ENTRADA="entrada.txt"
VERBDB="verbum.db"
SAIDA="saida.txt"

INPUT=$(cat "$ENTRADA" | tr -d '\r')
VERBO=$(echo "$INPUT" | cut -d':' -f1 | awk '{print tolower($1)}')
COMANDO=$(echo "$INPUT" | cut -d':' -f2-)

if [[ -z "$VERBO" || -z "$COMANDO" ]]; then
  echo "[PROTO_VERBUM] Formato inválido. Use: verbo: comando" >> "$SAIDA"
  exit 1
fi

echo "$VERBO|$COMANDO|$(date +%s)" >> "$VERBDB"
echo "[PROTO_VERBUM] Verbo '$VERBO' registrado como: $COMANDO" >> "$SAIDA"

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/PROTO_VERBUM.sh -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DOMINION.sh
-rwxrwxrwx. 1 u0_a292 u0_a292 544 2025-06-10 05:24:58.751988497 -0300 /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DOMINION.sh
006b9011c2b6ed942016d11a03dcd708b650d3a3783ccfb8adc619e09d7a5778  /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DOMINION.sh
MIME: text/x-shellscript
----- INÍCIO DO CONTEÚDO (extensão: .sh) -----