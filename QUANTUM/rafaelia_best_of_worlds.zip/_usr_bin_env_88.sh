#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name="rafaelia",
    version="0.1.0",
    description="Núcleo simbiótico RAFAELIA",
    author="Rafael Melo Reis",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/setup.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/core_logic.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.4K 2025-06-01 01:32:38.743977993 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/core_logic.cpython-312.pyc
b9a7272b71fa49b074f2f987b396df379137169162a75892b76404be8704342b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/core_logic.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  59 a6 38 68 d2 01 00 00  |........Y.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 8c 00  00 00 97 00 02 00 47 00  |..............G.|
00000030  64 00 84 00 64 01 ab 02  00 00 00 00 00 00 5a 00  |d...d.........Z.|
00000040  65 01 64 02 6b 28 00 00  72 35 02 00 65 00 ab 00  |e.d.k(..r5..e...|
00000050  00 00 00 00 00 00 5a 02  02 00 65 03 65 02 6a 09  |......Z...e.e.j.|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000070  00 00 64 03 ab 01 00 00  00 00 00 00 ab 01 00 00  |..d.............|
00000080  00 00 00 00 01 00 02 00  65 03 65 02 6a 0b 00 00  |........e.e.j...|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000a0  ab 00 00 00 00 00 00 00  ab 01 00 00 00 00 00 00  |................|
000000b0  01 00 79 04 79 04 29 05  63 00 00 00 00 00 00 00  |..y.y.).c.......|
000000c0  00 00 00 00 00 01 00 00  00 00 00 00 00 f3 1e 00  |................|
000000d0  00 00 97 00 65 00 5a 01  64 00 5a 02 64 01 84 00  |....e.Z.d.Z.d...|
000000e0  5a 03 64 02 84 00 5a 04  64 03 84 00 5a 05 79 04  |Z.d...Z.d...Z.y.|
000000f0  29 05 da 08 52 61 66 61  65 6c 49 41 63 01 00 00  |)...RafaelIAc...|
00000100  00 00 00 00 00 00 00 00  00 02 00 00 00 03 00 00  |................|
00000110  00 f3 20 00 00 00 97 00  64 01 7c 00 5f 00 00 00  |.. .....d.|._...|
00000120  00 00 00 00 00 00 67 00  7c 00 5f 01 00 00 00 00  |......g.|._.....|
00000130  00 00 00 00 79 00 29 02  4e da 05 61 74 69 76 6f  |....y.).N..ativo|
00000140  29 02 da 06 65 73 74 61  64 6f da 07 6d 65 6d 6f  |)...estado..memo|
00000150  72 69 61 a9 01 da 04 73  65 6c 66 73 01 00 00 00  |ria....selfs....|
00000160  20 fa 67 2f 64 61 74 61  2f 64 61 74 61 2f 63 6f  | .g/data/data/co|
00000170  6d 2e 74 65 72 6d 75 78  2f 66 69 6c 65 73 2f 68  |m.termux/files/h|
00000180  6f 6d 65 2f 52 41 46 41  45 4c 49 41 2f 48 43 50  |ome/RAFAELIA/HCP|
00000190  4d 2f 43 4f 52 45 2f 52  41 46 41 45 4c 49 41 2f  |M/CORE/RAFAELIA/|
000001a0  48 43 50 4d 2f 43 4f 52  45 2f 62 75 69 6c 64 2f  |HCPM/CORE/build/|
000001b0  6c 69 62 2f 72 61 66 61  65 6c 69 61 2f 63 6f 72  |lib/rafaelia/cor|
000001c0  65 5f 6c 6f 67 69 63 2e  70 79 da 08 5f 5f 69 6e  |e_logic.py..__in|
000001d0  69 74 5f 5f 7a 11 52 61  66 61 65 6c 49 41 2e 5f  |it__z.RafaelIA._|
000001e0  5f 69 6e 69 74 5f 5f 02  00 00 00 73 10 00 00 00  |_init__....s....|
000001f0  80 00 d8 16 1d 88 04 8c  0b d8 17 19 88 04 8d 0c  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/core_logic.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 198 2025-06-01 01:32:38.883977993 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc
8d81c0d7e189eba1b1b308054f95c22bb83c38157fbb1b0921ab4f6a827db8d2  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  59 a6 38 68 00 00 00 00  |........Y.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 65 2f  |N..r..........e/|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |RE/RAFAELIA/HCPM|
00000080  2f 43 4f 52 45 2f 62 75  69 6c 64 2f 6c 69 62 2f  |/CORE/build/lib/|
00000090  72 61 66 61 65 6c 69 61  2f 5f 5f 69 6e 69 74 5f  |rafaelia/__init_|
000000a0  5f 2e 70 79 da 08 3c 6d  6f 64 75 6c 65 3e 72 05  |_.py..<module>r.|
000000b0  00 00 00 01 00 00 00 73  05 00 00 00 f1 03 01 01  |.......s........|
000000c0  01 72 03 00 00 00                                 |.r....|
000000c6
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/build/lib/rafaelia/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 469 2025-06-01 01:32:38.595977993 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc
6819b71e67d7936287758133d12d3d12c842829148c54e56e8ef1775eb3c5682  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  59 a6 38 68 f5 00 00 00  |........Y.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 42 00  00 00 97 00 64 00 64 01  |......B.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 01 00 02 00 65 01  |l.m.Z.m.Z.....e.|
00000040  64 02 64 03 64 04 64 05  02 00 65 02 64 06 ac 07  |d.d.d.d...e.d...|
00000050  ab 01 00 00 00 00 00 00  64 08 64 06 69 01 ac 09  |........d.d.i...|
00000060  ab 06 00 00 00 00 00 00  01 00 79 0a 29 0b e9 00  |..........y.)...|
00000070  00 00 00 29 02 da 05 73  65 74 75 70 da 0d 66 69  |...)...setup..fi|
00000080  6e 64 5f 70 61 63 6b 61  67 65 73 da 08 72 61 66  |nd_packages..raf|
00000090  61 65 6c 69 61 7a 05 30  2e 31 2e 30 75 1c 00 00  |aeliaz.0.1.0u...|
000000a0  00 4e c3 ba 63 6c 65 6f  20 73 69 6d 62 69 c3 b3  |.N..cleo simbi..|
000000b0  74 69 63 6f 20 52 41 46  41 45 4c 49 41 7a 10 52  |tico RAFAELIAz.R|
000000c0  61 66 61 65 6c 20 4d 65  6c 6f 20 52 65 69 73 da  |afael Melo Reis.|
000000d0  03 73 72 63 29 01 da 05  77 68 65 72 65 da 00 29  |.src)...where..)|
000000e0  06 da 04 6e 61 6d 65 da  07 76 65 72 73 69 6f 6e  |...name..version|
000000f0  da 0b 64 65 73 63 72 69  70 74 69 6f 6e da 06 61  |..description..a|
00000100  75 74 68 6f 72 da 08 70  61 63 6b 61 67 65 73 da  |uthor..packages.|
00000110  0b 70 61 63 6b 61 67 65  5f 64 69 72 4e 29 03 da  |.package_dirN)..|
00000120  0a 73 65 74 75 70 74 6f  6f 6c 73 72 03 00 00 00  |.setuptoolsr....|
00000130  72 04 00 00 00 a9 00 f3  00 00 00 00 fa 4f 2f 64  |r............O/d|
00000140  61 74 61 2f 64 61 74 61  2f 63 6f 6d 2e 74 65 72  |ata/data/com.ter|
00000150  6d 75 78 2f 66 69 6c 65  73 2f 68 6f 6d 65 2f 52  |mux/files/home/R|
00000160  41 46 41 45 4c 49 41 2f  48 43 50 4d 2f 43 4f 52  |AFAELIA/HCPM/COR|
00000170  45 2f 52 41 46 41 45 4c  49 41 2f 48 43 50 4d 2f  |E/RAFAELIA/HCPM/|
00000180  43 4f 52 45 2f 73 65 74  75 70 2e 70 79 da 08 3c  |CORE/setup.py..<|
00000190  6d 6f 64 75 6c 65 3e 72  13 00 00 00 01 00 00 00  |module>r........|
000001a0  73 2b 00 00 00 f0 03 01  01 01 df 00 2b e1 00 05  |s+..........+...|
000001b0  d8 09 13 d8 0c 13 d8 10  2e d8 0b 1d d9 0d 1a a0  |................|
000001c0  15 d4 0d 27 d8 11 13 90  55 90 0b f6 0d 07 01 02  |...'....U.......|
000001d0  72 11 00 00 00                                    |r....|
000001d5
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/src/rafaelia_mod/__init__.py
-rwxrwxrwx. 1 u0_a292 u0_a292 134 2025-06-02 22:55:19.146164464 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/src/rafaelia_mod/__init__.py
c69f7d61bec3a99841cfc43ce626148130a0bb0866a9118493c064e4535011dd  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/src/rafaelia_mod/__init__.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----