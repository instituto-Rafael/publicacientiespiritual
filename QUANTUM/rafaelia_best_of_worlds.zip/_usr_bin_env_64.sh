#!/usr/bin/env python3
import os
import re


_default_seps = os.sep + str(os.altsep) * bool(os.altsep)


class Translator:
    """
    >>> Translator('xyz')
    Traceback (most recent call last):
    ...
    AssertionError: Invalid separators

    >>> Translator('')
    Traceback (most recent call last):
    ...
    AssertionError: Invalid separators
    """

    seps: str

    def __init__(self, seps: str = _default_seps):
        assert seps and set(seps) <= set(_default_seps), "Invalid separators"
        self.seps = seps

    def translate(self, pattern):
        """
        Given a glob pattern, produce a regex that matches it.
        """
        return self.extend(self.translate_core(pattern))

    def extend(self, pattern):
        r"""
        Extend regex for pattern-wide concerns.

        Apply '(?s:)' to create a non-matching group that
        matches newlines (valid on Unix).

        Append '\Z' to imply fullmatch even when match is used.
        """
        return rf'(?s:{pattern})\Z'

    def translate_core(self, pattern):
        r"""
        Given a glob pattern, produce a regex that matches it.

        >>> t = Translator()
        >>> t.translate_core('*.txt').replace('\\\\', '')
        '[^/]*\\.txt'
        >>> t.translate_core('a?txt')
        'a[^/]txt'
        >>> t.translate_core('**/*').replace('\\\\', '')
        '.*/[^/][^/]*'
        """
        self.restrict_rglob(pattern)
        return ''.join(map(self.replace, separate(self.star_not_empty(pattern))))

    def replace(self, match):
        """
        Perform the replacements for a match from :func:`separate`.
        """
        return match.group('set') or (
            re.escape(match.group(0))
            .replace('\\*\\*', r'.*')
            .replace('\\*', rf'[^{re.escape(self.seps)}]*')
            .replace('\\?', r'[^/]')
        )

    def restrict_rglob(self, pattern):
        """
        Raise ValueError if ** appears in anything but a full path segment.

        >>> Translator().translate('**foo')
        Traceback (most recent call last):
        ...
        ValueError: ** must appear alone in a path segment
        """
        seps_pattern = rf'[{re.escape(self.seps)}]+'
        segments = re.split(seps_pattern, pattern)
        if any('**' in segment and segment != '**' for segment in segments):
            raise ValueError("** must appear alone in a path segment")

    def star_not_empty(self, pattern):
        """
        Ensure that * will not match an empty segment.
        """

        def handle_segment(match):
            segment = match.group(0)
            return '?*' if segment == '*' else segment

        not_seps_pattern = rf'[^{re.escape(self.seps)}]+'
        return re.sub(not_seps_pattern, handle_segment, pattern)


def separate(pattern):
    """
    Separate out character sets to avoid translating their contents.

    >>> [m.group(0) for m in separate('*.txt')]
    ['*.txt']
    >>> [m.group(0) for m in separate('a[?]txt')]
    ['a', '[?]', 'txt']
    """
    return re.finditer(r'([^\[]+)|(?P<set>[\[].*?[\]])|([\[][^\]]*$)', pattern)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/glob.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 234 2025-06-01 01:30:06.795978102 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/__init__.cpython-312.pyc
69c12fa8cdfa84d7b3be3cd4be31eea789696449a9900f51782c841ba6463f82  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 89 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000000a0  74 75 70 74 6f 6f 6c 73  2f 5f 76 65 6e 64 6f 72  |tuptools/_vendor|
000000b0  2f 7a 69 70 70 2f 63 6f  6d 70 61 74 2f 5f 5f 69  |/zipp/compat/__i|
000000c0  6e 69 74 5f 5f 2e 70 79  da 08 3c 6d 6f 64 75 6c  |nit__.py..<modul|
000000d0  65 3e 72 05 00 00 00 01  00 00 00 73 05 00 00 00  |e>r........s....|
000000e0  f1 03 01 01 01 72 03 00  00 00                    |.....r....|
000000ea
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/py310.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 545 2025-06-01 01:30:06.951978102 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/py310.cpython-312.pyc
4b2353fde23e359c87f27cc296dfab80b34f03471a40f346f33c15ac217f3a16  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/py310.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 db 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 58 00  00 00 97 00 64 00 64 01  |......X.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 04 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  84 01 5a 02 65 00 6a 06  00 00 00 00 00 00 00 00  |..Z.e.j.........|
00000050  00 00 00 00 00 00 00 00  00 00 64 03 6b 44 00 00  |..........d.kD..|
00000060  72 0d 65 01 6a 08 00 00  00 00 00 00 00 00 00 00  |r.e.j...........|
00000070  00 00 00 00 00 00 00 00  5a 04 79 01 65 02 5a 04  |........Z.y.e.Z.|
00000080  79 01 29 05 e9 00 00 00  00 4e 63 02 00 00 00 02  |y.)......Nc.....|
00000090  00 00 00 00 00 00 00 01  00 00 00 03 00 00 00 f3  |................|
000000a0  06 00 00 00 97 00 7c 00  53 00 29 01 4e a9 00 29  |......|.S.).N..)|
000000b0  02 da 08 65 6e 63 6f 64  69 6e 67 da 0a 73 74 61  |...encoding..sta|
000000c0  63 6b 6c 65 76 65 6c 73  02 00 00 00 20 20 fa 86  |cklevels....  ..|
000000d0  2f 64 61 74 61 2f 64 61  74 61 2f 63 6f 6d 2e 74  |/data/data/com.t|
000000e0  65 72 6d 75 78 2f 66 69  6c 65 73 2f 68 6f 6d 65  |ermux/files/home|
000000f0  2f 52 41 46 41 45 4c 49  41 2f 48 43 50 4d 2f 43  |/RAFAELIA/HCPM/C|
00000100  4f 52 45 2f 76 65 6e 76  5f 72 61 66 61 65 6c 69  |ORE/venv_rafaeli|
00000110  61 2f 6c 69 62 2f 70 79  74 68 6f 6e 33 2e 31 32  |a/lib/python3.12|
00000120  2f 73 69 74 65 2d 70 61  63 6b 61 67 65 73 2f 73  |/site-packages/s|
00000130  65 74 75 70 74 6f 6f 6c  73 2f 5f 76 65 6e 64 6f  |etuptools/_vendo|
00000140  72 2f 7a 69 70 70 2f 63  6f 6d 70 61 74 2f 70 79  |r/zipp/compat/py|
00000150  33 31 30 2e 70 79 da 0e  5f 74 65 78 74 5f 65 6e  |310.py.._text_en|
00000160  63 6f 64 69 6e 67 72 08  00 00 00 05 00 00 00 73  |codingr........s|
00000170  07 00 00 00 80 00 d8 0b  13 80 4f f3 00 00 00 00  |..........O.....|
00000180  29 02 e9 03 00 00 00 e9  0a 00 00 00 29 01 e9 02  |)...........)...|
00000190  00 00 00 29 05 da 03 73  79 73 da 02 69 6f 72 08  |...)...sys..ior.|
000001a0  00 00 00 da 0c 76 65 72  73 69 6f 6e 5f 69 6e 66  |.....version_inf|
000001b0  6f da 0d 74 65 78 74 5f  65 6e 63 6f 64 69 6e 67  |o..text_encoding|
000001c0  72 04 00 00 00 72 09 00  00 00 72 07 00 00 00 da  |r....r....r.....|
000001d0  08 3c 6d 6f 64 75 6c 65  3e 72 11 00 00 00 01 00  |.<module>r......|
000001e0  00 00 73 35 00 00 00 f0  03 01 01 01 db 00 0a db  |..s5............|
000001f0  00 09 f3 06 01 01 14 f0  0a 00 19 1c d7 18 28 d1  |..............(.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/compat/__pycache__/py310.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 23K 2025-06-01 01:30:06.483978102 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/__init__.cpython-312.pyc
9081249ec4aa7ee13038c5e6e8d8c1ba9898207aad369517259dcc522a98390e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 64 34 00 00  |..........8hd4..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 1e 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 5a 06 64 00 64 01  6c 07 5a 07 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000070  6c 08 5a 08 64 02 64 03  6c 09 6d 0a 5a 0a 01 00  |l.Z.d.d.l.m.Z...|
00000080  64 02 64 04 6c 0b 6d 0c  5a 0c 01 00 64 05 67 01  |d.d.l.m.Z...d.g.|
00000090  5a 0d 64 06 84 00 5a 0e  64 07 84 00 5a 0f 65 10  |Z.d...Z.d...Z.e.|
000000a0  6a 22 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j"..............|
000000b0  00 00 00 00 5a 12 09 00  64 08 84 00 5a 13 02 00  |....Z...d...Z...|
000000c0  47 00 64 09 84 00 64 0a  ab 02 00 00 00 00 00 00  |G.d...d.........|
000000d0  5a 14 02 00 47 00 64 0b  84 00 64 0c ab 02 00 00  |Z...G.d...d.....|
000000e0  00 00 00 00 5a 15 02 00  47 00 64 0d 84 00 64 0e  |....Z...G.d...d.|
000000f0  65 14 65 15 65 02 6a 2c  00 00 00 00 00 00 00 00  |e.e.e.j,........|
00000100  00 00 00 00 00 00 00 00  00 00 ab 05 00 00 00 00  |................|
00000110  00 00 5a 17 02 00 47 00  64 0f 84 00 64 10 65 17  |..Z...G.d...d.e.|
00000120  ab 03 00 00 00 00 00 00  5a 18 64 13 64 11 84 01  |........Z.d.d...|
00000130  5a 19 02 00 47 00 64 12  84 00 64 05 ab 02 00 00  |Z...G.d...d.....|
00000140  00 00 00 00 5a 1a 79 01  29 14 e9 00 00 00 00 4e  |....Z.y.)......N|
00000150  e9 01 00 00 00 29 01 da  0d 74 65 78 74 5f 65 6e  |.....)...text_en|
00000160  63 6f 64 69 6e 67 29 01  da 0a 54 72 61 6e 73 6c  |coding)...Transl|
00000170  61 74 6f 72 da 04 50 61  74 68 63 01 00 00 00 00  |ator..Pathc.....|
00000180  00 00 00 00 00 00 00 05  00 00 00 03 00 00 00 f3  |................|
00000190  42 00 00 00 97 00 74 01  00 00 00 00 00 00 00 00  |B.....t.........|
000001a0  6a 02 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000001b0  00 00 00 00 74 05 00 00  00 00 00 00 00 00 7c 00  |....t.........|.|
000001c0  ab 01 00 00 00 00 00 00  64 01 64 02 ab 03 00 00  |........d.d.....|
000001d0  00 00 00 00 53 00 29 03  61 32 01 00 00 0a 20 20  |....S.).a2....  |
000001e0  20 20 47 69 76 65 6e 20  61 20 70 61 74 68 20 77  |  Given a path w|
000001f0  69 74 68 20 65 6c 65 6d  65 6e 74 73 20 73 65 70  |ith elements sep|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/glob.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.2K 2025-06-01 01:30:06.639978102 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/glob.cpython-312.pyc
cad31e9b8448edc9ab1dfb20dc33d36680a05f496b8f2b49208261eb5ea288f7  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/glob.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 0a 0c 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 92 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 65 00 6a 04  |l.Z.d.d.l.Z.e.j.|
00000040  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000050  00 00 02 00 65 03 65 00  6a 08 00 00 00 00 00 00  |....e.e.j.......|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 ab 01 00 00  |................|
00000070  00 00 00 00 02 00 65 05  65 00 6a 08 00 00 00 00  |......e.e.j.....|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 01  |................|
00000090  00 00 00 00 00 00 7a 05  00 00 7a 00 00 00 5a 06  |......z...z...Z.|
000000a0  02 00 47 00 64 02 84 00  64 03 ab 02 00 00 00 00  |..G.d...d.......|
000000b0  00 00 5a 07 64 04 84 00  5a 08 79 01 29 05 e9 00  |..Z.d...Z.y.)...|
000000c0  00 00 00 4e 63 00 00 00  00 00 00 00 00 00 00 00  |...Nc...........|
000000d0  00 03 00 00 00 00 00 00  00 f3 50 00 00 00 97 00  |..........P.....|
000000e0  65 00 5a 01 64 00 5a 02  55 00 64 01 5a 03 65 04  |e.Z.d.Z.U.d.Z.e.|
000000f0  65 05 64 02 3c 00 00 00  65 06 66 01 64 02 65 04  |e.d.<...e.f.d.e.|
00000100  66 02 64 03 84 05 5a 07  64 04 84 00 5a 08 64 05  |f.d...Z.d...Z.d.|
00000110  84 00 5a 09 64 06 84 00  5a 0a 64 07 84 00 5a 0b  |..Z.d...Z.d...Z.|
00000120  64 08 84 00 5a 0c 64 09  84 00 5a 0d 79 0a 29 0b  |d...Z.d...Z.y.).|
00000130  da 0a 54 72 61 6e 73 6c  61 74 6f 72 7a e3 0a 20  |..Translatorz.. |
00000140  20 20 20 3e 3e 3e 20 54  72 61 6e 73 6c 61 74 6f  |   >>> Translato|
00000150  72 28 27 78 79 7a 27 29  0a 20 20 20 20 54 72 61  |r('xyz').    Tra|
00000160  63 65 62 61 63 6b 20 28  6d 6f 73 74 20 72 65 63  |ceback (most rec|
00000170  65 6e 74 20 63 61 6c 6c  20 6c 61 73 74 29 3a 0a  |ent call last):.|
00000180  20 20 20 20 2e 2e 2e 0a  20 20 20 20 41 73 73 65  |    ....    Asse|
00000190  72 74 69 6f 6e 45 72 72  6f 72 3a 20 49 6e 76 61  |rtionError: Inva|
000001a0  6c 69 64 20 73 65 70 61  72 61 74 6f 72 73 0a 0a  |lid separators..|
000001b0  20 20 20 20 3e 3e 3e 20  54 72 61 6e 73 6c 61 74  |    >>> Translat|
000001c0  6f 72 28 27 27 29 0a 20  20 20 20 54 72 61 63 65  |or('').    Trace|
000001d0  62 61 63 6b 20 28 6d 6f  73 74 20 72 65 63 65 6e  |back (most recen|
000001e0  74 20 63 61 6c 6c 20 6c  61 73 74 29 3a 0a 20 20  |t call last):.  |
000001f0  20 20 2e 2e 2e 0a 20 20  20 20 41 73 73 65 72 74  |  ....    Assert|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/zipp/__pycache__/glob.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/__pycache__/typing_extensions.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 137K 2025-06-01 01:29:48.883978115 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/__pycache__/typing_extensions.cpython-312.pyc
993859d3ff3e6cea6e6c2b5ada82ef78e16a2292e9a2b22b58d0fe6c23fc3618  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/__pycache__/typing_extensions.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 33 0d 02 00  |..........8h3...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 11 00 00  |................|
00000020  00 00 00 00 00 f3 66 20  00 00 97 00 64 00 64 01  |......f ....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 01 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 5a 06 64 00 64 01  6c 07 5a 07 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000070  6c 08 5a 09 64 00 64 01  6c 0a 5a 0a 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000080  6c 0b 5a 0b 67 00 64 02  a2 01 5a 0c 64 03 5a 0d  |l.Z.g.d...Z.d.Z.|
00000090  65 0e 5a 0f 65 07 6a 20  00 00 00 00 00 00 00 00  |e.Z.e.j ........|
000000a0  00 00 00 00 00 00 00 00  00 00 64 04 6b 5c 00 00  |..........d.k\..|
000000b0  5a 11 02 00 47 00 64 05  84 00 64 06 ab 02 00 00  |Z...G.d...d.....|
000000c0  00 00 00 00 5a 12 02 00  65 12 ab 00 00 00 00 00  |....Z...e.......|
000000d0  00 00 5a 13 65 07 6a 20  00 00 00 00 00 00 00 00  |..Z.e.j ........|
000000e0  00 00 00 00 00 00 00 00  00 00 64 07 6b 5c 00 00  |..........d.k\..|
000000f0  72 04 64 08 84 00 5a 14  6e 16 65 07 6a 20 00 00  |r.d...Z.n.e.j ..|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000110  64 09 6b 5c 00 00 72 04  64 0a 84 00 5a 14 6e 03  |d.k\..r.d...Z.n.|
00000120  64 0b 84 00 5a 14 65 0a  6a 2a 00 00 00 00 00 00  |d...Z.e.j*......|
00000130  00 00 00 00 00 00 00 00  00 00 00 00 5a 15 02 00  |............Z...|
00000140  65 0a 6a 2c 00 00 00 00  00 00 00 00 00 00 00 00  |e.j,............|
00000150  00 00 00 00 00 00 64 0c  ab 01 00 00 00 00 00 00  |......d.........|
00000160  5a 17 02 00 65 0a 6a 2c  00 00 00 00 00 00 00 00  |Z...e.j,........|
00000170  00 00 00 00 00 00 00 00  00 00 64 0d ab 01 00 00  |..........d.....|
00000180  00 00 00 00 5a 18 02 00  65 0a 6a 2c 00 00 00 00  |....Z...e.j,....|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 0e  |..............d.|
000001a0  ab 01 00 00 00 00 00 00  5a 19 02 00 65 0a 6a 2c  |........Z...e.j,|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001c0  00 00 64 0f 64 03 ac 10  ab 02 00 00 00 00 00 00  |..d.d...........|
000001d0  5a 1a 02 00 65 0a 6a 2c  00 00 00 00 00 00 00 00  |Z...e.j,........|
000001e0  00 00 00 00 00 00 00 00  00 00 64 11 64 03 ac 12  |..........d.d...|
000001f0  ab 02 00 00 00 00 00 00  5a 1b 65 07 6a 20 00 00  |........Z.e.j ..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/__pycache__/typing_extensions.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/command/bdist_wheel.py
-rwxrwxrwx. 1 u0_a292 u0_a292 22K 2025-06-02 22:55:15.514164467 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/command/bdist_wheel.py
fbf9037639a45f5994eff7e95b0cf016afcf0b11122ec33f48f03fc78dea4335  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/command/bdist_wheel.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----