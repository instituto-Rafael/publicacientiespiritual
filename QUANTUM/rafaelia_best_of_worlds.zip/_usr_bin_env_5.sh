#!/usr/bin/env python3
from .core import contents, where

__all__ = ["contents", "where"]
__version__ = "2025.01.31"

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__init__.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 350 2025-06-01 01:28:34.927978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__init__.cpython-312.pyc
d6cc9eed7c28fd15b0a9c42a0d51e95b84fd064d210c56fb8d2bfe0fab672f10  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 75 00 00 00  |........R.5hu...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 20 00  00 00 97 00 64 00 64 01  |...... .....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 01 00 64 02 64 03  |l.m.Z.m.Z...d.d.|
00000040  67 02 5a 03 64 04 5a 04  79 05 29 06 e9 01 00 00  |g.Z.d.Z.y.).....|
00000050  00 29 02 da 08 63 6f 6e  74 65 6e 74 73 da 05 77  |.)...contents..w|
00000060  68 65 72 65 72 03 00 00  00 72 04 00 00 00 7a 0a  |herer....r....z.|
00000070  32 30 32 35 2e 30 31 2e  33 31 4e 29 05 da 04 63  |2025.01.31N)...c|
00000080  6f 72 65 72 03 00 00 00  72 04 00 00 00 da 07 5f  |orer....r......_|
00000090  5f 61 6c 6c 5f 5f da 0b  5f 5f 76 65 72 73 69 6f  |_all__..__versio|
000000a0  6e 5f 5f a9 00 f3 00 00  00 00 fa 7e 2f 64 61 74  |n__........~/dat|
000000b0  61 2f 64 61 74 61 2f 63  6f 6d 2e 74 65 72 6d 75  |a/data/com.termu|
000000c0  78 2f 66 69 6c 65 73 2f  68 6f 6d 65 2f 52 41 46  |x/files/home/RAF|
000000d0  41 45 4c 49 41 2f 48 43  50 4d 2f 43 4f 52 45 2f  |AELIA/HCPM/CORE/|
000000e0  76 65 6e 76 5f 72 61 66  61 65 6c 69 61 2f 6c 69  |venv_rafaelia/li|
000000f0  62 2f 70 79 74 68 6f 6e  33 2e 31 32 2f 73 69 74  |b/python3.12/sit|
00000100  65 2d 70 61 63 6b 61 67  65 73 2f 70 69 70 2f 5f  |e-packages/pip/_|
00000110  76 65 6e 64 6f 72 2f 63  65 72 74 69 66 69 2f 5f  |vendor/certifi/_|
00000120  5f 69 6e 69 74 5f 5f 2e  70 79 da 08 3c 6d 6f 64  |_init__.py..<mod|
00000130  75 6c 65 3e 72 0b 00 00  00 01 00 00 00 73 17 00  |ule>r........s..|
00000140  00 00 f0 03 01 01 01 e7  00 21 e0 0b 15 90 77 d0  |.........!....w.|
00000150  0a 1f 80 07 d8 0e 1a 81  0b 72 09 00 00 00        |.........r....|
0000015e
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__main__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 677 2025-06-01 01:28:35.091978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__main__.cpython-312.pyc
19c1fdfeaec6418539b1f7bdd05da3a2e1696feec5ae1b145aa10d85a71bc4df  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__main__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ff 00 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d4 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 6d 03  |l.Z.d.d.l.m.Z.m.|
00000040  5a 03 01 00 02 00 65 00  6a 08 00 00 00 00 00 00  |Z.....e.j.......|
00000050  00 00 00 00 00 00 00 00  00 00 00 00 ab 00 00 00  |................|
00000060  00 00 00 00 5a 05 65 05  6a 0d 00 00 00 00 00 00  |....Z.e.j.......|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 64 03 64 04  |............d.d.|
00000080  64 05 ac 06 ab 03 00 00  00 00 00 00 01 00 65 05  |d.............e.|
00000090  6a 0f 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000a0  00 00 00 00 ab 00 00 00  00 00 00 00 5a 08 65 08  |............Z.e.|
000000b0  6a 04 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000c0  00 00 00 00 72 0e 02 00  65 09 02 00 65 02 ab 00  |....r...e...e...|
000000d0  00 00 00 00 00 00 ab 01  00 00 00 00 00 00 01 00  |................|
000000e0  79 01 02 00 65 09 02 00  65 03 ab 00 00 00 00 00  |y...e...e.......|
000000f0  00 00 ab 01 00 00 00 00  00 00 01 00 79 01 29 07  |............y.).|
00000100  e9 00 00 00 00 4e 29 02  da 08 63 6f 6e 74 65 6e  |.....N)...conten|
00000110  74 73 da 05 77 68 65 72  65 7a 02 2d 63 7a 0a 2d  |ts..wherez.-cz.-|
00000120  2d 63 6f 6e 74 65 6e 74  73 da 0a 73 74 6f 72 65  |-contents..store|
00000130  5f 74 72 75 65 29 01 da  06 61 63 74 69 6f 6e 29  |_true)...action)|
00000140  0a da 08 61 72 67 70 61  72 73 65 da 13 70 69 70  |...argparse..pip|
00000150  2e 5f 76 65 6e 64 6f 72  2e 63 65 72 74 69 66 69  |._vendor.certifi|
00000160  72 03 00 00 00 72 04 00  00 00 da 0e 41 72 67 75  |r....r......Argu|
00000170  6d 65 6e 74 50 61 72 73  65 72 da 06 70 61 72 73  |mentParser..pars|
00000180  65 72 da 0c 61 64 64 5f  61 72 67 75 6d 65 6e 74  |er..add_argument|
00000190  da 0a 70 61 72 73 65 5f  61 72 67 73 da 04 61 72  |..parse_args..ar|
000001a0  67 73 da 05 70 72 69 6e  74 a9 00 f3 00 00 00 00  |gs..print.......|
000001b0  fa 7e 2f 64 61 74 61 2f  64 61 74 61 2f 63 6f 6d  |.~/data/data/com|
000001c0  2e 74 65 72 6d 75 78 2f  66 69 6c 65 73 2f 68 6f  |.termux/files/ho|
000001d0  6d 65 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |me/RAFAELIA/HCPM|
000001e0  2f 43 4f 52 45 2f 76 65  6e 76 5f 72 61 66 61 65  |/CORE/venv_rafae|
000001f0  6c 69 61 2f 6c 69 62 2f  70 79 74 68 6f 6e 33 2e  |lia/lib/python3.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/__main__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/core.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.2K 2025-06-01 01:28:35.267978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/core.cpython-312.pyc
46d05d90460bc9da0cbc714065d5279f60abd5710c53e61d4f2953ce5a548a09  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/core.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 86 11 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0b 00 00  |................|
00000020  00 00 00 00 00 f3 46 01  00 00 97 00 64 00 5a 00  |......F.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 16 64 04 84 04 5a 03  65 01 6a 08 00 00 00 00  |d.d...Z.e.j.....|
00000050  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 05  |..............d.|
00000060  6b 5c 00 00 72 19 64 01  64 06 6c 05 6d 06 5a 06  |k\..r.d.d.l.m.Z.|
00000070  6d 07 5a 07 01 00 64 02  61 08 64 02 61 09 64 03  |m.Z...d.a.d.a.d.|
00000080  65 0a 66 02 64 07 84 04  5a 0b 64 03 65 0a 66 02  |e.f.d...Z.d.e.f.|
00000090  64 08 84 04 5a 0c 79 02  65 01 6a 08 00 00 00 00  |d...Z.y.e.j.....|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 09  |..............d.|
000000b0  6b 5c 00 00 72 19 64 01  64 0a 6c 05 6d 0d 5a 0e  |k\..r.d.d.l.m.Z.|
000000c0  6d 0f 5a 0f 01 00 64 02  61 08 64 02 61 09 64 03  |m.Z...d.a.d.a.d.|
000000d0  65 0a 66 02 64 0b 84 04  5a 0b 64 03 65 0a 66 02  |e.f.d...Z.d.e.f.|
000000e0  64 0c 84 04 5a 0c 79 02  64 01 64 02 6c 10 5a 10  |d...Z.y.d.d.l.Z.|
000000f0  64 01 64 02 6c 11 5a 11  64 01 64 0d 6c 12 6d 13  |d.d.l.Z.d.d.l.m.|
00000100  5a 13 01 00 65 13 65 11  6a 28 00 00 00 00 00 00  |Z...e.e.j(......|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 65 0a 66 02  |............e.f.|
00000120  19 00 00 00 5a 15 65 13  65 0a 64 0e 66 02 19 00  |....Z.e.e.d.f...|
00000130  00 00 5a 16 09 00 09 00  64 17 64 0f 65 15 64 10  |..Z.....d.d.e.d.|
00000140  65 16 64 11 65 0a 64 12  65 0a 64 03 65 0a 66 0a  |e.d.e.d.e.d.e.f.|
00000150  64 13 84 05 5a 0f 64 03  65 0a 66 02 64 14 84 04  |d...Z.d.e.f.d...|
00000160  5a 0b 64 03 65 0a 66 02  64 15 84 04 5a 0c 79 02  |Z.d.e.f.d...Z.y.|
00000170  29 18 7a 65 0a 63 65 72  74 69 66 69 2e 70 79 0a  |).ze.certifi.py.|
00000180  7e 7e 7e 7e 7e 7e 7e 7e  7e 7e 0a 0a 54 68 69 73  |~~~~~~~~~~..This|
00000190  20 6d 6f 64 75 6c 65 20  72 65 74 75 72 6e 73 20  | module returns |
000001a0  74 68 65 20 69 6e 73 74  61 6c 6c 61 74 69 6f 6e  |the installation|
000001b0  20 6c 6f 63 61 74 69 6f  6e 20 6f 66 20 63 61 63  | location of cac|
000001c0  65 72 74 2e 70 65 6d 20  6f 72 20 69 74 73 20 63  |ert.pem or its c|
000001d0  6f 6e 74 65 6e 74 73 2e  0a e9 00 00 00 00 4e da  |ontents.......N.|
000001e0  06 72 65 74 75 72 6e 63  00 00 00 00 00 00 00 00  |.returnc........|
000001f0  00 00 00 00 05 00 00 00  03 00 00 00 f3 32 00 00  |.............2..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/certifi/__pycache__/core.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_lint_dependency_groups.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.9K 2025-06-01 01:28:35.919978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_lint_dependency_groups.cpython-312.pyc
e7fcc3431f70d99337cd1e7d64eecc80f1ad96bb1415b4a74af4d545109cd38f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_lint_dependency_groups.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ae 06 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |................|
00000020  00 00 00 00 01 f3 60 00  00 00 97 00 64 00 64 01  |......`.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 03 64 04 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 03 64 05  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 02 64 06 9c 01 64 09  64 07 84 06 5a 08 65 09  |d.d...d.d...Z.e.|
00000070  64 08 6b 28 00 00 72 08  02 00 65 08 ab 00 00 00  |d.k(..r...e.....|
00000080  00 00 00 00 01 00 79 02  79 02 29 0a e9 00 00 00  |......y.y.).....|
00000090  00 29 01 da 0b 61 6e 6e  6f 74 61 74 69 6f 6e 73  |.)...annotations|
000000a0  4e e9 01 00 00 00 29 01  da 17 44 65 70 65 6e 64  |N.....)...Depend|
000000b0  65 6e 63 79 47 72 6f 75  70 52 65 73 6f 6c 76 65  |encyGroupResolve|
000000c0  72 29 01 da 07 74 6f 6d  6c 6c 69 62 29 01 da 04  |r)...tomllib)...|
000000d0  61 72 67 76 63 00 00 00  00 00 00 00 00 01 00 00  |argvc...........|
000000e0  00 07 00 00 00 03 00 00  01 f3 d4 03 00 00 97 00  |................|
000000f0  74 00 00 00 00 00 00 00  00 00 80 26 74 03 00 00  |t..........&t...|
00000100  00 00 00 00 00 00 64 01  74 04 00 00 00 00 00 00  |......d.t.......|
00000110  00 00 6a 06 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
00000120  00 00 00 00 00 00 ac 02  ab 02 00 00 00 00 00 00  |................|
00000130  01 00 74 09 00 00 00 00  00 00 00 00 64 03 ab 01  |..t.........d...|
00000140  00 00 00 00 00 00 82 01  74 0b 00 00 00 00 00 00  |........t.......|
00000150  00 00 6a 0c 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
00000160  00 00 00 00 00 00 64 04  ac 05 ab 01 00 00 00 00  |......d.........|
00000170  00 00 7d 01 7c 01 6a 0f  00 00 00 00 00 00 00 00  |..}.|.j.........|
00000180  00 00 00 00 00 00 00 00  00 00 64 06 64 07 64 08  |..........d.d.d.|
00000190  64 09 ac 0a ab 04 00 00  00 00 00 00 01 00 7c 01  |d.............|.|
000001a0  6a 11 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000001b0  00 00 00 00 7c 00 81 02  7c 00 6e 12 74 04 00 00  |....|...|.n.t...|
000001c0  00 00 00 00 00 00 6a 12  00 00 00 00 00 00 00 00  |......j.........|
000001d0  00 00 00 00 00 00 00 00  00 00 64 0b 64 00 1a 00  |..........d.d...|
000001e0  ab 01 00 00 00 00 00 00  7d 02 74 15 00 00 00 00  |........}.t.....|
000001f0  00 00 00 00 7c 02 6a 16  00 00 00 00 00 00 00 00  |....|.j.........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_lint_dependency_groups.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 409 2025-06-01 01:28:35.431978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__init__.cpython-312.pyc
33e6fc76a7485890e2017985b1ba2110fe2e1e83bae24851deddae53ae3d1a1c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 fa 00 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 20 00  00 00 97 00 64 00 64 01  |...... .....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 6d 03 5a 03 6d 04  |l.m.Z.m.Z.m.Z.m.|
00000040  5a 04 01 00 64 01 5a 05  79 02 29 03 e9 01 00 00  |Z...d.Z.y.).....|
00000050  00 29 04 da 15 43 79 63  6c 69 63 44 65 70 65 6e  |.)...CyclicDepen|
00000060  64 65 6e 63 79 45 72 72  6f 72 da 16 44 65 70 65  |dencyError..Depe|
00000070  6e 64 65 6e 63 79 47 72  6f 75 70 49 6e 63 6c 75  |ndencyGroupInclu|
00000080  64 65 da 17 44 65 70 65  6e 64 65 6e 63 79 47 72  |de..DependencyGr|
00000090  6f 75 70 52 65 73 6f 6c  76 65 72 da 07 72 65 73  |oupResolver..res|
000000a0  6f 6c 76 65 4e 29 06 da  0f 5f 69 6d 70 6c 65 6d  |olveN)..._implem|
000000b0  65 6e 74 61 74 69 6f 6e  72 03 00 00 00 72 04 00  |entationr....r..|
000000c0  00 00 72 05 00 00 00 72  06 00 00 00 da 07 5f 5f  |..r....r......__|
000000d0  61 6c 6c 5f 5f a9 00 f3  00 00 00 00 fa 88 2f 64  |all__........./d|
000000e0  61 74 61 2f 64 61 74 61  2f 63 6f 6d 2e 74 65 72  |ata/data/com.ter|
000000f0  6d 75 78 2f 66 69 6c 65  73 2f 68 6f 6d 65 2f 52  |mux/files/home/R|
00000100  41 46 41 45 4c 49 41 2f  48 43 50 4d 2f 43 4f 52  |AFAELIA/HCPM/COR|
00000110  45 2f 76 65 6e 76 5f 72  61 66 61 65 6c 69 61 2f  |E/venv_rafaelia/|
00000120  6c 69 62 2f 70 79 74 68  6f 6e 33 2e 31 32 2f 73  |lib/python3.12/s|
00000130  69 74 65 2d 70 61 63 6b  61 67 65 73 2f 70 69 70  |ite-packages/pip|
00000140  2f 5f 76 65 6e 64 6f 72  2f 64 65 70 65 6e 64 65  |/_vendor/depende|
00000150  6e 63 79 5f 67 72 6f 75  70 73 2f 5f 5f 69 6e 69  |ncy_groups/__ini|
00000160  74 5f 5f 2e 70 79 da 08  3c 6d 6f 64 75 6c 65 3e  |t__.py..<module>|
00000170  72 0c 00 00 00 01 00 00  00 73 16 00 00 00 f0 03  |r........s......|
00000180  01 01 01 f7 02 05 01 02  f3 00 05 01 02 f0 0e 05  |................|
00000190  0b 02 81 07 72 0a 00 00  00                       |....r....|
00000199
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__main__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.7K 2025-06-01 01:28:35.595978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__main__.cpython-312.pyc
8e84c65dcfb4ae252db437ffb743568cd8738c2d9ca4d014c11a6f5d69ae198d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__main__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ad 06 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 4e 00  00 00 97 00 64 00 64 01  |......N.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 02 64 03  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 02 64 04 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 07 64 05  84 04 5a 06 65 07 64 06  |Z...d.d...Z.e.d.|
00000060  6b 28 00 00 72 08 02 00  65 06 ab 00 00 00 00 00  |k(..r...e.......|
00000070  00 00 01 00 79 01 79 01  29 08 e9 00 00 00 00 4e  |....y.y.)......N|
00000080  e9 01 00 00 00 29 01 da  07 72 65 73 6f 6c 76 65  |.....)...resolve|
00000090  29 01 da 07 74 6f 6d 6c  6c 69 62 63 00 00 00 00  |)...tomllibc....|
000000a0  00 00 00 00 00 00 00 00  06 00 00 00 03 00 00 00  |................|
000000b0  f3 a6 03 00 00 97 00 74  00 00 00 00 00 00 00 00  |.......t........|
000000c0  00 80 26 74 03 00 00 00  00 00 00 00 00 64 01 74  |..&t.........d.t|
000000d0  04 00 00 00 00 00 00 00  00 6a 06 00 00 00 00 00  |.........j......|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 00 ac 02 ab  |................|
000000f0  02 00 00 00 00 00 00 01  00 74 09 00 00 00 00 00  |.........t......|
00000100  00 00 00 64 03 ab 01 00  00 00 00 00 00 82 01 74  |...d...........t|
00000110  0b 00 00 00 00 00 00 00  00 6a 0c 00 00 00 00 00  |.........j......|
00000120  00 00 00 00 00 00 00 00  00 00 00 00 00 64 04 ac  |.............d..|
00000130  05 ab 01 00 00 00 00 00  00 7d 00 7c 00 6a 0f 00  |.........}.|.j..|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  00 64 06 64 07 64 08 ac  09 ab 03 00 00 00 00 00  |.d.d.d..........|
00000160  00 01 00 7c 00 6a 0f 00  00 00 00 00 00 00 00 00  |...|.j..........|
00000170  00 00 00 00 00 00 00 00  00 64 0a 64 0b 64 0c 64  |.........d.d.d.d|
00000180  0d ac 0e ab 04 00 00 00  00 00 00 01 00 7c 00 6a  |.............|.j|
00000190  0f 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  00 00 00 64 0f 64 10 64  11 ac 12 ab 03 00 00 00  |...d.d.d........|
000001b0  00 00 00 01 00 7c 00 6a  0f 00 00 00 00 00 00 00  |.....|.j........|
000001c0  00 00 00 00 00 00 00 00  00 00 00 64 13 64 14 64  |...........d.d.d|
000001d0  15 64 16 ac 17 ab 04 00  00 00 00 00 00 01 00 7c  |.d.............||
000001e0  00 6a 11 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
000001f0  00 00 00 00 00 ab 00 00  00 00 00 00 00 7d 01 74  |.............}.t|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/__main__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_implementation.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.5K 2025-06-01 01:28:35.759978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_implementation.cpython-312.pyc
11d93c67736e2edca03dbc8b4776c31310815225826ed8a92b76fc2505951e43  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_implementation.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 69 1f 00 00  |.........x3hi...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 c0 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 0e 64 05 84 04 5a 08  09 00 09 00 09 00 09 00  |d.d...Z.........|
00000070  64 0f 64 06 84 04 5a 09  65 02 6a 14 00 00 00 00  |d.d...Z.e.j.....|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 02 00  |................|
00000090  47 00 64 07 84 00 64 08  ab 02 00 00 00 00 00 00  |G.d...d.........|
000000a0  ab 00 00 00 00 00 00 00  5a 0b 02 00 47 00 64 09  |........Z...G.d.|
000000b0  84 00 64 0a 65 0c ab 03  00 00 00 00 00 00 5a 0d  |..d.e.........Z.|
000000c0  02 00 47 00 64 0b 84 00  64 0c ab 02 00 00 00 00  |..G.d...d.......|
000000d0  00 00 5a 0e 09 00 09 00  09 00 09 00 09 00 09 00  |..Z.............|
000000e0  64 10 64 0d 84 04 5a 0f  79 02 29 11 e9 00 00 00  |d.d...Z.y.).....|
000000f0  00 29 01 da 0b 61 6e 6e  6f 74 61 74 69 6f 6e 73  |.)...annotations|
00000100  4e 29 01 da 07 4d 61 70  70 69 6e 67 29 01 da 0b  |N)...Mapping)...|
00000110  52 65 71 75 69 72 65 6d  65 6e 74 63 01 00 00 00  |Requirementc....|
00000120  00 00 00 00 00 00 00 00  05 00 00 00 03 00 00 01  |................|
00000130  f3 4c 00 00 00 97 00 74  01 00 00 00 00 00 00 00  |.L.....t........|
00000140  00 6a 02 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
00000150  00 00 00 00 00 64 01 64  02 7c 00 ab 03 00 00 00  |.....d.d.|......|
00000160  00 00 00 6a 05 00 00 00  00 00 00 00 00 00 00 00  |...j............|
00000170  00 00 00 00 00 00 00 ab  00 00 00 00 00 00 00 53  |...............S|
00000180  00 29 03 4e 7a 06 5b 2d  5f 2e 5d 2b da 01 2d 29  |.).Nz.[-_.]+..-)|
00000190  03 da 02 72 65 da 03 73  75 62 da 05 6c 6f 77 65  |...re..sub..lowe|
000001a0  72 29 01 da 04 6e 61 6d  65 73 01 00 00 00 20 fa  |r)...names.... .|
000001b0  8f 2f 64 61 74 61 2f 64  61 74 61 2f 63 6f 6d 2e  |./data/data/com.|
000001c0  74 65 72 6d 75 78 2f 66  69 6c 65 73 2f 68 6f 6d  |termux/files/hom|
000001d0  65 2f 52 41 46 41 45 4c  49 41 2f 48 43 50 4d 2f  |e/RAFAELIA/HCPM/|
000001e0  43 4f 52 45 2f 76 65 6e  76 5f 72 61 66 61 65 6c  |CORE/venv_rafael|
000001f0  69 61 2f 6c 69 62 2f 70  79 74 68 6f 6e 33 2e 31  |ia/lib/python3.1|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_implementation.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_pip_wrapper.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.4K 2025-06-01 01:28:36.083978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_pip_wrapper.cpython-312.pyc
9171798ccc60dda4863695eceb002c723e216278e2b8dc18632c66b69ee1724c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_pip_wrapper.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 49 07 00 00  |.........x3hI...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |................|
00000020  00 00 00 00 01 f3 70 00  00 00 97 00 64 00 64 01  |......p.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 03 64 04 6c 05 6d 06  5a 06 01 00 64 03 64 05  |d.d.l.m.Z...d.d.|
00000060  6c 07 6d 08 5a 08 01 00  64 0a 64 06 84 04 5a 09  |l.m.Z...d.d...Z.|
00000070  64 02 64 07 9c 01 64 0b  64 08 84 06 5a 0a 65 0b  |d.d...d.d...Z.e.|
00000080  64 09 6b 28 00 00 72 08  02 00 65 0a ab 00 00 00  |d.k(..r...e.....|
00000090  00 00 00 00 01 00 79 02  79 02 29 0c e9 00 00 00  |......y.y.).....|
000000a0  00 29 01 da 0b 61 6e 6e  6f 74 61 74 69 6f 6e 73  |.)...annotations|
000000b0  4e e9 01 00 00 00 29 01  da 17 44 65 70 65 6e 64  |N.....)...Depend|
000000c0  65 6e 63 79 47 72 6f 75  70 52 65 73 6f 6c 76 65  |encyGroupResolve|
000000d0  72 29 01 da 07 74 6f 6d  6c 6c 69 62 63 01 00 00  |r)...tomllibc...|
000000e0  00 00 00 00 00 00 00 00  00 06 00 00 00 03 00 00  |................|
000000f0  01 f3 56 00 00 00 97 00  74 01 00 00 00 00 00 00  |..V.....t.......|
00000100  00 00 6a 02 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
00000110  00 00 00 00 00 00 74 04  00 00 00 00 00 00 00 00  |......t.........|
00000120  6a 06 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000130  00 00 00 00 64 01 64 02  64 03 67 04 7c 00 a2 01  |....d.d.d.g.|...|
00000140  ab 01 00 00 00 00 00 00  01 00 79 00 29 04 4e 7a  |..........y.).Nz|
00000150  02 2d 6d da 03 70 69 70  da 07 69 6e 73 74 61 6c  |.-m..pip..instal|
00000160  6c 29 04 da 0a 73 75 62  70 72 6f 63 65 73 73 da  |l)...subprocess.|
00000170  0a 63 68 65 63 6b 5f 63  61 6c 6c da 03 73 79 73  |.check_call..sys|
00000180  da 0a 65 78 65 63 75 74  61 62 6c 65 29 01 da 04  |..executable)...|
00000190  64 65 70 73 73 01 00 00  00 20 fa 8c 2f 64 61 74  |depss.... ../dat|
000001a0  61 2f 64 61 74 61 2f 63  6f 6d 2e 74 65 72 6d 75  |a/data/com.termu|
000001b0  78 2f 66 69 6c 65 73 2f  68 6f 6d 65 2f 52 41 46  |x/files/home/RAF|
000001c0  41 45 4c 49 41 2f 48 43  50 4d 2f 43 4f 52 45 2f  |AELIA/HCPM/CORE/|
000001d0  76 65 6e 76 5f 72 61 66  61 65 6c 69 61 2f 6c 69  |venv_rafaelia/li|
000001e0  62 2f 70 79 74 68 6f 6e  33 2e 31 32 2f 73 69 74  |b/python3.12/sit|
000001f0  65 2d 70 61 63 6b 61 67  65 73 2f 70 69 70 2f 5f  |e-packages/pip/_|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_pip_wrapper.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_toml_compat.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 510 2025-06-01 01:28:36.239978167 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_toml_compat.cpython-312.pyc
ab3dd750be0a6cefcf63e116e2480b2dc4911aef2ed7536c4bed0b4607653cdd  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_toml_compat.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 1d 01 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 56 00  00 00 97 00 09 00 64 00  |......V.......d.|
00000030  64 01 6c 00 5a 00 64 03  5a 05 79 01 23 00 65 01  |d.l.Z.d.Z.y.#.e.|
00000040  24 00 72 1a 01 00 09 00  64 00 64 02 6c 02 6d 03  |$.r.....d.d.l.m.|
00000050  5a 00 01 00 6e 0d 23 00  65 04 24 00 72 05 01 00  |Z...n.#.e.$.r...|
00000060  64 01 5a 00 59 00 6e 04  77 00 78 03 59 00 77 01  |d.Z.Y.n.w.x.Y.w.|
00000070  59 00 64 03 5a 05 79 01  77 00 78 03 59 00 77 01  |Y.d.Z.y.w.x.Y.w.|
00000080  29 04 e9 00 00 00 00 4e  29 01 da 05 74 6f 6d 6c  |)......N)...toml|
00000090  69 29 01 da 07 74 6f 6d  6c 6c 69 62 29 06 72 04  |i)...tomllib).r.|
000000a0  00 00 00 da 0b 49 6d 70  6f 72 74 45 72 72 6f 72  |.....ImportError|
000000b0  da 0b 70 69 70 2e 5f 76  65 6e 64 6f 72 72 03 00  |..pip._vendorr..|
000000c0  00 00 da 13 4d 6f 64 75  6c 65 4e 6f 74 46 6f 75  |....ModuleNotFou|
000000d0  6e 64 45 72 72 6f 72 da  07 5f 5f 61 6c 6c 5f 5f  |ndError..__all__|
000000e0  a9 00 f3 00 00 00 00 fa  8c 2f 64 61 74 61 2f 64  |........./data/d|
000000f0  61 74 61 2f 63 6f 6d 2e  74 65 72 6d 75 78 2f 66  |ata/com.termux/f|
00000100  69 6c 65 73 2f 68 6f 6d  65 2f 52 41 46 41 45 4c  |iles/home/RAFAEL|
00000110  49 41 2f 48 43 50 4d 2f  43 4f 52 45 2f 76 65 6e  |IA/HCPM/CORE/ven|
00000120  76 5f 72 61 66 61 65 6c  69 61 2f 6c 69 62 2f 70  |v_rafaelia/lib/p|
00000130  79 74 68 6f 6e 33 2e 31  32 2f 73 69 74 65 2d 70  |ython3.12/site-p|
00000140  61 63 6b 61 67 65 73 2f  70 69 70 2f 5f 76 65 6e  |ackages/pip/_ven|
00000150  64 6f 72 2f 64 65 70 65  6e 64 65 6e 63 79 5f 67  |dor/dependency_g|
00000160  72 6f 75 70 73 2f 5f 74  6f 6d 6c 5f 63 6f 6d 70  |roups/_toml_comp|
00000170  61 74 2e 70 79 da 08 3c  6d 6f 64 75 6c 65 3e 72  |at.py..<module>r|
00000180  0c 00 00 00 01 00 00 00  73 48 00 00 00 f0 03 01  |........sH......|
00000190  01 01 f0 02 06 01 17 db  04 12 f0 0e 00 0b 17 81  |................|
000001a0  07 f8 f0 0d 00 08 13 f2  00 04 01 17 f0 02 03 05  |................|
000001b0  17 de 08 30 f8 d8 0b 1e  f2 00 01 05 17 d8 12 16  |...0............|
000001c0  8a 07 f0 03 01 05 17 fb  f0 06 00 0b 17 81 07 f0  |................|
000001d0  0d 04 01 17 fa 73 24 00  00 00 82 04 09 00 89 05  |.....s$.........|
000001e0  28 03 8f 06 16 02 95 01  28 03 96 07 20 05 9d 02  |(.......(... ...|
000001f0  28 03 9f 01 20 05 a0 03  28 03 a7 01 28 03        |(... ...(...(.|
000001fe
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/dependency_groups/__pycache__/_toml_compat.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.3K 2025-06-01 01:28:36.403978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/__init__.cpython-312.pyc
8643fbcc3b7f62151c467a54f5639405d001d9d874c8b7098e8ced9bdb52136b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 71 02 00 00  |.........x3hq...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 c4 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 02 5a 01  02 00 47 00 64 03 84 00  |l.Z.d.Z...G.d...|
00000040  64 04 65 02 ab 03 00 00  00 00 00 00 5a 03 09 00  |d.e.........Z...|
00000050  64 00 64 05 6c 00 6d 04  5a 04 01 00 02 00 65 00  |d.d.l.m.Z.....e.|
00000060  6a 0e 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000070  00 00 00 00 65 08 ab 01  00 00 00 00 00 00 5a 09  |....e.........Z.|
00000080  65 09 6a 15 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000090  00 00 00 00 00 00 02 00  65 04 ab 00 00 00 00 00  |........e.......|
000000a0  00 00 ab 01 00 00 00 00  00 00 01 00 79 01 23 00  |............y.#.|
000000b0  65 05 24 00 72 18 01 00  02 00 47 00 64 06 84 00  |e.$.r.....G.d...|
000000c0  64 07 65 00 6a 0c 00 00  00 00 00 00 00 00 00 00  |d.e.j...........|
000000d0  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
000000e0  5a 04 59 00 8c 45 77 00  78 03 59 00 77 01 29 08  |Z.Y..Ew.x.Y.w.).|
000000f0  e9 00 00 00 00 4e 7a 05  30 2e 33 2e 39 63 00 00  |.....Nz.0.3.9c..|
00000100  00 00 00 00 00 00 00 00  00 00 01 00 00 00 00 00  |................|
00000110  00 00 f3 0c 00 00 00 97  00 65 00 5a 01 64 00 5a  |.........e.Z.d.Z|
00000120  02 79 01 29 02 da 10 44  69 73 74 6c 69 62 45 78  |.y.)...DistlibEx|
00000130  63 65 70 74 69 6f 6e 4e  29 03 da 08 5f 5f 6e 61  |ceptionN)...__na|
00000140  6d 65 5f 5f da 0a 5f 5f  6d 6f 64 75 6c 65 5f 5f  |me__..__module__|
00000150  da 0c 5f 5f 71 75 61 6c  6e 61 6d 65 5f 5f a9 00  |..__qualname__..|
00000160  f3 00 00 00 00 fa 7e 2f  64 61 74 61 2f 64 61 74  |......~/data/dat|
00000170  61 2f 63 6f 6d 2e 74 65  72 6d 75 78 2f 66 69 6c  |a/com.termux/fil|
00000180  65 73 2f 68 6f 6d 65 2f  52 41 46 41 45 4c 49 41  |es/home/RAFAELIA|
00000190  2f 48 43 50 4d 2f 43 4f  52 45 2f 76 65 6e 76 5f  |/HCPM/CORE/venv_|
000001a0  72 61 66 61 65 6c 69 61  2f 6c 69 62 2f 70 79 74  |rafaelia/lib/pyt|
000001b0  68 6f 6e 33 2e 31 32 2f  73 69 74 65 2d 70 61 63  |hon3.12/site-pac|
000001c0  6b 61 67 65 73 2f 70 69  70 2f 5f 76 65 6e 64 6f  |kages/pip/_vendo|
000001d0  72 2f 64 69 73 74 6c 69  62 2f 5f 5f 69 6e 69 74  |r/distlib/__init|
000001e0  5f 5f 2e 70 79 72 04 00  00 00 72 04 00 00 00 0c  |__.pyr....r.....|
000001f0  00 00 00 73 05 00 00 00  84 00 d8 04 08 72 09 00  |...s.........r..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/compat.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 45K 2025-06-01 01:28:36.587978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/compat.cpython-312.pyc
1b0f02dbc02d91bc168941f7801405f0ddb0e4a17c45283a4b800a5e4c01414a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/compat.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 fb a1 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 b2 07  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 05 5a 05  09 00 64 00 64 02 6c 06  |d.d.l.Z...d.d.l.|
00000060  5a 06 65 05 6a 10 00 00  00 00 00 00 00 00 00 00  |Z.e.j...........|
00000070  00 00 00 00 00 00 00 00  64 00 19 00 00 00 64 03  |........d.....d.|
00000080  6b 02 00 00 72 83 64 00  64 04 6c 09 6d 09 5a 09  |k...r.d.d.l.m.Z.|
00000090  01 00 65 0a 66 01 5a 0b  65 0c 5a 0d 64 00 64 05  |..e.f.Z.e.Z.d.d.|
000000a0  6c 0e 6d 0f 5a 10 01 00  64 00 64 02 6c 11 5a 12  |l.m.Z...d.d.l.Z.|
000000b0  64 00 64 02 6c 13 5a 14  64 00 64 06 6c 15 6d 15  |d.d.l.Z.d.d.l.m.|
000000c0  5a 15 6d 16 5a 16 6d 17  5a 17 6d 18 5a 18 6d 19  |Z.m.Z.m.Z.m.Z.m.|
000000d0  5a 19 01 00 64 00 64 07  6c 1a 6d 1b 5a 1b 6d 1c  |Z...d.d.l.m.Z.m.|
000000e0  5a 1d 6d 1e 5a 1e 6d 1f  5a 1f 6d 20 5a 20 6d 21  |Z.m.Z.m.Z.m Z m!|
000000f0  5a 21 6d 22 5a 22 01 00  64 08 84 00 5a 1c 64 00  |Z!m"Z"..d...Z.d.|
00000100  64 02 6c 23 5a 23 64 00  64 09 6c 23 6d 24 5a 24  |d.l#Z#d.d.l#m$Z$|
00000110  6d 25 5a 25 6d 26 5a 26  6d 27 5a 27 6d 28 5a 28  |m%Z%m&Z&m'Z'm(Z(|
00000120  6d 29 5a 29 6d 2a 5a 2a  6d 2b 5a 2b 6d 2c 5a 2c  |m)Z)m*Z*m+Z+m,Z,|
00000130  01 00 65 06 72 06 64 00  64 0a 6c 23 6d 2d 5a 2d  |..e.r.d.d.l#m-Z-|
00000140  01 00 64 00 64 02 6c 2e  5a 2e 64 00 64 02 6c 2f  |..d.d.l.Z.d.d.l/|
00000150  5a 2f 64 00 64 02 6c 30  5a 31 64 00 64 0b 6c 32  |Z/d.d.l0Z1d.d.l2|
00000160  6d 32 5a 32 01 00 64 00  64 02 6c 33 5a 33 65 34  |m2Z2..d.d.l3Z3e4|
00000170  5a 34 64 00 64 0c 6c 35  6d 36 5a 37 01 00 64 00  |Z4d.d.l5m6Z7..d.|
00000180  64 0d 6c 35 6d 38 5a 39  01 00 6e 83 64 00 64 04  |d.l5m8Z9..n.d.d.|
00000190  6c 3a 6d 09 5a 09 01 00  65 3b 66 01 5a 0b 65 3b  |l:m.Z...e;f.Z.e;|
000001a0  5a 0d 64 00 64 0e 6c 3a  6d 3c 5a 10 01 00 64 00  |Z.d.d.l:m<Z...d.|
000001b0  64 02 6c 12 5a 12 64 00  64 02 6c 14 5a 14 64 00  |d.l.Z.d.d.l.Z.d.|
000001c0  64 0f 6c 3d 6d 15 5a 15  6d 16 5a 16 6d 17 5a 17  |d.l=m.Z.m.Z.m.Z.|
000001d0  6d 1c 5a 1c 6d 1e 5a 1e  6d 18 5a 18 6d 19 5a 19  |m.Z.m.Z.m.Z.m.Z.|
000001e0  6d 22 5a 22 01 00 64 00  64 10 6c 3e 6d 25 5a 25  |m"Z"..d.d.l>m%Z%|
000001f0  6d 1b 5a 1b 6d 24 5a 24  6d 1f 5a 1f 6d 20 5a 20  |m.Z.m$Z$m.Z.m Z |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/compat.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/database.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 65K 2025-06-01 01:28:36.771978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/database.cpython-312.pyc
4e22e773f7aefde6a5ca64ec7e1fccf6e4c3996e7bd79e3e86598f688befe449  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/database.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 d8 c7 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 ca 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 01 64 03  6c 06 5a 06 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 5a 07 64 01 64 03  6c 08 5a 08 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000070  6c 09 5a 09 64 01 64 03  6c 0a 5a 0a 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000080  6c 0b 5a 0b 64 04 64 05  6c 0c 6d 0d 5a 0d 6d 0e  |l.Z.d.d.l.m.Z.m.|
00000090  5a 0e 01 00 64 04 64 06  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
000000a0  64 04 64 07 6c 11 6d 12  5a 12 6d 13 5a 13 01 00  |d.d.l.m.Z.m.Z...|
000000b0  64 04 64 08 6c 14 6d 15  5a 15 6d 16 5a 16 6d 17  |d.d.l.m.Z.m.Z.m.|
000000c0  5a 17 6d 18 5a 18 01 00  64 04 64 09 6c 19 6d 1a  |Z.m.Z...d.d.l.m.|
000000d0  5a 1a 6d 1b 5a 1b 6d 1c  5a 1c 6d 1d 5a 1d 6d 1e  |Z.m.Z.m.Z.m.Z.m.|
000000e0  5a 1e 6d 1f 5a 1f 6d 20  5a 20 01 00 67 00 64 0a  |Z.m.Z.m Z ..g.d.|
000000f0  a2 01 5a 21 02 00 65 07  6a 44 00 00 00 00 00 00  |..Z!..e.jD......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 65 23 ab 01  |............e#..|
00000110  00 00 00 00 00 00 5a 24  64 0b 5a 25 64 0c 5a 26  |......Z$d.Z%d.Z&|
00000120  64 0d 65 16 64 0e 64 0f  64 10 65 25 64 11 66 07  |d.e.d.d.d.e%d.f.|
00000130  5a 27 64 12 5a 28 02 00  47 00 64 13 84 00 64 14  |Z'd.Z(..G.d...d.|
00000140  65 29 ab 03 00 00 00 00  00 00 5a 2a 02 00 47 00  |e)........Z*..G.|
00000150  64 15 84 00 64 16 65 29  ab 03 00 00 00 00 00 00  |d...d.e)........|
00000160  5a 2b 02 00 47 00 64 17  84 00 64 18 65 29 ab 03  |Z+..G.d...d.e)..|
00000170  00 00 00 00 00 00 5a 2c  02 00 47 00 64 19 84 00  |......Z,..G.d...|
00000180  64 1a 65 2c ab 03 00 00  00 00 00 00 5a 2d 02 00  |d.e,........Z-..|
00000190  47 00 64 1b 84 00 64 1c  65 2d ab 03 00 00 00 00  |G.d...d.e-......|
000001a0  00 00 5a 2e 02 00 47 00  64 1d 84 00 64 1e 65 2d  |..Z...G.d...d.e-|
000001b0  ab 03 00 00 00 00 00 00  5a 2f 65 2e 5a 30 65 2f  |........Z/e.Z0e/|
000001c0  5a 31 02 00 47 00 64 1f  84 00 64 20 65 29 ab 03  |Z1..G.d...d e)..|
000001d0  00 00 00 00 00 00 5a 32  64 25 64 21 84 01 5a 33  |......Z2d%d!..Z3|
000001e0  64 22 84 00 5a 34 64 23  84 00 5a 35 64 24 84 00  |d"..Z4d#..Z5d$..|
000001f0  5a 36 79 03 29 26 7a 17  50 45 50 20 33 37 36 20  |Z6y.)&z.PEP 376 |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/database.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/index.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 24K 2025-06-01 01:28:36.939978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/index.cpython-312.pyc
62ed7bd0d9e351dd0792723c9babcafb55707b972445891b31379dd09bce3b69  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/index.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 3d 51 00 00  |.........x3h=Q..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 e2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 09 00 64 00  |l.Z.d.d.l.Z...d.|
00000060  64 02 6c 06 6d 07 5a 07  01 00 64 03 64 04 6c 0a  |d.l.m.Z...d.d.l.|
00000070  6d 0b 5a 0b 01 00 64 03  64 05 6c 0c 6d 0d 5a 0d  |m.Z...d.d.l.m.Z.|
00000080  6d 0e 5a 0e 6d 0f 5a 0f  6d 10 5a 10 6d 11 5a 11  |m.Z.m.Z.m.Z.m.Z.|
00000090  6d 12 5a 12 01 00 64 03  64 06 6c 13 6d 14 5a 14  |m.Z...d.d.l.m.Z.|
000000a0  6d 15 5a 15 01 00 02 00  65 01 6a 2c 00 00 00 00  |m.Z.....e.j,....|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 65 17  |..............e.|
000000c0  ab 01 00 00 00 00 00 00  5a 18 64 07 5a 19 64 08  |........Z.d.Z.d.|
000000d0  5a 1a 02 00 47 00 64 09  84 00 64 0a 65 1b ab 03  |Z...G.d...d.e...|
000000e0  00 00 00 00 00 00 5a 1c  79 01 23 00 65 08 24 00  |......Z.y.#.e.$.|
000000f0  72 09 01 00 64 00 64 02  6c 09 6d 07 5a 07 01 00  |r...d.d.l.m.Z...|
00000100  59 00 8c 4d 77 00 78 03  59 00 77 01 29 0b e9 00  |Y..Mw.x.Y.w.)...|
00000110  00 00 00 4e 29 01 da 06  54 68 72 65 61 64 e9 01  |...N)...Thread..|
00000120  00 00 00 29 01 da 10 44  69 73 74 6c 69 62 45 78  |...)...DistlibEx|
00000130  63 65 70 74 69 6f 6e 29  06 da 14 48 54 54 50 42  |ception)...HTTPB|
00000140  61 73 69 63 41 75 74 68  48 61 6e 64 6c 65 72 da  |asicAuthHandler.|
00000150  07 52 65 71 75 65 73 74  da 0f 48 54 54 50 50 61  |.Request..HTTPPa|
00000160  73 73 77 6f 72 64 4d 67  72 da 08 75 72 6c 70 61  |sswordMgr..urlpa|
00000170  72 73 65 da 0c 62 75 69  6c 64 5f 6f 70 65 6e 65  |rse..build_opene|
00000180  72 da 0c 73 74 72 69 6e  67 5f 74 79 70 65 73 29  |r..string_types)|
00000190  02 da 07 7a 69 70 5f 64  69 72 da 0b 53 65 72 76  |...zip_dir..Serv|
000001a0  65 72 50 72 6f 78 79 7a  15 68 74 74 70 73 3a 2f  |erProxyz.https:/|
000001b0  2f 70 79 70 69 2e 6f 72  67 2f 70 79 70 69 da 04  |/pypi.org/pypi..|
000001c0  70 79 70 69 63 00 00 00  00 00 00 00 00 00 00 00  |pypic...........|
000001d0  00 02 00 00 00 00 00 00  00 f3 9a 00 00 00 97 00  |................|
000001e0  65 00 5a 01 64 00 5a 02  64 01 5a 03 64 02 5a 04  |e.Z.d.Z.d.Z.d.Z.|
000001f0  64 16 64 04 84 01 5a 05  64 05 84 00 5a 06 64 06  |d.d...Z.d...Z.d.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/index.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/locators.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 59K 2025-06-01 01:28:37.111978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/locators.cpython-312.pyc
2ec0a5f437aef4a0568d23766cc3963c280783dca1fd866710b28bdf4068fefa  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/locators.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 69 c7 00 00  |........R.5hi...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 0a 03  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 01 6c 03 5a 03  64 00 64 01 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 01 6c 05 5a 05  64 00 64 01 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 01 6c 07 5a 07  09 00 64 00 64 01 6c 08  |d.d.l.Z...d.d.l.|
00000070  5a 08 64 00 64 01 6c 0b  5a 0b 64 03 64 04 6c 0c  |Z.d.d.l.Z.d.d.l.|
00000080  6d 0d 5a 0d 01 00 64 03  64 05 6c 0e 6d 0f 5a 0f  |m.Z...d.d.l.m.Z.|
00000090  6d 10 5a 10 6d 11 5a 11  6d 12 5a 12 6d 13 5a 13  |m.Z.m.Z.m.Z.m.Z.|
000000a0  6d 14 5a 14 6d 15 5a 15  6d 16 5a 16 6d 17 5a 17  |m.Z.m.Z.m.Z.m.Z.|
000000b0  6d 18 5a 19 6d 1a 5a 1a  6d 1b 5a 1b 6d 1c 5a 1c  |m.Z.m.Z.m.Z.m.Z.|
000000c0  6d 1d 5a 1d 01 00 64 03  64 06 6c 1e 6d 1f 5a 1f  |m.Z...d.d.l.m.Z.|
000000d0  6d 20 5a 20 6d 21 5a 21  01 00 64 03 64 07 6c 22  |m Z m!Z!..d.d.l"|
000000e0  6d 23 5a 23 6d 24 5a 24  01 00 64 03 64 08 6c 25  |m#Z#m$Z$..d.d.l%|
000000f0  6d 26 5a 26 6d 27 5a 27  6d 28 5a 28 6d 29 5a 29  |m&Z&m'Z'm(Z(m)Z)|
00000100  6d 2a 5a 2a 6d 2b 5a 2b  6d 2c 5a 2c 6d 2d 5a 2d  |m*Z*m+Z+m,Z,m-Z-|
00000110  01 00 64 03 64 09 6c 2e  6d 2f 5a 2f 6d 30 5a 30  |..d.d.l.m/Z/m0Z0|
00000120  01 00 64 03 64 0a 6c 31  6d 32 5a 32 6d 33 5a 33  |..d.d.l1m2Z2m3Z3|
00000130  01 00 02 00 65 04 6a 68  00 00 00 00 00 00 00 00  |....e.jh........|
00000140  00 00 00 00 00 00 00 00  00 00 65 35 ab 01 00 00  |..........e5....|
00000150  00 00 00 00 5a 36 02 00  65 07 6a 6e 00 00 00 00  |....Z6..e.jn....|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 0b  |..............d.|
00000170  ab 01 00 00 00 00 00 00  5a 38 02 00 65 07 6a 6e  |........Z8..e.jn|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  00 00 64 0c 65 07 6a 72  00 00 00 00 00 00 00 00  |..d.e.jr........|
000001a0  00 00 00 00 00 00 00 00  00 00 ab 02 00 00 00 00  |................|
000001b0  00 00 5a 3a 02 00 65 07  6a 6e 00 00 00 00 00 00  |..Z:..e.jn......|
000001c0  00 00 00 00 00 00 00 00  00 00 00 00 64 0d ab 01  |............d...|
000001d0  00 00 00 00 00 00 5a 3b  64 0e 5a 3c 64 2b 64 0f  |......Z;d.Z<d+d.|
000001e0  84 01 5a 3d 02 00 47 00  64 10 84 00 64 11 65 19  |..Z=..G.d...d.e.|
000001f0  ab 03 00 00 00 00 00 00  5a 3e 02 00 47 00 64 12  |........Z>..G.d.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/locators.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/manifest.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 15K 2025-06-01 01:28:37.279978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/manifest.cpython-312.pyc
ee799b44c14810bfa4dd9bb8997eb3d14ee88e4d6922e7f44610a248d25896cc  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/manifest.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 58 37 00 00  |.........x3hX7..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 40 01  00 00 97 00 64 00 5a 00  |......@.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 03 64 04 6c 06 6d 07  |d.d.l.Z.d.d.l.m.|
00000060  5a 07 01 00 64 03 64 05  6c 08 6d 09 5a 09 01 00  |Z...d.d.l.m.Z...|
00000070  64 03 64 06 6c 0a 6d 0b  5a 0b 01 00 64 07 67 01  |d.d.l.m.Z...d.g.|
00000080  5a 0c 02 00 65 02 6a 1a  00 00 00 00 00 00 00 00  |Z...e.j.........|
00000090  00 00 00 00 00 00 00 00  00 00 65 0e ab 01 00 00  |..........e.....|
000000a0  00 00 00 00 5a 0f 02 00  65 04 6a 20 00 00 00 00  |....Z...e.j ....|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 08  |..............d.|
000000c0  65 04 6a 22 00 00 00 00  00 00 00 00 00 00 00 00  |e.j"............|
000000d0  00 00 00 00 00 00 ab 02  00 00 00 00 00 00 5a 12  |..............Z.|
000000e0  02 00 65 04 6a 20 00 00  00 00 00 00 00 00 00 00  |..e.j ..........|
000000f0  00 00 00 00 00 00 00 00  64 09 65 04 6a 22 00 00  |........d.e.j"..|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000110  65 04 6a 26 00 00 00 00  00 00 00 00 00 00 00 00  |e.j&............|
00000120  00 00 00 00 00 00 7a 07  00 00 ab 02 00 00 00 00  |......z.........|
00000130  00 00 5a 14 65 05 6a 2a  00 00 00 00 00 00 00 00  |..Z.e.j*........|
00000140  00 00 00 00 00 00 00 00  00 00 64 02 64 0a 1a 00  |..........d.d...|
00000150  5a 16 02 00 47 00 64 0b  84 00 64 07 65 17 ab 03  |Z...G.d...d.e...|
00000160  00 00 00 00 00 00 5a 18  79 02 29 0c 7a 75 0a 43  |......Z.y.).zu.C|
00000170  6c 61 73 73 20 72 65 70  72 65 73 65 6e 74 69 6e  |lass representin|
00000180  67 20 74 68 65 20 6c 69  73 74 20 6f 66 20 66 69  |g the list of fi|
00000190  6c 65 73 20 69 6e 20 61  20 64 69 73 74 72 69 62  |les in a distrib|
000001a0  75 74 69 6f 6e 2e 0a 0a  45 71 75 69 76 61 6c 65  |ution...Equivale|
000001b0  6e 74 20 74 6f 20 64 69  73 74 75 74 69 6c 73 2e  |nt to distutils.|
000001c0  66 69 6c 65 6c 69 73 74  2c 20 62 75 74 20 66 69  |filelist, but fi|
000001d0  78 65 73 20 73 6f 6d 65  20 70 72 6f 62 6c 65 6d  |xes some problem|
000001e0  73 2e 0a e9 00 00 00 00  4e e9 01 00 00 00 29 01  |s.......N.....).|
000001f0  da 10 44 69 73 74 6c 69  62 45 78 63 65 70 74 69  |..DistlibExcepti|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/manifest.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/markers.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.6K 2025-06-01 01:28:37.443978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/markers.cpython-312.pyc
46c6ff7f0cd3543d3f7d60b0ce8f77087940593311fb5d27cc0e0224e024aa55  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/markers.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 2c 14 00 00  |.........x3h,...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 fa 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 03 64 04 6c 05 6d 06  5a 06 01 00 64 03 64 05  |d.d.l.m.Z...d.d.|
00000060  6c 07 6d 08 5a 08 6d 09  5a 09 01 00 64 03 64 06  |l.m.Z.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0c 01 00  64 07 67 01 5a 0d 02 00  |l.m.Z...d.g.Z...|
00000080  65 02 6a 1c 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000090  00 00 00 00 00 00 64 08  ab 01 00 00 00 00 00 00  |......d.........|
000000a0  5a 0f 64 09 64 0a 68 02  5a 10 64 0b 84 00 5a 11  |Z.d.d.h.Z.d...Z.|
000000b0  64 0c 84 00 5a 12 64 0d  84 00 5a 13 02 00 47 00  |d...Z.d...Z...G.|
000000c0  64 0e 84 00 64 0f 65 14  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000d0  5a 15 02 00 65 02 6a 1c  00 00 00 00 00 00 00 00  |Z...e.j.........|
000000e0  00 00 00 00 00 00 00 00  00 00 64 10 ab 01 00 00  |..........d.....|
000000f0  00 00 00 00 5a 16 64 11  84 00 5a 17 02 00 65 17  |....Z.d...Z...e.|
00000100  ab 00 00 00 00 00 00 00  5a 18 5b 17 02 00 65 15  |........Z.[...e.|
00000110  ab 00 00 00 00 00 00 00  5a 19 64 13 64 12 84 01  |........Z.d.d...|
00000120  5a 1a 79 02 29 14 7a 47  0a 50 61 72 73 65 72 20  |Z.y.).zG.Parser |
00000130  66 6f 72 20 74 68 65 20  65 6e 76 69 72 6f 6e 6d  |for the environm|
00000140  65 6e 74 20 6d 61 72 6b  65 72 73 20 6d 69 63 72  |ent markers micr|
00000150  6f 2d 6c 61 6e 67 75 61  67 65 20 64 65 66 69 6e  |o-language defin|
00000160  65 64 20 69 6e 20 50 45  50 20 35 30 38 2e 0a e9  |ed in PEP 508...|
00000170  00 00 00 00 4e e9 01 00  00 00 29 01 da 0c 73 74  |....N.....)...st|
00000180  72 69 6e 67 5f 74 79 70  65 73 29 02 da 07 69 6e  |ring_types)...in|
00000190  5f 76 65 6e 76 da 0c 70  61 72 73 65 5f 6d 61 72  |_venv..parse_mar|
000001a0  6b 65 72 29 01 da 0d 4c  65 67 61 63 79 56 65 72  |ker)...LegacyVer|
000001b0  73 69 6f 6e da 09 69 6e  74 65 72 70 72 65 74 7a  |sion..interpretz|
000001c0  3c 28 28 5c 64 2b 28 5c  2e 5c 64 2b 29 2a 5c 77  |<((\d+(\.\d+)*\w|
000001d0  2a 29 7c 5c 27 28 5c 64  2b 28 5c 2e 5c 64 2b 29  |*)|\'(\d+(\.\d+)|
000001e0  2a 5c 77 2a 29 5c 27 7c  5c 22 28 5c 64 2b 28 5c  |*\w*)\'|\"(\d+(\|
000001f0  2e 5c 64 2b 29 2a 5c 77  2a 29 5c 22 29 da 0e 70  |.\d+)*\w*)\")..p|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/markers.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/metadata.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 41K 2025-06-01 01:28:37.631978166 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/metadata.cpython-312.pyc
94ed9f679d52a57c3f42f4dccdc0a916269012a2bfd6a868f0e5707c72a6ad54  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/metadata.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 5b 97 00 00  |........R.5h[...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 f0 03  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 04  6c 04 6d 05 5a 05 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 01 64 03 6c 06 5a 06  64 01 64 03 6c 07 5a 07  |d.d.l.Z.d.d.l.Z.|
00000060  64 01 64 03 6c 08 5a 08  64 05 64 06 6c 09 6d 0a  |d.d.l.Z.d.d.l.m.|
00000070  5a 0a 6d 0b 5a 0b 01 00  64 05 64 07 6c 0c 6d 0d  |Z.m.Z...d.d.l.m.|
00000080  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 01 00 64 05 64 08  |Z.m.Z.m.Z...d.d.|
00000090  6c 10 6d 11 5a 11 01 00  64 05 64 09 6c 12 6d 13  |l.m.Z...d.d.l.m.|
000000a0  5a 13 6d 14 5a 14 01 00  64 05 64 0a 6c 15 6d 16  |Z.m.Z...d.d.l.m.|
000000b0  5a 16 6d 17 5a 17 01 00  02 00 65 07 6a 30 00 00  |Z.m.Z.....e.j0..|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000d0  65 19 ab 01 00 00 00 00  00 00 5a 1a 02 00 47 00  |e.........Z...G.|
000000e0  64 0b 84 00 64 0c 65 0a  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000f0  5a 1b 02 00 47 00 64 0d  84 00 64 0e 65 0a ab 03  |Z...G.d...d.e...|
00000100  00 00 00 00 00 00 5a 1c  02 00 47 00 64 0f 84 00  |......Z...G.d...|
00000110  64 10 65 0a ab 03 00 00  00 00 00 00 5a 1d 02 00  |d.e.........Z...|
00000120  47 00 64 11 84 00 64 12  65 0a ab 03 00 00 00 00  |G.d...d.e.......|
00000130  00 00 5a 1e 67 00 64 13  a2 01 5a 1f 64 14 5a 20  |..Z.g.d...Z.d.Z |
00000140  64 15 5a 21 02 00 65 08  6a 44 00 00 00 00 00 00  |d.Z!..e.jD......|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 64 16 ab 01  |............d...|
00000160  00 00 00 00 00 00 5a 23  02 00 65 08 6a 44 00 00  |......Z#..e.jD..|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000180  64 17 ab 01 00 00 00 00  00 00 5a 24 64 18 5a 25  |d.........Z$d.Z%|
00000190  64 19 5a 26 64 1a 5a 27  64 1b 5a 28 64 1c 5a 29  |d.Z&d.Z'd.Z(d.Z)|
000001a0  64 1d 5a 2a 64 1e 5a 2b  65 2a 64 1f 7a 00 00 00  |d.Z*d.Z+e*d.z...|
000001b0  5a 2c 64 20 5a 2d 64 21  5a 2e 65 2c 65 2e 7a 00  |Z,d Z-d!Z.e,e.z.|
000001c0  00 00 5a 2f 02 00 65 30  ab 00 00 00 00 00 00 00  |..Z/..e0........|
000001d0  5a 31 65 31 6a 65 00 00  00 00 00 00 00 00 00 00  |Z1e1je..........|
000001e0  00 00 00 00 00 00 00 00  65 25 ab 01 00 00 00 00  |........e%......|
000001f0  00 00 01 00 65 31 6a 65  00 00 00 00 00 00 00 00  |....e1je........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/metadata.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/resources.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 17K 2025-06-01 01:28:37.795978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/resources.cpython-312.pyc
5eb58155147c6ef3ddb0c00c5896108c58b954f174539a7dd98e7d9f2fc3e8d3  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/resources.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 44 2a 00 00  |.........x3hD*..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 2e 02  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 05 5a 05  64 00 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 02 6c 07 5a 07  64 00 64 02 6c 08 5a 08  |d.d.l.Z.d.d.l.Z.|
00000070  64 00 64 02 6c 09 5a 09  64 03 64 04 6c 0a 6d 0b  |d.d.l.Z.d.d.l.m.|
00000080  5a 0b 01 00 64 03 64 05  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000090  5a 0e 6d 0f 5a 0f 01 00  02 00 65 04 6a 20 00 00  |Z.m.Z.....e.j ..|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  65 11 ab 01 00 00 00 00  00 00 5a 12 64 02 61 13  |e.........Z.d.a.|
000000c0  02 00 47 00 64 06 84 00  64 07 65 0f ab 03 00 00  |..G.d...d.e.....|
000000d0  00 00 00 00 5a 14 02 00  47 00 64 08 84 00 64 09  |....Z...G.d...d.|
000000e0  65 15 ab 03 00 00 00 00  00 00 5a 16 02 00 47 00  |e.........Z...G.|
000000f0  64 0a 84 00 64 0b 65 16  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000100  5a 17 02 00 47 00 64 0c  84 00 64 0d 65 16 ab 03  |Z...G.d...d.e...|
00000110  00 00 00 00 00 00 5a 18  02 00 47 00 64 0e 84 00  |......Z...G.d...|
00000120  64 0f 65 15 ab 03 00 00  00 00 00 00 5a 19 02 00  |d.e.........Z...|
00000130  47 00 64 10 84 00 64 11  65 19 ab 03 00 00 00 00  |G.d...d.e.......|
00000140  00 00 5a 1a 02 00 65 1b  64 02 ab 01 00 00 00 00  |..Z...e.d.......|
00000150  00 00 65 19 65 09 6a 38  00 00 00 00 00 00 00 00  |..e.e.j8........|
00000160  00 00 00 00 00 00 00 00  00 00 65 1a 69 02 5a 1d  |..........e.i.Z.|
00000170  09 00 09 00 64 00 64 02  6c 1e 5a 1f 65 19 65 1d  |....d.d.l.Z.e.e.|
00000180  65 1f 6a 44 00 00 00 00  00 00 00 00 00 00 00 00  |e.jD............|
00000190  00 00 00 00 00 00 3c 00  00 00 65 19 65 1d 65 1f  |......<...e.e.e.|
000001a0  6a 46 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jF..............|
000001b0  00 00 00 00 3c 00 00 00  65 19 65 1d 65 1f 6a 48  |....<...e.e.e.jH|
000001c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001d0  00 00 3c 00 00 00 5b 1f  64 12 84 00 5a 26 69 00  |..<...[.d...Z&i.|
000001e0  5a 27 64 13 84 00 5a 28  02 00 65 08 6a 52 00 00  |Z'd...Z(..e.jR..|
000001f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/resources.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/scripts.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 20K 2025-06-01 01:28:37.959978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/scripts.cpython-312.pyc
233c3c91c5bc7d478605ca28b4c76c217c1fd94be81850df5960c232738cfe21  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/scripts.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 b0 48 00 00  |.........x3h.H..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 50 02  00 00 97 00 64 00 64 01  |......P.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 05 5a 05  64 00 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 02 6c 07 5a 07  64 00 64 03 6c 08 6d 09  |d.d.l.Z.d.d.l.m.|
00000070  5a 09 01 00 64 04 64 05  6c 0a 6d 0b 5a 0b 6d 0c  |Z...d.d.l.m.Z.m.|
00000080  5a 0c 6d 0d 5a 0d 01 00  64 04 64 06 6c 0e 6d 0f  |Z.m.Z...d.d.l.m.|
00000090  5a 0f 01 00 64 04 64 07  6c 10 6d 11 5a 11 6d 12  |Z...d.d.l.m.Z.m.|
000000a0  5a 12 6d 13 5a 13 6d 14  5a 14 6d 15 5a 15 6d 16  |Z.m.Z.m.Z.m.Z.m.|
000000b0  5a 16 01 00 02 00 65 02  6a 2e 00 00 00 00 00 00  |Z.....e.j.......|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 65 18 ab 01  |............e...|
000000d0  00 00 00 00 00 00 5a 19  64 08 6a 35 00 00 00 00  |......Z.d.j5....|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 00  |................|
000000f0  00 00 00 00 00 00 5a 1b  02 00 65 04 6a 38 00 00  |......Z...e.j8..|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000110  64 09 ab 01 00 00 00 00  00 00 5a 1d 64 0a 5a 1e  |d.........Z.d.Z.|
00000120  65 03 6a 3e 00 00 00 00  00 00 00 00 00 00 00 00  |e.j>............|
00000130  00 00 00 00 00 00 64 0b  6b 28 00 00 73 1e 65 03  |......d.k(..s.e.|
00000140  6a 3e 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j>..............|
00000150  00 00 00 00 64 0c 6b 28  00 00 72 79 65 03 6a 40  |....d.k(..rye.j@|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000170  00 00 64 0b 6b 28 00 00  72 6a 65 18 6a 43 00 00  |..d.k(..rje.jC..|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  64 0d 64 04 ab 02 00 00  00 00 00 00 64 00 19 00  |d.d.........d...|
000001a0  00 00 5a 22 02 00 65 0f  65 22 ab 01 00 00 00 00  |..Z"..e.e"......|
000001b0  00 00 6a 47 00 00 00 00  00 00 00 00 00 00 00 00  |..jG............|
000001c0  00 00 00 00 00 00 64 0e  ab 01 00 00 00 00 00 00  |......d.........|
000001d0  44 00 8f 00 63 02 69 00  63 02 5d 34 00 00 7d 00  |D...c.i.c.]4..}.|
000001e0  7c 00 6a 3e 00 00 00 00  00 00 00 00 00 00 00 00  ||.j>............|
000001f0  00 00 00 00 00 00 6a 49  00 00 00 00 00 00 00 00  |......jI........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/scripts.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/util.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 87K 2025-06-01 01:28:38.167978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/util.cpython-312.pyc
90c38f39f4130aea51b9be75f7021f26e9da14f1193536d33d465fd82183bece  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/util.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 91 04 01 00  |........R.5h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 28 07  00 00 97 00 64 00 64 01  |......(.....d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 01 6c 03 5a 03  64 00 64 01 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 03 6c 05 6d 06  5a 07 01 00 64 00 64 01  |d.d.l.m.Z...d.d.|
00000060  6c 08 5a 08 64 00 64 01  6c 09 5a 09 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000070  6c 0a 5a 0a 64 00 64 01  6c 0b 5a 0b 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000080  6c 0c 5a 0c 64 00 64 01  6c 0d 5a 0d 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000090  6c 0e 5a 0e 09 00 64 00  64 01 6c 0f 5a 0f 64 00  |l.Z...d.d.l.Z.d.|
000000a0  64 01 6c 11 5a 11 64 00  64 01 6c 12 5a 12 64 00  |d.l.Z.d.d.l.Z.d.|
000000b0  64 01 6c 13 5a 13 64 00  64 01 6c 14 5a 14 64 00  |d.l.Z.d.d.l.Z.d.|
000000c0  64 01 6c 15 5a 15 09 00  64 00 64 01 6c 16 5a 16  |d.l.Z...d.d.l.Z.|
000000d0  64 00 64 01 6c 18 5a 18  64 04 64 05 6c 19 6d 1a  |d.d.l.Z.d.d.l.m.|
000000e0  5a 1a 01 00 64 04 64 06  6c 1b 6d 1c 5a 1c 6d 1d  |Z...d.d.l.m.Z.m.|
000000f0  5a 1d 6d 1e 5a 1e 6d 1f  5a 1f 6d 20 5a 20 6d 21  |Z.m.Z.m.Z.m Z m!|
00000100  5a 21 6d 22 5a 22 6d 23  5a 23 6d 24 5a 24 6d 25  |Z!m"Z"m#Z#m$Z$m%|
00000110  5a 25 6d 26 5a 26 6d 27  5a 27 6d 28 5a 28 6d 29  |Z%m&Z&m'Z'm(Z(m)|
00000120  5a 29 6d 2a 5a 2a 6d 2b  5a 2b 6d 2c 5a 2c 6d 2d  |Z)m*Z*m+Z+m,Z,m-|
00000130  5a 2d 6d 2e 5a 2e 6d 2f  5a 2f 01 00 02 00 65 0a  |Z-m.Z.m/Z/....e.|
00000140  6a 60 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j`..............|
00000150  00 00 00 00 65 31 ab 01  00 00 00 00 00 00 5a 32  |....e1........Z2|
00000160  02 00 65 0d 6a 66 00 00  00 00 00 00 00 00 00 00  |..e.jf..........|
00000170  00 00 00 00 00 00 00 00  64 07 ab 01 00 00 00 00  |........d.......|
00000180  00 00 5a 34 02 00 65 0d  6a 66 00 00 00 00 00 00  |..Z4..e.jf......|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 64 08 ab 01  |............d...|
000001a0  00 00 00 00 00 00 5a 35  02 00 65 0d 6a 66 00 00  |......Z5..e.jf..|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001c0  64 09 ab 01 00 00 00 00  00 00 5a 36 02 00 65 0d  |d.........Z6..e.|
000001d0  6a 66 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jf..............|
000001e0  00 00 00 00 64 0a ab 01  00 00 00 00 00 00 5a 37  |....d.........Z7|
000001f0  02 00 65 0d 6a 66 00 00  00 00 00 00 00 00 00 00  |..e.jf..........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/util.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/version.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 30K 2025-06-01 01:28:38.343978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/version.cpython-312.pyc
1492d4ca1c46048bb7e06231d401e6e81073d683ee0eee39b34109d283dbd1c8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/version.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 af 5c 00 00  |.........x3h.\..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0c 00 00  |................|
00000020  00 00 00 00 00 f3 e2 04  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 03 64 04 6c 03 6d 04  5a 04 01 00 64 03 64 05  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  67 00 64 06 a2 01 5a 07  |l.m.Z...g.d...Z.|
00000060  02 00 65 01 6a 10 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
00000070  00 00 00 00 00 00 00 00  65 09 ab 01 00 00 00 00  |........e.......|
00000080  00 00 5a 0a 02 00 47 00  64 07 84 00 64 08 65 0b  |..Z...G.d...d.e.|
00000090  ab 03 00 00 00 00 00 00  5a 0c 02 00 47 00 64 09  |........Z...G.d.|
000000a0  84 00 64 0a 65 0d ab 03  00 00 00 00 00 00 5a 0e  |..d.e.........Z.|
000000b0  02 00 47 00 64 0b 84 00  64 0c 65 0d ab 03 00 00  |..G.d...d.e.....|
000000c0  00 00 00 00 5a 0f 02 00  65 02 6a 20 00 00 00 00  |....Z...e.j ....|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 0d  |..............d.|
000000e0  65 02 6a 22 00 00 00 00  00 00 00 00 00 00 00 00  |e.j"............|
000000f0  00 00 00 00 00 00 ab 02  00 00 00 00 00 00 5a 12  |..............Z.|
00000100  64 0e 84 00 5a 13 65 13  5a 14 02 00 47 00 64 0f  |d...Z.e.Z...G.d.|
00000110  84 00 64 10 65 0e ab 03  00 00 00 00 00 00 5a 15  |..d.e.........Z.|
00000120  64 11 84 00 5a 16 02 00  47 00 64 12 84 00 64 13  |d...Z...G.d...d.|
00000130  65 0f ab 03 00 00 00 00  00 00 5a 17 02 00 65 02  |e.........Z...e.|
00000140  6a 20 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j ..............|
00000150  00 00 00 00 64 14 ab 01  00 00 00 00 00 00 64 15  |....d.........d.|
00000160  66 02 02 00 65 02 6a 20  00 00 00 00 00 00 00 00  |f...e.j ........|
00000170  00 00 00 00 00 00 00 00  00 00 64 16 ab 01 00 00  |..........d.....|
00000180  00 00 00 00 64 17 66 02  02 00 65 02 6a 20 00 00  |....d.f...e.j ..|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  64 18 ab 01 00 00 00 00  00 00 64 15 66 02 02 00  |d.........d.f...|
000001b0  65 02 6a 20 00 00 00 00  00 00 00 00 00 00 00 00  |e.j ............|
000001c0  00 00 00 00 00 00 64 19  ab 01 00 00 00 00 00 00  |......d.........|
000001d0  64 1a 66 02 02 00 65 02  6a 20 00 00 00 00 00 00  |d.f...e.j ......|
000001e0  00 00 00 00 00 00 00 00  00 00 00 00 64 1b ab 01  |............d...|
000001f0  00 00 00 00 00 00 64 1c  66 02 02 00 65 02 6a 20  |......d.f...e.j |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/version.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/wheel.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 52K 2025-06-01 01:28:38.535978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/wheel.cpython-312.pyc
a428a5f69f36f0ab18d320495607ea62109a123b98101737951ea858eb33c89a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/wheel.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 cb ab 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 dc 04  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 03 6c 05 6d 06  5a 06 01 00 64 00 64 02  |d.d.l.m.Z...d.d.|
00000060  6c 07 5a 07 64 00 64 02  6c 08 5a 08 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000070  6c 09 5a 09 64 00 64 02  6c 0a 5a 0a 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000080  6c 0b 5a 0b 64 00 64 02  6c 0c 5a 0c 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000090  6c 0d 5a 0d 64 00 64 02  6c 0e 5a 0e 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
000000a0  6c 0f 5a 0f 64 00 64 02  6c 10 5a 10 64 04 64 05  |l.Z.d.d.l.Z.d.d.|
000000b0  6c 11 6d 12 5a 12 6d 13  5a 13 01 00 64 04 64 06  |l.m.Z.m.Z...d.d.|
000000c0  6c 14 6d 15 5a 15 6d 16  5a 16 6d 17 5a 17 6d 18  |l.m.Z.m.Z.m.Z.m.|
000000d0  5a 18 6d 19 5a 19 01 00  64 04 64 07 6c 1a 6d 1b  |Z.m.Z...d.d.l.m.|
000000e0  5a 1b 01 00 64 04 64 08  6c 1c 6d 1d 5a 1d 6d 1e  |Z...d.d.l.m.Z.m.|
000000f0  5a 1e 6d 1f 5a 1f 01 00  64 04 64 09 6c 20 6d 21  |Z.m.Z...d.d.l m!|
00000100  5a 21 6d 22 5a 22 6d 23  5a 23 6d 24 5a 24 6d 25  |Z!m"Z"m#Z#m$Z$m%|
00000110  5a 25 6d 26 5a 26 6d 27  5a 27 6d 28 5a 28 6d 29  |Z%m&Z&m'Z'm(Z(m)|
00000120  5a 29 6d 2a 5a 2a 01 00  64 04 64 0a 6c 2b 6d 2c  |Z)m*Z*..d.d.l+m,|
00000130  5a 2c 6d 2d 5a 2d 01 00  02 00 65 09 6a 5c 00 00  |Z,m-Z-....e.j\..|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  65 2f ab 01 00 00 00 00  00 00 5a 30 64 02 61 31  |e/........Z0d.a1|
00000160  02 00 65 32 65 0e 64 0b  ab 02 00 00 00 00 00 00  |..e2e.d.........|
00000170  72 03 64 0c 5a 33 6e 32  65 0e 6a 68 00 00 00 00  |r.d.Z3n2e.jh....|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 6a 6b  |..............jk|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  00 00 64 0d ab 01 00 00  00 00 00 00 72 03 64 0e  |..d.........r.d.|
000001b0  5a 33 6e 14 65 0e 6a 68  00 00 00 00 00 00 00 00  |Z3n.e.jh........|
000001c0  00 00 00 00 00 00 00 00  00 00 64 0f 6b 28 00 00  |..........d.k(..|
000001d0  72 03 64 10 5a 33 6e 02  64 11 5a 33 02 00 65 15  |r.d.Z3n.d.Z3..e.|
000001e0  6a 6c 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jl..............|
000001f0  00 00 00 00 64 12 ab 01  00 00 00 00 00 00 5a 37  |....d.........Z7|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distlib/__pycache__/wheel.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 992 2025-06-01 01:28:38.695978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__init__.cpython-312.pyc
ac557b9b3c9583d53b8dd4e4d439530928fa1065f04920ce10f8634ee4f2b01f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 d5 03 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 78 00  00 00 97 00 64 00 64 01  |......x.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 6d 03 5a 03 6d 04  |l.m.Z.m.Z.m.Z.m.|
00000040  5a 04 6d 05 5a 05 6d 06  5a 06 6d 07 5a 07 6d 08  |Z.m.Z.m.Z.m.Z.m.|
00000050  5a 08 6d 09 5a 09 6d 0a  5a 0a 6d 0b 5a 0b 6d 0c  |Z.m.Z.m.Z.m.Z.m.|
00000060  5a 0c 6d 0d 5a 0d 6d 0e  5a 0e 6d 0f 5a 0f 6d 10  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 10 6d 11 5a 11 6d 12  5a 12 6d 13 5a 13 6d 14  |Z.m.Z.m.Z.m.Z.m.|
00000080  5a 14 6d 15 5a 15 6d 16  5a 16 6d 17 5a 17 6d 18  |Z.m.Z.m.Z.m.Z.m.|
00000090  5a 18 01 00 67 00 64 02  a2 01 5a 19 65 05 5a 05  |Z...g.d...Z.e.Z.|
000000a0  79 03 29 04 e9 01 00 00  00 29 18 da 14 4e 4f 52  |y.)......)...NOR|
000000b0  4d 41 4c 49 5a 45 44 5f  44 49 53 54 52 4f 5f 49  |MALIZED_DISTRO_I|
000000c0  44 da 11 4e 4f 52 4d 41  4c 49 5a 45 44 5f 4c 53  |D..NORMALIZED_LS|
000000d0  42 5f 49 44 da 10 4e 4f  52 4d 41 4c 49 5a 45 44  |B_ID..NORMALIZED|
000000e0  5f 4f 53 5f 49 44 da 11  4c 69 6e 75 78 44 69 73  |_OS_ID..LinuxDis|
000000f0  74 72 69 62 75 74 69 6f  6e da 0b 5f 5f 76 65 72  |tribution..__ver|
00000100  73 69 6f 6e 5f 5f da 0c  62 75 69 6c 64 5f 6e 75  |sion__..build_nu|
00000110  6d 62 65 72 da 08 63 6f  64 65 6e 61 6d 65 da 13  |mber..codename..|
00000120  64 69 73 74 72 6f 5f 72  65 6c 65 61 73 65 5f 61  |distro_release_a|
00000130  74 74 72 da 13 64 69 73  74 72 6f 5f 72 65 6c 65  |ttr..distro_rele|
00000140  61 73 65 5f 69 6e 66 6f  da 02 69 64 da 04 69 6e  |ase_info..id..in|
00000150  66 6f da 04 6c 69 6b 65  da 12 6c 69 6e 75 78 5f  |fo..like..linux_|
00000160  64 69 73 74 72 69 62 75  74 69 6f 6e da 10 6c 73  |distribution..ls|
00000170  62 5f 72 65 6c 65 61 73  65 5f 61 74 74 72 da 10  |b_release_attr..|
00000180  6c 73 62 5f 72 65 6c 65  61 73 65 5f 69 6e 66 6f  |lsb_release_info|
00000190  da 0d 6d 61 6a 6f 72 5f  76 65 72 73 69 6f 6e da  |..major_version.|
000001a0  0d 6d 69 6e 6f 72 5f 76  65 72 73 69 6f 6e da 04  |.minor_version..|
000001b0  6e 61 6d 65 da 0f 6f 73  5f 72 65 6c 65 61 73 65  |name..os_release|
000001c0  5f 61 74 74 72 da 0f 6f  73 5f 72 65 6c 65 61 73  |_attr..os_releas|
000001d0  65 5f 69 6e 66 6f da 0a  75 6e 61 6d 65 5f 61 74  |e_info..uname_at|
000001e0  74 72 da 0a 75 6e 61 6d  65 5f 69 6e 66 6f da 07  |tr..uname_info..|
000001f0  76 65 72 73 69 6f 6e da  0d 76 65 72 73 69 6f 6e  |version..version|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__main__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 324 2025-06-01 01:28:38.855978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__main__.cpython-312.pyc
23a07005db099f061d9f2041bc3144fa18abc234952d7bddd631be51da2bec04  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__main__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 40 00 00 00  |.........x3h@...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 2a 00  00 00 97 00 64 00 64 01  |......*.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  65 02 64 02 6b 28 00 00  |l.m.Z...e.d.k(..|
00000040  72 08 02 00 65 01 ab 00  00 00 00 00 00 00 01 00  |r...e...........|
00000050  79 03 79 03 29 04 e9 01  00 00 00 29 01 da 04 6d  |y.y.)......)...m|
00000060  61 69 6e da 08 5f 5f 6d  61 69 6e 5f 5f 4e 29 03  |ain..__main__N).|
00000070  da 06 64 69 73 74 72 6f  72 03 00 00 00 da 08 5f  |..distror......_|
00000080  5f 6e 61 6d 65 5f 5f a9  00 f3 00 00 00 00 fa 7d  |_name__........}|
00000090  2f 64 61 74 61 2f 64 61  74 61 2f 63 6f 6d 2e 74  |/data/data/com.t|
000000a0  65 72 6d 75 78 2f 66 69  6c 65 73 2f 68 6f 6d 65  |ermux/files/home|
000000b0  2f 52 41 46 41 45 4c 49  41 2f 48 43 50 4d 2f 43  |/RAFAELIA/HCPM/C|
000000c0  4f 52 45 2f 76 65 6e 76  5f 72 61 66 61 65 6c 69  |ORE/venv_rafaeli|
000000d0  61 2f 6c 69 62 2f 70 79  74 68 6f 6e 33 2e 31 32  |a/lib/python3.12|
000000e0  2f 73 69 74 65 2d 70 61  63 6b 61 67 65 73 2f 70  |/site-packages/p|
000000f0  69 70 2f 5f 76 65 6e 64  6f 72 2f 64 69 73 74 72  |ip/_vendor/distr|
00000100  6f 2f 5f 5f 6d 61 69 6e  5f 5f 2e 70 79 da 08 3c  |o/__main__.py..<|
00000110  6d 6f 64 75 6c 65 3e 72  0a 00 00 00 01 00 00 00  |module>r........|
00000120  73 1a 00 00 00 f0 03 01  01 01 dd 00 18 e0 03 0b  |s...............|
00000130  88 7a d2 03 19 d9 04 08  85 46 f0 03 00 04 1a 72  |.z.......F.....r|
00000140  08 00 00 00                                       |....|
00000144
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/__main__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/distro.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 53K 2025-06-01 01:28:39.031978165 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/distro.cpython-312.pyc
b364a68dbc92bbdfe18fad28073b866b45a5c0ae5dfbabe104b88f964143d919  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/distro/__pycache__/distro.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 16 c1 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 ba 03  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 01 64 02 6c 07 5a 07  64 01 64 02 6c 08 5a 08  |d.d.l.Z.d.d.l.Z.|
00000070  64 01 64 02 6c 09 5a 09  64 01 64 03 6c 0a 6d 0b  |d.d.l.Z.d.d.l.m.|
00000080  5a 0b 6d 0c 5a 0c 6d 0d  5a 0d 6d 0e 5a 0e 6d 0f  |Z.m.Z.m.Z.m.Z.m.|
00000090  5a 0f 6d 10 5a 10 6d 11  5a 11 6d 12 5a 12 6d 13  |Z.m.Z.m.Z.m.Z.m.|
000000a0  5a 13 01 00 09 00 64 01  64 04 6c 0a 6d 14 5a 14  |Z.....d.d.l.m.Z.|
000000b0  01 00 64 05 5a 17 02 00  47 00 64 06 84 00 64 07  |..d.Z...G.d...d.|
000000c0  65 14 ab 03 00 00 00 00  00 00 5a 18 02 00 47 00  |e.........Z...G.|
000000d0  64 08 84 00 64 09 65 14  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000e0  5a 19 65 04 6a 34 00 00  00 00 00 00 00 00 00 00  |Z.e.j4..........|
000000f0  00 00 00 00 00 00 00 00  6a 37 00 00 00 00 00 00  |........j7......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 64 0a 64 0b  |............d.d.|
00000110  ab 02 00 00 00 00 00 00  5a 1c 65 04 6a 34 00 00  |........Z.e.j4..|
00000120  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000130  6a 37 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j7..............|
00000140  00 00 00 00 64 0c 64 0d  ab 02 00 00 00 00 00 00  |....d.d.........|
00000150  5a 1d 64 0e 5a 1e 64 0f  64 10 64 11 9c 02 5a 1f  |Z.d.Z.d.d.d...Z.|
00000160  64 0f 64 0f 64 12 64 12  64 12 64 13 9c 05 5a 20  |d.d.d.d.d.d...Z |
00000170  64 14 64 12 69 01 5a 21  02 00 65 05 6a 44 00 00  |d.d.i.Z!..e.jD..|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  64 15 ab 01 00 00 00 00  00 00 5a 23 02 00 65 05  |d.........Z#..e.|
000001a0  6a 44 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jD..............|
000001b0  00 00 00 00 64 16 ab 01  00 00 00 00 00 00 5a 24  |....d.........Z$|
000001c0  67 00 64 17 a2 01 5a 25  64 18 64 19 64 1a 65 1e  |g.d...Z%d.d.d.e.|