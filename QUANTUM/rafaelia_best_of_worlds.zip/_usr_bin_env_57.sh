#!/usr/bin/env python3
"""Tests for distutils.sysconfig."""

import contextlib
import distutils
import os
import pathlib
import subprocess
import sys
from distutils import sysconfig
from distutils.ccompiler import new_compiler  # noqa: F401
from distutils.unixccompiler import UnixCCompiler

import jaraco.envs
import path
import pytest
from jaraco.text import trim
from test.support import swap_item


def _gen_makefile(root, contents):
    jaraco.path.build({'Makefile': trim(contents)}, root)
    return root / 'Makefile'


@pytest.mark.usefixtures('save_env')
class TestSysconfig:
    def test_get_config_h_filename(self):
        config_h = sysconfig.get_config_h_filename()
        assert os.path.isfile(config_h)

    @pytest.mark.skipif("platform.system() == 'Windows'")
    @pytest.mark.skipif("sys.implementation.name != 'cpython'")
    def test_get_makefile_filename(self):
        makefile = sysconfig.get_makefile_filename()
        assert os.path.isfile(makefile)

    def test_get_python_lib(self, tmp_path):
        assert sysconfig.get_python_lib() != sysconfig.get_python_lib(prefix=tmp_path)

    def test_get_config_vars(self):
        cvars = sysconfig.get_config_vars()
        assert isinstance(cvars, dict)
        assert cvars

    @pytest.mark.skipif('sysconfig.IS_PYPY')
    @pytest.mark.skipif('sysconfig.python_build')
    @pytest.mark.xfail('platform.system() == "Windows"')
    def test_srcdir_simple(self):
        # See #15364.
        srcdir = pathlib.Path(sysconfig.get_config_var('srcdir'))

        assert srcdir.absolute()
        assert srcdir.is_dir()

        makefile = pathlib.Path(sysconfig.get_makefile_filename())
        assert makefile.parent.samefile(srcdir)

    @pytest.mark.skipif('sysconfig.IS_PYPY')
    @pytest.mark.skipif('not sysconfig.python_build')
    def test_srcdir_python_build(self):
        # See #15364.
        srcdir = pathlib.Path(sysconfig.get_config_var('srcdir'))

        # The python executable has not been installed so srcdir
        # should be a full source checkout.
        Python_h = srcdir.joinpath('Include', 'Python.h')
        assert Python_h.is_file()
        assert sysconfig._is_python_source_dir(srcdir)
        assert sysconfig._is_python_source_dir(str(srcdir))

    def test_srcdir_independent_of_cwd(self):
        """
        srcdir should be independent of the current working directory
        """
        # See #15364.
        srcdir = sysconfig.get_config_var('srcdir')
        with path.Path('..'):
            srcdir2 = sysconfig.get_config_var('srcdir')
        assert srcdir == srcdir2

    def customize_compiler(self):
        # make sure AR gets caught
        class compiler:
            compiler_type = 'unix'
            executables = UnixCCompiler.executables

            def __init__(self):
                self.exes = {}

            def set_executables(self, **kw):
                for k, v in kw.items():
                    self.exes[k] = v

        sysconfig_vars = {
            'AR': 'sc_ar',
            'CC': 'sc_cc',
            'CXX': 'sc_cxx',
            'ARFLAGS': '--sc-arflags',
            'CFLAGS': '--sc-cflags',
            'CCSHARED': '--sc-ccshared',
            'LDSHARED': 'sc_ldshared',
            'SHLIB_SUFFIX': 'sc_shutil_suffix',
        }

        comp = compiler()
        with contextlib.ExitStack() as cm:
            for key, value in sysconfig_vars.items():
                cm.enter_context(swap_item(sysconfig._config_vars, key, value))
            sysconfig.customize_compiler(comp)

        return comp

    @pytest.mark.skipif("not isinstance(new_compiler(), UnixCCompiler)")
    @pytest.mark.usefixtures('disable_macos_customization')
    def test_customize_compiler(self):
        # Make sure that sysconfig._config_vars is initialized
        sysconfig.get_config_vars()

        os.environ['AR'] = 'env_ar'
        os.environ['CC'] = 'env_cc'
        os.environ['CPP'] = 'env_cpp'
        os.environ['CXX'] = 'env_cxx --env-cxx-flags'
        os.environ['LDSHARED'] = 'env_ldshared'
        os.environ['LDFLAGS'] = '--env-ldflags'
        os.environ['ARFLAGS'] = '--env-arflags'
        os.environ['CFLAGS'] = '--env-cflags'
        os.environ['CPPFLAGS'] = '--env-cppflags'
        os.environ['RANLIB'] = 'env_ranlib'

        comp = self.customize_compiler()
        assert comp.exes['archiver'] == 'env_ar --env-arflags'
        assert comp.exes['preprocessor'] == 'env_cpp --env-cppflags'
        assert comp.exes['compiler'] == 'env_cc --env-cflags --env-cppflags'
        assert comp.exes['compiler_so'] == (
            'env_cc --env-cflags --env-cppflags --sc-ccshared'
        )
        assert (
            comp.exes['compiler_cxx']
            == 'env_cxx --env-cxx-flags --sc-cflags --env-cppflags'
        )
        assert comp.exes['linker_exe'] == 'env_cc'
        assert comp.exes['linker_so'] == (
            'env_ldshared --env-ldflags --env-cflags --env-cppflags'
        )
        assert comp.shared_lib_extension == 'sc_shutil_suffix'

        if sys.platform == "darwin":
            assert comp.exes['ranlib'] == 'env_ranlib'
        else:
            assert 'ranlib' not in comp.exes

        del os.environ['AR']
        del os.environ['CC']
        del os.environ['CPP']
        del os.environ['CXX']
        del os.environ['LDSHARED']
        del os.environ['LDFLAGS']
        del os.environ['ARFLAGS']
        del os.environ['CFLAGS']
        del os.environ['CPPFLAGS']
        del os.environ['RANLIB']

        comp = self.customize_compiler()
        assert comp.exes['archiver'] == 'sc_ar --sc-arflags'
        assert comp.exes['preprocessor'] == 'sc_cc -E'
        assert comp.exes['compiler'] == 'sc_cc --sc-cflags'
        assert comp.exes['compiler_so'] == 'sc_cc --sc-cflags --sc-ccshared'
        assert comp.exes['compiler_cxx'] == 'sc_cxx --sc-cflags'
        assert comp.exes['linker_exe'] == 'sc_cc'
        assert comp.exes['linker_so'] == 'sc_ldshared'
        assert comp.shared_lib_extension == 'sc_shutil_suffix'
        assert 'ranlib' not in comp.exes

    def test_parse_makefile_base(self, tmp_path):
        makefile = _gen_makefile(
            tmp_path,
            """
            CONFIG_ARGS=  '--arg1=optarg1' 'ENV=LIB'
            VAR=$OTHER
            OTHER=foo
            """,
        )
        d = sysconfig.parse_makefile(makefile)
        assert d == {'CONFIG_ARGS': "'--arg1=optarg1' 'ENV=LIB'", 'OTHER': 'foo'}

    def test_parse_makefile_literal_dollar(self, tmp_path):
        makefile = _gen_makefile(
            tmp_path,
            """
            CONFIG_ARGS=  '--arg1=optarg1' 'ENV=\\$$LIB'
            VAR=$OTHER
            OTHER=foo
            """,
        )
        d = sysconfig.parse_makefile(makefile)
        assert d == {'CONFIG_ARGS': r"'--arg1=optarg1' 'ENV=\$LIB'", 'OTHER': 'foo'}

    def test_sysconfig_module(self):
        import sysconfig as global_sysconfig

        assert global_sysconfig.get_config_var('CFLAGS') == sysconfig.get_config_var(
            'CFLAGS'
        )
        assert global_sysconfig.get_config_var('LDFLAGS') == sysconfig.get_config_var(
            'LDFLAGS'
        )

    # On macOS, binary installers support extension module building on
    # various levels of the operating system with differing Xcode
    # configurations, requiring customization of some of the
    # compiler configuration directives to suit the environment on
    # the installed machine. Some of these customizations may require
    # running external programs and are thus deferred until needed by
    # the first extension module build. Only
    # the Distutils version of sysconfig is used for extension module
    # builds, which happens earlier in the Distutils tests. This may
    # cause the following tests to fail since no tests have caused
    # the global version of sysconfig to call the customization yet.
    # The solution for now is to simply skip this test in this case.
    # The longer-term solution is to only have one version of sysconfig.
    @pytest.mark.skipif("sysconfig.get_config_var('CUSTOMIZED_OSX_COMPILER')")
    def test_sysconfig_compiler_vars(self):
        import sysconfig as global_sysconfig

        if sysconfig.get_config_var('CUSTOMIZED_OSX_COMPILER'):
            pytest.skip('compiler flags customized')
        assert global_sysconfig.get_config_var('LDSHARED') == sysconfig.get_config_var(
            'LDSHARED'
        )
        assert global_sysconfig.get_config_var('CC') == sysconfig.get_config_var('CC')

    @pytest.mark.skipif("not sysconfig.get_config_var('EXT_SUFFIX')")
    def test_SO_deprecation(self):
        with pytest.warns(DeprecationWarning):
            sysconfig.get_config_var('SO')

    def test_customize_compiler_before_get_config_vars(self, tmp_path):
        # Issue #21923: test that a Distribution compiler
        # instance can be called without an explicit call to
        # get_config_vars().
        jaraco.path.build(
            {
                'file': trim("""
                    from distutils.core import Distribution
                    config = Distribution().get_command_obj('config')
                    # try_compile may pass or it may fail if no compiler
                    # is found but it should not raise an exception.
                    rc = config.try_compile('int x;')
                    """)
            },
            tmp_path,
        )
        p = subprocess.Popen(
            [sys.executable, tmp_path / 'file'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            universal_newlines=True,
            encoding='utf-8',
        )
        outs, errs = p.communicate()
        assert 0 == p.returncode, "Subprocess failed: " + outs

    def test_parse_config_h(self):
        config_h = sysconfig.get_config_h_filename()
        input = {}
        with open(config_h, encoding="utf-8") as f:
            result = sysconfig.parse_config_h(f, g=input)
        assert input is result
        with open(config_h, encoding="utf-8") as f:
            result = sysconfig.parse_config_h(f)
        assert isinstance(result, dict)

    @pytest.mark.skipif("platform.system() != 'Windows'")
    @pytest.mark.skipif("sys.implementation.name != 'cpython'")
    def test_win_ext_suffix(self):
        assert sysconfig.get_config_var("EXT_SUFFIX").endswith(".pyd")
        assert sysconfig.get_config_var("EXT_SUFFIX") != ".pyd"

    @pytest.mark.skipif("platform.system() != 'Windows'")
    @pytest.mark.skipif("sys.implementation.name != 'cpython'")
    @pytest.mark.skipif(
        '\\PCbuild\\'.casefold() not in sys.executable.casefold(),
        reason='Need sys.executable to be in a source tree',
    )
    def test_win_build_venv_from_source_tree(self, tmp_path):
        """Ensure distutils.sysconfig detects venvs from source tree builds."""
        env = jaraco.envs.VEnv()
        env.create_opts = env.clean_opts
        env.root = tmp_path
        env.ensure_env()
        cmd = [
            env.exe(),
            "-c",
            "import distutils.sysconfig; print(distutils.sysconfig.python_build)",
        ]
        distutils_path = os.path.dirname(os.path.dirname(distutils.__file__))
        out = subprocess.check_output(
            cmd, env={**os.environ, "PYTHONPATH": distutils_path}
        )
        assert out == "True"

    def test_get_python_inc_missing_config_dir(self, monkeypatch):
        """
        In portable Python installations, the sysconfig will be broken,
        pointing to the directories where the installation was built and
        not where it currently is. In this case, ensure that the missing
        directory isn't used for get_python_inc.

        See pypa/distutils#178.
        """

        def override(name):
            if name == 'INCLUDEPY':
                return '/does-not-exist'
            return sysconfig.get_config_var(name)

        monkeypatch.setattr(sysconfig, 'get_config_var', override)

        assert os.path.exists(sysconfig.get_python_inc())

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/test_sysconfig.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 238 2025-06-01 01:29:48.487978115 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/__init__.cpython-312.pyc
29422da6f46b2dfb166c40a0be5576ae07e11d313b0191378ffce135e42dd3bf  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 8d 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000000a0  74 75 70 74 6f 6f 6c 73  2f 5f 64 69 73 74 75 74  |tuptools/_distut|
000000b0  69 6c 73 2f 74 65 73 74  73 2f 63 6f 6d 70 61 74  |ils/tests/compat|
000000c0  2f 5f 5f 69 6e 69 74 5f  5f 2e 70 79 da 08 3c 6d  |/__init__.py..<m|
000000d0  6f 64 75 6c 65 3e 72 05  00 00 00 01 00 00 00 73  |odule>r........s|
000000e0  05 00 00 00 f1 03 01 01  01 72 03 00 00 00        |.........r....|
000000ee
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/py39.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 722 2025-06-01 01:29:48.647978115 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/py39.cpython-312.pyc
e26f6a5051f245a57494557dd70d1cabcdfbbce9424464d2ef41132b941564e0  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/py39.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 02 04 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 bc 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 65 00 6a 02  00 00 00 00 00 00 00 00  |l.Z.e.j.........|
00000040  00 00 00 00 00 00 00 00  00 00 64 02 6b 5c 00 00  |..........d.k\..|
00000050  72 25 64 00 64 03 6c 02  6d 03 5a 03 01 00 64 00  |r%d.d.l.m.Z...d.|
00000060  64 04 6c 02 6d 04 5a 04  01 00 64 00 64 05 6c 05  |d.l.m.Z...d.d.l.|
00000070  6d 06 5a 06 01 00 64 00  64 06 6c 05 6d 07 5a 07  |m.Z...d.d.l.m.Z.|
00000080  01 00 64 00 64 07 6c 05  6d 08 5a 08 01 00 64 00  |..d.d.l.m.Z...d.|
00000090  64 08 6c 05 6d 09 5a 09  01 00 79 01 64 00 64 03  |d.l.m.Z...y.d.d.|
000000a0  6c 0a 6d 03 5a 03 01 00  64 00 64 04 6c 0a 6d 04  |l.m.Z...d.d.l.m.|
000000b0  5a 04 01 00 64 00 64 05  6c 0a 6d 06 5a 06 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 06 6c 0a 6d 07  5a 07 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000d0  6c 0a 6d 08 5a 08 01 00  64 00 64 08 6c 0a 6d 09  |l.m.Z...d.d.l.m.|
000000e0  5a 09 01 00 79 01 29 09  e9 00 00 00 00 4e 29 02  |Z...y.)......N).|
000000f0  e9 03 00 00 00 e9 0a 00  00 00 29 01 da 0b 43 6c  |..........)...Cl|
00000100  65 61 6e 49 6d 70 6f 72  74 29 01 da 0d 44 69 72  |eanImport)...Dir|
00000110  73 4f 6e 53 79 73 50 61  74 68 29 01 da 13 45 6e  |sOnSysPath)...En|
00000120  76 69 72 6f 6e 6d 65 6e  74 56 61 72 47 75 61 72  |vironmentVarGuar|
00000130  64 29 01 da 06 72 6d 74  72 65 65 29 01 da 13 73  |d)...rmtree)...s|
00000140  6b 69 70 5f 75 6e 6c 65  73 73 5f 73 79 6d 6c 69  |kip_unless_symli|
00000150  6e 6b 29 01 da 06 75 6e  6c 69 6e 6b 29 0b da 03  |nk)...unlink)...|
00000160  73 79 73 da 0c 76 65 72  73 69 6f 6e 5f 69 6e 66  |sys..version_inf|
00000170  6f da 1a 74 65 73 74 2e  73 75 70 70 6f 72 74 2e  |o..test.support.|
00000180  69 6d 70 6f 72 74 5f 68  65 6c 70 65 72 72 05 00  |import_helperr..|
00000190  00 00 72 06 00 00 00 da  16 74 65 73 74 2e 73 75  |..r......test.su|
000001a0  70 70 6f 72 74 2e 6f 73  5f 68 65 6c 70 65 72 72  |pport.os_helperr|
000001b0  07 00 00 00 72 08 00 00  00 72 09 00 00 00 72 0a  |....r....r....r.|
000001c0  00 00 00 da 0c 74 65 73  74 2e 73 75 70 70 6f 72  |.....test.suppor|
000001d0  74 a9 00 f3 00 00 00 00  fa 89 2f 64 61 74 61 2f  |t........./data/|
000001e0  64 61 74 61 2f 63 6f 6d  2e 74 65 72 6d 75 78 2f  |data/com.termux/|
000001f0  66 69 6c 65 73 2f 68 6f  6d 65 2f 52 41 46 41 45  |files/home/RAFAE|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/compat/__pycache__/py39.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_install_headers.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.9K 2025-06-01 01:29:46.391978116 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_install_headers.cpython-312.pyc
db29c3b6575d0d27740de1ebf2a6a9882eb2ffd5ec91d624cf2210706810280a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_install_headers.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 a8 03 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 96 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 01 64 02 6c 06 5a 06  65 06 6a 0e 00 00 00 00  |d.d.l.Z.e.j.....|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 6a 11  |..............j.|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000080  00 00 64 05 ab 01 00 00  00 00 00 00 02 00 47 00  |..d...........G.|
00000090  64 06 84 00 64 07 65 05  6a 12 00 00 00 00 00 00  |d...d.e.j.......|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 ab 03 00 00  |................|
000000b0  00 00 00 00 ab 00 00 00  00 00 00 00 5a 0a 79 02  |............Z.y.|
000000c0  29 08 7a 2c 54 65 73 74  73 20 66 6f 72 20 64 69  |).z,Tests for di|
000000d0  73 74 75 74 69 6c 73 2e  63 6f 6d 6d 61 6e 64 2e  |stutils.command.|
000000e0  69 6e 73 74 61 6c 6c 5f  68 65 61 64 65 72 73 2e  |install_headers.|
000000f0  e9 00 00 00 00 4e 29 01  da 0f 69 6e 73 74 61 6c  |.....N)...instal|
00000100  6c 5f 68 65 61 64 65 72  73 29 01 da 07 73 75 70  |l_headers)...sup|
00000110  70 6f 72 74 da 08 73 61  76 65 5f 65 6e 76 63 00  |port..save_envc.|
00000120  00 00 00 00 00 00 00 00  00 00 00 01 00 00 00 00  |................|
00000130  00 00 00 f3 12 00 00 00  97 00 65 00 5a 01 64 00  |..........e.Z.d.|
00000140  5a 02 64 01 84 00 5a 03  79 02 29 03 da 12 54 65  |Z.d...Z.y.)...Te|
00000150  73 74 49 6e 73 74 61 6c  6c 48 65 61 64 65 72 73  |stInstallHeaders|
00000160  63 01 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |c...............|
00000170  00 03 00 00 00 f3 20 02  00 00 97 00 7c 00 6a 01  |...... .....|.j.|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  00 00 ab 00 00 00 00 00  00 00 7d 01 74 02 00 00  |..........}.t...|
000001a0  00 00 00 00 00 00 6a 04  00 00 00 00 00 00 00 00  |......j.........|
000001b0  00 00 00 00 00 00 00 00  00 00 6a 07 00 00 00 00  |..........j.....|
000001c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 7c 01  |..............|.|
000001d0  64 01 ab 02 00 00 00 00  00 00 7d 02 74 02 00 00  |d.........}.t...|
000001e0  00 00 00 00 00 00 6a 04  00 00 00 00 00 00 00 00  |......j.........|
000001f0  00 00 00 00 00 00 00 00  00 00 6a 07 00 00 00 00  |..........j.....|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_install_headers.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.9K 2025-06-01 01:29:42.715978119 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/__init__.cpython-312.pyc
c8b29cce6116a425c3392be104308edb54911487c46c71a9cc20abd6f849d9d1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 cd 05 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 32 00  00 00 97 00 64 00 5a 00  |......2.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 67 00 66 01  64 04 65 03 65 04 19 00  |Z...g.f.d.e.e...|
00000050  00 00 66 02 64 05 84 05  5a 05 79 02 29 06 61 18  |..f.d...Z.y.).a.|
00000060  01 00 00 0a 54 65 73 74  20 73 75 69 74 65 20 66  |....Test suite f|
00000070  6f 72 20 64 69 73 74 75  74 69 6c 73 2e 0a 0a 54  |or distutils...T|
00000080  65 73 74 73 20 66 6f 72  20 74 68 65 20 63 6f 6d  |ests for the com|
00000090  6d 61 6e 64 20 63 6c 61  73 73 65 73 20 69 6e 20  |mand classes in |
000000a0  74 68 65 20 64 69 73 74  75 74 69 6c 73 2e 63 6f  |the distutils.co|
000000b0  6d 6d 61 6e 64 20 70 61  63 6b 61 67 65 20 61 72  |mmand package ar|
000000c0  65 0a 69 6e 63 6c 75 64  65 64 20 69 6e 20 64 69  |e.included in di|
000000d0  73 74 75 74 69 6c 73 2e  74 65 73 74 73 20 61 73  |stutils.tests as|
000000e0  20 77 65 6c 6c 2c 20 69  6e 73 74 65 61 64 20 6f  | well, instead o|
000000f0  66 20 75 73 69 6e 67 20  61 20 73 65 70 61 72 61  |f using a separa|
00000100  74 65 0a 64 69 73 74 75  74 69 6c 73 2e 63 6f 6d  |te.distutils.com|
00000110  6d 61 6e 64 2e 74 65 73  74 73 20 70 61 63 6b 61  |mand.tests packa|
00000120  67 65 2c 20 73 69 6e 63  65 20 63 6f 6d 6d 61 6e  |ge, since comman|
00000130  64 20 69 64 65 6e 74 69  66 69 63 61 74 69 6f 6e  |d identification|
00000140  20 69 73 20 64 6f 6e 65  0a 62 79 20 69 6d 70 6f  | is done.by impo|
00000150  72 74 20 72 61 74 68 65  72 20 74 68 61 6e 20 6d  |rt rather than m|
00000160  61 74 63 68 69 6e 67 20  70 72 65 2d 64 65 66 69  |atching pre-defi|
00000170  6e 65 64 20 6e 61 6d 65  73 2e 0a e9 00 00 00 00  |ned names.......|
00000180  4e 29 01 da 08 53 65 71  75 65 6e 63 65 da 09 63  |N)...Sequence..c|
00000190  6d 64 5f 6e 61 6d 65 73  63 01 00 00 00 00 00 00  |md_namesc.......|
000001a0  00 00 00 00 00 05 00 00  00 03 00 00 00 f3 6e 01  |..............n.|
000001b0  00 00 97 00 64 01 64 02  6c 00 6d 01 7d 01 6d 02  |....d.d.l.m.}.m.|
000001c0  7d 02 6d 03 7d 03 01 00  7c 01 6a 09 00 00 00 00  |}.m.}...|.j.....|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 00  |................|
000001e0  00 00 00 00 00 00 7d 04  7c 03 6a 0b 00 00 00 00  |......}.|.j.....|
000001f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 7c 04  |..............|.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/support.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.3K 2025-06-01 01:29:42.871978119 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/support.cpython-312.pyc
b056a4ea11a990ed9a7dac75e0575450521a79d645181fecc31dc6f2a82b31de  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/support.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 03 10 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 dc 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 01 64 02 6c 07 5a 07  64 01 64 03 6c 08 6d 09  |d.d.l.Z.d.d.l.m.|
00000070  5a 09 01 00 64 01 64 02  6c 0a 5a 0a 64 01 64 04  |Z...d.d.l.Z.d.d.|
00000080  6c 0b 6d 0c 5a 0c 01 00  65 0a 6a 1a 00 00 00 00  |l.m.Z...e.j.....|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 00 00 6a 1d  |..............j.|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  00 00 64 05 ab 01 00 00  00 00 00 00 02 00 47 00  |..d...........G.|
000000c0  64 06 84 00 64 07 ab 02  00 00 00 00 00 00 ab 00  |d...d...........|
000000d0  00 00 00 00 00 00 5a 0f  02 00 47 00 64 08 84 00  |......Z...G.d...|
000000e0  64 09 ab 02 00 00 00 00  00 00 5a 10 64 0a 84 00  |d.........Z.d...|
000000f0  5a 11 64 0b 84 00 5a 12  64 0c 84 00 5a 13 64 0d  |Z.d...Z.d...Z.d.|
00000100  84 00 5a 14 79 02 29 0e  7a 26 53 75 70 70 6f 72  |..Z.y.).z&Suppor|
00000110  74 20 63 6f 64 65 20 66  6f 72 20 64 69 73 74 75  |t code for distu|
00000120  74 69 6c 73 20 74 65 73  74 20 63 61 73 65 73 2e  |tils test cases.|
00000130  e9 00 00 00 00 4e 29 01  da 0c 44 69 73 74 72 69  |.....N)...Distri|
00000140  62 75 74 69 6f 6e 29 01  da 0f 61 6c 77 61 79 73  |bution)...always|
00000150  5f 69 74 65 72 61 62 6c  65 da 19 64 69 73 74 75  |_iterable..distu|
00000160  74 69 6c 73 5f 6d 61 6e  61 67 65 64 5f 74 65 6d  |tils_managed_tem|
00000170  70 64 69 72 63 00 00 00  00 00 00 00 00 00 00 00  |pdirc...........|
00000180  00 02 00 00 00 00 00 00  00 f3 26 00 00 00 97 00  |..........&.....|
00000190  65 00 5a 01 64 00 5a 02  64 01 5a 03 64 02 84 00  |e.Z.d.Z.d.Z.d...|
000001a0  5a 04 64 06 64 03 84 01  5a 05 64 07 64 04 84 01  |Z.d.d...Z.d.d...|
000001b0  5a 06 79 05 29 08 da 0e  54 65 6d 70 64 69 72 4d  |Z.y.)...TempdirM|
000001c0  61 6e 61 67 65 72 7a 49  0a 20 20 20 20 4d 69 78  |anagerzI.    Mix|
000001d0  2d 69 6e 20 63 6c 61 73  73 20 74 68 61 74 20 68  |-in class that h|
000001e0  61 6e 64 6c 65 73 20 74  65 6d 70 6f 72 61 72 79  |andles temporary|
000001f0  20 64 69 72 65 63 74 6f  72 69 65 73 20 66 6f 72  | directories for|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/support.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_archive_util.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 21K 2025-06-01 01:29:43.035978119 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_archive_util.cpython-312.pyc
45d1bf00512bbde3affd8bad5b3447469cb69d0e88d19f263b3cca045c701b63  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_archive_util.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 0b 2e 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 f8 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 01 64 03 6c 07 6d 08  5a 08 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000070  6c 09 6d 0a 5a 0a 6d 0b  5a 0b 6d 0c 5a 0c 6d 0d  |l.m.Z.m.Z.m.Z.m.|
00000080  5a 0d 6d 0e 5a 0e 01 00  64 01 64 05 6c 0f 6d 10  |Z.m.Z...d.d.l.m.|
00000090  5a 10 01 00 64 01 64 06  6c 11 6d 12 5a 12 01 00  |Z...d.d.l.m.Z...|
000000a0  64 01 64 07 6c 13 6d 14  5a 14 01 00 64 01 64 02  |d.d.l.m.Z...d.d.|
000000b0  6c 15 5a 15 64 01 64 02  6c 16 5a 16 64 01 64 08  |l.Z.d.d.l.Z.d.d.|
000000c0  6c 17 6d 18 5a 18 01 00  64 09 64 0a 6c 19 6d 1a  |l.m.Z...d.d.l.m.|
000000d0  5a 1a 6d 1b 5a 1b 6d 1c  5a 1c 6d 1d 5a 1d 6d 1e  |Z.m.Z.m.Z.m.Z.m.|
000000e0  5a 1e 01 00 64 0b 84 00  5a 1f 64 0c 84 00 5a 20  |Z...d...Z.d...Z |
000000f0  64 0d 84 00 5a 21 02 00  47 00 64 0e 84 00 64 0f  |d...Z!..G.d...d.|
00000100  65 12 6a 44 00 00 00 00  00 00 00 00 00 00 00 00  |e.jD............|
00000110  00 00 00 00 00 00 ab 03  00 00 00 00 00 00 5a 23  |..............Z#|
00000120  79 02 29 10 7a 21 54 65  73 74 73 20 66 6f 72 20  |y.).z!Tests for |
00000130  64 69 73 74 75 74 69 6c  73 2e 61 72 63 68 69 76  |distutils.archiv|
00000140  65 5f 75 74 69 6c 2e e9  00 00 00 00 4e 29 01 da  |e_util......N)..|
00000150  0c 61 72 63 68 69 76 65  5f 75 74 69 6c 29 05 da  |.archive_util)..|
00000160  0f 41 52 43 48 49 56 45  5f 46 4f 52 4d 41 54 53  |.ARCHIVE_FORMATS|
00000170  da 15 63 68 65 63 6b 5f  61 72 63 68 69 76 65 5f  |..check_archive_|
00000180  66 6f 72 6d 61 74 73 da  0c 6d 61 6b 65 5f 61 72  |formats..make_ar|
00000190  63 68 69 76 65 da 0c 6d  61 6b 65 5f 74 61 72 62  |chive..make_tarb|
000001a0  61 6c 6c da 0c 6d 61 6b  65 5f 7a 69 70 66 69 6c  |all..make_zipfil|
000001b0  65 29 01 da 05 73 70 61  77 6e 29 01 da 07 73 75  |e)...spawn)...su|
000001c0  70 70 6f 72 74 29 01 da  0a 73 70 6c 69 74 64 72  |pport)...splitdr|
000001d0  69 76 65 29 01 da 05 70  61 74 63 68 e9 01 00 00  |ive)...patch....|
000001e0  00 29 05 da 0d 55 49 44  5f 30 5f 53 55 50 50 4f  |.)...UID_0_SUPPO|
000001f0  52 54 da 03 67 72 70 da  03 70 77 64 da 0d 72 65  |RT..grp..pwd..re|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_archive_util.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.9K 2025-06-01 01:29:43.195978119 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist.cpython-312.pyc
97f8ca61bfb67382cafffd486e3d88314ff657fc1307d81f6ffdee234830bc32  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 74 05 00 00  |..........8ht...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 4a 00  00 00 97 00 64 00 5a 00  |......J.....d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 6d 04 5a 04 01 00  02 00 47 00 64 04 84 00  |l.m.Z.....G.d...|
00000050  64 05 65 04 6a 0a 00 00  00 00 00 00 00 00 00 00  |d.e.j...........|
00000060  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
00000070  5a 06 79 06 29 07 7a 22  54 65 73 74 73 20 66 6f  |Z.y.).z"Tests fo|
00000080  72 20 64 69 73 74 75 74  69 6c 73 2e 63 6f 6d 6d  |r distutils.comm|
00000090  61 6e 64 2e 62 64 69 73  74 2e e9 00 00 00 00 29  |and.bdist......)|
000000a0  01 da 05 62 64 69 73 74  29 01 da 07 73 75 70 70  |...bdist)...supp|
000000b0  6f 72 74 63 00 00 00 00  00 00 00 00 00 00 00 00  |ortc............|
000000c0  01 00 00 00 00 00 00 00  f3 18 00 00 00 97 00 65  |...............e|
000000d0  00 5a 01 64 00 5a 02 64  01 84 00 5a 03 64 02 84  |.Z.d.Z.d...Z.d..|
000000e0  00 5a 04 79 03 29 04 da  09 54 65 73 74 42 75 69  |.Z.y.)...TestBui|
000000f0  6c 64 63 01 00 00 00 00  00 00 00 00 00 00 00 03  |ldc.............|
00000100  00 00 00 03 00 00 00 f3  d4 00 00 00 97 00 7c 00  |..............|.|
00000110  6a 01 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000120  00 00 00 00 ab 00 00 00  00 00 00 00 64 01 19 00  |............d...|
00000130  00 00 7d 01 74 03 00 00  00 00 00 00 00 00 7c 01  |..}.t.........|.|
00000140  ab 01 00 00 00 00 00 00  7d 02 64 02 67 01 7c 02  |........}.d.g.|.|
00000150  5f 02 00 00 00 00 00 00  00 00 7c 02 6a 07 00 00  |_.........|.j...|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000170  ab 00 00 00 00 00 00 00  01 00 7c 02 6a 04 00 00  |..........|.j...|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  64 02 67 01 6b 28 00 00  73 02 4a 00 82 01 67 00  |d.g.k(..s.J...g.|
000001a0  64 03 a2 01 7d 03 74 09  00 00 00 00 00 00 00 00  |d...}.t.........|
000001b0  7c 02 6a 0a 00 00 00 00  00 00 00 00 00 00 00 00  ||.j.............|
000001c0  00 00 00 00 00 00 ab 01  00 00 00 00 00 00 7d 04  |..............}.|
000001d0  7c 04 7c 03 6b 28 00 00  73 02 4a 00 82 01 79 00  ||.|.k(..s.J...y.|
000001e0  29 04 4e e9 01 00 00 00  da 05 67 7a 74 61 72 29  |).N.......gztar)|
000001f0  07 da 05 62 7a 74 61 72  72 09 00 00 00 da 03 72  |...bztarr......r|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_dumb.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.8K 2025-06-01 01:29:43.359978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_dumb.cpython-312.pyc
913460bf895dc5bc126a46a978e1e86ef2c982da0cff6a774761e86abcbae145  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_dumb.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 c7 08 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 4c 01  00 00 97 00 64 00 5a 00  |......L.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 01 64 05 6c 08 6d 09  5a 09 01 00 64 01 64 02  |d.d.l.m.Z...d.d.|
00000070  6c 0a 5a 0a 64 06 5a 0b  65 09 6a 18 00 00 00 00  |l.Z.d.Z.e.j.....|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 65 0a  |..............e.|
00000090  6a 1a 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000a0  00 00 00 00 6a 1d 00 00  00 00 00 00 00 00 00 00  |....j...........|
000000b0  00 00 00 00 00 00 00 00  64 07 ab 01 00 00 00 00  |........d.......|
000000c0  00 00 65 0a 6a 1a 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
000000d0  00 00 00 00 00 00 00 00  6a 1d 00 00 00 00 00 00  |........j.......|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 64 08 ab 01  |............d...|
000000f0  00 00 00 00 00 00 65 0a  6a 1a 00 00 00 00 00 00  |......e.j.......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 6a 1d 00 00  |............j...|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000120  64 09 ab 01 00 00 00 00  00 00 02 00 47 00 64 0a  |d...........G.d.|
00000130  84 00 64 0b 65 09 6a 1e  00 00 00 00 00 00 00 00  |..d.e.j.........|
00000140  00 00 00 00 00 00 00 00  00 00 ab 03 00 00 00 00  |................|
00000150  00 00 ab 00 00 00 00 00  00 00 ab 00 00 00 00 00  |................|
*
00000170  00 00 5a 10 79 02 29 0c  7a 27 54 65 73 74 73 20  |..Z.y.).z'Tests |
00000180  66 6f 72 20 64 69 73 74  75 74 69 6c 73 2e 63 6f  |for distutils.co|
00000190  6d 6d 61 6e 64 2e 62 64  69 73 74 5f 64 75 6d 62  |mmand.bdist_dumb|
000001a0  2e e9 00 00 00 00 4e 29  01 da 0a 62 64 69 73 74  |......N)...bdist|
000001b0  5f 64 75 6d 62 29 01 da  0c 44 69 73 74 72 69 62  |_dumb)...Distrib|
000001c0  75 74 69 6f 6e 29 01 da  07 73 75 70 70 6f 72 74  |ution)...support|
000001d0  7a 96 66 72 6f 6d 20 64  69 73 74 75 74 69 6c 73  |z.from distutils|
000001e0  2e 63 6f 72 65 20 69 6d  70 6f 72 74 20 73 65 74  |.core import set|
000001f0  75 70 0a 69 6d 70 6f 72  74 20 66 6f 6f 0a 0a 73  |up.import foo..s|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_dumb.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_rpm.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.6K 2025-06-01 01:29:43.519978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_rpm.cpython-312.pyc
2160c141e8f57b8c84cfc8d4a573ebf172c56d8dbcfe698f51cc6e44c784611e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_rpm.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 5c 0f 00 00  |..........8h\...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 a6 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 01 64 05 6c 08 6d 09  5a 09 01 00 64 01 64 02  |d.d.l.m.Z...d.d.|
00000070  6c 0a 5a 0a 64 01 64 06  6c 0b 6d 0c 5a 0c 01 00  |l.Z.d.d.l.m.Z...|
00000080  64 07 5a 0d 02 00 65 0a  6a 1c 00 00 00 00 00 00  |d.Z...e.j.......|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 64 08 ac 09  |............d...|
000000a0  ab 01 00 00 00 00 00 00  64 0a 84 00 ab 00 00 00  |........d.......|
000000b0  00 00 00 00 5a 0f 65 0a  6a 20 00 00 00 00 00 00  |....Z.e.j ......|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 6a 23 00 00  |............j#..|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  64 0b 64 0c ac 0d ab 02  00 00 00 00 00 00 5a 12  |d.d...........Z.|
000000f0  65 0a 6a 20 00 00 00 00  00 00 00 00 00 00 00 00  |e.j ............|
00000100  00 00 00 00 00 00 6a 27  00 00 00 00 00 00 00 00  |......j'........|
00000110  00 00 00 00 00 00 00 00  00 00 64 0e ab 01 00 00  |..........d.....|
00000120  00 00 00 00 65 0a 6a 20  00 00 00 00 00 00 00 00  |....e.j ........|
00000130  00 00 00 00 00 00 00 00  00 00 6a 27 00 00 00 00  |..........j'....|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 0f  |..............d.|
00000150  ab 01 00 00 00 00 00 00  65 0a 6a 20 00 00 00 00  |........e.j ....|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 00 00 6a 27  |..............j'|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000180  00 00 64 10 ab 01 00 00  00 00 00 00 02 00 47 00  |..d...........G.|
00000190  64 11 84 00 64 12 65 09  6a 28 00 00 00 00 00 00  |d...d.e.j(......|
000001a0  00 00 00 00 00 00 00 00  00 00 00 00 ab 03 00 00  |................|
000001b0  00 00 00 00 ab 00 00 00  00 00 00 00 ab 00 00 00  |................|
000001c0  00 00 00 00 ab 00 00 00  00 00 00 00 5a 15 79 02  |............Z.y.|
000001d0  29 13 7a 26 54 65 73 74  73 20 66 6f 72 20 64 69  |).z&Tests for di|
000001e0  73 74 75 74 69 6c 73 2e  63 6f 6d 6d 61 6e 64 2e  |stutils.command.|
000001f0  62 64 69 73 74 5f 72 70  6d 2e e9 00 00 00 00 4e  |bdist_rpm......N|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_bdist_rpm.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.8K 2025-06-01 01:29:43.675978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build.cpython-312.pyc
75d4fe238cff428735f9fbc8838e95787142d7326ba1c6ca415e667949fb7e7b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 ce 06 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 6a 00  00 00 97 00 64 00 5a 00  |......j.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 03 6c 03 6d 04  5a 04 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 6d 09 5a 09 01 00  02 00 47 00 64 06 84 00  |Z.m.Z.....G.d...|
00000070  64 07 65 06 6a 14 00 00  00 00 00 00 00 00 00 00  |d.e.j...........|
00000080  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
00000090  5a 0b 79 02 29 08 7a 22  54 65 73 74 73 20 66 6f  |Z.y.).z"Tests fo|
000000a0  72 20 64 69 73 74 75 74  69 6c 73 2e 63 6f 6d 6d  |r distutils.comm|
000000b0  61 6e 64 2e 62 75 69 6c  64 2e e9 00 00 00 00 4e  |and.build......N|
000000c0  29 01 da 05 62 75 69 6c  64 29 01 da 07 73 75 70  |)...build)...sup|
000000d0  70 6f 72 74 29 02 da 0e  67 65 74 5f 63 6f 6e 66  |port)...get_conf|
000000e0  69 67 5f 76 61 72 da 0c  67 65 74 5f 70 6c 61 74  |ig_var..get_plat|
000000f0  66 6f 72 6d 63 00 00 00  00 00 00 00 00 00 00 00  |formc...........|
00000100  00 01 00 00 00 00 00 00  00 f3 12 00 00 00 97 00  |................|
00000110  65 00 5a 01 64 00 5a 02  64 01 84 00 5a 03 79 02  |e.Z.d.Z.d...Z.y.|
00000120  29 03 da 09 54 65 73 74  42 75 69 6c 64 63 01 00  |)...TestBuildc..|
00000130  00 00 00 00 00 00 00 00  00 00 07 00 00 00 03 00  |................|
00000140  00 00 f3 68 04 00 00 97  00 7c 00 6a 01 00 00 00  |...h.....|.j....|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 ab  |................|
00000160  00 00 00 00 00 00 00 5c  02 00 00 7d 01 7d 02 74  |.......\...}.}.t|
00000170  03 00 00 00 00 00 00 00  00 7c 02 ab 01 00 00 00  |.........|......|
00000180  00 00 00 7d 03 7c 03 6a  05 00 00 00 00 00 00 00  |...}.|.j........|
00000190  00 00 00 00 00 00 00 00  00 00 00 ab 00 00 00 00  |................|
000001a0  00 00 00 01 00 7c 03 6a  06 00 00 00 00 00 00 00  |.....|.j........|
000001b0  00 00 00 00 00 00 00 00  00 00 00 74 09 00 00 00  |...........t....|
000001c0  00 00 00 00 00 ab 00 00  00 00 00 00 00 6b 28 00  |.............k(.|
000001d0  00 73 02 4a 00 82 01 74  0a 00 00 00 00 00 00 00  |.s.J...t........|
000001e0  00 6a 0c 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
000001f0  00 00 00 00 00 6a 0f 00  00 00 00 00 00 00 00 00  |.....j..........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_clib.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.5K 2025-06-01 01:29:43.835978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_clib.cpython-312.pyc
806d5c42bc2aa19d31d2a853c48595fb69a2b01c42b080f2294dc80a3eb09854  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_clib.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 eb 10 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 6a 00  00 00 97 00 64 00 5a 00  |......j.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 01 64 05 6c 06 6d 07  5a 07 6d 08 5a 08 01 00  |d.d.l.m.Z.m.Z...|
00000060  64 01 64 02 6c 09 5a 09  02 00 47 00 64 06 84 00  |d.d.l.Z...G.d...|
00000070  64 07 65 08 6a 14 00 00  00 00 00 00 00 00 00 00  |d.e.j...........|
00000080  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
00000090  5a 0b 79 02 29 08 7a 27  54 65 73 74 73 20 66 6f  |Z.y.).z'Tests fo|
000000a0  72 20 64 69 73 74 75 74  69 6c 73 2e 63 6f 6d 6d  |r distutils.comm|
000000b0  61 6e 64 2e 62 75 69 6c  64 5f 63 6c 69 62 2e e9  |and.build_clib..|
000000c0  00 00 00 00 4e 29 01 da  0a 62 75 69 6c 64 5f 63  |....N)...build_c|
000000d0  6c 69 62 29 01 da 13 44  69 73 74 75 74 69 6c 73  |lib)...Distutils|
000000e0  53 65 74 75 70 45 72 72  6f 72 29 02 da 1b 6d 69  |SetupError)...mi|
000000f0  73 73 69 6e 67 5f 63 6f  6d 70 69 6c 65 72 5f 65  |ssing_compiler_e|
00000100  78 65 63 75 74 61 62 6c  65 da 07 73 75 70 70 6f  |xecutable..suppo|
00000110  72 74 63 00 00 00 00 00  00 00 00 00 00 00 00 03  |rtc.............|
00000120  00 00 00 00 00 00 00 f3  66 00 00 00 97 00 65 00  |........f.....e.|
00000130  5a 01 64 00 5a 02 64 01  84 00 5a 03 64 02 84 00  |Z.d.Z.d...Z.d...|
00000140  5a 04 64 03 84 00 5a 05  64 04 84 00 5a 06 65 07  |Z.d...Z.d...Z.e.|
00000150  6a 10 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000160  00 00 00 00 6a 13 00 00  00 00 00 00 00 00 00 00  |....j...........|
00000170  00 00 00 00 00 00 00 00  64 05 ab 01 00 00 00 00  |........d.......|
00000180  00 00 64 06 84 00 ab 00  00 00 00 00 00 00 5a 0a  |..d...........Z.|
00000190  79 07 29 08 da 0d 54 65  73 74 42 75 69 6c 64 43  |y.)...TestBuildC|
000001a0  4c 69 62 63 01 00 00 00  00 00 00 00 00 00 00 00  |Libc............|
000001b0  06 00 00 00 03 00 00 00  f3 00 03 00 00 97 00 7c  |...............||
000001c0  00 6a 01 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
000001d0  00 00 00 00 00 ab 00 00  00 00 00 00 00 5c 02 00  |.............\..|
000001e0  00 7d 01 7d 02 74 03 00  00 00 00 00 00 00 00 7c  |.}.}.t.........||
000001f0  02 ab 01 00 00 00 00 00  00 7d 03 74 05 00 00 00  |.........}.t....|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_clib.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_ext.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 29K 2025-06-01 01:29:44.003978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_ext.cpython-312.pyc
d6cb0b73405b73caffed0400fe1ac4a6eb347491ba288ac15aa5e29030d4574a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_ext.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 11 58 00 00  |..........8h.X..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 ee 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 04 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 00 64 01  6c 06 5a 06 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 5a 07 64 00 64 01  6c 08 5a 08 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000070  6c 09 5a 09 64 00 64 01  6c 0a 5a 0a 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000080  6c 0b 5a 0b 64 00 64 01  6c 0c 5a 0c 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000090  6c 0d 5a 0d 64 00 64 02  6c 0e 6d 0f 5a 0f 01 00  |l.Z.d.d.l.m.Z...|
000000a0  64 00 64 03 6c 10 6d 11  5a 11 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
000000b0  6c 12 6d 13 5a 13 01 00  64 00 64 05 6c 14 6d 15  |l.m.Z...d.d.l.m.|
000000c0  5a 15 6d 16 5a 16 6d 17  5a 17 6d 18 5a 18 01 00  |Z.m.Z.m.Z.m.Z...|
000000d0  64 00 64 06 6c 19 6d 1a  5a 1a 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000e0  6c 1b 6d 1c 5a 1c 01 00  64 00 64 08 6c 1d 6d 1e  |l.m.Z...d.d.l.m.|
000000f0  5a 1e 6d 1f 5a 1f 6d 20  5a 20 01 00 64 00 64 09  |Z.m.Z.m Z ..d.d.|
00000100  6c 21 6d 22 5a 22 01 00  64 00 64 01 6c 23 5a 24  |l!m"Z"..d.d.l#Z$|
00000110  64 00 64 01 6c 25 5a 25  64 00 64 01 6c 26 5a 26  |d.d.l%Z%d.d.l&Z&|
00000120  64 00 64 0a 6c 27 6d 28  5a 28 01 00 64 0b 64 0c  |d.d.l'm(Z(..d.d.|
00000130  6c 29 6d 2a 5a 2b 01 00  02 00 65 26 6a 58 00 00  |l)m*Z+....e&jX..|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  ab 00 00 00 00 00 00 00  64 0d 84 00 ab 00 00 00  |........d.......|
00000160  00 00 00 00 5a 2d 65 00  6a 5c 00 00 00 00 00 00  |....Z-e.j\......|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 64 0e 84 00  |............d...|
00000180  ab 00 00 00 00 00 00 00  5a 2f 65 00 6a 5c 00 00  |........Z/e.j\..|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  64 0f 84 00 ab 00 00 00  00 00 00 00 5a 30 65 26  |d...........Z0e&|
000001b0  6a 62 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jb..............|
000001c0  00 00 00 00 6a 65 00 00  00 00 00 00 00 00 00 00  |....je..........|
000001d0  00 00 00 00 00 00 00 00  64 10 ab 01 00 00 00 00  |........d.......|
000001e0  00 00 02 00 47 00 64 11  84 00 64 12 65 1e ab 03  |....G.d...d.e...|
000001f0  00 00 00 00 00 00 ab 00  00 00 00 00 00 00 5a 33  |..............Z3|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_ext.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_py.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.7K 2025-06-01 01:29:44.163978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_py.cpython-312.pyc
7085e01c7a3b1f07e259e99e03ff78f9a3a4ecd8508eaf224ef8298adecd84fc  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_py.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 e2 1a 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 a0 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 03 6c 03 6d 04  5a 04 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 01 64 06  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 01 64 02 6c 0b 5a 0c  64 01 64 02 6c 0d 5a 0d  |d.d.l.Z.d.d.l.Z.|
00000080  65 0a 6a 1c 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000090  00 00 00 00 00 00 02 00  47 00 64 07 84 00 64 08  |........G.d...d.|
000000a0  65 0a 6a 1e 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
000000b0  00 00 00 00 00 00 ab 03  00 00 00 00 00 00 ab 00  |................|
000000c0  00 00 00 00 00 00 5a 10  79 02 29 09 7a 25 54 65  |......Z.y.).z%Te|
000000d0  73 74 73 20 66 6f 72 20  64 69 73 74 75 74 69 6c  |sts for distutil|
000000e0  73 2e 63 6f 6d 6d 61 6e  64 2e 62 75 69 6c 64 5f  |s.command.build_|
000000f0  70 79 2e e9 00 00 00 00  4e 29 01 da 08 62 75 69  |py......N)...bui|
00000100  6c 64 5f 70 79 29 01 da  0c 44 69 73 74 72 69 62  |ld_py)...Distrib|
00000110  75 74 69 6f 6e 29 01 da  12 44 69 73 74 75 74 69  |ution)...Distuti|
00000120  6c 73 46 69 6c 65 45 72  72 6f 72 29 01 da 07 73  |lsFileError)...s|
00000130  75 70 70 6f 72 74 63 00  00 00 00 00 00 00 00 00  |upportc.........|
00000140  00 00 00 03 00 00 00 00  00 00 00 f3 ae 00 00 00  |................|
00000150  97 00 65 00 5a 01 64 00  5a 02 64 01 84 00 5a 03  |..e.Z.d.Z.d...Z.|
00000160  64 02 84 00 5a 04 65 05  6a 0c 00 00 00 00 00 00  |d...Z.e.j.......|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 6a 0f 00 00  |............j...|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  64 03 ab 01 00 00 00 00  00 00 64 04 84 00 ab 00  |d.........d.....|
000001a0  00 00 00 00 00 00 5a 08  65 05 6a 0c 00 00 00 00  |......Z.e.j.....|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 6a 0f  |..............j.|
000001c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001d0  00 00 64 03 ab 01 00 00  00 00 00 00 64 05 84 00  |..d.........d...|
000001e0  ab 00 00 00 00 00 00 00  5a 09 64 06 84 00 5a 0a  |........Z.d...Z.|
000001f0  64 07 84 00 5a 0b 64 08  84 00 5a 0c 79 09 29 0a  |d...Z.d...Z.y.).|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_py.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_scripts.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.7K 2025-06-01 01:29:44.315978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_scripts.cpython-312.pyc
edf7d378e68e115a42d3dd4b90c6c928890e3148fb7a7fce30e5c826a6a6a689  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_scripts.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 40 0b 00 00  |..........8h@...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 7a 00  00 00 97 00 64 00 5a 00  |......z.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 03 6c 03 6d 04  5a 04 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 01 64 06  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 01 64 02 6c 0b 5a 0c  02 00 47 00 64 07 84 00  |d.d.l.Z...G.d...|
00000080  64 08 65 0a 6a 1a 00 00  00 00 00 00 00 00 00 00  |d.e.j...........|
00000090  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
000000a0  5a 0e 79 02 29 09 7a 2a  54 65 73 74 73 20 66 6f  |Z.y.).z*Tests fo|
000000b0  72 20 64 69 73 74 75 74  69 6c 73 2e 63 6f 6d 6d  |r distutils.comm|
000000c0  61 6e 64 2e 62 75 69 6c  64 5f 73 63 72 69 70 74  |and.build_script|
000000d0  73 2e e9 00 00 00 00 4e  29 01 da 09 73 79 73 63  |s......N)...sysc|
000000e0  6f 6e 66 69 67 29 01 da  0d 62 75 69 6c 64 5f 73  |onfig)...build_s|
000000f0  63 72 69 70 74 73 29 01  da 0c 44 69 73 74 72 69  |cripts)...Distri|
00000100  62 75 74 69 6f 6e 29 01  da 07 73 75 70 70 6f 72  |bution)...suppor|
00000110  74 63 00 00 00 00 00 00  00 00 00 00 00 00 02 00  |tc..............|
00000120  00 00 00 00 00 00 f3 34  00 00 00 97 00 65 00 5a  |.......4.....e.Z|
00000130  01 64 00 5a 02 64 01 84  00 5a 03 64 02 84 00 5a  |.d.Z.d...Z.d...Z|
00000140  04 64 03 84 00 5a 05 65  06 64 04 84 00 ab 00 00  |.d...Z.e.d......|
00000150  00 00 00 00 00 5a 07 64  05 84 00 5a 08 79 06 29  |.....Z.d...Z.y.)|
00000160  07 da 10 54 65 73 74 42  75 69 6c 64 53 63 72 69  |...TestBuildScri|
00000170  70 74 73 63 01 00 00 00  00 00 00 00 00 00 00 00  |ptsc............|
00000180  04 00 00 00 03 00 00 00  f3 be 00 00 00 97 00 7c  |...............||
00000190  00 6a 01 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
000001a0  00 00 00 00 00 64 01 67  00 ab 02 00 00 00 00 00  |.....d.g........|
000001b0  00 7d 01 7c 01 6a 02 00  00 00 00 00 00 00 00 00  |.}.|.j..........|
000001c0  00 00 00 00 00 00 00 00  00 72 02 4a 00 82 01 7c  |.........r.J...||
000001d0  01 6a 04 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
000001e0  00 00 00 00 00 81 02 4a  00 82 01 7c 01 6a 07 00  |.......J...|.j..|
000001f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_build_scripts.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_check.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.0K 2025-06-01 01:29:44.471978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_check.cpython-312.pyc
fd9a2a1358155aa061119aee6ec6a74bba4d5e98e70727624cbad1c6246c867a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_check.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 52 18 00 00  |..........8hR...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 e6 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 03 6c 03 6d 04  5a 04 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 01 64 02  6c 09 5a 09 09 00 64 01  |Z...d.d.l.Z...d.|
00000070  64 02 6c 0a 5a 0a 65 01  6a 18 00 00 00 00 00 00  |d.l.Z.e.j.......|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 6a 1b 00 00  |............j...|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000a0  65 0e ab 01 00 00 00 00  00 00 5a 0f 65 08 6a 20  |e.........Z.e.j |
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  00 00 02 00 47 00 64 06  84 00 64 07 65 08 6a 22  |....G.d...d.e.j"|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  00 00 ab 03 00 00 00 00  00 00 ab 00 00 00 00 00  |................|
000000f0  00 00 5a 12 79 02 23 00  65 0b 24 00 72 05 01 00  |..Z.y.#.e.$.r...|
00000100  64 02 5a 0a 59 00 8c 49  77 00 78 03 59 00 77 01  |d.Z.Y..Iw.x.Y.w.|
00000110  29 08 7a 22 54 65 73 74  73 20 66 6f 72 20 64 69  |).z"Tests for di|
00000120  73 74 75 74 69 6c 73 2e  63 6f 6d 6d 61 6e 64 2e  |stutils.command.|
00000130  63 68 65 63 6b 2e e9 00  00 00 00 4e 29 01 da 05  |check......N)...|
00000140  63 68 65 63 6b 29 01 da  13 44 69 73 74 75 74 69  |check)...Distuti|
00000150  6c 73 53 65 74 75 70 45  72 72 6f 72 29 01 da 07  |lsSetupError)...|
00000160  73 75 70 70 6f 72 74 63  00 00 00 00 00 00 00 00  |supportc........|
00000170  00 00 00 00 02 00 00 00  00 00 00 00 f3 38 00 00  |.............8..|
00000180  00 97 00 65 00 5a 01 64  00 5a 02 64 09 64 02 84  |...e.Z.d.Z.d.d..|
00000190  01 5a 03 64 03 84 00 5a  04 64 04 84 00 5a 05 64  |.Z.d...Z.d...Z.d|
000001a0  05 84 00 5a 06 64 06 84  00 5a 07 64 07 84 00 5a  |...Z.d...Z.d...Z|
000001b0  08 64 08 84 00 5a 09 79  01 29 0a da 09 54 65 73  |.d...Z.y.)...Tes|
000001c0  74 43 68 65 63 6b 4e 63  03 00 00 00 00 00 00 00  |tCheckNc........|
000001d0  00 00 00 00 06 00 00 00  0b 00 00 00 f3 7c 01 00  |.............|..|
000001e0  00 97 00 7c 01 80 02 69  00 7d 01 7c 02 81 29 74  |...|...i.}.|..)t|
000001f0  01 00 00 00 00 00 00 00  00 6a 02 00 00 00 00 00  |.........j......|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_check.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_clean.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.9K 2025-06-01 01:29:44.619978118 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_clean.cpython-312.pyc
d43522d5c4b654871c0dbb2b94332076d7a31998afd5638cdb442f9865c34fad  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_clean.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 d8 04 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 52 00  00 00 97 00 64 00 5a 00  |......R.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  02 00 47 00 64 05 84 00  64 06 65 05 6a 0c 00 00  |..G.d...d.e.j...|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000070  ab 03 00 00 00 00 00 00  5a 07 79 02 29 07 7a 22  |........Z.y.).z"|
00000080  54 65 73 74 73 20 66 6f  72 20 64 69 73 74 75 74  |Tests for distut|
00000090  69 6c 73 2e 63 6f 6d 6d  61 6e 64 2e 63 6c 65 61  |ils.command.clea|
000000a0  6e 2e e9 00 00 00 00 4e  29 01 da 05 63 6c 65 61  |n......N)...clea|
000000b0  6e 29 01 da 07 73 75 70  70 6f 72 74 63 00 00 00  |n)...supportc...|
000000c0  00 00 00 00 00 00 00 00  00 01 00 00 00 00 00 00  |................|
000000d0  00 f3 12 00 00 00 97 00  65 00 5a 01 64 00 5a 02  |........e.Z.d.Z.|
000000e0  64 01 84 00 5a 03 79 02  29 03 da 09 54 65 73 74  |d...Z.y.)...Test|
000000f0  43 6c 65 61 6e 63 01 00  00 00 00 00 00 00 00 00  |Cleanc..........|
00000100  00 00 08 00 00 00 03 00  00 00 f3 7a 02 00 00 97  |...........z....|
00000110  00 7c 00 6a 01 00 00 00  00 00 00 00 00 00 00 00  |.|.j............|
00000120  00 00 00 00 00 00 00 ab  00 00 00 00 00 00 00 5c  |...............\|
00000130  02 00 00 7d 01 7d 02 74  03 00 00 00 00 00 00 00  |...}.}.t........|
00000140  00 7c 02 ab 01 00 00 00  00 00 00 7d 03 64 01 44  |.|.........}.d.D|
00000150  00 8f 04 63 02 67 00 63  02 5d 24 00 00 7d 04 7c  |...c.g.c.]$..}.||
00000160  04 74 04 00 00 00 00 00  00 00 00 6a 06 00 00 00  |.t.........j....|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 6a  |...............j|
00000180  09 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  00 00 00 7c 01 7c 04 ab  02 00 00 00 00 00 00 66  |...|.|.........f|
000001a0  02 91 02 8c 26 04 00 7d  05 7d 04 7c 05 44 00 5d  |....&..}.}.|.D.]|
000001b0  63 00 00 5c 02 00 00 7d  06 7d 07 74 05 00 00 00  |c..\...}.}.t....|
000001c0  00 00 00 00 00 6a 0a 00  00 00 00 00 00 00 00 00  |.....j..........|
000001d0  00 00 00 00 00 00 00 00  00 7c 07 ab 01 00 00 00  |.........|......|
000001e0  00 00 00 01 00 74 0d 00  00 00 00 00 00 00 00 7c  |.....t.........||
000001f0  03 7c 06 7c 07 ab 03 00  00 00 00 00 00 01 00 7c  |.|.|...........||
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_clean.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_cmd.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.2K 2025-06-01 01:29:44.775978117 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_cmd.cpython-312.pyc
c3ad5fa2cd975fae0346f60e793cbbc6f8fa946bf382d5c5d2691ee85eb9b972  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/__pycache__/test_cmd.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 b6 0c 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 96 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 01 64 05 6c 06 6d 07  5a 07 01 00 64 01 64 06  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 01 64 02 6c 0a 5a 0a  |l.m.Z...d.d.l.Z.|
00000070  02 00 47 00 64 07 84 00  64 08 65 05 ab 03 00 00  |..G.d...d.e.....|
00000080  00 00 00 00 5a 0b 65 0a  6a 18 00 00 00 00 00 00  |....Z.e.j.......|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 64 09 84 00  |............d...|
000000a0  ab 00 00 00 00 00 00 00  5a 0d 02 00 47 00 64 0a  |........Z...G.d.|
000000b0  84 00 64 0b ab 02 00 00  00 00 00 00 5a 0e 79 02  |..d.........Z.y.|
000000c0  29 0c 7a 18 54 65 73 74  73 20 66 6f 72 20 64 69  |).z.Tests for di|
000000d0  73 74 75 74 69 6c 73 2e  63 6d 64 2e e9 00 00 00  |stutils.cmd.....|
000000e0  00 4e 29 01 da 05 64 65  62 75 67 29 01 da 07 43  |.N)...debug)...C|
000000f0  6f 6d 6d 61 6e 64 29 01  da 0c 44 69 73 74 72 69  |ommand)...Distri|
00000100  62 75 74 69 6f 6e 29 01  da 14 44 69 73 74 75 74  |bution)...Distut|
00000110  69 6c 73 4f 70 74 69 6f  6e 45 72 72 6f 72 63 00  |ilsOptionErrorc.|
00000120  00 00 00 00 00 00 00 00  00 00 00 01 00 00 00 00  |................|
00000130  00 00 00 f3 12 00 00 00  97 00 65 00 5a 01 64 00  |..........e.Z.d.|
00000140  5a 02 64 01 84 00 5a 03  79 02 29 03 da 05 4d 79  |Z.d...Z.y.)...My|
00000150  43 6d 64 63 01 00 00 00  00 00 00 00 00 00 00 00  |Cmdc............|
00000160  00 00 00 00 03 00 00 00  f3 04 00 00 00 97 00 79  |...............y|
00000170  00 a9 01 4e a9 00 29 01  da 04 73 65 6c 66 73 01  |...N..)...selfs.|
00000180  00 00 00 20 fa 86 2f 64  61 74 61 2f 64 61 74 61  |... ../data/data|
00000190  2f 63 6f 6d 2e 74 65 72  6d 75 78 2f 66 69 6c 65  |/com.termux/file|
000001a0  73 2f 68 6f 6d 65 2f 52  41 46 41 45 4c 49 41 2f  |s/home/RAFAELIA/|
000001b0  48 43 50 4d 2f 43 4f 52  45 2f 76 65 6e 76 5f 72  |HCPM/CORE/venv_r|
000001c0  61 66 61 65 6c 69 61 2f  6c 69 62 2f 70 79 74 68  |afaelia/lib/pyth|
000001d0  6f 6e 33 2e 31 32 2f 73  69 74 65 2d 70 61 63 6b  |on3.12/site-pack|
000001e0  61 67 65 73 2f 73 65 74  75 70 74 6f 6f 6c 73 2f  |ages/setuptools/|
000001f0  5f 64 69 73 74 75 74 69  6c 73 2f 74 65 73 74 73  |_distutils/tests|