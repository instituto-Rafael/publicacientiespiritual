#!/usr/bin/env python3
import re
import itertools
import textwrap
import functools

try:
    from importlib.resources import files  # type: ignore
except ImportError:  # pragma: nocover
    from importlib_resources import files  # type: ignore

from jaraco.functools import compose, method_cache
from jaraco.context import ExceptionTrap


def substitution(old, new):
    """
    Return a function that will perform a substitution on a string
    """
    return lambda s: s.replace(old, new)


def multi_substitution(*substitutions):
    """
    Take a sequence of pairs specifying substitutions, and create
    a function that performs those substitutions.

    >>> multi_substitution(('foo', 'bar'), ('bar', 'baz'))('foo')
    'baz'
    """
    substitutions = itertools.starmap(substitution, substitutions)
    # compose function applies last function first, so reverse the
    #  substitutions to get the expected order.
    substitutions = reversed(tuple(substitutions))
    return compose(*substitutions)


class FoldedCase(str):
    """
    A case insensitive string class; behaves just like str
    except compares equal when the only variation is case.

    >>> s = FoldedCase('hello world')

    >>> s == 'Hello World'
    True

    >>> 'Hello World' == s
    True

    >>> s != 'Hello World'
    False

    >>> s.index('O')
    4

    >>> s.split('O')
    ['hell', ' w', 'rld']

    >>> sorted(map(FoldedCase, ['GAMMA', 'alpha', 'Beta']))
    ['alpha', 'Beta', 'GAMMA']

    Sequence membership is straightforward.

    >>> "Hello World" in [s]
    True
    >>> s in ["Hello World"]
    True

    Allows testing for set inclusion, but candidate and elements
    must both be folded.

    >>> FoldedCase("Hello World") in {s}
    True
    >>> s in {FoldedCase("Hello World")}
    True

    String inclusion works as long as the FoldedCase object
    is on the right.

    >>> "hello" in FoldedCase("Hello World")
    True

    But not if the FoldedCase object is on the left:

    >>> FoldedCase('hello') in 'Hello World'
    False

    In that case, use ``in_``:

    >>> FoldedCase('hello').in_('Hello World')
    True

    >>> FoldedCase('hello') > FoldedCase('Hello')
    False

    >>> FoldedCase('ß') == FoldedCase('ss')
    True
    """

    def __lt__(self, other):
        return self.casefold() < other.casefold()

    def __gt__(self, other):
        return self.casefold() > other.casefold()

    def __eq__(self, other):
        return self.casefold() == other.casefold()

    def __ne__(self, other):
        return self.casefold() != other.casefold()

    def __hash__(self):
        return hash(self.casefold())

    def __contains__(self, other):
        return super().casefold().__contains__(other.casefold())

    def in_(self, other):
        "Does self appear in other?"
        return self in FoldedCase(other)

    # cache casefold since it's likely to be called frequently.
    @method_cache
    def casefold(self):
        return super().casefold()

    def index(self, sub):
        return self.casefold().index(sub.casefold())

    def split(self, splitter=' ', maxsplit=0):
        pattern = re.compile(re.escape(splitter), re.I)
        return pattern.split(self, maxsplit)


# Python 3.8 compatibility
_unicode_trap = ExceptionTrap(UnicodeDecodeError)


@_unicode_trap.passes
def is_decodable(value):
    r"""
    Return True if the supplied value is decodable (using the default
    encoding).

    >>> is_decodable(b'\xff')
    False
    >>> is_decodable(b'\x32')
    True
    """
    value.decode()


def is_binary(value):
    r"""
    Return True if the value appears to be binary (that is, it's a byte
    string and isn't decodable).

    >>> is_binary(b'\xff')
    True
    >>> is_binary('\xff')
    False
    """
    return isinstance(value, bytes) and not is_decodable(value)


def trim(s):
    r"""
    Trim something like a docstring to remove the whitespace that
    is common due to indentation and formatting.

    >>> trim("\n\tfoo = bar\n\t\tbar = baz\n")
    'foo = bar\n\tbar = baz'
    """
    return textwrap.dedent(s).strip()


def wrap(s):
    """
    Wrap lines of text, retaining existing newlines as
    paragraph markers.

    >>> print(wrap(lorem_ipsum))
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
    minim veniam, quis nostrud exercitation ullamco laboris nisi ut
    aliquip ex ea commodo consequat. Duis aute irure dolor in
    reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
    pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
    culpa qui officia deserunt mollit anim id est laborum.
    <BLANKLINE>
    Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam
    varius, turpis et commodo pharetra, est eros bibendum elit, nec luctus
    magna felis sollicitudin mauris. Integer in mauris eu nibh euismod
    gravida. Duis ac tellus et risus vulputate vehicula. Donec lobortis
    risus a elit. Etiam tempor. Ut ullamcorper, ligula eu tempor congue,
    eros est euismod turpis, id tincidunt sapien risus a quam. Maecenas
    fermentum consequat mi. Donec fermentum. Pellentesque malesuada nulla
    a mi. Duis sapien sem, aliquet nec, commodo eget, consequat quis,
    neque. Aliquam faucibus, elit ut dictum aliquet, felis nisl adipiscing
    sapien, sed malesuada diam lacus eget erat. Cras mollis scelerisque
    nunc. Nullam arcu. Aliquam consequat. Curabitur augue lorem, dapibus
    quis, laoreet et, pretium ac, nisi. Aenean magna nisl, mollis quis,
    molestie eu, feugiat in, orci. In hac habitasse platea dictumst.
    """
    paragraphs = s.splitlines()
    wrapped = ('\n'.join(textwrap.wrap(para)) for para in paragraphs)
    return '\n\n'.join(wrapped)


def unwrap(s):
    r"""
    Given a multi-line string, return an unwrapped version.

    >>> wrapped = wrap(lorem_ipsum)
    >>> wrapped.count('\n')
    20
    >>> unwrapped = unwrap(wrapped)
    >>> unwrapped.count('\n')
    1
    >>> print(unwrapped)
    Lorem ipsum dolor sit amet, consectetur adipiscing ...
    Curabitur pretium tincidunt lacus. Nulla gravida orci ...

    """
    paragraphs = re.split(r'\n\n+', s)
    cleaned = (para.replace('\n', ' ') for para in paragraphs)
    return '\n'.join(cleaned)


lorem_ipsum: str = (
    files(__name__).joinpath('Lorem ipsum.txt').read_text(encoding='utf-8')
)


class Splitter:
    """object that will split a string with the given arguments for each call

    >>> s = Splitter(',')
    >>> s('hello, world, this is your, master calling')
    ['hello', ' world', ' this is your', ' master calling']
    """

    def __init__(self, *args):
        self.args = args

    def __call__(self, s):
        return s.split(*self.args)


def indent(string, prefix=' ' * 4):
    """
    >>> indent('foo')
    '    foo'
    """
    return prefix + string


class WordSet(tuple):
    """
    Given an identifier, return the words that identifier represents,
    whether in camel case, underscore-separated, etc.

    >>> WordSet.parse("camelCase")
    ('camel', 'Case')

    >>> WordSet.parse("under_sep")
    ('under', 'sep')

    Acronyms should be retained

    >>> WordSet.parse("firstSNL")
    ('first', 'SNL')

    >>> WordSet.parse("you_and_I")
    ('you', 'and', 'I')

    >>> WordSet.parse("A simple test")
    ('A', 'simple', 'test')

    Multiple caps should not interfere with the first cap of another word.

    >>> WordSet.parse("myABCClass")
    ('my', 'ABC', 'Class')

    The result is a WordSet, providing access to other forms.

    >>> WordSet.parse("myABCClass").underscore_separated()
    'my_ABC_Class'

    >>> WordSet.parse('a-command').camel_case()
    'ACommand'

    >>> WordSet.parse('someIdentifier').lowered().space_separated()
    'some identifier'

    Slices of the result should return another WordSet.

    >>> WordSet.parse('taken-out-of-context')[1:].underscore_separated()
    'out_of_context'

    >>> WordSet.from_class_name(WordSet()).lowered().space_separated()
    'word set'

    >>> example = WordSet.parse('figured it out')
    >>> example.headless_camel_case()
    'figuredItOut'
    >>> example.dash_separated()
    'figured-it-out'

    """

    _pattern = re.compile('([A-Z]?[a-z]+)|([A-Z]+(?![a-z]))')

    def capitalized(self):
        return WordSet(word.capitalize() for word in self)

    def lowered(self):
        return WordSet(word.lower() for word in self)

    def camel_case(self):
        return ''.join(self.capitalized())

    def headless_camel_case(self):
        words = iter(self)
        first = next(words).lower()
        new_words = itertools.chain((first,), WordSet(words).camel_case())
        return ''.join(new_words)

    def underscore_separated(self):
        return '_'.join(self)

    def dash_separated(self):
        return '-'.join(self)

    def space_separated(self):
        return ' '.join(self)

    def trim_right(self, item):
        """
        Remove the item from the end of the set.

        >>> WordSet.parse('foo bar').trim_right('foo')
        ('foo', 'bar')
        >>> WordSet.parse('foo bar').trim_right('bar')
        ('foo',)
        >>> WordSet.parse('').trim_right('bar')
        ()
        """
        return self[:-1] if self and self[-1] == item else self

    def trim_left(self, item):
        """
        Remove the item from the beginning of the set.

        >>> WordSet.parse('foo bar').trim_left('foo')
        ('bar',)
        >>> WordSet.parse('foo bar').trim_left('bar')
        ('foo', 'bar')
        >>> WordSet.parse('').trim_left('bar')
        ()
        """
        return self[1:] if self and self[0] == item else self

    def trim(self, item):
        """
        >>> WordSet.parse('foo bar').trim('foo')
        ('bar',)
        """
        return self.trim_left(item).trim_right(item)

    def __getitem__(self, item):
        result = super().__getitem__(item)
        if isinstance(item, slice):
            result = WordSet(result)
        return result

    @classmethod
    def parse(cls, identifier):
        matches = cls._pattern.finditer(identifier)
        return WordSet(match.group(0) for match in matches)

    @classmethod
    def from_class_name(cls, subject):
        return cls.parse(subject.__class__.__name__)


# for backward compatibility
words = WordSet.parse


def simple_html_strip(s):
    r"""
    Remove HTML from the string `s`.

    >>> str(simple_html_strip(''))
    ''

    >>> print(simple_html_strip('A <bold>stormy</bold> day in paradise'))
    A stormy day in paradise

    >>> print(simple_html_strip('Somebody <!-- do not --> tell the truth.'))
    Somebody  tell the truth.

    >>> print(simple_html_strip('What about<br/>\nmultiple lines?'))
    What about
    multiple lines?
    """
    html_stripper = re.compile('(<!--.*?-->)|(<[^>]*>)|([^<]+)', re.DOTALL)
    texts = (match.group(3) or '' for match in html_stripper.finditer(s))
    return ''.join(texts)


class SeparatedValues(str):
    """
    A string separated by a separator. Overrides __iter__ for getting
    the values.

    >>> list(SeparatedValues('a,b,c'))
    ['a', 'b', 'c']

    Whitespace is stripped and empty values are discarded.

    >>> list(SeparatedValues(' a,   b   , c,  '))
    ['a', 'b', 'c']
    """

    separator = ','

    def __iter__(self):
        parts = self.split(self.separator)
        return filter(None, (part.strip() for part in parts))


class Stripper:
    r"""
    Given a series of lines, find the common prefix and strip it from them.

    >>> lines = [
    ...     'abcdefg\n',
    ...     'abc\n',
    ...     'abcde\n',
    ... ]
    >>> res = Stripper.strip_prefix(lines)
    >>> res.prefix
    'abc'
    >>> list(res.lines)
    ['defg\n', '\n', 'de\n']

    If no prefix is common, nothing should be stripped.

    >>> lines = [
    ...     'abcd\n',
    ...     '1234\n',
    ... ]
    >>> res = Stripper.strip_prefix(lines)
    >>> res.prefix = ''
    >>> list(res.lines)
    ['abcd\n', '1234\n']
    """

    def __init__(self, prefix, lines):
        self.prefix = prefix
        self.lines = map(self, lines)

    @classmethod
    def strip_prefix(cls, lines):
        prefix_lines, lines = itertools.tee(lines)
        prefix = functools.reduce(cls.common_prefix, prefix_lines)
        return cls(prefix, lines)

    def __call__(self, line):
        if not self.prefix:
            return line
        null, prefix, rest = line.partition(self.prefix)
        return rest

    @staticmethod
    def common_prefix(s1, s2):
        """
        Return the common prefix of two lines.
        """
        index = min(len(s1), len(s2))
        while s1[:index] != s2[:index]:
            index -= 1
        return s1[:index]


def remove_prefix(text, prefix):
    """
    Remove the prefix from the text if it exists.

    >>> remove_prefix('underwhelming performance', 'underwhelming ')
    'performance'

    >>> remove_prefix('something special', 'sample')
    'something special'
    """
    null, prefix, rest = text.rpartition(prefix)
    return rest


def remove_suffix(text, suffix):
    """
    Remove the suffix from the text if it exists.

    >>> remove_suffix('name.git', '.git')
    'name'

    >>> remove_suffix('something special', 'sample')
    'something special'
    """
    rest, suffix, null = text.partition(suffix)
    return rest


def normalize_newlines(text):
    r"""
    Replace alternate newlines with the canonical newline.

    >>> normalize_newlines('Lorem Ipsum\u2029')
    'Lorem Ipsum\n'
    >>> normalize_newlines('Lorem Ipsum\r\n')
    'Lorem Ipsum\n'
    >>> normalize_newlines('Lorem Ipsum\x85')
    'Lorem Ipsum\n'
    """
    newlines = ['\r\n', '\r', '\n', '\u0085', '\u2028', '\u2029']
    pattern = '|'.join(newlines)
    return re.sub(pattern, '\n', text)


def _nonblank(str):
    return str and not str.startswith('#')


@functools.singledispatch
def yield_lines(iterable):
    r"""
    Yield valid lines of a string or iterable.

    >>> list(yield_lines(''))
    []
    >>> list(yield_lines(['foo', 'bar']))
    ['foo', 'bar']
    >>> list(yield_lines('foo\nbar'))
    ['foo', 'bar']
    >>> list(yield_lines('\nfoo\n#bar\nbaz #comment'))
    ['foo', 'baz #comment']
    >>> list(yield_lines(['foo\nbar', 'baz', 'bing\n\n\n']))
    ['foo', 'bar', 'baz', 'bing']
    """
    return itertools.chain.from_iterable(map(yield_lines, iterable))


@yield_lines.register(str)
def _(text):
    return filter(_nonblank, map(str.strip, text.splitlines()))


def drop_comment(line):
    """
    Drop comments.

    >>> drop_comment('foo # bar')
    'foo'

    A hash without a space may be in a URL.

    >>> drop_comment('http://example.com/foo#bar')
    'http://example.com/foo#bar'
    """
    return line.partition(' #')[0]


def join_continuation(lines):
    r"""
    Join lines continued by a trailing backslash.

    >>> list(join_continuation(['foo \\', 'bar', 'baz']))
    ['foobar', 'baz']
    >>> list(join_continuation(['foo \\', 'bar', 'baz']))
    ['foobar', 'baz']
    >>> list(join_continuation(['foo \\', 'bar \\', 'baz']))
    ['foobarbaz']

    Not sure why, but...
    The character preceding the backslash is also elided.

    >>> list(join_continuation(['goo\\', 'dly']))
    ['godly']

    A terrible idea, but...
    If no line is available to continue, suppress the lines.

    >>> list(join_continuation(['foo', 'bar\\', 'baz\\']))
    ['foo']
    """
    lines = iter(lines)
    for item in lines:
        while item.endswith('\\'):
            try:
                item = item[:-2].strip() + next(lines)
            except StopIteration:
                return
        yield item


def read_newlines(filename, limit=1024):
    r"""
    >>> tmp_path = getfixture('tmp_path')
    >>> filename = tmp_path / 'out.txt'
    >>> _ = filename.write_text('foo\n', newline='', encoding='utf-8')
    >>> read_newlines(filename)
    '\n'
    >>> _ = filename.write_text('foo\r\n', newline='', encoding='utf-8')
    >>> read_newlines(filename)
    '\r\n'
    >>> _ = filename.write_text('foo\r\nbar\nbing\r', newline='', encoding='utf-8')
    >>> read_newlines(filename)
    ('\r', '\n', '\r\n')
    """
    with open(filename, encoding='utf-8') as fp:
        fp.read(limit)
    return fp.newlines

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__init__.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 25K 2025-06-01 01:29:53.831978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/__init__.cpython-312.pyc
d0deeb8ba20f51aeca80a7d21c448aac667ae9c5b9503e82440addb072ba7e14  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 7a 3f 00 00  |..........8hz?..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 30 02  00 00 97 00 55 00 64 00  |......0.....U.d.|
00000030  64 01 6c 00 5a 00 64 00  64 01 6c 01 5a 01 64 00  |d.l.Z.d.d.l.Z.d.|
00000040  64 01 6c 02 5a 02 64 00  64 01 6c 03 5a 03 09 00  |d.l.Z.d.d.l.Z...|
00000050  64 00 64 02 6c 04 6d 05  5a 05 01 00 64 00 64 03  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 6d 0a  5a 0a 01 00 64 00 64 04  |l.m.Z.m.Z...d.d.|
00000070  6c 0b 6d 0c 5a 0c 01 00  64 05 84 00 5a 0d 64 06  |l.m.Z...d...Z.d.|
00000080  84 00 5a 0e 02 00 47 00  64 07 84 00 64 08 65 0f  |..Z...G.d...d.e.|
00000090  ab 03 00 00 00 00 00 00  5a 10 02 00 65 0c 65 11  |........Z...e.e.|
000000a0  ab 01 00 00 00 00 00 00  5a 12 65 12 6a 26 00 00  |........Z.e.j&..|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  64 09 84 00 ab 00 00 00  00 00 00 00 5a 14 64 0a  |d...........Z.d.|
000000d0  84 00 5a 15 64 0b 84 00  5a 16 64 0c 84 00 5a 17  |..Z.d...Z.d...Z.|
000000e0  64 0d 84 00 5a 18 02 00  65 05 65 19 ab 01 00 00  |d...Z...e.e.....|
000000f0  00 00 00 00 6a 35 00 00  00 00 00 00 00 00 00 00  |....j5..........|
00000100  00 00 00 00 00 00 00 00  64 0e ab 01 00 00 00 00  |........d.......|
00000110  00 00 6a 37 00 00 00 00  00 00 00 00 00 00 00 00  |..j7............|
00000120  00 00 00 00 00 00 64 0f  ac 10 ab 01 00 00 00 00  |......d.........|
00000130  00 00 5a 1c 65 0f 65 1d  64 11 3c 00 00 00 02 00  |..Z.e.e.d.<.....|
00000140  47 00 64 12 84 00 64 13  ab 02 00 00 00 00 00 00  |G.d...d.........|
00000150  5a 1e 64 25 64 14 84 01  5a 1f 02 00 47 00 64 15  |Z.d%d...Z...G.d.|
00000160  84 00 64 16 65 20 ab 03  00 00 00 00 00 00 5a 21  |..d.e ........Z!|
00000170  65 21 6a 44 00 00 00 00  00 00 00 00 00 00 00 00  |e!jD............|
00000180  00 00 00 00 00 00 5a 23  64 17 84 00 5a 24 02 00  |......Z#d...Z$..|
00000190  47 00 64 18 84 00 64 19  65 0f ab 03 00 00 00 00  |G.d...d.e.......|
000001a0  00 00 5a 25 02 00 47 00  64 1a 84 00 64 1b ab 02  |..Z%..G.d...d...|
000001b0  00 00 00 00 00 00 5a 26  64 1c 84 00 5a 27 64 1d  |......Z&d...Z'd.|
000001c0  84 00 5a 28 64 1e 84 00  5a 29 64 1f 84 00 5a 2a  |..Z(d...Z)d...Z*|
000001d0  65 03 6a 56 00 00 00 00  00 00 00 00 00 00 00 00  |e.jV............|
000001e0  00 00 00 00 00 00 64 20  84 00 ab 00 00 00 00 00  |......d ........|
000001f0  00 00 5a 2c 65 2c 6a 5b  00 00 00 00 00 00 00 00  |..Z,e,j[........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/layouts.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.2K 2025-06-01 01:29:53.983978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/layouts.cpython-312.pyc
6a537e7875638c001733d7a1281ec0d008f402bc93873fde23cb9ee8a79e82f1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/layouts.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 83 02 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 60 00  00 00 97 00 64 00 5a 00  |......`.....d.Z.|
00000030  64 01 5a 01 65 02 6a 07  00 00 00 00 00 00 00 00  |d.Z.e.j.........|
00000040  00 00 00 00 00 00 00 00  00 00 65 00 65 01 ab 02  |..........e.e...|
00000050  00 00 00 00 00 00 5a 04  65 02 6a 07 00 00 00 00  |......Z.e.j.....|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 65 01  |..............e.|
00000070  65 00 ab 02 00 00 00 00  00 00 5a 05 64 02 84 00  |e.........Z.d...|
00000080  5a 06 64 03 84 00 5a 07  79 04 29 05 7a 46 2d 3d  |Z.d...Z.y.).zF-=|
00000090  71 77 65 72 74 79 75 69  6f 70 5b 5d 61 73 64 66  |qwertyuiop[]asdf|
000000a0  67 68 6a 6b 6c 3b 27 7a  78 63 76 62 6e 6d 2c 2e  |ghjkl;'zxcvbnm,.|
000000b0  2f 5f 2b 51 57 45 52 54  59 55 49 4f 50 7b 7d 41  |/_+QWERTYUIOP{}A|
000000c0  53 44 46 47 48 4a 4b 4c  3a 22 5a 58 43 56 42 4e  |SDFGHJKL:"ZXCVBN|
000000d0  4d 3c 3e 3f 7a 46 5b 5d  27 2c 2e 70 79 66 67 63  |M<>?zF[]',.pyfgc|
000000e0  72 6c 2f 3d 61 6f 65 75  69 64 68 74 6e 73 2d 3b  |rl/=aoeuidhtns-;|
000000f0  71 6a 6b 78 62 6d 77 76  7a 7b 7d 22 3c 3e 50 59  |qjkxbmwvz{}"<>PY|
00000100  46 47 43 52 4c 3f 2b 41  4f 45 55 49 44 48 54 4e  |FGCRL?+AOEUIDHTN|
00000110  53 5f 3a 51 4a 4b 58 42  4d 57 56 5a 63 02 00 00  |S_:QJKXBMWVZc...|
00000120  00 00 00 00 00 00 00 00  00 03 00 00 00 03 00 00  |................|
00000130  00 f3 24 00 00 00 97 00  7c 00 6a 01 00 00 00 00  |..$.....|.j.....|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 7c 01  |..............|.|
00000150  ab 01 00 00 00 00 00 00  53 00 29 01 7a 6d 0a 20  |........S.).zm. |
00000160  20 20 20 3e 3e 3e 20 74  72 61 6e 73 6c 61 74 65  |   >>> translate|
00000170  28 27 64 76 6f 72 61 6b  27 2c 20 74 6f 5f 64 76  |('dvorak', to_dv|
00000180  6f 72 61 6b 29 0a 20 20  20 20 27 65 6b 72 70 61  |orak).    'ekrpa|
00000190  74 27 0a 20 20 20 20 3e  3e 3e 20 74 72 61 6e 73  |t'.    >>> trans|
000001a0  6c 61 74 65 28 27 71 77  65 72 74 79 27 2c 20 74  |late('qwerty', t|
000001b0  6f 5f 71 77 65 72 74 79  29 0a 20 20 20 20 27 78  |o_qwerty).    'x|
000001c0  2c 64 6f 6b 74 27 0a 20  20 20 20 29 01 da 09 74  |,dokt'.    )...t|
000001d0  72 61 6e 73 6c 61 74 65  29 02 da 05 69 6e 70 75  |ranslate)...inpu|
000001e0  74 da 0b 74 72 61 6e 73  6c 61 74 69 6f 6e 73 02  |t..translations.|
000001f0  00 00 00 20 20 fa 88 2f  64 61 74 61 2f 64 61 74  |...  ../data/dat|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/layouts.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/show-newlines.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.5K 2025-06-01 01:29:54.147978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/show-newlines.cpython-312.pyc
05f49cd1577055ba9c6e37ed98d861984aa5a11eb36d8d64d817cdacfc8f9212  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/show-newlines.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 88 03 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 5e 00  00 00 97 00 64 00 64 01  |......^.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 01 6c 04 5a 05  |l.m.Z...d.d.l.Z.|
00000050  64 03 84 00 5a 06 02 00  02 00 65 00 6a 00 00 00  |d...Z.....e.j...|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000070  65 07 ab 01 00 00 00 00  00 00 65 06 ab 01 00 00  |e.........e.....|
00000080  00 00 00 00 01 00 79 01  29 04 e9 00 00 00 00 4e  |......y.)......N|
00000090  29 01 da 0f 61 6c 77 61  79 73 5f 69 74 65 72 61  |)...always_itera|
000000a0  62 6c 65 63 01 00 00 00  00 00 00 00 00 00 00 00  |blec............|
000000b0  07 00 00 00 03 00 00 00  f3 10 01 00 00 97 00 74  |...............t|
000000c0  00 00 00 00 00 00 00 00  00 6a 02 00 00 00 00 00  |.........j......|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 6a 05 00  |.............j..|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000f0  00 7c 00 ab 01 00 00 00  00 00 00 7d 01 74 07 00  |.|.........}.t..|
00000100  00 00 00 00 00 00 00 74  09 00 00 00 00 00 00 00  |.......t........|
00000110  00 74 0b 00 00 00 00 00  00 00 00 7c 01 ab 01 00  |.t.........|....|
00000120  00 00 00 00 00 ab 01 00  00 00 00 00 00 ab 01 00  |................|
00000130  00 00 00 00 00 7d 02 74  0d 00 00 00 00 00 00 00  |.....}.t........|
00000140  00 6a 0e 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
00000150  00 00 00 00 00 ab 00 00  00 00 00 00 00 7d 03 74  |.............}.t|
00000160  11 00 00 00 00 00 00 00  00 7c 03 6a 13 00 00 00  |.........|.j....|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 64  |...............d|
00000180  01 7c 02 ab 02 00 00 00  00 00 00 7c 03 6a 15 00  |.|.........|.j..|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  00 64 02 7c 02 ab 02 00  00 00 00 00 00 74 17 00  |.d.|.........t..|
000001b0  00 00 00 00 00 00 00 7c  01 ab 01 00 00 00 00 00  |.......|........|
000001c0  00 ab 03 00 00 00 00 00  00 01 00 79 03 29 04 61  |...........y.).a|
000001d0  c1 01 00 00 0a 20 20 20  20 52 65 70 6f 72 74 20  |.....    Report |
000001e0  74 68 65 20 6e 65 77 6c  69 6e 65 73 20 69 6e 20  |the newlines in |
000001f0  74 68 65 20 69 6e 64 69  63 61 74 65 64 20 66 69  |the indicated fi|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/show-newlines.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/strip-prefix.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 948 2025-06-01 01:29:54.307978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/strip-prefix.cpython-312.pyc
492ebdecddccdca4f8718f68ca34aa741e38d080eb179fe3624ee0f2c58ea513  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/strip-prefix.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 9c 01 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 56 00  00 00 97 00 64 00 64 01  |......V.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 03 84 00 5a 04 02 00  |l.m.Z...d...Z...|
00000050  02 00 65 01 6a 02 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
00000060  00 00 00 00 00 00 00 00  65 05 ab 01 00 00 00 00  |........e.......|
00000070  00 00 65 04 ab 01 00 00  00 00 00 00 01 00 79 01  |..e...........y.|
00000080  29 04 e9 00 00 00 00 4e  29 01 da 08 53 74 72 69  |)......N)...Stri|
00000090  70 70 65 72 63 00 00 00  00 00 00 00 00 00 00 00  |pperc...........|
000000a0  00 05 00 00 00 03 00 00  00 f3 98 00 00 00 97 00  |................|
000000b0  74 00 00 00 00 00 00 00  00 00 6a 02 00 00 00 00  |t.........j.....|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 6a 05  |..............j.|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  00 00 74 07 00 00 00 00  00 00 00 00 6a 08 00 00  |..t.........j...|
000000f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000100  74 00 00 00 00 00 00 00  00 00 6a 0a 00 00 00 00  |t.........j.....|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 01  |................|
00000120  00 00 00 00 00 00 6a 0c  00 00 00 00 00 00 00 00  |......j.........|
00000130  00 00 00 00 00 00 00 00  00 00 ab 01 00 00 00 00  |................|
00000140  00 00 01 00 79 01 29 02  7a c5 0a 20 20 20 20 53  |....y.).z..    S|
00000150  74 72 69 70 20 61 6e 79  20 63 6f 6d 6d 6f 6e 20  |trip any common |
00000160  70 72 65 66 69 78 20 66  72 6f 6d 20 73 74 64 69  |prefix from stdi|
00000170  6e 2e 0a 0a 20 20 20 20  3e 3e 3e 20 69 6d 70 6f  |n...    >>> impo|
00000180  72 74 20 69 6f 2c 20 70  79 74 65 73 74 0a 20 20  |rt io, pytest.  |
00000190  20 20 3e 3e 3e 20 67 65  74 66 69 78 74 75 72 65  |  >>> getfixture|
000001a0  28 27 6d 6f 6e 6b 65 79  70 61 74 63 68 27 29 2e  |('monkeypatch').|
000001b0  73 65 74 61 74 74 72 28  27 73 79 73 2e 73 74 64  |setattr('sys.std|
000001c0  69 6e 27 2c 20 69 6f 2e  53 74 72 69 6e 67 49 4f  |in', io.StringIO|
000001d0  28 27 61 62 63 64 65 66  5c 6e 61 62 63 31 32 33  |('abcdef\nabc123|
000001e0  27 29 29 0a 20 20 20 20  3e 3e 3e 20 73 74 72 69  |')).    >>> stri|
000001f0  70 5f 70 72 65 66 69 78  28 29 0a 20 20 20 20 64  |p_prefix().    d|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/strip-prefix.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-dvorak.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 488 2025-06-01 01:29:54.467978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-dvorak.cpython-312.pyc
2a755928253de12a6129e4b010e484ca533948551f23521fc0cedc11793a1272  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-dvorak.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 77 00 00 00  |..........8hw...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 78 00  00 00 97 00 64 00 64 01  |......x.....d.d.|
00000030  6c 00 5a 00 64 02 64 03  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  65 03 64 04 6b 28 00 00  78 01 72 29 01 00 02 00  |e.d.k(..x.r)....|
00000050  65 02 6a 08 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000060  00 00 00 00 00 00 65 00  6a 0a 00 00 00 00 00 00  |......e.j.......|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 65 02 6a 0c  |............e.j.|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000090  00 00 ab 02 00 00 00 00  00 00 01 00 79 01 01 00  |............y...|
000000a0  79 01 29 05 e9 00 00 00  00 4e e9 01 00 00 00 29  |y.)......N.....)|
000000b0  01 da 07 6c 61 79 6f 75  74 73 da 08 5f 5f 6d 61  |...layouts..__ma|
000000c0  69 6e 5f 5f 29 07 da 03  73 79 73 da 00 72 04 00  |in__)...sys..r..|
000000d0  00 00 da 08 5f 5f 6e 61  6d 65 5f 5f da 11 5f 74  |....__name__.._t|
000000e0  72 61 6e 73 6c 61 74 65  5f 73 74 72 65 61 6d da  |ranslate_stream.|
000000f0  05 73 74 64 69 6e da 09  74 6f 5f 64 76 6f 72 61  |.stdin..to_dvora|
00000100  6b a9 00 f3 00 00 00 00  fa 8a 2f 64 61 74 61 2f  |k........./data/|
00000110  64 61 74 61 2f 63 6f 6d  2e 74 65 72 6d 75 78 2f  |data/com.termux/|
00000120  66 69 6c 65 73 2f 68 6f  6d 65 2f 52 41 46 41 45  |files/home/RAFAE|
00000130  4c 49 41 2f 48 43 50 4d  2f 43 4f 52 45 2f 76 65  |LIA/HCPM/CORE/ve|
00000140  6e 76 5f 72 61 66 61 65  6c 69 61 2f 6c 69 62 2f  |nv_rafaelia/lib/|
00000150  70 79 74 68 6f 6e 33 2e  31 32 2f 73 69 74 65 2d  |python3.12/site-|
00000160  70 61 63 6b 61 67 65 73  2f 73 65 74 75 70 74 6f  |packages/setupto|
00000170  6f 6c 73 2f 5f 76 65 6e  64 6f 72 2f 6a 61 72 61  |ols/_vendor/jara|
00000180  63 6f 2f 74 65 78 74 2f  74 6f 2d 64 76 6f 72 61  |co/text/to-dvora|
00000190  6b 2e 70 79 da 08 3c 6d  6f 64 75 6c 65 3e 72 0f  |k.py..<module>r.|
000001a0  00 00 00 01 00 00 00 73  37 00 00 00 f0 03 01 01  |.......s7.......|
000001b0  01 db 00 0a e5 00 15 f0  06 00 01 09 88 4a d1 00  |.............J..|
000001c0  16 d2 00 52 d0 1b 34 98  37 d7 1b 34 d1 1b 34 b0  |...R..4.7..4..4.|
000001d0  53 b7 59 b1 59 c0 07 d7  40 51 d1 40 51 d5 1b 52  |S.Y.Y...@Q.@Q..R|
000001e0  d1 00 52 72 0d 00 00 00                           |..Rr....|
000001e8
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-dvorak.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-qwerty.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 488 2025-06-01 01:29:54.619978110 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-qwerty.cpython-312.pyc
c6cd5652c1cb2cdfe06e5c681db67f4bf54a9cd0bdb17fa162227668fd0941ec  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-qwerty.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 77 00 00 00  |..........8hw...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 78 00  00 00 97 00 64 00 64 01  |......x.....d.d.|
00000030  6c 00 5a 00 64 02 64 03  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  65 03 64 04 6b 28 00 00  78 01 72 29 01 00 02 00  |e.d.k(..x.r)....|
00000050  65 02 6a 08 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000060  00 00 00 00 00 00 65 00  6a 0a 00 00 00 00 00 00  |......e.j.......|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 65 02 6a 0c  |............e.j.|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000090  00 00 ab 02 00 00 00 00  00 00 01 00 79 01 01 00  |............y...|
000000a0  79 01 29 05 e9 00 00 00  00 4e e9 01 00 00 00 29  |y.)......N.....)|
000000b0  01 da 07 6c 61 79 6f 75  74 73 da 08 5f 5f 6d 61  |...layouts..__ma|
000000c0  69 6e 5f 5f 29 07 da 03  73 79 73 da 00 72 04 00  |in__)...sys..r..|
000000d0  00 00 da 08 5f 5f 6e 61  6d 65 5f 5f da 11 5f 74  |....__name__.._t|
000000e0  72 61 6e 73 6c 61 74 65  5f 73 74 72 65 61 6d da  |ranslate_stream.|
000000f0  05 73 74 64 69 6e da 09  74 6f 5f 71 77 65 72 74  |.stdin..to_qwert|
00000100  79 a9 00 f3 00 00 00 00  fa 8a 2f 64 61 74 61 2f  |y........./data/|
00000110  64 61 74 61 2f 63 6f 6d  2e 74 65 72 6d 75 78 2f  |data/com.termux/|
00000120  66 69 6c 65 73 2f 68 6f  6d 65 2f 52 41 46 41 45  |files/home/RAFAE|
00000130  4c 49 41 2f 48 43 50 4d  2f 43 4f 52 45 2f 76 65  |LIA/HCPM/CORE/ve|
00000140  6e 76 5f 72 61 66 61 65  6c 69 61 2f 6c 69 62 2f  |nv_rafaelia/lib/|
00000150  70 79 74 68 6f 6e 33 2e  31 32 2f 73 69 74 65 2d  |python3.12/site-|
00000160  70 61 63 6b 61 67 65 73  2f 73 65 74 75 70 74 6f  |packages/setupto|
00000170  6f 6c 73 2f 5f 76 65 6e  64 6f 72 2f 6a 61 72 61  |ols/_vendor/jara|
00000180  63 6f 2f 74 65 78 74 2f  74 6f 2d 71 77 65 72 74  |co/text/to-qwert|
00000190  79 2e 70 79 da 08 3c 6d  6f 64 75 6c 65 3e 72 0f  |y.py..<module>r.|
000001a0  00 00 00 01 00 00 00 73  37 00 00 00 f0 03 01 01  |.......s7.......|
000001b0  01 db 00 0a e5 00 15 f0  06 00 01 09 88 4a d1 00  |.............J..|
000001c0  16 d2 00 52 d0 1b 34 98  37 d7 1b 34 d1 1b 34 b0  |...R..4.7..4..4.|
000001d0  53 b7 59 b1 59 c0 07 d7  40 51 d1 40 51 d5 1b 52  |S.Y.Y...@Q.@Q..R|
000001e0  d1 00 52 72 0d 00 00 00                           |..Rr....|
000001e8
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/text/__pycache__/to-qwerty.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/__pycache__/context.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 14K 2025-06-01 01:29:53.323978111 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/__pycache__/context.cpython-312.pyc
1521899c05a39f193a12399930fbb47c72c2303abbf35e90b39ef96657a95b99  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/__pycache__/context.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 50 25 00 00  |..........8hP%..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 01 f3 34 02  00 00 97 00 64 00 64 01  |......4.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 05 5a 05  64 00 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 02 6c 07 5a 07  64 00 64 02 6c 08 5a 08  |d.d.l.Z.d.d.l.Z.|
00000070  64 00 64 02 6c 09 5a 09  64 00 64 02 6c 0a 5a 0b  |d.d.l.Z.d.d.l.Z.|
00000080  64 00 64 02 6c 0c 5a 0c  64 00 64 03 6c 0d 6d 0e  |d.d.l.Z.d.d.l.m.|
00000090  5a 0e 01 00 65 08 6a 1e  00 00 00 00 00 00 00 00  |Z...e.j.........|
000000a0  00 00 00 00 00 00 00 00  00 00 64 04 6b 02 00 00  |..........d.k...|
000000b0  72 07 64 00 64 05 6c 10  6d 11 5a 11 01 00 6e 04  |r.d.d.l.m.Z...n.|
000000c0  64 00 64 02 6c 11 5a 11  65 02 6a 24 00 00 00 00  |d.d.l.Z.e.j$....|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 16  |..............d.|
000000e0  64 06 84 04 ab 00 00 00  00 00 00 00 5a 13 65 02  |d...........Z.e.|
000000f0  6a 24 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j$..............|
00000100  00 00 00 00 09 00 64 17  09 00 09 00 09 00 64 18  |......d.......d.|
00000110  64 07 84 05 ab 00 00 00  00 00 00 00 5a 14 09 00  |d...........Z...|
00000120  09 00 09 00 09 00 64 19  64 08 84 04 5a 15 64 09  |......d.d...Z.d.|
00000130  84 00 5a 16 02 00 65 16  65 13 65 14 ab 02 00 00  |..Z...e.e.e.....|
00000140  00 00 00 00 5a 17 65 02  6a 24 00 00 00 00 00 00  |....Z.e.j$......|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 64 0a 84 00  |............d...|
00000160  ab 00 00 00 00 00 00 00  5a 18 64 0b 84 00 5a 19  |........Z.d...Z.|
00000170  65 02 6a 24 00 00 00 00  00 00 00 00 00 00 00 00  |e.j$............|
00000180  00 00 00 00 00 00 65 06  6a 34 00 00 00 00 00 00  |......e.j4......|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 66 01 64 0c  |............f.d.|
000001a0  84 01 ab 00 00 00 00 00  00 00 5a 1b 65 02 6a 24  |..........Z.e.j$|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001c0  00 00 64 02 64 0d 65 1b  66 03 64 0e 84 01 ab 00  |..d.d.e.f.d.....|
000001d0  00 00 00 00 00 00 5a 1c  64 0f 84 00 5a 1d 02 00  |......Z.d...Z...|
000001e0  47 00 64 10 84 00 64 11  ab 02 00 00 00 00 00 00  |G.d...d.........|
000001f0  5a 1e 02 00 47 00 64 12  84 00 64 13 65 02 6a 3e  |Z...G.d...d.e.j>|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/jaraco/__pycache__/context.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/more_itertools/more.py
-rwxrwxrwx. 1 u0_a292 u0_a292 145K 2025-06-02 22:55:15.234164467 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/more_itertools/more.py
27d5a620ef95d7ce1a8d689dd32d7a6c25b413ac19f297cf510cc2834ea3b081  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_vendor/more_itertools/more.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----