#!/bin/bash
# ∴ VERBO_DOMINION ∆ Controle de verbos

VERBDB="verbum.db"
SAIDA="saida.txt"

echo "[DOMINION] Verbos:" > "$SAIDA"
awk -F'|' '{ printf "- %s → %s\n", $1, $2 }' "$VERBDB" >> "$SAIDA"

VERBO=$(cat entrada.txt | tr -d '\r' | head -n1 | awk '{print tolower($1)}')
COMANDO=$(grep "^$VERBO|" "$VERBDB" | tail -n1 | cut -d'|' -f2)

if [[ -n "$COMANDO" ]]; then
  echo "[DOMINION] Executando '$VERBO': $COMANDO" >> "$SAIDA"
  bash -c "$COMANDO" >> "$SAIDA" 2>&1
else
  echo "[DOMINION] Verbo '$VERBO' não encontrado" >> "$SAIDA"
fi

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DOMINION.sh -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSÃO.sh
-rwxrwxrwx. 1 u0_a292 u0_a292 430 2025-06-10 05:22:04.663988621 -0300 /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSÃO.sh
5c9076c93ebdabd983751054bec549905917d3dc2ed895ca9c314dcdb85afeb6  /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/VERBO_DIMENSÃO.sh
MIME: text/x-shellscript
----- INÍCIO DO CONTEÚDO (extensão: .sh) -----