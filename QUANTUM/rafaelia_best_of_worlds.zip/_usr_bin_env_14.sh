#!/usr/bin/env python3
# don't import any costly modules
import os
import sys

report_url = (
    "https://github.com/pypa/setuptools/issues/new?template=distutils-deprecation.yml"
)


def warn_distutils_present():
    if 'distutils' not in sys.modules:
        return
    import warnings

    warnings.warn(
        "Distutils was imported before Setuptools, but importing Setuptools "
        "also replaces the `distutils` module in `sys.modules`. This may lead "
        "to undesirable behaviors or errors. To avoid these issues, avoid "
        "using distutils directly, ensure that setuptools is installed in the "
        "traditional way (e.g. not an editable install), and/or make sure "
        "that setuptools is always imported before distutils."
    )


def clear_distutils():
    if 'distutils' not in sys.modules:
        return
    import warnings

    warnings.warn(
        "Setuptools is replacing distutils. Support for replacing "
        "an already imported distutils is deprecated. In the future, "
        "this condition will fail. "
        f"Register concerns at {report_url}"
    )
    mods = [
        name
        for name in sys.modules
        if name == "distutils" or name.startswith("distutils.")
    ]
    for name in mods:
        del sys.modules[name]


def enabled():
    """
    Allow selection of distutils by environment variable.
    """
    which = os.environ.get('SETUPTOOLS_USE_DISTUTILS', 'local')
    if which == 'stdlib':
        import warnings

        warnings.warn(
            "Reliance on distutils from stdlib is deprecated. Users "
            "must rely on setuptools to provide the distutils module. "
            "Avoid importing distutils or import setuptools first, "
            "and avoid setting SETUPTOOLS_USE_DISTUTILS=stdlib. "
            f"Register concerns at {report_url}"
        )
    return which == 'local'


def ensure_local_distutils():
    import importlib

    clear_distutils()

    # With the DistutilsMetaFinder in place,
    # perform an import to cause distutils to be
    # loaded from setuptools._distutils. Ref #2906.
    with shim():
        importlib.import_module('distutils')

    # check that submodules load as expected
    core = importlib.import_module('distutils.core')
    assert '_distutils' in core.__file__, core.__file__
    assert 'setuptools._distutils.log' not in sys.modules


def do_override():
    """
    Ensure that the local copy of distutils is preferred over stdlib.

    See https://github.com/pypa/setuptools/issues/417#issuecomment-392298401
    for more motivation.
    """
    if enabled():
        warn_distutils_present()
        ensure_local_distutils()


class _TrivialRe:
    def __init__(self, *patterns) -> None:
        self._patterns = patterns

    def match(self, string):
        return all(pat in string for pat in self._patterns)


class DistutilsMetaFinder:
    def find_spec(self, fullname, path, target=None):
        # optimization: only consider top level modules and those
        # found in the CPython test suite.
        if path is not None and not fullname.startswith('test.'):
            return None

        method_name = 'spec_for_{fullname}'.format(**locals())
        method = getattr(self, method_name, lambda: None)
        return method()

    def spec_for_distutils(self):
        if self.is_cpython():
            return None

        import importlib
        import importlib.abc
        import importlib.util

        try:
            mod = importlib.import_module('setuptools._distutils')
        except Exception:
            # There are a couple of cases where setuptools._distutils
            # may not be present:
            # - An older Setuptools without a local distutils is
            #   taking precedence. Ref #2957.
            # - Path manipulation during sitecustomize removes
            #   setuptools from the path but only after the hook
            #   has been loaded. Ref #2980.
            # In either case, fall back to stdlib behavior.
            return None

        class DistutilsLoader(importlib.abc.Loader):
            def create_module(self, spec):
                mod.__name__ = 'distutils'
                return mod

            def exec_module(self, module):
                pass

        return importlib.util.spec_from_loader(
            'distutils', DistutilsLoader(), origin=mod.__file__
        )

    @staticmethod
    def is_cpython():
        """
        Suppress supplying distutils for CPython (build and tests).
        Ref #2965 and #3007.
        """
        return os.path.isfile('pybuilddir.txt')

    def spec_for_pip(self):
        """
        Ensure stdlib distutils when running under pip.
        See pypa/pip#8761 for rationale.
        """
        if sys.version_info >= (3, 12) or self.pip_imported_during_build():
            return
        clear_distutils()
        self.spec_for_distutils = lambda: None

    @classmethod
    def pip_imported_during_build(cls):
        """
        Detect if pip is being imported in a build script. Ref #2355.
        """
        import traceback

        return any(
            cls.frame_file_is_setup(frame) for frame, line in traceback.walk_stack(None)
        )

    @staticmethod
    def frame_file_is_setup(frame):
        """
        Return True if the indicated frame suggests a setup.py file.
        """
        # some frames may not have __file__ (#2940)
        return frame.f_globals.get('__file__', '').endswith('setup.py')

    def spec_for_sensitive_tests(self):
        """
        Ensure stdlib distutils when running select tests under CPython.

        python/cpython#91169
        """
        clear_distutils()
        self.spec_for_distutils = lambda: None

    sensitive_tests = (
        [
            'test.test_distutils',
            'test.test_peg_generator',
            'test.test_importlib',
        ]
        if sys.version_info < (3, 10)
        else [
            'test.test_distutils',
        ]
    )


for name in DistutilsMetaFinder.sensitive_tests:
    setattr(
        DistutilsMetaFinder,
        f'spec_for_{name}',
        DistutilsMetaFinder.spec_for_sensitive_tests,
    )


DISTUTILS_FINDER = DistutilsMetaFinder()


def add_shim():
    DISTUTILS_FINDER in sys.meta_path or insert_shim()


class shim:
    def __enter__(self) -> None:
        insert_shim()

    def __exit__(self, exc: object, value: object, tb: object) -> None:
        _remove_shim()


def insert_shim():
    sys.meta_path.insert(0, DISTUTILS_FINDER)


def _remove_shim():
    try:
        sys.meta_path.remove(DISTUTILS_FINDER)
    except ValueError:
        pass


if sys.version_info < (3, 12):
    # DistutilsMetaFinder can only be disabled in Python < 3.12 (PEP 632)
    remove_shim = _remove_shim

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__init__.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 11K 2025-06-01 01:29:25.239978131 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/__init__.cpython-312.pyc
f2594b8e6d152e8ab246357234cddfd4115bb91d92257e0598cde4fd0c115385  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 63 1a 00 00  |..........8hc...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 06 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 02 5a 02  |l.Z.d.d.l.Z.d.Z.|
00000040  64 03 84 00 5a 03 64 04  84 00 5a 04 64 05 84 00  |d...Z.d...Z.d...|
00000050  5a 05 64 06 84 00 5a 06  64 07 84 00 5a 07 02 00  |Z.d...Z.d...Z...|
00000060  47 00 64 08 84 00 64 09  ab 02 00 00 00 00 00 00  |G.d...d.........|
00000070  5a 08 02 00 47 00 64 0a  84 00 64 0b ab 02 00 00  |Z...G.d...d.....|
00000080  00 00 00 00 5a 09 65 09  6a 14 00 00 00 00 00 00  |....Z.e.j.......|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 44 00 5d 19  |............D.].|
000000a0  00 00 5a 0b 02 00 65 0c  65 09 64 0c 65 0b 9b 00  |..Z...e.e.d.e...|
000000b0  9d 02 65 09 6a 1a 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
000000c0  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
000000d0  01 00 8c 1b 04 00 02 00  65 09 ab 00 00 00 00 00  |........e.......|
000000e0  00 00 5a 0e 64 0d 84 00  5a 0f 02 00 47 00 64 0e  |..Z.d...Z...G.d.|
000000f0  84 00 64 0f ab 02 00 00  00 00 00 00 5a 10 64 10  |..d.........Z.d.|
00000100  84 00 5a 11 64 11 84 00  5a 12 65 01 6a 26 00 00  |..Z.d...Z.e.j&..|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000120  64 12 6b 02 00 00 72 03  65 12 5a 14 79 01 79 01  |d.k...r.e.Z.y.y.|
00000130  29 13 e9 00 00 00 00 4e  7a 50 68 74 74 70 73 3a  |)......NzPhttps:|
00000140  2f 2f 67 69 74 68 75 62  2e 63 6f 6d 2f 70 79 70  |//github.com/pyp|
00000150  61 2f 73 65 74 75 70 74  6f 6f 6c 73 2f 69 73 73  |a/setuptools/iss|
00000160  75 65 73 2f 6e 65 77 3f  74 65 6d 70 6c 61 74 65  |ues/new?template|
00000170  3d 64 69 73 74 75 74 69  6c 73 2d 64 65 70 72 65  |=distutils-depre|
00000180  63 61 74 69 6f 6e 2e 79  6d 6c 63 00 00 00 00 00  |cation.ymlc.....|
00000190  00 00 00 00 00 00 00 03  00 00 00 03 00 00 00 f3  |................|
000001a0  54 00 00 00 97 00 64 01  74 00 00 00 00 00 00 00  |T.....d.t.......|
000001b0  00 00 6a 02 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
000001c0  00 00 00 00 00 00 76 01  72 01 79 00 64 02 64 00  |......v.r.y.d.d.|
000001d0  6c 02 7d 00 7c 00 6a 07  00 00 00 00 00 00 00 00  |l.}.|.j.........|
000001e0  00 00 00 00 00 00 00 00  00 00 64 03 ab 01 00 00  |..........d.....|
000001f0  00 00 00 00 01 00 79 00  29 04 4e da 09 64 69 73  |......y.).N..dis|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/override.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 320 2025-06-01 01:29:25.387978131 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/override.cpython-312.pyc
dcc1125258acdcced9f1e83a425e421ba9f4c1b424e4561e71e734b37d81dce7  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/override.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 2c 00 00 00  |..........8h,...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |................|
00000020  00 00 00 00 00 f3 30 00  00 00 97 00 02 00 65 00  |......0.......e.|
00000030  64 00 ab 01 00 00 00 00  00 00 6a 03 00 00 00 00  |d.........j.....|
00000040  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 00  |................|
00000050  00 00 00 00 00 00 01 00  79 01 29 02 da 0f 5f 64  |........y.)..._d|
00000060  69 73 74 75 74 69 6c 73  5f 68 61 63 6b 4e 29 02  |istutils_hackN).|
00000070  da 0a 5f 5f 69 6d 70 6f  72 74 5f 5f da 0b 64 6f  |..__import__..do|
00000080  5f 6f 76 65 72 72 69 64  65 a9 00 f3 00 00 00 00  |_override.......|
00000090  fa 7a 2f 64 61 74 61 2f  64 61 74 61 2f 63 6f 6d  |.z/data/data/com|
000000a0  2e 74 65 72 6d 75 78 2f  66 69 6c 65 73 2f 68 6f  |.termux/files/ho|
000000b0  6d 65 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |me/RAFAELIA/HCPM|
000000c0  2f 43 4f 52 45 2f 76 65  6e 76 5f 72 61 66 61 65  |/CORE/venv_rafae|
000000d0  6c 69 61 2f 6c 69 62 2f  70 79 74 68 6f 6e 33 2e  |lia/lib/python3.|
000000e0  31 32 2f 73 69 74 65 2d  70 61 63 6b 61 67 65 73  |12/site-packages|
000000f0  2f 5f 64 69 73 74 75 74  69 6c 73 5f 68 61 63 6b  |/_distutils_hack|
00000100  2f 6f 76 65 72 72 69 64  65 2e 70 79 da 08 3c 6d  |/override.py..<m|
00000110  6f 64 75 6c 65 3e 72 08  00 00 00 01 00 00 00 73  |odule>r........s|
00000120  17 00 00 00 f0 03 01 01  01 d9 00 0a d0 0b 1c d3  |................|
00000130  00 1d d7 00 29 d1 00 29  d5 00 2b 72 06 00 00 00  |....)..)..+r....|
00000140
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/_distutils_hack/__pycache__/override.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/__init__.py
-rwxrwxrwx. 1 u0_a292 u0_a292 124K 2025-06-02 22:55:14.562164467 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/__init__.py
568709e6080f378e431bbd45fca5bdf0970f0ddfb3363b5bc62d6f7aa89a6d1c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/__init__.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----