#!/bin/bash
{"archive_info": {"hash": "sha256=f5025c13f4cc38d10089924fbe3fdc22184222743b61dad6cae77e0f0c9216d6", "hashes": {"sha256": "f5025c13f4cc38d10089924fbe3fdc22184222743b61dad6cae77e0f0c9216d6"}}, "url": "file:///data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/dist/rafaelia_mod-0.1.0-py3-none-any.whl"}

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/venv_modulo/lib/python3.12/site-packages/rafaelia_mod-0.1.0.dist-info/direct_url.json -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/venv_modulo/bin/pip
-rwxrwxrwx. 1 u0_a292 u0_a292 300 2025-05-29 15:30:45.318751782 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/venv_modulo/bin/pip
f1a25b01e695095d1daa688ebb704a09902fbc44a1d53ede5f87671b2bcd6f77  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/venv_modulo/bin/pip
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----