#!/bin/sh
echo 'APK simbiótico ∞ RafaelIA executado'
----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/downloads/rafaelia_app.apk -----

========================================
ARQUIVO: /data/data/com.termux/files/home/downloads/Untitled
-rw-------. 1 u0_a292 u0_a292 306 2025-07-29 07:24:09.559994980 -0300 /data/data/com.termux/files/home/downloads/Untitled
0837f0a1440988c8a66a6fce476364d7938f56a1bb9292a9eae6c1113107ccf7  /data/data/com.termux/files/home/downloads/Untitled
MIME: application/json
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  7b 22 6e 62 66 6f 72 6d  61 74 22 3a 34 2c 22 6e  |{"nbformat":4,"n|
00000010  62 66 6f 72 6d 61 74 5f  6d 69 6e 6f 72 22 3a 30  |bformat_minor":0|
00000020  2c 22 6d 65 74 61 64 61  74 61 22 3a 7b 22 63 6f  |,"metadata":{"co|
00000030  6c 61 62 22 3a 7b 22 6e  61 6d 65 22 3a 22 55 6e  |lab":{"name":"Un|
00000040  74 69 74 6c 65 64 22 2c  22 61 75 74 68 6f 72 73  |titled","authors|
00000050  68 69 70 5f 74 61 67 22  3a 22 41 42 58 39 54 79  |hip_tag":"ABX9Ty|
00000060  4f 38 6a 4b 45 4a 4b 6d  36 42 48 44 62 47 2f 77  |O8jKEJKm6BHDbG/w|
00000070  63 4c 59 4e 2f 2f 22 7d  2c 22 6b 65 72 6e 65 6c  |cLYN//"},"kernel|
00000080  73 70 65 63 22 3a 7b 22  6e 61 6d 65 22 3a 22 70  |spec":{"name":"p|
00000090  79 74 68 6f 6e 33 22 2c  22 64 69 73 70 6c 61 79  |ython3","display|
000000a0  5f 6e 61 6d 65 22 3a 22  50 79 74 68 6f 6e 20 33  |_name":"Python 3|
000000b0  22 7d 2c 22 6c 61 6e 67  75 61 67 65 5f 69 6e 66  |"},"language_inf|
000000c0  6f 22 3a 7b 22 6e 61 6d  65 22 3a 22 70 79 74 68  |o":{"name":"pyth|
000000d0  6f 6e 22 7d 7d 2c 22 63  65 6c 6c 73 22 3a 5b 7b  |on"}},"cells":[{|
000000e0  22 63 65 6c 6c 5f 74 79  70 65 22 3a 22 63 6f 64  |"cell_type":"cod|
000000f0  65 22 2c 22 65 78 65 63  75 74 69 6f 6e 5f 63 6f  |e","execution_co|
00000100  75 6e 74 22 3a 30 2c 22  6d 65 74 61 64 61 74 61  |unt":0,"metadata|
00000110  22 3a 7b 7d 2c 22 6f 75  74 70 75 74 73 22 3a 5b  |":{},"outputs":[|
00000120  5d 2c 22 73 6f 75 72 63  65 22 3a 5b 22 22 5d 7d  |],"source":[""]}|
00000130  5d 7d                                             |]}|
00000132
----- FIM hexdump: /data/data/com.termux/files/home/downloads/Untitled -----

========================================
ARQUIVO: /data/data/com.termux/files/home/downloads/com.termux.widget_1000.apk
-rwxrwxrwx. 1 u0_a292 u0_a292 5.6M 2025-05-18 18:59:30.015049568 -0300 /data/data/com.termux/files/home/downloads/com.termux.widget_1000.apk
eae97f6b032d97662bc1f2f75d08e4a3f431aabd645d84321ccb02dbbf0248b4  /data/data/com.termux/files/home/downloads/com.termux.widget_1000.apk
MIME: application/vnd.android.package-archive
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  50 4b 03 04 00 00 00 00  08 00 21 08 21 02 05 47  |PK........!.!..G|
00000010  08 2b 34 00 00 00 38 00  00 00 39 00 00 00 4d 45  |.+4...8...9...ME|
00000020  54 41 2d 49 4e 46 2f 63  6f 6d 2f 61 6e 64 72 6f  |TA-INF/com/andro|
00000030  69 64 2f 62 75 69 6c 64  2f 67 72 61 64 6c 65 2f  |id/build/gradle/|
00000040  61 70 70 2d 6d 65 74 61  64 61 74 61 2e 70 72 6f  |app-metadata.pro|
00000050  70 65 72 74 69 65 73 4b  2c 28 f0 4d 2d 49 4c 49  |pertiesK,(.M-ILI|
00000060  2c 49 0c 4b 2d 2a ce cc  cf b3 35 d4 33 e4 4a cc  |,I.K-*....5.3.J.|
00000070  4b 29 ca cf 4c 71 2f 4a  4c c9 49 0d c8 29 4d cf  |K)..Lq/JL.I..)M.|
00000080  cc 83 49 5b e8 99 eb 19  73 01 00 50 4b 03 04 00  |..I[....s..PK...|
00000090  00 00 00 08 00 21 08 21  02 2d 29 2b a5 75 00 00  |.....!.!.-)+.u..|
000000a0  00 78 00 00 00 27 00 00  00 4d 45 54 41 2d 49 4e  |.x...'...META-IN|
000000b0  46 2f 76 65 72 73 69 6f  6e 2d 63 6f 6e 74 72 6f  |F/version-contro|
000000c0  6c 2d 69 6e 66 6f 2e 74  65 78 74 70 72 6f 74 6f  |l-info.textproto|
000000d0  0d ca 41 0a c2 30 10 40  d1 7d 4e 31 04 0f 10 9a  |..A..0.@.}N1....|
000000e0  9a 9a 6e 55 4a dd 28 a5  fb 30 89 23 06 6a a7 24  |..nUJ.(..0.#.j.$|
000000f0  41 10 f1 ee 66 f9 79 3f  d1 c6 39 16 4e 91 32 7c  |A...f.y?..9.N.2||
00000100  05 40 fe e4 42 af 1e 86  71 ae b5 70 c0 c5 25 e6  |.@..B...q..p..%.|
00000110  e2 36 2c cf 1e e4 ee 36  5d 2f e7 e3 ec 4e e3 24  |.6,....6]/...N.$|
00000120  eb 91 e8 1d 73 e4 b5 92  09 de e3 fe e1 c9 2a 7d  |....s.........*}|
00000130  c7 d6 76 21 1c c8 2b 34  9d a2 46 93 6e ac 22 34  |..v!..+4..F.n."4|
00000140  b6 95 e2 27 fe 50 4b 03  04 00 00 00 00 00 00 21  |...'.PK........!|
00000150  08 21 02 ea 09 70 44 bb  05 00 00 bb 05 00 00 1b  |.!...pD.........|
00000160  00 02 00 61 73 73 65 74  73 2f 64 65 78 6f 70 74  |...assets/dexopt|
00000170  2f 62 61 73 65 6c 69 6e  65 2e 70 72 6f 66 00 00  |/baseline.prof..|
00000180  70 72 6f 00 30 31 30 00  01 0a 1e 00 00 aa 05 00  |pro.010.........|
00000190  00 78 01 ed 98 7b 88 54  75 14 c7 cf bd 73 67 76  |.x...{.Tu....sgv|
000001a0  46 57 9d 75 7d b7 d6 dd  76 13 b3 dd 1a cd c0 c2  |FW.u}...v.......|
000001b0  e8 a2 52 59 52 42 8a 7f  64 b1 4b 5a 8a 42 3e 40  |..RYRB..d.KZ.B>@|
000001c0  0c 02 ef ea f6 20 0c 36  09 0a 82 b0 07 1a 24 b1  |..... .6......$.|
000001d0  3d 0c 09 a5 91 8c 8a 0a  8d fe 89 08 9a 02 fb 2b  |=..............+|
000001e0  6b 8a fe e8 b1 30 9d cf  cc 3d ee cf 71 97 64 e9  |k....0...=..q.d.|
000001f0  8f d8 e6 37 9c 3d ef ef  39 bf c7 fc e6 de 9d 28  |...7.=..9......(|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/downloads/com.termux.widget_1000.apk -----

========================================
ARQUIVO: /data/data/com.termux/files/home/downloads/apktool
-rwxrwxrwx. 1 u0_a292 u0_a292 86 2025-06-03 19:26:19.859083841 -0300 /data/data/com.termux/files/home/downloads/apktool
8e1705e29005e124fd902302182bcd5e64defff9ba380d2c8565576c005ef37f  /data/data/com.termux/files/home/downloads/apktool
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----