#!/usr/bin/env python3
import functools
import logging
import os
import pathlib
import sys
import sysconfig
from typing import Any, Dict, Optional

from pip._internal.models.scheme import SCHEME_KEYS, Scheme
from pip._internal.utils.compat import WINDOWS
from pip._internal.utils.deprecation import deprecated
from pip._internal.utils.virtualenv import running_under_virtualenv

from . import _sysconfig
from .base import (
    USER_CACHE_DIR,
    get_major_minor_version,
    get_src_prefix,
    is_osx_framework,
    site_packages,
    user_site,
)

__all__ = [
    "USER_CACHE_DIR",
    "get_bin_prefix",
    "get_bin_user",
    "get_major_minor_version",
    "get_platlib",
    "get_purelib",
    "get_scheme",
    "get_src_prefix",
    "site_packages",
    "user_site",
]


logger = logging.getLogger(__name__)


_PLATLIBDIR: str = getattr(sys, "platlibdir", "lib")

_USE_SYSCONFIG_DEFAULT = sys.version_info >= (3, 10)


def _should_use_sysconfig() -> bool:
    """This function determines the value of _USE_SYSCONFIG.

    By default, pip uses sysconfig on Python 3.10+.
    But Python distributors can override this decision by setting:
        sysconfig._PIP_USE_SYSCONFIG = True / False
    Rationale in https://github.com/pypa/pip/issues/10647

    This is a function for testability, but should be constant during any one
    run.
    """
    return bool(getattr(sysconfig, "_PIP_USE_SYSCONFIG", _USE_SYSCONFIG_DEFAULT))


_USE_SYSCONFIG = _should_use_sysconfig()

if not _USE_SYSCONFIG:
    # Import distutils lazily to avoid deprecation warnings,
    # but import it soon enough that it is in memory and available during
    # a pip reinstall.
    from . import _distutils

# Be noisy about incompatibilities if this platforms "should" be using
# sysconfig, but is explicitly opting out and using distutils instead.
if _USE_SYSCONFIG_DEFAULT and not _USE_SYSCONFIG:
    _MISMATCH_LEVEL = logging.WARNING
else:
    _MISMATCH_LEVEL = logging.DEBUG


def _looks_like_bpo_44860() -> bool:
    """The resolution to bpo-44860 will change this incorrect platlib.

    See <https://bugs.python.org/issue44860>.
    """
    from distutils.command.install import INSTALL_SCHEMES

    try:
        unix_user_platlib = INSTALL_SCHEMES["unix_user"]["platlib"]
    except KeyError:
        return False
    return unix_user_platlib == "$usersite"


def _looks_like_red_hat_patched_platlib_purelib(scheme: Dict[str, str]) -> bool:
    platlib = scheme["platlib"]
    if "/$platlibdir/" in platlib:
        platlib = platlib.replace("/$platlibdir/", f"/{_PLATLIBDIR}/")
    if "/lib64/" not in platlib:
        return False
    unpatched = platlib.replace("/lib64/", "/lib/")
    return unpatched.replace("$platbase/", "$base/") == scheme["purelib"]


@functools.lru_cache(maxsize=None)
def _looks_like_red_hat_lib() -> bool:
    """Red Hat patches platlib in unix_prefix and unix_home, but not purelib.

    This is the only way I can see to tell a Red Hat-patched Python.
    """
    from distutils.command.install import INSTALL_SCHEMES

    return all(
        k in INSTALL_SCHEMES
        and _looks_like_red_hat_patched_platlib_purelib(INSTALL_SCHEMES[k])
        for k in ("unix_prefix", "unix_home")
    )


@functools.lru_cache(maxsize=None)
def _looks_like_debian_scheme() -> bool:
    """Debian adds two additional schemes."""
    from distutils.command.install import INSTALL_SCHEMES

    return "deb_system" in INSTALL_SCHEMES and "unix_local" in INSTALL_SCHEMES


@functools.lru_cache(maxsize=None)
def _looks_like_red_hat_scheme() -> bool:
    """Red Hat patches ``sys.prefix`` and ``sys.exec_prefix``.

    Red Hat's ``00251-change-user-install-location.patch`` changes the install
    command's ``prefix`` and ``exec_prefix`` to append ``"/local"``. This is
    (fortunately?) done quite unconditionally, so we create a default command
    object without any configuration to detect this.
    """
    from distutils.command.install import install
    from distutils.dist import Distribution

    cmd: Any = install(Distribution())
    cmd.finalize_options()
    return (
        cmd.exec_prefix == f"{os.path.normpath(sys.exec_prefix)}/local"
        and cmd.prefix == f"{os.path.normpath(sys.prefix)}/local"
    )


@functools.lru_cache(maxsize=None)
def _looks_like_slackware_scheme() -> bool:
    """Slackware patches sysconfig but fails to patch distutils and site.

    Slackware changes sysconfig's user scheme to use ``"lib64"`` for the lib
    path, but does not do the same to the site module.
    """
    if user_site is None:  # User-site not available.
        return False
    try:
        paths = sysconfig.get_paths(scheme="posix_user", expand=False)
    except KeyError:  # User-site not available.
        return False
    return "/lib64/" in paths["purelib"] and "/lib64/" not in user_site


@functools.lru_cache(maxsize=None)
def _looks_like_msys2_mingw_scheme() -> bool:
    """MSYS2 patches distutils and sysconfig to use a UNIX-like scheme.

    However, MSYS2 incorrectly patches sysconfig ``nt`` scheme. The fix is
    likely going to be included in their 3.10 release, so we ignore the warning.
    See msys2/MINGW-packages#9319.

    MSYS2 MINGW's patch uses lowercase ``"lib"`` instead of the usual uppercase,
    and is missing the final ``"site-packages"``.
    """
    paths = sysconfig.get_paths("nt", expand=False)
    return all(
        "Lib" not in p and "lib" in p and not p.endswith("site-packages")
        for p in (paths[key] for key in ("platlib", "purelib"))
    )


@functools.lru_cache(maxsize=None)
def _warn_mismatched(old: pathlib.Path, new: pathlib.Path, *, key: str) -> None:
    issue_url = "https://github.com/pypa/pip/issues/10151"
    message = (
        "Value for %s does not match. Please report this to <%s>"
        "\ndistutils: %s"
        "\nsysconfig: %s"
    )
    logger.log(_MISMATCH_LEVEL, message, key, issue_url, old, new)


def _warn_if_mismatch(old: pathlib.Path, new: pathlib.Path, *, key: str) -> bool:
    if old == new:
        return False
    _warn_mismatched(old, new, key=key)
    return True


@functools.lru_cache(maxsize=None)
def _log_context(
    *,
    user: bool = False,
    home: Optional[str] = None,
    root: Optional[str] = None,
    prefix: Optional[str] = None,
) -> None:
    parts = [
        "Additional context:",
        "user = %r",
        "home = %r",
        "root = %r",
        "prefix = %r",
    ]

    logger.log(_MISMATCH_LEVEL, "\n".join(parts), user, home, root, prefix)


def get_scheme(
    dist_name: str,
    user: bool = False,
    home: Optional[str] = None,
    root: Optional[str] = None,
    isolated: bool = False,
    prefix: Optional[str] = None,
) -> Scheme:
    new = _sysconfig.get_scheme(
        dist_name,
        user=user,
        home=home,
        root=root,
        isolated=isolated,
        prefix=prefix,
    )
    if _USE_SYSCONFIG:
        return new

    old = _distutils.get_scheme(
        dist_name,
        user=user,
        home=home,
        root=root,
        isolated=isolated,
        prefix=prefix,
    )

    warning_contexts = []
    for k in SCHEME_KEYS:
        old_v = pathlib.Path(getattr(old, k))
        new_v = pathlib.Path(getattr(new, k))

        if old_v == new_v:
            continue

        # distutils incorrectly put PyPy packages under ``site-packages/python``
        # in the ``posix_home`` scheme, but PyPy devs said they expect the
        # directory name to be ``pypy`` instead. So we treat this as a bug fix
        # and not warn about it. See bpo-43307 and python/cpython#24628.
        skip_pypy_special_case = (
            sys.implementation.name == "pypy"
            and home is not None
            and k in ("platlib", "purelib")
            and old_v.parent == new_v.parent
            and old_v.name.startswith("python")
            and new_v.name.startswith("pypy")
        )
        if skip_pypy_special_case:
            continue

        # sysconfig's ``osx_framework_user`` does not include ``pythonX.Y`` in
        # the ``include`` value, but distutils's ``headers`` does. We'll let
        # CPython decide whether this is a bug or feature. See bpo-43948.
        skip_osx_framework_user_special_case = (
            user
            and is_osx_framework()
            and k == "headers"
            and old_v.parent.parent == new_v.parent
            and old_v.parent.name.startswith("python")
        )
        if skip_osx_framework_user_special_case:
            continue

        # On Red Hat and derived Linux distributions, distutils is patched to
        # use "lib64" instead of "lib" for platlib.
        if k == "platlib" and _looks_like_red_hat_lib():
            continue

        # On Python 3.9+, sysconfig's posix_user scheme sets platlib against
        # sys.platlibdir, but distutils's unix_user incorrectly coninutes
        # using the same $usersite for both platlib and purelib. This creates a
        # mismatch when sys.platlibdir is not "lib".
        skip_bpo_44860 = (
            user
            and k == "platlib"
            and not WINDOWS
            and _PLATLIBDIR != "lib"
            and _looks_like_bpo_44860()
        )
        if skip_bpo_44860:
            continue

        # Slackware incorrectly patches posix_user to use lib64 instead of lib,
        # but not usersite to match the location.
        skip_slackware_user_scheme = (
            user
            and k in ("platlib", "purelib")
            and not WINDOWS
            and _looks_like_slackware_scheme()
        )
        if skip_slackware_user_scheme:
            continue

        # Both Debian and Red Hat patch Python to place the system site under
        # /usr/local instead of /usr. Debian also places lib in dist-packages
        # instead of site-packages, but the /usr/local check should cover it.
        skip_linux_system_special_case = (
            not (user or home or prefix or running_under_virtualenv())
            and old_v.parts[1:3] == ("usr", "local")
            and len(new_v.parts) > 1
            and new_v.parts[1] == "usr"
            and (len(new_v.parts) < 3 or new_v.parts[2] != "local")
            and (_looks_like_red_hat_scheme() or _looks_like_debian_scheme())
        )
        if skip_linux_system_special_case:
            continue

        # MSYS2 MINGW's sysconfig patch does not include the "site-packages"
        # part of the path. This is incorrect and will be fixed in MSYS.
        skip_msys2_mingw_bug = (
            WINDOWS and k in ("platlib", "purelib") and _looks_like_msys2_mingw_scheme()
        )
        if skip_msys2_mingw_bug:
            continue

        # CPython's POSIX install script invokes pip (via ensurepip) against the
        # interpreter located in the source tree, not the install site. This
        # triggers special logic in sysconfig that's not present in distutils.
        # https://github.com/python/cpython/blob/8c21941ddaf/Lib/sysconfig.py#L178-L194
        skip_cpython_build = (
            sysconfig.is_python_build(check_home=True)
            and not WINDOWS
            and k in ("headers", "include", "platinclude")
        )
        if skip_cpython_build:
            continue

        warning_contexts.append((old_v, new_v, f"scheme.{k}"))

    if not warning_contexts:
        return old

    # Check if this path mismatch is caused by distutils config files. Those
    # files will no longer work once we switch to sysconfig, so this raises a
    # deprecation message for them.
    default_old = _distutils.distutils_scheme(
        dist_name,
        user,
        home,
        root,
        isolated,
        prefix,
        ignore_config_files=True,
    )
    if any(default_old[k] != getattr(old, k) for k in SCHEME_KEYS):
        deprecated(
            reason=(
                "Configuring installation scheme with distutils config files "
                "is deprecated and will no longer work in the near future. If you "
                "are using a Homebrew or Linuxbrew Python, please see discussion "
                "at https://github.com/Homebrew/homebrew-core/issues/76621"
            ),
            replacement=None,
            gone_in=None,
        )
        return old

    # Post warnings about this mismatch so user can report them back.
    for old_v, new_v, key in warning_contexts:
        _warn_mismatched(old_v, new_v, key=key)
    _log_context(user=user, home=home, root=root, prefix=prefix)

    return old


def get_bin_prefix() -> str:
    new = _sysconfig.get_bin_prefix()
    if _USE_SYSCONFIG:
        return new

    old = _distutils.get_bin_prefix()
    if _warn_if_mismatch(pathlib.Path(old), pathlib.Path(new), key="bin_prefix"):
        _log_context()
    return old


def get_bin_user() -> str:
    return _sysconfig.get_scheme("", user=True).scripts


def _looks_like_deb_system_dist_packages(value: str) -> bool:
    """Check if the value is Debian's APT-controlled dist-packages.

    Debian's ``distutils.sysconfig.get_python_lib()`` implementation returns the
    default package path controlled by APT, but does not patch ``sysconfig`` to
    do the same. This is similar to the bug worked around in ``get_scheme()``,
    but here the default is ``deb_system`` instead of ``unix_local``. Ultimately
    we can't do anything about this Debian bug, and this detection allows us to
    skip the warning when needed.
    """
    if not _looks_like_debian_scheme():
        return False
    if value == "/usr/lib/python3/dist-packages":
        return True
    return False


def get_purelib() -> str:
    """Return the default pure-Python lib location."""
    new = _sysconfig.get_purelib()
    if _USE_SYSCONFIG:
        return new

    old = _distutils.get_purelib()
    if _looks_like_deb_system_dist_packages(old):
        return old
    if _warn_if_mismatch(pathlib.Path(old), pathlib.Path(new), key="purelib"):
        _log_context()
    return old


def get_platlib() -> str:
    """Return the default platform-shared lib location."""
    new = _sysconfig.get_platlib()
    if _USE_SYSCONFIG:
        return new

    from . import _distutils

    old = _distutils.get_platlib()
    if _looks_like_deb_system_dist_packages(old):
        return old
    if _warn_if_mismatch(pathlib.Path(old), pathlib.Path(new), key="platlib"):
        _log_context()
    return old

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__init__.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 16K 2025-06-01 01:28:16.683978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/__init__.cpython-312.pyc
b37dcb8fa925220d65342ea2719d157a9d13108999391d96b3e0709c7735485b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 fc 37 00 00  |........R.5h.7..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0f 00 00  |................|
00000020  00 00 00 00 00 f3 48 04  00 00 97 00 55 00 64 00  |......H.....U.d.|
00000030  64 01 6c 00 5a 00 64 00  64 01 6c 01 5a 01 64 00  |d.l.Z.d.d.l.Z.d.|
00000040  64 01 6c 02 5a 02 64 00  64 01 6c 03 5a 03 64 00  |d.l.Z.d.d.l.Z.d.|
00000050  64 01 6c 04 5a 04 64 00  64 01 6c 05 5a 05 64 00  |d.l.Z.d.d.l.Z.d.|
00000060  64 02 6c 06 6d 07 5a 07  6d 08 5a 08 6d 09 5a 09  |d.l.m.Z.m.Z.m.Z.|
00000070  01 00 64 00 64 03 6c 0a  6d 0b 5a 0b 6d 0c 5a 0c  |..d.d.l.m.Z.m.Z.|
00000080  01 00 64 00 64 04 6c 0d  6d 0e 5a 0e 01 00 64 00  |..d.d.l.m.Z...d.|
00000090  64 05 6c 0f 6d 10 5a 10  01 00 64 00 64 06 6c 11  |d.l.m.Z...d.d.l.|
000000a0  6d 12 5a 12 01 00 64 07  64 08 6c 13 6d 14 5a 14  |m.Z...d.d.l.m.Z.|
000000b0  01 00 64 07 64 09 6c 15  6d 16 5a 16 6d 17 5a 17  |..d.d.l.m.Z.m.Z.|
000000c0  6d 18 5a 18 6d 19 5a 19  6d 1a 5a 1a 6d 1b 5a 1b  |m.Z.m.Z.m.Z.m.Z.|
000000d0  01 00 67 00 64 0a a2 01  5a 1c 02 00 65 01 6a 3a  |..g.d...Z...e.j:|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000f0  00 00 65 1e ab 01 00 00  00 00 00 00 5a 1f 02 00  |..e.........Z...|
00000100  65 20 65 04 64 0b 64 0c  ab 03 00 00 00 00 00 00  |e e.d.d.........|
00000110  5a 21 65 22 65 23 64 0d  3c 00 00 00 65 04 6a 48  |Z!e"e#d.<...e.jH|
00000120  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000130  00 00 64 0e 6b 5c 00 00  5a 25 64 0f 65 26 66 02  |..d.k\..Z%d.e&f.|
00000140  64 10 84 04 5a 27 02 00  65 27 ab 00 00 00 00 00  |d...Z'..e'......|
00000150  00 00 5a 28 65 28 73 06  64 07 64 11 6c 13 6d 29  |..Z(e(s.d.d.l.m)|
00000160  5a 29 01 00 65 25 72 0f  65 28 73 0d 65 01 6a 54  |Z)..e%r.e(s.e.jT|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000180  00 00 5a 2b 6e 0c 65 01  6a 58 00 00 00 00 00 00  |..Z+n.e.jX......|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 5a 2b 64 0f  |............Z+d.|
000001a0  65 26 66 02 64 12 84 04  5a 2d 64 13 65 08 65 22  |e&f.d...Z-d.e.e"|
000001b0  65 22 66 02 19 00 00 00  64 0f 65 26 66 04 64 14  |e"f.....d.e&f.d.|
000001c0  84 04 5a 2e 02 00 65 00  6a 5e 00 00 00 00 00 00  |..Z...e.j^......|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 64 01 ac 15  |............d...|
000001e0  ab 01 00 00 00 00 00 00  64 0f 65 26 66 02 64 16  |........d.e&f.d.|
000001f0  84 04 ab 00 00 00 00 00  00 00 5a 30 02 00 65 00  |..........Z0..e.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_distutils.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.7K 2025-06-01 01:28:16.843978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_distutils.cpython-312.pyc
b2f12d9798b5d898e0f50143e282977b73b4ecf78781f6feea9b55ef9027f57a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_distutils.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 7d 17 00 00  |.........x3h}...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 14 00 00  |................|
00000020  00 00 00 00 00 f3 c0 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  09 00 02 00 65 01 64 01  ab 01 00 00 00 00 00 00  |....e.d.........|
00000040  6a 05 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000050  00 00 00 00 ab 00 00 00  00 00 00 00 01 00 64 02  |..............d.|
00000060  64 03 6c 05 5a 05 64 02  64 03 6c 06 5a 06 64 02  |d.l.Z.d.d.l.Z.d.|
00000070  64 03 6c 07 5a 07 64 02  64 04 6c 08 6d 09 5a 0a  |d.l.Z.d.d.l.m.Z.|
00000080  01 00 64 02 64 05 6c 0b  6d 0c 5a 0c 01 00 64 02  |..d.d.l.m.Z...d.|
00000090  64 06 6c 0b 6d 0d 5a 0e  01 00 64 02 64 07 6c 0f  |d.l.m.Z...d.d.l.|
000000a0  6d 10 5a 10 01 00 64 02  64 08 6c 11 6d 12 5a 12  |m.Z...d.d.l.m.Z.|
000000b0  6d 13 5a 13 6d 14 5a 14  6d 15 5a 15 01 00 64 02  |m.Z.m.Z.m.Z...d.|
000000c0  64 09 6c 16 6d 17 5a 17  01 00 64 02 64 0a 6c 18  |d.l.m.Z...d.d.l.|
000000d0  6d 19 5a 19 01 00 64 02  64 0b 6c 1a 6d 1b 5a 1b  |m.Z...d.d.l.m.Z.|
000000e0  01 00 64 0c 64 0d 6c 1c  6d 1d 5a 1d 01 00 02 00  |..d.d.l.m.Z.....|
000000f0  65 05 6a 3c 00 00 00 00  00 00 00 00 00 00 00 00  |e.j<............|
00000100  00 00 00 00 00 00 65 1f  ab 01 00 00 00 00 00 00  |......e.........|
00000110  5a 20 09 00 09 00 09 00  09 00 09 00 64 1d 64 0e  |Z ..........d.d.|
00000120  64 0f 9c 01 64 10 65 21  64 11 65 22 64 12 65 14  |d...d.e!d.e"d.e.|
00000130  65 21 19 00 00 00 64 13  65 14 65 21 19 00 00 00  |e!....d.e.e!....|
00000140  64 14 65 22 64 15 65 14  65 21 19 00 00 00 64 16  |d.e"d.e.e!....d.|
00000150  65 22 64 17 65 12 65 21  65 21 66 02 19 00 00 00  |e"d.e.e!e!f.....|
00000160  66 10 64 18 84 07 5a 23  09 00 09 00 09 00 09 00  |f.d...Z#........|
00000170  09 00 64 1d 64 10 65 21  64 11 65 22 64 12 65 14  |..d.d.e!d.e"d.e.|
00000180  65 21 19 00 00 00 64 13  65 14 65 21 19 00 00 00  |e!....d.e.e!....|
00000190  64 14 65 22 64 15 65 14  65 21 19 00 00 00 64 17  |d.e"d.e.e!....d.|
000001a0  65 17 66 0e 64 19 84 05  5a 24 64 17 65 21 66 02  |e.f.d...Z$d.e!f.|
000001b0  64 1a 84 04 5a 25 64 17  65 21 66 02 64 1b 84 04  |d...Z%d.e!f.d...|
000001c0  5a 26 64 17 65 21 66 02  64 1c 84 04 5a 27 79 03  |Z&d.e!f.d...Z'y.|
000001d0  23 00 65 03 65 04 66 02  24 00 72 03 01 00 59 00  |#.e.e.f.$.r...Y.|
000001e0  8c c2 77 00 78 03 59 00  77 01 29 1e 7a 37 4c 6f  |..w.x.Y.w.).z7Lo|
000001f0  63 61 74 69 6f 6e 73 20  77 68 65 72 65 20 77 65  |cations where we|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_distutils.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_sysconfig.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.9K 2025-06-01 01:28:17.003978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_sysconfig.cpython-312.pyc
dbf2fbfc5e1f780d5ae85190464991c8360b74fe74977799a8236b4ad39c5fb5  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_sysconfig.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 2c 1e 00 00  |.........x3h,...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0f 00 00  |................|
00000020  00 00 00 00 00 f3 f2 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 02  6c 05 6d 06 5a 06 6d 07  |l.Z.d.d.l.m.Z.m.|
00000060  5a 07 01 00 64 00 64 03  6c 08 6d 09 5a 09 6d 0a  |Z...d.d.l.m.Z.m.|
00000070  5a 0a 01 00 64 00 64 04  6c 0b 6d 0c 5a 0c 01 00  |Z...d.d.l.m.Z...|
00000080  64 05 64 06 6c 0d 6d 0e  5a 0e 6d 0f 5a 0f 6d 10  |d.d.l.m.Z.m.Z.m.|
00000090  5a 10 01 00 02 00 65 00  6a 22 00 00 00 00 00 00  |Z.....e.j"......|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 65 12 ab 01  |............e...|
000000b0  00 00 00 00 00 00 5a 13  02 00 65 14 02 00 65 03  |......Z...e...e.|
000000c0  6a 2a 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j*..............|
000000d0  00 00 00 00 ab 00 00 00  00 00 00 00 ab 01 00 00  |................|
000000e0  00 00 00 00 5a 16 02 00  65 17 65 03 64 07 64 01  |....Z...e.e.d.d.|
000000f0  ab 03 00 00 00 00 00 00  5a 18 64 08 65 19 66 02  |........Z.d.e.f.|
00000100  64 09 84 04 5a 1a 64 08  65 1b 66 02 64 0a 84 04  |d...Z.d.e.f.d...|
00000110  5a 1c 64 08 65 1b 66 02  64 0b 84 04 5a 1d 64 08  |Z.d.e.f.d...Z.d.|
00000120  65 1b 66 02 64 0c 84 04  5a 1e 67 00 64 0d a2 01  |e.f.d...Z.g.d...|
00000130  5a 1f 02 00 65 03 6a 40  00 00 00 00 00 00 00 00  |Z...e.j@........|
00000140  00 00 00 00 00 00 00 00  00 00 64 0e ab 01 00 00  |..........d.....|
00000150  00 00 00 00 81 11 65 1f  6a 43 00 00 00 00 00 00  |......e.jC......|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 64 0e ab 01  |............d...|
00000170  00 00 00 00 00 00 01 00  09 00 09 00 09 00 09 00  |................|
00000180  09 00 64 19 64 0f 65 1b  64 10 65 19 64 11 65 04  |..d.d.e.d.e.d.e.|
00000190  6a 44 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jD..............|
000001a0  00 00 00 00 65 1b 19 00  00 00 64 12 65 04 6a 44  |....e.....d.e.jD|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001c0  00 00 65 1b 19 00 00 00  64 13 65 19 64 14 65 04  |..e.....d.e.d.e.|
000001d0  6a 44 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jD..............|
000001e0  00 00 00 00 65 1b 19 00  00 00 64 08 65 0a 66 0e  |....e.....d.e.f.|
000001f0  64 15 84 05 5a 23 64 08  65 1b 66 02 64 16 84 04  |d...Z#d.e.f.d...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/_sysconfig.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/base.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.8K 2025-06-01 01:28:17.163978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/base.cpython-312.pyc
4fad0f7e4ee6ebd0b1b941a32974b72232d372d34140c92918a31a33f48ac8de  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/base.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 fc 09 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 86 01  00 00 97 00 55 00 64 00  |............U.d.|
00000030  64 01 6c 00 5a 00 64 00  64 01 6c 01 5a 01 64 00  |d.l.Z.d.d.l.Z.d.|
00000040  64 01 6c 02 5a 02 64 00  64 01 6c 03 5a 03 64 00  |d.l.Z.d.d.l.Z.d.|
00000050  64 01 6c 04 5a 04 64 00  64 01 6c 05 5a 05 64 00  |d.l.Z.d.d.l.Z.d.|
00000060  64 02 6c 06 6d 07 5a 07  01 00 64 00 64 03 6c 08  |d.l.m.Z...d.d.l.|
00000070  6d 09 5a 09 01 00 64 00  64 04 6c 0a 6d 0b 5a 0b  |m.Z...d.d.l.m.Z.|
00000080  01 00 02 00 65 09 6a 18  00 00 00 00 00 00 00 00  |....e.j.........|
00000090  00 00 00 00 00 00 00 00  00 00 64 05 ab 01 00 00  |..........d.....|
000000a0  00 00 00 00 5a 0d 02 00  65 04 6a 1c 00 00 00 00  |....Z...e.j.....|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 06  |..............d.|
000000c0  ab 01 00 00 00 00 00 00  5a 0f 65 10 65 11 64 07  |........Z.e.e.d.|
000000d0  3c 00 00 00 64 08 65 10  66 02 64 09 84 04 5a 12  |<...d.e.f.d...Z.|
000000e0  64 0a 65 10 64 0b 65 10  64 08 65 10 66 06 64 0c  |d.e.d.e.d.e.f.d.|
000000f0  84 04 5a 13 64 08 65 10  66 02 64 0d 84 04 5a 14  |..Z.d.e.f.d...Z.|
00000100  09 00 02 00 65 02 6a 2a  00 00 00 00 00 00 00 00  |....e.j*........|
00000110  00 00 00 00 00 00 00 00  00 00 ab 00 00 00 00 00  |................|
00000120  00 00 5a 16 65 05 6a 2e  00 00 00 00 00 00 00 00  |..Z.e.j.........|
00000130  00 00 00 00 00 00 00 00  00 00 65 10 19 00 00 00  |..........e.....|
00000140  65 11 64 0e 3c 00 00 00  02 00 65 00 6a 34 00 00  |e.d.<.....e.j4..|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000160  64 01 ac 0f ab 01 00 00  00 00 00 00 64 08 65 1b  |d...........d.e.|
00000170  66 02 64 10 84 04 ab 00  00 00 00 00 00 00 5a 1c  |f.d...........Z.|
00000180  79 01 23 00 65 18 24 00  72 0f 01 00 65 02 6a 32  |y.#.e.$.r...e.j2|
00000190  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001a0  00 00 5a 16 59 00 8c 30  77 00 78 03 59 00 77 01  |..Z.Y..0w.x.Y.w.|
000001b0  29 11 e9 00 00 00 00 4e  29 01 da 11 49 6e 73 74  |)......N)...Inst|
000001c0  61 6c 6c 61 74 69 6f 6e  45 72 72 6f 72 29 01 da  |allationError)..|
000001d0  07 61 70 70 64 69 72 73  29 01 da 18 72 75 6e 6e  |.appdirs)...runn|
000001e0  69 6e 67 5f 75 6e 64 65  72 5f 76 69 72 74 75 61  |ing_under_virtua|
000001f0  6c 65 6e 76 da 03 70 69  70 da 07 70 75 72 65 6c  |lenv..pip..purel|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/locations/__pycache__/base.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 389 2025-06-01 01:28:17.955978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/__init__.cpython-312.pyc
c588b368cb5a64a9005a384e16072a24a2095c73b3caad46eec605cbfbc5ce9a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 87 00 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 28 00  00 00 97 00 64 00 64 01  |......(.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 6d 03  |l.m.Z...d.d.l.m.|
00000040  5a 03 01 00 67 00 64 03  a2 01 5a 04 64 04 5a 05  |Z...g.d...Z.d.Z.|
00000050  79 05 29 06 e9 01 00 00  00 29 01 da 0c 44 69 73  |y.)......)...Dis|
00000060  74 72 69 62 75 74 69 6f  6e 29 01 da 0b 45 6e 76  |tribution)...Env|
00000070  69 72 6f 6e 6d 65 6e 74  29 03 da 04 4e 41 4d 45  |ironment)...NAME|
00000080  72 03 00 00 00 72 04 00  00 00 da 09 69 6d 70 6f  |r....r......impo|
00000090  72 74 6c 69 62 4e 29 06  da 06 5f 64 69 73 74 73  |rtlibN)..._dists|
000000a0  72 03 00 00 00 da 05 5f  65 6e 76 73 72 04 00 00  |r......_envsr...|
000000b0  00 da 07 5f 5f 61 6c 6c  5f 5f 72 05 00 00 00 a9  |...__all__r.....|
000000c0  00 f3 00 00 00 00 fa 8b  2f 64 61 74 61 2f 64 61  |......../data/da|
000000d0  74 61 2f 63 6f 6d 2e 74  65 72 6d 75 78 2f 66 69  |ta/com.termux/fi|
000000e0  6c 65 73 2f 68 6f 6d 65  2f 52 41 46 41 45 4c 49  |les/home/RAFAELI|
000000f0  41 2f 48 43 50 4d 2f 43  4f 52 45 2f 76 65 6e 76  |A/HCPM/CORE/venv|
00000100  5f 72 61 66 61 65 6c 69  61 2f 6c 69 62 2f 70 79  |_rafaelia/lib/py|
00000110  74 68 6f 6e 33 2e 31 32  2f 73 69 74 65 2d 70 61  |thon3.12/site-pa|
00000120  63 6b 61 67 65 73 2f 70  69 70 2f 5f 69 6e 74 65  |ckages/pip/_inte|
00000130  72 6e 61 6c 2f 6d 65 74  61 64 61 74 61 2f 69 6d  |rnal/metadata/im|
00000140  70 6f 72 74 6c 69 62 2f  5f 5f 69 6e 69 74 5f 5f  |portlib/__init__|
00000150  2e 70 79 da 08 3c 6d 6f  64 75 6c 65 3e 72 0d 00  |.py..<module>r..|
00000160  00 00 01 00 00 00 73 15  00 00 00 f0 03 01 01 01  |......s.........|
00000170  dd 00 20 dd 00 1e e2 0a  31 80 07 e0 07 12 81 04  |.. .....1.......|
00000180  72 0b 00 00 00                                    |r....|
00000185
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_compat.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.5K 2025-06-01 01:28:18.111978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_compat.cpython-312.pyc
0f5174168df6c3376962a023669a1000a123c2126c2ea5201444e2a666280291  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_compat.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ec 0a 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 30 01  00 00 97 00 64 00 64 01  |......0.....d.d.|
00000030  6c 00 5a 01 64 00 64 01  6c 02 5a 02 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 03 6d 04 5a 04 6d 05  5a 05 6d 06 5a 06 6d 07  |l.m.Z.m.Z.m.Z.m.|
00000050  5a 07 6d 08 5a 08 01 00  64 00 64 03 6c 09 6d 0a  |Z.m.Z...d.d.l.m.|
00000060  5a 0a 6d 0b 5a 0b 01 00  02 00 47 00 64 04 84 00  |Z.m.Z.....G.d...|
00000070  64 05 65 0c ab 03 00 00  00 00 00 00 5a 0d 02 00  |d.e.........Z...|
00000080  47 00 64 06 84 00 64 07  65 06 ab 03 00 00 00 00  |G.d...d.e.......|
00000090  00 00 5a 0e 64 08 65 01  6a 1e 00 00 00 00 00 00  |..Z.d.e.j.......|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 6a 20 00 00  |............j ..|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  64 09 65 05 65 0e 19 00  00 00 66 04 64 0a 84 04  |d.e.e.....f.d...|
000000d0  5a 11 64 0b 65 01 6a 1e  00 00 00 00 00 00 00 00  |Z.d.e.j.........|
000000e0  00 00 00 00 00 00 00 00  00 00 6a 20 00 00 00 00  |..........j ....|
000000f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 09  |..............d.|
00000100  65 07 65 05 65 12 19 00  00 00 65 05 65 12 19 00  |e.e.e.....e.e...|
00000110  00 00 66 02 19 00 00 00  66 04 64 0c 84 04 5a 13  |..f.....f.d...Z.|
00000120  64 0b 65 01 6a 1e 00 00  00 00 00 00 00 00 00 00  |d.e.j...........|
00000130  00 00 00 00 00 00 00 00  6a 20 00 00 00 00 00 00  |........j ......|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 64 09 65 0a  |............d.e.|
00000150  66 04 64 0d 84 04 5a 14  79 01 29 0e e9 00 00 00  |f.d...Z.y.).....|
00000160  00 4e 29 05 da 03 41 6e  79 da 08 4f 70 74 69 6f  |.N)...Any..Optio|
00000170  6e 61 6c da 08 50 72 6f  74 6f 63 6f 6c da 05 54  |nal..Protocol..T|
00000180  75 70 6c 65 da 04 63 61  73 74 29 02 da 0e 4e 6f  |uple..cast)...No|
00000190  72 6d 61 6c 69 7a 65 64  4e 61 6d 65 da 11 63 61  |rmalizedName..ca|
000001a0  6e 6f 6e 69 63 61 6c 69  7a 65 5f 6e 61 6d 65 63  |nonicalize_namec|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 06 00 00 00  |................|
000001c0  00 00 00 00 f3 54 00 00  00 97 00 65 00 5a 01 64  |.....T.....e.Z.d|
000001d0  00 5a 02 64 01 65 03 6a  08 00 00 00 00 00 00 00  |.Z.d.e.j........|
000001e0  00 00 00 00 00 00 00 00  00 00 00 6a 0a 00 00 00  |...........j....|
000001f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 64  |...............d|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_compat.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_dists.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 13K 2025-06-01 01:28:18.271978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_dists.cpython-312.pyc
1c833fffa75489dd37b28cae6505d761971ab8785a7de7dc0e3070abe55d0c63  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_dists.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 57 20 00 00  |.........x3hW ..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 54 01  00 00 97 00 64 00 64 01  |......T.....d.d.|
00000030  6c 00 5a 01 64 00 64 01  6c 02 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000050  6c 06 6d 07 5a 07 01 00  64 00 64 03 6c 08 6d 09  |l.m.Z...d.d.l.m.|
00000060  5a 09 6d 0a 5a 0a 6d 0b  5a 0b 6d 0c 5a 0c 6d 0d  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 6d 10 5a 10 6d 11  |Z.m.Z.m.Z.m.Z.m.|
00000080  5a 11 01 00 64 00 64 04  6c 12 6d 13 5a 13 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 05 6c 14 6d 15  5a 15 6d 16 5a 16 01 00  |d.d.l.m.Z.m.Z...|
000000a0  64 00 64 06 6c 17 6d 18  5a 18 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000b0  6c 17 6d 19 5a 1a 01 00  64 00 64 08 6c 1b 6d 1c  |l.m.Z...d.d.l.m.|
000000c0  5a 1c 6d 1d 5a 1d 01 00  64 00 64 09 6c 1e 6d 1f  |Z.m.Z...d.d.l.m.|
000000d0  5a 1f 6d 20 5a 20 6d 21  5a 21 6d 22 5a 22 01 00  |Z.m Z m!Z!m"Z"..|
000000e0  64 00 64 0a 6c 23 6d 24  5a 24 01 00 64 00 64 0b  |d.d.l#m$Z$..d.d.|
000000f0  6c 25 6d 26 5a 26 01 00  64 00 64 0c 6c 27 6d 28  |l%m&Z&..d.d.l'm(|
00000100  5a 28 01 00 64 00 64 0d  6c 29 6d 2a 5a 2a 6d 2b  |Z(..d.d.l)m*Z*m+|
00000110  5a 2b 01 00 64 0e 64 0f  6c 2c 6d 2d 5a 2d 6d 2e  |Z+..d.d.l,m-Z-m.|
00000120  5a 2e 6d 2f 5a 2f 01 00  02 00 47 00 64 10 84 00  |Z.m/Z/....G.d...|
00000130  64 11 65 03 6a 60 00 00  00 00 00 00 00 00 00 00  |d.e.j`..........|
00000140  00 00 00 00 00 00 00 00  6a 62 00 00 00 00 00 00  |........jb......|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 ab 03 00 00  |................|
00000160  00 00 00 00 5a 32 02 00  47 00 64 12 84 00 64 13  |....Z2..G.d...d.|
00000170  65 1f ab 03 00 00 00 00  00 00 5a 31 79 01 29 14  |e.........Z1y.).|
00000180  e9 00 00 00 00 4e 29 01  da 08 50 61 74 68 4c 69  |.....N)...PathLi|
00000190  6b 65 29 09 da 0a 43 6f  6c 6c 65 63 74 69 6f 6e  |ke)...Collection|
000001a0  da 04 44 69 63 74 da 08  49 74 65 72 61 62 6c 65  |..Dict..Iterable|
000001b0  da 08 49 74 65 72 61 74  6f 72 da 07 4d 61 70 70  |..Iterator..Mapp|
000001c0  69 6e 67 da 08 4f 70 74  69 6f 6e 61 6c da 08 53  |ing..Optional..S|
000001d0  65 71 75 65 6e 63 65 da  05 55 6e 69 6f 6e da 04  |equence..Union..|
000001e0  63 61 73 74 29 01 da 0b  52 65 71 75 69 72 65 6d  |cast)...Requirem|
000001f0  65 6e 74 29 02 da 0e 4e  6f 72 6d 61 6c 69 7a 65  |ent)...Normalize|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_dists.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_envs.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 8.0K 2025-06-01 01:28:18.431978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_envs.cpython-312.pyc
821538767ea43445396d7895331ed897c507e4b9a41c69abf8daeda2fae629cf  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_envs.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 b1 14 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 0a 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 01 64 00 64 01  6c 02 5a 02 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 03 5a 03 64 00 64 01  6c 04 5a 04 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 00 64 01  6c 06 5a 06 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 6d 08 5a 08 6d 09  5a 09 6d 0a 5a 0a 6d 0b  |l.m.Z.m.Z.m.Z.m.|
00000070  5a 0b 6d 0c 5a 0c 6d 0d  5a 0d 01 00 64 00 64 03  |Z.m.Z.m.Z...d.d.|
00000080  6c 0e 6d 0f 5a 0f 6d 10  5a 10 6d 11 5a 11 6d 12  |l.m.Z.m.Z.m.Z.m.|
00000090  5a 12 01 00 64 00 64 04  6c 13 6d 14 5a 14 6d 15  |Z...d.d.l.m.Z.m.|
000000a0  5a 15 01 00 64 00 64 05  6c 16 6d 17 5a 17 01 00  |Z...d.d.l.m.Z...|
000000b0  64 06 64 07 6c 18 6d 19  5a 19 6d 1a 5a 1a 6d 1b  |d.d.l.m.Z.m.Z.m.|
000000c0  5a 1b 6d 1c 5a 1c 01 00  64 06 64 08 6c 1d 6d 1e  |Z.m.Z...d.d.l.m.|
000000d0  5a 1e 01 00 02 00 65 02  6a 3e 00 00 00 00 00 00  |Z.....e.j>......|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 65 20 ab 01  |............e ..|
000000f0  00 00 00 00 00 00 5a 21  64 09 65 22 64 0a 65 23  |......Z!d.e"d.e#|
00000100  66 04 64 0b 84 04 5a 24  02 00 47 00 64 0c 84 00  |f.d...Z$..G.d...|
00000110  64 0d ab 02 00 00 00 00  00 00 5a 25 02 00 47 00  |d.........Z%..G.|
00000120  64 0e 84 00 64 0f 65 15  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000130  5a 26 79 01 29 10 e9 00  00 00 00 4e 29 06 da 08  |Z&y.)......N)...|
00000140  49 74 65 72 61 74 6f 72  da 04 4c 69 73 74 da 08  |Iterator..List..|
00000150  4f 70 74 69 6f 6e 61 6c  da 08 53 65 71 75 65 6e  |Optional..Sequen|
00000160  63 65 da 03 53 65 74 da  05 54 75 70 6c 65 29 04  |ce..Set..Tuple).|
00000170  da 14 49 6e 76 61 6c 69  64 57 68 65 65 6c 46 69  |..InvalidWheelFi|
00000180  6c 65 6e 61 6d 65 da 0e  4e 6f 72 6d 61 6c 69 7a  |lename..Normaliz|
00000190  65 64 4e 61 6d 65 da 11  63 61 6e 6f 6e 69 63 61  |edName..canonica|
000001a0  6c 69 7a 65 5f 6e 61 6d  65 da 14 70 61 72 73 65  |lize_name..parse|
000001b0  5f 77 68 65 65 6c 5f 66  69 6c 65 6e 61 6d 65 29  |_wheel_filename)|
000001c0  02 da 10 42 61 73 65 44  69 73 74 72 69 62 75 74  |...BaseDistribut|
000001d0  69 6f 6e da 0f 42 61 73  65 45 6e 76 69 72 6f 6e  |ion..BaseEnviron|
000001e0  6d 65 6e 74 29 01 da 0f  57 48 45 45 4c 5f 45 58  |ment)...WHEEL_EX|
000001f0  54 45 4e 53 49 4f 4e e9  01 00 00 00 29 04 da 0b  |TENSION.....)...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/importlib/__pycache__/_envs.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.6K 2025-06-01 01:28:17.319978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/__init__.cpython-312.pyc
0f1b41e96b3eb9252fe080e4837219b38c1ba81596df7a7b4b301f1cb2ad121a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 5b 16 00 00  |.........x3h[...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 46 01  00 00 97 00 64 00 64 01  |......F.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 6d 05 5a 05 6d 06  5a 06 6d 07 5a 07 6d 08  |l.m.Z.m.Z.m.Z.m.|
00000060  5a 08 6d 09 5a 09 6d 0a  5a 0a 01 00 64 00 64 03  |Z.m.Z.m.Z...d.d.|
00000070  6c 0b 6d 0c 5a 0c 01 00  64 00 64 04 6c 0d 6d 0e  |l.m.Z...d.d.l.m.|
00000080  5a 0e 01 00 64 05 64 06  6c 0f 6d 10 5a 10 6d 11  |Z...d.d.l.m.Z.m.|
00000090  5a 11 6d 12 5a 12 6d 13  5a 13 6d 14 5a 14 01 00  |Z.m.Z.m.Z.m.Z...|
000000a0  67 00 64 07 a2 01 5a 15  64 08 65 16 66 02 64 09  |g.d...Z.d.e.f.d.|
000000b0  84 04 5a 17 64 1a 64 0a  84 04 5a 18 02 00 47 00  |..Z.d.d...Z...G.|
000000c0  64 0b 84 00 64 0c 65 08  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000d0  5a 19 02 00 65 01 6a 34  00 00 00 00 00 00 00 00  |Z...e.j4........|
000000e0  00 00 00 00 00 00 00 00  00 00 64 01 ac 0d ab 01  |..........d.....|
000000f0  00 00 00 00 00 00 64 08  65 19 66 02 64 0e 84 04  |......d.e.f.d...|
00000100  ab 00 00 00 00 00 00 00  5a 1b 64 08 65 11 66 02  |........Z.d.e.f.|
00000110  64 0f 84 04 5a 1c 64 10  65 07 65 05 65 1d 19 00  |d...Z.d.e.e.e...|
00000120  00 00 19 00 00 00 64 08  65 11 66 04 64 11 84 04  |......d.e.f.d...|
00000130  5a 1e 64 12 65 1d 64 08  65 10 66 04 64 13 84 04  |Z.d.e.d.e.f.d...|
00000140  5a 1f 64 14 65 14 64 15  65 1d 64 08 65 10 66 06  |Z.d.e.d.e.d.e.f.|
00000150  64 16 84 04 5a 20 64 17  65 21 64 18 65 1d 64 15  |d...Z d.e!d.e.d.|
00000160  65 1d 64 08 65 10 66 08  64 19 84 04 5a 22 79 01  |e.d.e.f.d...Z"y.|
00000170  29 1b e9 00 00 00 00 4e  29 06 da 04 4c 69 73 74  |)......N)...List|
00000180  da 07 4c 69 74 65 72 61  6c da 08 4f 70 74 69 6f  |..Literal..Optio|
00000190  6e 61 6c da 08 50 72 6f  74 6f 63 6f 6c da 04 54  |nal..Protocol..T|
000001a0  79 70 65 da 04 63 61 73  74 29 01 da 0a 64 65 70  |ype..cast)...dep|
000001b0  72 65 63 61 74 65 64 29  01 da 09 73 74 72 74 6f  |recated)...strto|
000001c0  62 6f 6f 6c e9 01 00 00  00 29 05 da 10 42 61 73  |bool.....)...Bas|
000001d0  65 44 69 73 74 72 69 62  75 74 69 6f 6e da 0f 42  |eDistribution..B|
000001e0  61 73 65 45 6e 76 69 72  6f 6e 6d 65 6e 74 da 0f  |aseEnvironment..|
000001f0  46 69 6c 65 73 79 73 74  65 6d 57 68 65 65 6c da  |FilesystemWheel.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/_json.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.0K 2025-06-01 01:28:17.475978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/_json.cpython-312.pyc
dba2f332a4a7eade63ecc08dbab8ab887e0730331d3f8467767bdc36b2bfca95  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/_json.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 93 0a 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 72 00  00 00 97 00 64 00 64 01  |......r.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 6d 03 5a 03 01 00  |l.m.Z.m.Z.m.Z...|
00000040  64 00 64 02 6c 04 6d 05  5a 05 01 00 64 00 64 03  |d.d.l.m.Z...d.d.|
00000050  6c 06 6d 07 5a 07 6d 08  5a 08 6d 09 5a 09 6d 0a  |l.m.Z.m.Z.m.Z.m.|
00000060  5a 0a 6d 0b 5a 0b 01 00  67 00 64 04 a2 01 5a 0c  |Z.m.Z...g.d...Z.|
00000070  64 05 65 0d 64 06 65 0d  66 04 64 07 84 04 5a 0e  |d.e.d.e.f.d...Z.|
00000080  64 08 65 05 64 06 65 08  65 0d 65 07 66 02 19 00  |d.e.d.e.e.e.f...|
00000090  00 00 66 04 64 09 84 04  5a 0f 79 0a 29 0b e9 00  |..f.d...Z.y.)...|
000000a0  00 00 00 29 03 da 06 48  65 61 64 65 72 da 0d 64  |...)...Header..d|
000000b0  65 63 6f 64 65 5f 68 65  61 64 65 72 da 0b 6d 61  |ecode_header..ma|
000000c0  6b 65 5f 68 65 61 64 65  72 29 01 da 07 4d 65 73  |ke_header)...Mes|
000000d0  73 61 67 65 29 05 da 03  41 6e 79 da 04 44 69 63  |sage)...Any..Dic|
000000e0  74 da 04 4c 69 73 74 da  05 55 6e 69 6f 6e da 04  |t..List..Union..|
000000f0  63 61 73 74 29 1b 29 02  7a 10 4d 65 74 61 64 61  |cast).).z.Metada|
00000100  74 61 2d 56 65 72 73 69  6f 6e 46 29 02 da 04 4e  |ta-VersionF)...N|
00000110  61 6d 65 46 29 02 da 07  56 65 72 73 69 6f 6e 46  |ameF)...VersionF|
00000120  29 02 da 07 44 79 6e 61  6d 69 63 54 29 02 da 08  |)...DynamicT)...|
00000130  50 6c 61 74 66 6f 72 6d  54 29 02 7a 12 53 75 70  |PlatformT).z.Sup|
00000140  70 6f 72 74 65 64 2d 50  6c 61 74 66 6f 72 6d 54  |ported-PlatformT|
00000150  29 02 da 07 53 75 6d 6d  61 72 79 46 29 02 da 0b  |)...SummaryF)...|
00000160  44 65 73 63 72 69 70 74  69 6f 6e 46 29 02 7a 18  |DescriptionF).z.|
00000170  44 65 73 63 72 69 70 74  69 6f 6e 2d 43 6f 6e 74  |Description-Cont|
00000180  65 6e 74 2d 54 79 70 65  46 29 02 da 08 4b 65 79  |ent-TypeF)...Key|
00000190  77 6f 72 64 73 46 29 02  7a 09 48 6f 6d 65 2d 70  |wordsF).z.Home-p|
000001a0  61 67 65 46 29 02 7a 0c  44 6f 77 6e 6c 6f 61 64  |ageF).z.Download|
000001b0  2d 55 52 4c 46 29 02 da  06 41 75 74 68 6f 72 46  |-URLF)...AuthorF|
000001c0  29 02 7a 0c 41 75 74 68  6f 72 2d 65 6d 61 69 6c  |).z.Author-email|
000001d0  46 29 02 da 0a 4d 61 69  6e 74 61 69 6e 65 72 46  |F)...MaintainerF|
000001e0  29 02 7a 10 4d 61 69 6e  74 61 69 6e 65 72 2d 65  |).z.Maintainer-e|
000001f0  6d 61 69 6c 46 29 02 da  07 4c 69 63 65 6e 73 65  |mailF)...License|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/_json.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/base.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 35K 2025-06-01 01:28:17.643978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/base.cpython-312.pyc
13f253177f36de69d67350ff8e37b14f125e134206dffe3488141ff766a6aed9  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/base.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 7b 63 00 00  |.........x3h{c..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 2e 02  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 02 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 03 5a 03 64 00 64 01  6c 04 5a 04 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 00 64 01  6c 06 5a 06 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 5a 07 64 00 64 01  6c 08 5a 08 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000070  6c 09 6d 0a 5a 0a 6d 0b  5a 0b 6d 0c 5a 0c 6d 0d  |l.m.Z.m.Z.m.Z.m.|
00000080  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 6d 10 5a 10 6d 11  |Z.m.Z.m.Z.m.Z.m.|
00000090  5a 11 6d 12 5a 12 6d 13  5a 13 6d 14 5a 14 6d 15  |Z.m.Z.m.Z.m.Z.m.|
000000a0  5a 15 6d 16 5a 16 01 00  64 00 64 03 6c 17 6d 18  |Z.m.Z...d.d.l.m.|
000000b0  5a 18 01 00 64 00 64 04  6c 19 6d 1a 5a 1a 6d 1b  |Z...d.d.l.m.Z.m.|
000000c0  5a 1b 01 00 64 00 64 05  6c 1c 6d 1d 5a 1d 6d 1e  |Z...d.d.l.m.Z.m.|
000000d0  5a 1e 01 00 64 00 64 06  6c 1f 6d 20 5a 20 01 00  |Z...d.d.l.m Z ..|
000000e0  64 00 64 07 6c 21 6d 22  5a 22 01 00 64 00 64 08  |d.d.l!m"Z"..d.d.|
000000f0  6c 23 6d 24 5a 24 6d 25  5a 25 01 00 64 00 64 09  |l#m$Z$m%Z%..d.d.|
00000100  6c 26 6d 27 5a 27 6d 28  5a 28 6d 29 5a 29 01 00  |l&m'Z'm(Z(m)Z)..|
00000110  64 00 64 0a 6c 2a 6d 2b  5a 2b 01 00 64 00 64 0b  |d.d.l*m+Z+..d.d.|
00000120  6c 2c 6d 2d 5a 2d 01 00  64 00 64 0c 6c 2e 6d 2f  |l,m-Z-..d.d.l.m/|
00000130  5a 2f 6d 30 5a 30 01 00  64 00 64 0d 6c 31 6d 32  |Z/m0Z0..d.d.l1m2|
00000140  5a 32 01 00 64 0e 64 0f  6c 33 6d 34 5a 34 01 00  |Z2..d.d.l3m4Z4..|
00000150  65 16 65 35 65 06 6a 6c  00 00 00 00 00 00 00 00  |e.e5e.jl........|
00000160  00 00 00 00 00 00 00 00  00 00 66 02 19 00 00 00  |..........f.....|
00000170  5a 37 02 00 65 05 6a 70  00 00 00 00 00 00 00 00  |Z7..e.jp........|
00000180  00 00 00 00 00 00 00 00  00 00 65 39 ab 01 00 00  |..........e9....|
00000190  00 00 00 00 5a 3a 02 00  47 00 64 10 84 00 64 11  |....Z:..G.d...d.|
000001a0  65 14 ab 03 00 00 00 00  00 00 5a 3b 64 12 65 15  |e.........Z;d.e.|
000001b0  65 35 64 13 66 02 19 00  00 00 64 14 65 15 65 35  |e5d.f.....d.e.e5|
000001c0  64 13 66 02 19 00 00 00  64 15 65 35 66 06 64 16  |d.f.....d.e5f.d.|
000001d0  84 04 5a 3c 02 00 47 00  64 17 84 00 64 18 65 12  |..Z<..G.d...d.e.|
000001e0  ab 03 00 00 00 00 00 00  5a 3d 02 00 47 00 64 19  |........Z=..G.d.|
000001f0  84 00 64 1a 65 14 ab 03  00 00 00 00 00 00 5a 3e  |..d.e.........Z>|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/base.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/pkg_resources.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 16K 2025-06-01 01:28:17.811978180 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/pkg_resources.cpython-312.pyc
3829a295d8a82bc13b6f0c080d9906b867f09b3064a217c433b9d6d19425fdf9  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/pkg_resources.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 2e 29 00 00  |.........x3h.)..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 72 01  00 00 97 00 64 00 64 01  |......r.....d.d.|
00000030  6c 00 5a 01 64 00 64 01  6c 02 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 03 5a 03 64 00 64 01  6c 04 5a 04 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 00 64 02  6c 06 6d 07 5a 07 6d 08  |l.Z.d.d.l.m.Z.m.|
00000060  5a 08 6d 09 5a 09 6d 0a  5a 0a 6d 0b 5a 0b 6d 0c  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 0c 6d 0d 5a 0d 01 00  64 00 64 03 6c 0e 6d 0f  |Z.m.Z...d.d.l.m.|
00000080  5a 0f 01 00 64 00 64 04  6c 10 6d 11 5a 11 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 05 6c 12 6d 13  5a 13 6d 14 5a 14 01 00  |d.d.l.m.Z.m.Z...|
000000a0  64 00 64 06 6c 15 6d 16  5a 16 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000b0  6c 15 6d 17 5a 18 01 00  64 00 64 08 6c 19 6d 1a  |l.m.Z...d.d.l.m.|
000000c0  5a 1a 6d 1b 5a 1b 6d 1c  5a 1c 01 00 64 00 64 09  |Z.m.Z.m.Z...d.d.|
000000d0  6c 1d 6d 1e 5a 1e 01 00  64 00 64 0a 6c 1f 6d 20  |l.m.Z...d.d.l.m |
000000e0  5a 20 6d 21 5a 21 01 00  64 00 64 0b 6c 22 6d 23  |Z m!Z!..d.d.l"m#|
000000f0  5a 23 6d 24 5a 24 01 00  64 0c 64 0d 6c 25 6d 26  |Z#m$Z$..d.d.l%m&|
00000100  5a 26 6d 27 5a 27 6d 28  5a 28 6d 29 5a 29 6d 2a  |Z&m'Z'm(Z(m)Z)m*|
00000110  5a 2a 01 00 67 00 64 0e  a2 01 5a 2b 02 00 65 03  |Z*..g.d...Z+..e.|
00000120  6a 58 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |jX..............|
00000130  00 00 00 00 65 2d ab 01  00 00 00 00 00 00 5a 2e  |....e-........Z.|
00000140  64 0f 5a 2f 02 00 47 00  64 10 84 00 64 11 65 0c  |d.Z/..G.d...d.e.|
00000150  ab 03 00 00 00 00 00 00  5a 30 02 00 47 00 64 12  |........Z0..G.d.|
00000160  84 00 64 13 ab 02 00 00  00 00 00 00 5a 31 02 00  |..d.........Z1..|
00000170  47 00 64 14 84 00 64 15  65 26 ab 03 00 00 00 00  |G.d...d.e&......|
00000180  00 00 5a 32 02 00 47 00  64 16 84 00 64 17 65 28  |..Z2..G.d...d.e(|
00000190  ab 03 00 00 00 00 00 00  5a 33 79 01 29 18 e9 00  |........Z3y.)...|
000001a0  00 00 00 4e 29 07 da 0a  43 6f 6c 6c 65 63 74 69  |...N)...Collecti|
000001b0  6f 6e da 08 49 74 65 72  61 62 6c 65 da 08 49 74  |on..Iterable..It|
000001c0  65 72 61 74 6f 72 da 04  4c 69 73 74 da 07 4d 61  |erator..List..Ma|
000001d0  70 70 69 6e 67 da 0a 4e  61 6d 65 64 54 75 70 6c  |pping..NamedTupl|
000001e0  65 da 08 4f 70 74 69 6f  6e 61 6c 29 01 da 0d 70  |e..Optional)...p|
000001f0  6b 67 5f 72 65 73 6f 75  72 63 65 73 29 01 da 0b  |kg_resources)...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/metadata/__pycache__/pkg_resources.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/link.py
-rwxrwxrwx. 1 u0_a292 u0_a292 22K 2025-06-02 22:55:12.890164469 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/link.py
d6e623f41956b456fa668d9dcf50a354221e9c7a14ee22e1d443c6adecf60ba7  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/link.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----