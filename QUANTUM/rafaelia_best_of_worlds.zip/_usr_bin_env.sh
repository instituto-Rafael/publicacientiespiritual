#!/usr/bin/env python3
import logging
import shutil
import sys
import textwrap
import xmlrpc.client
from collections import OrderedDict
from optparse import Values
from typing import Dict, List, Optional, TypedDict

from pip._vendor.packaging.version import parse as parse_version

from pip._internal.cli.base_command import Command
from pip._internal.cli.req_command import SessionCommandMixin
from pip._internal.cli.status_codes import NO_MATCHES_FOUND, SUCCESS
from pip._internal.exceptions import CommandError
from pip._internal.metadata import get_default_environment
from pip._internal.metadata.base import BaseDistribution
from pip._internal.models.index import PyPI
from pip._internal.network.xmlrpc import PipXmlrpcTransport
from pip._internal.utils.logging import indent_log
from pip._internal.utils.misc import write_output


class TransformedHit(TypedDict):
    name: str
    summary: str
    versions: List[str]


logger = logging.getLogger(__name__)


class SearchCommand(Command, SessionCommandMixin):
    """Search for PyPI packages whose name or summary contains <query>."""

    usage = """
      %prog [options] <query>"""
    ignore_require_venv = True

    def add_options(self) -> None:
        self.cmd_opts.add_option(
            "-i",
            "--index",
            dest="index",
            metavar="URL",
            default=PyPI.pypi_url,
            help="Base URL of Python Package Index (default %default)",
        )

        self.parser.insert_option_group(0, self.cmd_opts)

    def run(self, options: Values, args: List[str]) -> int:
        if not args:
            raise CommandError("Missing required argument (search query).")
        query = args
        pypi_hits = self.search(query, options)
        hits = transform_hits(pypi_hits)

        terminal_width = None
        if sys.stdout.isatty():
            terminal_width = shutil.get_terminal_size()[0]

        print_results(hits, terminal_width=terminal_width)
        if pypi_hits:
            return SUCCESS
        return NO_MATCHES_FOUND

    def search(self, query: List[str], options: Values) -> List[Dict[str, str]]:
        index_url = options.index

        session = self.get_default_session(options)

        transport = PipXmlrpcTransport(index_url, session)
        pypi = xmlrpc.client.ServerProxy(index_url, transport)
        try:
            hits = pypi.search({"name": query, "summary": query}, "or")
        except xmlrpc.client.Fault as fault:
            message = (
                f"XMLRPC request failed [code: {fault.faultCode}]\n{fault.faultString}"
            )
            raise CommandError(message)
        assert isinstance(hits, list)
        return hits


def transform_hits(hits: List[Dict[str, str]]) -> List["TransformedHit"]:
    """
    The list from pypi is really a list of versions. We want a list of
    packages with the list of versions stored inline. This converts the
    list from pypi into one we can use.
    """
    packages: Dict[str, TransformedHit] = OrderedDict()
    for hit in hits:
        name = hit["name"]
        summary = hit["summary"]
        version = hit["version"]

        if name not in packages.keys():
            packages[name] = {
                "name": name,
                "summary": summary,
                "versions": [version],
            }
        else:
            packages[name]["versions"].append(version)

            # if this is the highest version, replace summary and score
            if version == highest_version(packages[name]["versions"]):
                packages[name]["summary"] = summary

    return list(packages.values())


def print_dist_installation_info(latest: str, dist: Optional[BaseDistribution]) -> None:
    if dist is not None:
        with indent_log():
            if dist.version == latest:
                write_output("INSTALLED: %s (latest)", dist.version)
            else:
                write_output("INSTALLED: %s", dist.version)
                if parse_version(latest).pre:
                    write_output(
                        "LATEST:    %s (pre-release; install"
                        " with `pip install --pre`)",
                        latest,
                    )
                else:
                    write_output("LATEST:    %s", latest)


def get_installed_distribution(name: str) -> Optional[BaseDistribution]:
    env = get_default_environment()
    return env.get_distribution(name)


def print_results(
    hits: List["TransformedHit"],
    name_column_width: Optional[int] = None,
    terminal_width: Optional[int] = None,
) -> None:
    if not hits:
        return
    if name_column_width is None:
        name_column_width = (
            max(
                [
                    len(hit["name"]) + len(highest_version(hit.get("versions", ["-"])))
                    for hit in hits
                ]
            )
            + 4
        )

    for hit in hits:
        name = hit["name"]
        summary = hit["summary"] or ""
        latest = highest_version(hit.get("versions", ["-"]))
        if terminal_width is not None:
            target_width = terminal_width - name_column_width - 5
            if target_width > 10:
                # wrap and indent summary to fit terminal
                summary_lines = textwrap.wrap(summary, target_width)
                summary = ("\n" + " " * (name_column_width + 3)).join(summary_lines)

        name_latest = f"{name} ({latest})"
        line = f"{name_latest:{name_column_width}} - {summary}"
        try:
            write_output(line)
            dist = get_installed_distribution(name)
            print_dist_installation_info(latest, dist)
        except UnicodeEncodeError:
            pass


def highest_version(versions: List[str]) -> str:
    return max(versions, key=parse_version)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/search.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.1K 2025-06-01 01:28:12.211978184 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc
815f5324ac8741b1525962c280ab911c897cc96498413826ce1de6cb0f778934  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 a9 0f 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 20 02  00 00 97 00 55 00 64 00  |...... .....U.d.|
00000030  5a 00 64 01 64 02 6c 01  5a 01 64 01 64 03 6c 02  |Z.d.d.l.Z.d.d.l.|
00000040  6d 03 5a 03 01 00 64 01  64 04 6c 04 6d 05 5a 05  |m.Z...d.d.l.m.Z.|
00000050  6d 06 5a 06 6d 07 5a 07  01 00 64 01 64 05 6c 08  |m.Z.m.Z...d.d.l.|
00000060  6d 09 5a 09 01 00 02 00  65 03 64 06 64 07 ab 02  |m.Z.....e.d.d...|
00000070  00 00 00 00 00 00 5a 0a  69 00 64 08 02 00 65 0a  |......Z.i.d...e.|
00000080  64 09 64 0a 64 0b ab 03  00 00 00 00 00 00 93 01  |d.d.d...........|
00000090  64 0c 02 00 65 0a 64 0d  64 0e 64 0f ab 03 00 00  |d...e.d.d.d.....|
000000a0  00 00 00 00 93 01 64 10  02 00 65 0a 64 11 64 12  |......d...e.d.d.|
000000b0  64 13 ab 03 00 00 00 00  00 00 93 01 64 14 02 00  |d...........d...|
000000c0  65 0a 64 15 64 16 64 17  ab 03 00 00 00 00 00 00  |e.d.d.d.........|
000000d0  93 01 64 18 02 00 65 0a  64 19 64 1a 64 1b ab 03  |..d...e.d.d.d...|
000000e0  00 00 00 00 00 00 93 01  64 1c 02 00 65 0a 64 1d  |........d...e.d.|
000000f0  64 1e 64 1f ab 03 00 00  00 00 00 00 93 01 64 20  |d.d...........d |
00000100  02 00 65 0a 64 21 64 22  64 23 ab 03 00 00 00 00  |..e.d!d"d#......|
00000110  00 00 93 01 64 24 02 00  65 0a 64 25 64 26 64 27  |....d$..e.d%d&d'|
00000120  ab 03 00 00 00 00 00 00  93 01 64 28 02 00 65 0a  |..........d(..e.|
00000130  64 29 64 2a 64 2b ab 03  00 00 00 00 00 00 93 01  |d)d*d+..........|
00000140  64 2c 02 00 65 0a 64 2d  64 2e 64 2f ab 03 00 00  |d,..e.d-d.d/....|
00000150  00 00 00 00 93 01 64 30  02 00 65 0a 64 31 64 32  |......d0..e.d1d2|
00000160  64 33 ab 03 00 00 00 00  00 00 93 01 64 34 02 00  |d3..........d4..|
00000170  65 0a 64 35 64 36 64 37  ab 03 00 00 00 00 00 00  |e.d5d6d7........|
00000180  93 01 64 38 02 00 65 0a  64 39 64 3a 64 3b ab 03  |..d8..e.d9d:d;..|
00000190  00 00 00 00 00 00 93 01  64 3c 02 00 65 0a 64 3d  |........d<..e.d=|
000001a0  64 3e 64 3f ab 03 00 00  00 00 00 00 93 01 64 40  |d>d?..........d@|
000001b0  02 00 65 0a 64 41 64 42  64 43 ab 03 00 00 00 00  |..e.dAdBdC......|
000001c0  00 00 93 01 64 44 02 00  65 0a 64 45 64 46 64 47  |....dD..e.dEdFdG|
000001d0  ab 03 00 00 00 00 00 00  93 01 64 48 02 00 65 0a  |..........dH..e.|
000001e0  64 49 64 4a 64 4b ab 03  00 00 00 00 00 00 93 01  |dIdJdK..........|
000001f0  64 4c 02 00 65 0a 64 4d  64 4e 64 4f ab 03 00 00  |dL..e.dMdNdO....|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.8K 2025-06-01 01:28:12.371978184 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc
cca60f8c6d260134e2a71a52c487c4c587463532d97b7a2b7438443482ad2b5a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 c2 1f 00 00  |........R.5h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 a6 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 6d 06 5a 06 01 00  64 00 64 04 6c 07 6d 08  |Z.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 00 64 05  6c 09 6d 0a 5a 0a 6d 0b  |Z...d.d.l.m.Z.m.|
00000070  5a 0b 01 00 64 00 64 06  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 01 00 64 00 64 07  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 08 6c 11 6d 12  5a 12 01 00 64 00 64 09  |d.d.l.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 01 00  02 00 65 12 65 15 ab 01  |l.m.Z.....e.e...|
000000b0  00 00 00 00 00 00 5a 16  02 00 47 00 64 0a 84 00  |......Z...G.d...|
000000c0  64 0b 65 08 ab 03 00 00  00 00 00 00 5a 17 79 01  |d.e.........Z.y.|
000000d0  29 0c e9 00 00 00 00 4e  29 01 da 06 56 61 6c 75  |)......N)...Valu|
000000e0  65 73 29 02 da 03 41 6e  79 da 04 4c 69 73 74 29  |es)...Any..List)|
000000f0  01 da 07 43 6f 6d 6d 61  6e 64 29 02 da 05 45 52  |...Command)...ER|
00000100  52 4f 52 da 07 53 55 43  43 45 53 53 29 02 da 0c  |ROR..SUCCESS)...|
00000110  43 6f 6d 6d 61 6e 64 45  72 72 6f 72 da 08 50 69  |CommandError..Pi|
00000120  70 45 72 72 6f 72 29 01  da 0a 66 69 6c 65 73 79  |pError)...filesy|
00000130  73 74 65 6d 29 01 da 09  67 65 74 4c 6f 67 67 65  |stem)...getLogge|
00000140  72 29 01 da 0b 66 6f 72  6d 61 74 5f 73 69 7a 65  |r)...format_size|
00000150  63 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |c...............|
00000160  00 00 00 00 00 f3 2c 01  00 00 97 00 65 00 5a 01  |......,.....e.Z.|
00000170  64 00 5a 02 64 01 5a 03  64 02 5a 04 64 03 5a 05  |d.Z.d.Z.d.Z.d.Z.|
00000180  64 17 64 06 84 04 5a 06  64 07 65 07 64 08 65 08  |d.d...Z.d.e.d.e.|
00000190  65 09 19 00 00 00 64 04  65 0a 66 06 64 09 84 04  |e.....d.e.f.d...|
000001a0  5a 0b 64 07 65 07 64 08  65 08 65 0c 19 00 00 00  |Z.d.e.d.e.e.....|
000001b0  64 04 64 05 66 06 64 0a  84 04 5a 0d 64 07 65 07  |d.d.f.d...Z.d.e.|
000001c0  64 08 65 08 65 0c 19 00  00 00 64 04 64 05 66 06  |d.e.e.....d.d.f.|
000001d0  64 0b 84 04 5a 0e 64 07  65 07 64 08 65 08 65 0c  |d...Z.d.e.d.e.e.|
000001e0  19 00 00 00 64 04 64 05  66 06 64 0c 84 04 5a 0f  |....d.d.f.d...Z.|
000001f0  64 0d 65 08 65 09 19 00  00 00 64 04 64 05 66 04  |d.e.e.....d.d.f.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.6K 2025-06-01 01:28:12.531978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc
11d840fe4871520d95018ba124f7f1253975d204f979f42c313d218f2d69b151  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 dc 08 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 b2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 00 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 6d 09 5a 09 01 00  64 00 64 06 6c 0a 6d 0b  |Z.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 00 64 07  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 6d 0f 5a 0f 01 00  64 00 64 08 6c 10 6d 11  |Z.m.Z...d.d.l.m.|
00000090  5a 11 01 00 64 00 64 09  6c 12 6d 13 5a 13 01 00  |Z...d.d.l.m.Z...|
000000a0  02 00 65 00 6a 28 00 00  00 00 00 00 00 00 00 00  |..e.j(..........|
000000b0  00 00 00 00 00 00 00 00  65 15 ab 01 00 00 00 00  |........e.......|
000000c0  00 00 5a 16 02 00 47 00  64 0a 84 00 64 0b 65 06  |..Z...G.d...d.e.|
000000d0  ab 03 00 00 00 00 00 00  5a 17 79 01 29 0c e9 00  |........Z.y.)...|
000000e0  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 01  |...N)...Values).|
000000f0  da 04 4c 69 73 74 29 01  da 07 43 6f 6d 6d 61 6e  |..List)...Comman|
00000100  64 29 02 da 05 45 52 52  4f 52 da 07 53 55 43 43  |d)...ERROR..SUCC|
00000110  45 53 53 29 01 da 17 67  65 74 5f 64 65 66 61 75  |ESS)...get_defau|
00000120  6c 74 5f 65 6e 76 69 72  6f 6e 6d 65 6e 74 29 03  |lt_environment).|
00000130  da 11 63 68 65 63 6b 5f  70 61 63 6b 61 67 65 5f  |..check_package_|
00000140  73 65 74 da 11 63 68 65  63 6b 5f 75 6e 73 75 70  |set..check_unsup|
00000150  70 6f 72 74 65 64 da 21  63 72 65 61 74 65 5f 70  |ported.!create_p|
00000160  61 63 6b 61 67 65 5f 73  65 74 5f 66 72 6f 6d 5f  |ackage_set_from_|
00000170  69 6e 73 74 61 6c 6c 65  64 29 01 da 0d 67 65 74  |installed)...get|
00000180  5f 73 75 70 70 6f 72 74  65 64 29 01 da 0c 77 72  |_supported)...wr|
00000190  69 74 65 5f 6f 75 74 70  75 74 63 00 00 00 00 00  |ite_outputc.....|
000001a0  00 00 00 00 00 00 00 06  00 00 00 00 00 00 00 f3  |................|
000001b0  32 00 00 00 97 00 65 00  5a 01 64 00 5a 02 64 01  |2.....e.Z.d.Z.d.|
000001c0  5a 03 64 02 5a 04 64 03  5a 05 64 04 65 06 64 05  |Z.d.Z.d.Z.d.e.d.|
000001d0  65 07 65 08 19 00 00 00  64 06 65 09 66 06 64 07  |e.e.....d.e.f.d.|
000001e0  84 04 5a 0a 79 08 29 09  da 0c 43 68 65 63 6b 43  |..Z.y.)...CheckC|
000001f0  6f 6d 6d 61 6e 64 7a 37  56 65 72 69 66 79 20 69  |ommandz7Verify i|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.4K 2025-06-01 01:28:12.695978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc
80bd6437d300a37c698d8207950ca1ce593407857701f16fef521b2563f4abf0  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ca 11 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 78 00  00 00 97 00 64 00 64 01  |......x.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 05 6c 08 6d 09  5a 09 01 00 64 00 64 06  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 01 00  64 07 5a 0c 64 08 64 09  |l.m.Z...d.Z.d.d.|
00000080  64 0a 64 0b 64 0c 9c 04  5a 0d 02 00 47 00 64 0d  |d.d.d...Z...G.d.|
00000090  84 00 64 0e 65 07 ab 03  00 00 00 00 00 00 5a 0e  |..d.e.........Z.|
000000a0  79 01 29 0f e9 00 00 00  00 4e 29 01 da 06 56 61  |y.)......N)...Va|
000000b0  6c 75 65 73 29 01 da 04  4c 69 73 74 29 01 da 07  |lues)...List)...|
000000c0  43 6f 6d 6d 61 6e 64 29  01 da 07 53 55 43 43 45  |Command)...SUCCE|
000000d0  53 53 29 01 da 08 67 65  74 5f 70 72 6f 67 7a 44  |SS)...get_progzD|
000000e0  0a 23 20 70 69 70 20 7b  73 68 65 6c 6c 7d 20 63  |.# pip {shell} c|
000000f0  6f 6d 70 6c 65 74 69 6f  6e 20 73 74 61 72 74 7b  |ompletion start{|
00000100  73 63 72 69 70 74 7d 23  20 70 69 70 20 7b 73 68  |script}# pip {sh|
00000110  65 6c 6c 7d 20 63 6f 6d  70 6c 65 74 69 6f 6e 20  |ell} completion |
00000120  65 6e 64 0a 61 1e 01 00  00 0a 20 20 20 20 20 20  |end.a.....      |
00000130  20 20 5f 70 69 70 5f 63  6f 6d 70 6c 65 74 69 6f  |  _pip_completio|
00000140  6e 28 29 0a 20 20 20 20  20 20 20 20 7b 7b 0a 20  |n().        {{. |
00000150  20 20 20 20 20 20 20 20  20 20 20 43 4f 4d 50 52  |           COMPR|
00000160  45 50 4c 59 3d 28 20 24  28 20 43 4f 4d 50 5f 57  |EPLY=( $( COMP_W|
00000170  4f 52 44 53 3d 22 24 7b  7b 43 4f 4d 50 5f 57 4f  |ORDS="${{COMP_WO|
00000180  52 44 53 5b 2a 5d 7d 7d  22 20 5c 0a 20 20 20 20  |RDS[*]}}" \.    |
00000190  20 20 20 20 20 20 20 20  20 20 20 20 20 20 20 20  |                |
000001a0  20 20 20 20 20 20 20 43  4f 4d 50 5f 43 57 4f 52  |       COMP_CWOR|
000001b0  44 3d 24 43 4f 4d 50 5f  43 57 4f 52 44 20 5c 0a  |D=$COMP_CWORD \.|
000001c0  20 20 20 20 20 20 20 20  20 20 20 20 20 20 20 20  |                |
000001d0  20 20 20 20 20 20 20 20  20 20 20 50 49 50 5f 41  |           PIP_A|
000001e0  55 54 4f 5f 43 4f 4d 50  4c 45 54 45 3d 31 20 24  |UTO_COMPLETE=1 $|
000001f0  31 20 32 3e 2f 64 65 76  2f 6e 75 6c 6c 20 29 20  |1 2>/dev/null ) |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 13K 2025-06-01 01:28:12.855978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc
bf767f58d9c2913cd74d682e6d61d83b382f5094d09ead7319683078e51ed566  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 26 26 00 00  |.........x3h&&..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 02  6c 03 6d 04 5a 04 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 00 64 03 6c 05 6d 06  5a 06 6d 07 5a 07 6d 08  |d.d.l.m.Z.m.Z.m.|
00000060  5a 08 01 00 64 00 64 04  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 00 64 05 6c 0b 6d 0c  5a 0c 6d 0d 5a 0d 01 00  |d.d.l.m.Z.m.Z...|
00000080  64 00 64 06 6c 0e 6d 0f  5a 0f 6d 10 5a 10 6d 11  |d.d.l.m.Z.m.Z.m.|
00000090  5a 11 6d 12 5a 12 01 00  64 00 64 07 6c 13 6d 14  |Z.m.Z...d.d.l.m.|
000000a0  5a 14 01 00 64 00 64 08  6c 15 6d 16 5a 16 01 00  |Z...d.d.l.m.Z...|
000000b0  64 00 64 09 6c 17 6d 18  5a 18 6d 19 5a 19 01 00  |d.d.l.m.Z.m.Z...|
000000c0  02 00 65 00 6a 34 00 00  00 00 00 00 00 00 00 00  |..e.j4..........|
000000d0  00 00 00 00 00 00 00 00  65 1b ab 01 00 00 00 00  |........e.......|
000000e0  00 00 5a 1c 02 00 47 00  64 0a 84 00 64 0b 65 0a  |..Z...G.d...d.e.|
000000f0  ab 03 00 00 00 00 00 00  5a 1d 79 01 29 0c e9 00  |........Z.y.)...|
00000100  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 03  |...N)...Values).|
00000110  da 03 41 6e 79 da 04 4c  69 73 74 da 08 4f 70 74  |..Any..List..Opt|
00000120  69 6f 6e 61 6c 29 01 da  07 43 6f 6d 6d 61 6e 64  |ional)...Command|
00000130  29 02 da 05 45 52 52 4f  52 da 07 53 55 43 43 45  |)...ERROR..SUCCE|
00000140  53 53 29 04 da 0d 43 6f  6e 66 69 67 75 72 61 74  |SS)...Configurat|
00000150  69 6f 6e da 04 4b 69 6e  64 da 17 67 65 74 5f 63  |ion..Kind..get_c|
00000160  6f 6e 66 69 67 75 72 61  74 69 6f 6e 5f 66 69 6c  |onfiguration_fil|
00000170  65 73 da 05 6b 69 6e 64  73 29 01 da 08 50 69 70  |es..kinds)...Pip|
00000180  45 72 72 6f 72 29 01 da  0a 69 6e 64 65 6e 74 5f  |Error)...indent_|
00000190  6c 6f 67 29 02 da 08 67  65 74 5f 70 72 6f 67 da  |log)...get_prog.|
000001a0  0c 77 72 69 74 65 5f 6f  75 74 70 75 74 63 00 00  |.write_outputc..|
000001b0  00 00 00 00 00 00 00 00  00 00 08 00 00 00 00 00  |................|
000001c0  00 00 f3 3e 01 00 00 97  00 65 00 5a 01 64 00 5a  |...>.....e.Z.d.Z|
000001d0  02 64 01 5a 03 64 02 5a  04 64 03 5a 05 64 1a 64  |.d.Z.d.Z.d.Z.d.d|
000001e0  06 84 04 5a 06 64 07 65  07 64 08 65 08 65 09 19  |...Z.d.e.d.e.e..|
000001f0  00 00 00 64 04 65 0a 66  06 64 09 84 04 5a 0b 64  |...d.e.f.d...Z.d|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.9K 2025-06-01 01:28:13.015978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc
cc0f1a0c474ace5b1f8a651ea94edc88bd81b334be34245307a41a5a571ade6c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 8d 1a 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 ba 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 6d 05 5a 05 01 00  64 00 64 03 6c 06 6d 07  |l.m.Z...d.d.l.m.|
00000060  5a 07 01 00 64 00 64 04  6c 08 6d 09 5a 09 6d 0a  |Z...d.d.l.m.Z.m.|
00000070  5a 0a 6d 0b 5a 0b 6d 0c  5a 0c 01 00 64 00 64 01  |Z.m.Z.m.Z...d.d.|
00000080  6c 0d 5a 0e 64 00 64 05  6c 0f 6d 10 5a 10 01 00  |l.Z.d.d.l.m.Z...|
00000090  64 00 64 06 6c 11 6d 12  5a 13 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000a0  6c 14 6d 15 5a 15 01 00  64 00 64 08 6c 16 6d 17  |l.m.Z...d.d.l.m.|
000000b0  5a 17 01 00 64 00 64 09  6c 18 6d 19 5a 19 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 0a 6c 1a 6d 1b  5a 1b 01 00 64 00 64 0b  |d.d.l.m.Z...d.d.|
000000d0  6c 1c 6d 1d 5a 1d 01 00  64 00 64 0c 6c 1e 6d 1f  |l.m.Z...d.d.l.m.|
000000e0  5a 1f 01 00 64 00 64 0d  6c 20 6d 21 5a 21 01 00  |Z...d.d.l m!Z!..|
000000f0  64 00 64 0e 6c 22 6d 23  5a 23 01 00 64 00 64 0f  |d.d.l"m#Z#..d.d.|
00000100  6c 24 6d 25 5a 25 01 00  02 00 65 01 6a 4c 00 00  |l$m%Z%....e.jL..|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000120  65 27 ab 01 00 00 00 00  00 00 5a 28 64 10 65 29  |e'........Z(d.e)|
00000130  64 11 65 09 64 12 64 01  66 06 64 13 84 04 5a 2a  |d.e.d.d.f.d...Z*|
00000140  64 22 64 14 84 04 5a 2b  64 12 65 0a 65 29 65 29  |d"d...Z+d.e.e)e)|
00000150  66 02 19 00 00 00 66 02  64 15 84 04 5a 2c 64 16  |f.....f.d...Z,d.|
00000160  65 29 64 12 65 0c 65 07  19 00 00 00 66 04 64 17  |e)d.e.e.....f.d.|
00000170  84 04 5a 2d 64 16 65 29  64 12 65 0c 65 29 19 00  |..Z-d.e)d.e.e)..|
00000180  00 00 66 04 64 18 84 04  5a 2e 64 19 65 0a 65 29  |..f.d...Z.d.e.e)|
00000190  65 29 66 02 19 00 00 00  64 12 64 01 66 04 64 1a  |e)f.....d.d.f.d.|
000001a0  84 04 5a 2f 64 22 64 1b  84 04 5a 30 64 1c 65 05  |..Z/d"d...Z0d.e.|
000001b0  64 12 64 01 66 04 64 1d  84 04 5a 31 64 1e 65 1d  |d.d.f.d...Z1d.e.|
000001c0  64 12 65 29 66 04 64 1f  84 04 5a 32 02 00 47 00  |d.e)f.d...Z2..G.|
000001d0  64 20 84 00 64 21 65 17  ab 03 00 00 00 00 00 00  |d ..d!e.........|
000001e0  5a 33 79 01 29 23 e9 00  00 00 00 4e 29 01 da 06  |Z3y.)#.....N)...|
000001f0  56 61 6c 75 65 73 29 01  da 0a 4d 6f 64 75 6c 65  |Values)...Module|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.4K 2025-06-01 01:28:13.175978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc
0ba9bdc36fcfdd7113b76d4838d523f774c4db7cba9a170e72896fe4aa56ee20  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 99 14 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 05 6c 08 6d 09  5a 09 01 00 64 00 64 06  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 6d 0c  5a 0c 01 00 64 00 64 07  |l.m.Z.m.Z...d.d.|
00000080  6c 0d 6d 0e 5a 0e 01 00  64 00 64 08 6c 0f 6d 10  |l.m.Z...d.d.l.m.|
00000090  5a 10 01 00 64 00 64 09  6c 11 6d 12 5a 12 01 00  |Z...d.d.l.m.Z...|
000000a0  64 00 64 0a 6c 13 6d 14  5a 14 6d 15 5a 15 6d 16  |d.d.l.m.Z.m.Z.m.|
000000b0  5a 16 01 00 64 00 64 0b  6c 17 6d 18 5a 18 01 00  |Z...d.d.l.m.Z...|
000000c0  02 00 65 00 6a 32 00 00  00 00 00 00 00 00 00 00  |..e.j2..........|
000000d0  00 00 00 00 00 00 00 00  65 1a ab 01 00 00 00 00  |........e.......|
000000e0  00 00 5a 1b 02 00 47 00  64 0c 84 00 64 0d 65 0b  |..Z...G.d...d.e.|
000000f0  ab 03 00 00 00 00 00 00  5a 1c 79 01 29 0e e9 00  |........Z.y.)...|
00000100  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 01  |...N)...Values).|
00000110  da 04 4c 69 73 74 29 01  da 0a 63 6d 64 6f 70 74  |..List)...cmdopt|
00000120  69 6f 6e 73 29 01 da 12  6d 61 6b 65 5f 74 61 72  |ions)...make_tar|
00000130  67 65 74 5f 70 79 74 68  6f 6e 29 02 da 12 52 65  |get_python)...Re|
00000140  71 75 69 72 65 6d 65 6e  74 43 6f 6d 6d 61 6e 64  |quirementCommand|
00000150  da 0c 77 69 74 68 5f 63  6c 65 61 6e 75 70 29 01  |..with_cleanup).|
00000160  da 07 53 55 43 43 45 53  53 29 01 da 11 67 65 74  |..SUCCESS)...get|
00000170  5f 62 75 69 6c 64 5f 74  72 61 63 6b 65 72 29 01  |_build_tracker).|
00000180  da 1d 63 68 65 63 6b 5f  6c 65 67 61 63 79 5f 73  |..check_legacy_s|
00000190  65 74 75 70 5f 70 79 5f  6f 70 74 69 6f 6e 73 29  |etup_py_options)|
000001a0  03 da 0a 65 6e 73 75 72  65 5f 64 69 72 da 0e 6e  |...ensure_dir..n|
000001b0  6f 72 6d 61 6c 69 7a 65  5f 70 61 74 68 da 0c 77  |ormalize_path..w|
000001c0  72 69 74 65 5f 6f 75 74  70 75 74 29 01 da 0d 54  |rite_output)...T|
000001d0  65 6d 70 44 69 72 65 63  74 6f 72 79 63 00 00 00  |empDirectoryc...|
000001e0  00 00 00 00 00 00 00 00  00 07 00 00 00 00 00 00  |................|
000001f0  00 f3 40 00 00 00 97 00  65 00 5a 01 64 00 5a 02  |..@.....e.Z.d.Z.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.3K 2025-06-01 01:28:13.335978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc
cdfbff93c88dbb6fca42f82b310cb8ae746e3f7ff16e4346007ff528ccdc2482  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 48 0c 00 00  |.........x3hH...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 98 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 6d 05 5a 05 01 00  |d.d.l.m.Z.m.Z...|
00000050  64 00 64 04 6c 06 6d 07  5a 07 01 00 64 00 64 05  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 00 64 06 6c 0a 6d 0b  |l.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 00 64 07  6c 0c 6d 0d 5a 0d 01 00  |Z...d.d.l.m.Z...|
00000080  64 00 64 08 6c 0e 6d 0f  5a 0f 01 00 64 09 65 10  |d.d.l.m.Z...d.e.|
00000090  66 02 64 0a 84 04 5a 11  64 09 65 04 65 12 19 00  |f.d...Z.d.e.e...|
000000a0  00 00 66 02 64 0b 84 04  5a 13 02 00 47 00 64 0c  |..f.d...Z...G.d.|
000000b0  84 00 64 0d 65 09 ab 03  00 00 00 00 00 00 5a 14  |..d.e.........Z.|
000000c0  79 01 29 0e e9 00 00 00  00 4e 29 01 da 06 56 61  |y.)......N)...Va|
000000d0  6c 75 65 73 29 02 da 0b  41 62 73 74 72 61 63 74  |lues)...Abstract|
000000e0  53 65 74 da 04 4c 69 73  74 29 01 da 0a 63 6d 64  |Set..List)...cmd|
000000f0  6f 70 74 69 6f 6e 73 29  01 da 07 43 6f 6d 6d 61  |options)...Comma|
00000100  6e 64 29 01 da 07 53 55  43 43 45 53 53 29 01 da  |nd)...SUCCESS)..|
00000110  06 66 72 65 65 7a 65 29  01 da 0b 73 74 64 6c 69  |.freeze)...stdli|
00000120  62 5f 70 6b 67 73 da 06  72 65 74 75 72 6e 63 00  |b_pkgs..returnc.|
00000130  00 00 00 00 00 00 00 00  00 00 00 02 00 00 00 03  |................|
00000140  00 00 00 f3 28 00 00 00  97 00 74 00 00 00 00 00  |....(.....t.....|
00000150  00 00 00 00 6a 02 00 00  00 00 00 00 00 00 00 00  |....j...........|
00000160  00 00 00 00 00 00 00 00  64 01 6b 02 00 00 53 00  |........d.k...S.|
00000170  29 02 4e 29 02 e9 03 00  00 00 e9 0c 00 00 00 29  |).N)...........)|
00000180  02 da 03 73 79 73 da 0c  76 65 72 73 69 6f 6e 5f  |...sys..version_|
00000190  69 6e 66 6f a9 00 f3 00  00 00 00 fa 7f 2f 64 61  |info........./da|
000001a0  74 61 2f 64 61 74 61 2f  63 6f 6d 2e 74 65 72 6d  |ta/data/com.term|
000001b0  75 78 2f 66 69 6c 65 73  2f 68 6f 6d 65 2f 52 41  |ux/files/home/RA|
000001c0  46 41 45 4c 49 41 2f 48  43 50 4d 2f 43 4f 52 45  |FAELIA/HCPM/CORE|
000001d0  2f 76 65 6e 76 5f 72 61  66 61 65 6c 69 61 2f 6c  |/venv_rafaelia/l|
000001e0  69 62 2f 70 79 74 68 6f  6e 33 2e 31 32 2f 73 69  |ib/python3.12/si|
000001f0  74 65 2d 70 61 63 6b 61  67 65 73 2f 70 69 70 2f  |te-packages/pip/|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/hash.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.0K 2025-06-01 01:28:13.491978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/hash.cpython-312.pyc
1591c4dc8065d961d207ea8dfc701267c5602fbbec04f5acb081602f618fdaca  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/hash.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 a7 06 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 be 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 02  6c 03 6d 04 5a 04 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 00 64 03 6c 05 6d 06  5a 06 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000060  6c 07 6d 08 5a 08 01 00  64 00 64 05 6c 09 6d 0a  |l.m.Z...d.d.l.m.|
00000070  5a 0a 6d 0b 5a 0b 01 00  64 00 64 06 6c 0c 6d 0d  |Z.m.Z...d.d.l.m.|
00000080  5a 0d 6d 0e 5a 0e 01 00  64 00 64 07 6c 0f 6d 10  |Z.m.Z...d.d.l.m.|
00000090  5a 10 6d 11 5a 11 01 00  02 00 65 01 6a 24 00 00  |Z.m.Z.....e.j$..|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  65 13 ab 01 00 00 00 00  00 00 5a 14 02 00 47 00  |e.........Z...G.|
000000c0  64 08 84 00 64 09 65 08  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000d0  5a 15 64 0a 65 16 64 0b  65 16 64 0c 65 16 66 06  |Z.d.e.d.e.d.e.f.|
000000e0  64 0d 84 04 5a 17 79 01  29 0e e9 00 00 00 00 4e  |d...Z.y.)......N|
000000f0  29 01 da 06 56 61 6c 75  65 73 29 01 da 04 4c 69  |)...Values)...Li|
00000100  73 74 29 01 da 07 43 6f  6d 6d 61 6e 64 29 02 da  |st)...Command)..|
00000110  05 45 52 52 4f 52 da 07  53 55 43 43 45 53 53 29  |.ERROR..SUCCESS)|
00000120  02 da 0d 46 41 56 4f 52  49 54 45 5f 48 41 53 48  |...FAVORITE_HASH|
00000130  da 0d 53 54 52 4f 4e 47  5f 48 41 53 48 45 53 29  |..STRONG_HASHES)|
00000140  02 da 0b 72 65 61 64 5f  63 68 75 6e 6b 73 da 0c  |...read_chunks..|
00000150  77 72 69 74 65 5f 6f 75  74 70 75 74 63 00 00 00  |write_outputc...|
00000160  00 00 00 00 00 00 00 00  00 06 00 00 00 00 00 00  |................|
00000170  00 f3 3a 00 00 00 97 00  65 00 5a 01 64 00 5a 02  |..:.....e.Z.d.Z.|
00000180  64 01 5a 03 64 02 5a 04  64 03 5a 05 64 0a 64 06  |d.Z.d.Z.d.Z.d.d.|
00000190  84 04 5a 06 64 07 65 07  64 08 65 08 65 09 19 00  |..Z.d.e.d.e.e...|
000001a0  00 00 64 04 65 0a 66 06  64 09 84 04 5a 0b 79 05  |..d.e.f.d...Z.y.|
000001b0  29 0b da 0b 48 61 73 68  43 6f 6d 6d 61 6e 64 7a  |)...HashCommandz|
000001c0  8d 0a 20 20 20 20 43 6f  6d 70 75 74 65 20 61 20  |..    Compute a |
000001d0  68 61 73 68 20 6f 66 20  61 20 6c 6f 63 61 6c 20  |hash of a local |
000001e0  70 61 63 6b 61 67 65 20  61 72 63 68 69 76 65 2e  |package archive.|
000001f0  0a 0a 20 20 20 20 54 68  65 73 65 20 63 61 6e 20  |..    These can |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/hash.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/help.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.7K 2025-06-01 01:28:13.651978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/help.cpython-312.pyc
d9b2887000d2e97de60abc3f9b43842840a7558224f5a04552fe352c37da569b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/help.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 6c 04 00 00  |.........x3hl...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 56 00  00 00 97 00 64 00 64 01  |......V.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 6d 03  |l.m.Z...d.d.l.m.|
00000040  5a 03 01 00 64 00 64 03  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 00 64 04 6c 06 6d 07  5a 07 01 00 64 00 64 05  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  02 00 47 00 64 06 84 00  |l.m.Z.....G.d...|
00000070  64 07 65 05 ab 03 00 00  00 00 00 00 5a 0a 79 08  |d.e.........Z.y.|
00000080  29 09 e9 00 00 00 00 29  01 da 06 56 61 6c 75 65  |)......)...Value|
00000090  73 29 01 da 04 4c 69 73  74 29 01 da 07 43 6f 6d  |s)...List)...Com|
000000a0  6d 61 6e 64 29 01 da 07  53 55 43 43 45 53 53 29  |mand)...SUCCESS)|
000000b0  01 da 0c 43 6f 6d 6d 61  6e 64 45 72 72 6f 72 63  |...CommandErrorc|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 06 00 00 00  |................|
000000d0  00 00 00 00 f3 32 00 00  00 97 00 65 00 5a 01 64  |.....2.....e.Z.d|
000000e0  00 5a 02 64 01 5a 03 64  02 5a 04 64 03 5a 05 64  |.Z.d.Z.d.Z.d.Z.d|
000000f0  04 65 06 64 05 65 07 65  08 19 00 00 00 64 06 65  |.e.d.e.e.....d.e|
00000100  09 66 06 64 07 84 04 5a  0a 79 08 29 09 da 0b 48  |.f.d...Z.y.)...H|
00000110  65 6c 70 43 6f 6d 6d 61  6e 64 7a 16 53 68 6f 77  |elpCommandz.Show|
00000120  20 68 65 6c 70 20 66 6f  72 20 63 6f 6d 6d 61 6e  | help for comman|
00000130  64 73 7a 16 0a 20 20 20  20 20 20 25 70 72 6f 67  |dsz..      %prog|
00000140  20 3c 63 6f 6d 6d 61 6e  64 3e 54 da 07 6f 70 74  | <command>T..opt|
00000150  69 6f 6e 73 da 04 61 72  67 73 da 06 72 65 74 75  |ions..args..retu|
00000160  72 6e 63 03 00 00 00 00  00 00 00 00 00 00 00 05  |rnc.............|
00000170  00 00 00 03 00 00 00 f3  24 01 00 00 97 00 64 01  |........$.....d.|
00000180  64 02 6c 00 6d 01 7d 03  6d 02 7d 04 6d 03 7d 05  |d.l.m.}.m.}.m.}.|
00000190  01 00 09 00 7c 02 64 01  19 00 00 00 7d 06 7c 06  |....|.d.....}.|.|
000001a0  7c 03 76 01 72 40 02 00  7c 05 7c 06 ab 01 00 00  ||.v.r@..|.|.....|
000001b0  00 00 00 00 7d 07 64 03  7c 06 9b 00 64 04 9d 03  |....}.d.|...d...|
000001c0  67 01 7d 08 7c 07 72 15  7c 08 6a 0d 00 00 00 00  |g.}.|.r.|.j.....|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 05  |..............d.|
000001e0  7c 07 9b 00 64 04 9d 03  ab 01 00 00 00 00 00 00  ||...d...........|
000001f0  01 00 74 0f 00 00 00 00  00 00 00 00 64 06 6a 11  |..t.........d.j.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/help.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/index.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.9K 2025-06-01 01:28:13.807978183 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/index.cpython-312.pyc
95feae2ab7931c8c1d4dd140eb8679a3f7a1b68ba559dd848be8fcb6a44713b5  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/index.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 cc 13 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 12 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 6d 06 5a 06 6d 07  5a 07 6d 08 5a 08 01 00  |Z.m.Z.m.Z.m.Z...|
00000060  64 00 64 04 6c 09 6d 0a  5a 0a 01 00 64 00 64 05  |d.d.l.m.Z...d.d.|
00000070  6c 0b 6d 0c 5a 0c 01 00  64 00 64 06 6c 0d 6d 0e  |l.m.Z...d.d.l.m.|
00000080  5a 0e 01 00 64 00 64 07  6c 0f 6d 10 5a 10 6d 11  |Z...d.d.l.m.Z.m.|
00000090  5a 11 01 00 64 00 64 08  6c 12 6d 13 5a 13 6d 14  |Z...d.d.l.m.Z.m.|
000000a0  5a 14 01 00 64 00 64 09  6c 15 6d 16 5a 16 6d 17  |Z...d.d.l.m.Z.m.|
000000b0  5a 17 6d 18 5a 18 01 00  64 00 64 0a 6c 19 6d 1a  |Z.m.Z...d.d.l.m.|
000000c0  5a 1a 01 00 64 00 64 0b  6c 1b 6d 1c 5a 1c 01 00  |Z...d.d.l.m.Z...|
000000d0  64 00 64 0c 6c 1d 6d 1e  5a 1e 01 00 64 00 64 0d  |d.d.l.m.Z...d.d.|
000000e0  6c 1f 6d 20 5a 20 01 00  64 00 64 0e 6c 21 6d 22  |l.m Z ..d.d.l!m"|
000000f0  5a 22 01 00 64 00 64 0f  6c 23 6d 24 5a 24 01 00  |Z"..d.d.l#m$Z$..|
00000100  02 00 65 01 6a 4a 00 00  00 00 00 00 00 00 00 00  |..e.jJ..........|
00000110  00 00 00 00 00 00 00 00  65 26 ab 01 00 00 00 00  |........e&......|
00000120  00 00 5a 27 02 00 47 00  64 10 84 00 64 11 65 0e  |..Z'..G.d...d.e.|
00000130  ab 03 00 00 00 00 00 00  5a 28 79 01 29 12 e9 00  |........Z(y.)...|
00000140  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 04  |...N)...Values).|
00000150  da 03 41 6e 79 da 08 49  74 65 72 61 62 6c 65 da  |..Any..Iterable.|
00000160  04 4c 69 73 74 da 08 4f  70 74 69 6f 6e 61 6c 29  |.List..Optional)|
00000170  01 da 07 56 65 72 73 69  6f 6e 29 01 da 0a 63 6d  |...Version)...cm|
00000180  64 6f 70 74 69 6f 6e 73  29 01 da 11 49 6e 64 65  |doptions)...Inde|
00000190  78 47 72 6f 75 70 43 6f  6d 6d 61 6e 64 29 02 da  |xGroupCommand)..|
000001a0  05 45 52 52 4f 52 da 07  53 55 43 43 45 53 53 29  |.ERROR..SUCCESS)|
000001b0  02 da 1a 67 65 74 5f 69  6e 73 74 61 6c 6c 65 64  |...get_installed|
000001c0  5f 64 69 73 74 72 69 62  75 74 69 6f 6e da 1c 70  |_distribution..p|
000001d0  72 69 6e 74 5f 64 69 73  74 5f 69 6e 73 74 61 6c  |rint_dist_instal|
000001e0  6c 61 74 69 6f 6e 5f 69  6e 66 6f 29 03 da 0c 43  |lation_info)...C|
000001f0  6f 6d 6d 61 6e 64 45 72  72 6f 72 da 14 44 69 73  |ommandError..Dis|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/index.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/inspect.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.0K 2025-06-01 01:28:13.967978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/inspect.cpython-312.pyc
d6567d6fdd87de1f95f3d832854293fbbf23b993472139438da05aad04fc64b2  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/inspect.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 75 0c 00 00  |.........x3hu...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d6 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 6d 05 5a 05 6d 06  |d.d.l.m.Z.m.Z.m.|
00000050  5a 06 01 00 64 00 64 04  6c 07 6d 08 5a 08 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 05 6c 09 6d 0a  5a 0a 01 00 64 00 64 06  |d.d.l.m.Z...d.d.|
00000070  6c 0b 6d 0c 5a 0c 01 00  64 00 64 07 6c 0d 6d 0e  |l.m.Z...d.d.l.m.|
00000080  5a 0e 01 00 64 00 64 08  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 09 6c 11 6d 12  5a 12 01 00 64 00 64 0a  |d.d.l.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 6d 15  5a 15 01 00 64 00 64 0b  |l.m.Z.m.Z...d.d.|
000000b0  6c 16 6d 17 5a 17 01 00  64 00 64 0c 6c 18 6d 19  |l.m.Z...d.d.l.m.|
000000c0  5a 19 01 00 02 00 65 00  6a 34 00 00 00 00 00 00  |Z.....e.j4......|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 65 1b ab 01  |............e...|
000000e0  00 00 00 00 00 00 5a 1c  02 00 47 00 64 0d 84 00  |......Z...G.d...|
000000f0  64 0e 65 10 ab 03 00 00  00 00 00 00 5a 1d 79 01  |d.e.........Z.y.|
00000100  29 0f e9 00 00 00 00 4e  29 01 da 06 56 61 6c 75  |)......N)...Valu|
00000110  65 73 29 03 da 03 41 6e  79 da 04 44 69 63 74 da  |es)...Any..Dict.|
00000120  04 4c 69 73 74 29 01 da  13 64 65 66 61 75 6c 74  |.List)...default|
00000130  5f 65 6e 76 69 72 6f 6e  6d 65 6e 74 29 01 da 0a  |_environment)...|
00000140  70 72 69 6e 74 5f 6a 73  6f 6e 29 01 da 0b 5f 5f  |print_json)...__|
00000150  76 65 72 73 69 6f 6e 5f  5f 29 01 da 0a 63 6d 64  |version__)...cmd|
00000160  6f 70 74 69 6f 6e 73 29  01 da 07 43 6f 6d 6d 61  |options)...Comma|
00000170  6e 64 29 01 da 07 53 55  43 43 45 53 53 29 02 da  |nd)...SUCCESS)..|
00000180  10 42 61 73 65 44 69 73  74 72 69 62 75 74 69 6f  |.BaseDistributio|
00000190  6e da 0f 67 65 74 5f 65  6e 76 69 72 6f 6e 6d 65  |n..get_environme|
000001a0  6e 74 29 01 da 0b 73 74  64 6c 69 62 5f 70 6b 67  |nt)...stdlib_pkg|
000001b0  73 29 01 da 0b 70 61 74  68 5f 74 6f 5f 75 72 6c  |s)...path_to_url|
000001c0  63 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |c...............|
000001d0  00 00 00 00 00 f3 54 00  00 00 97 00 65 00 5a 01  |......T.....e.Z.|
000001e0  64 00 5a 02 64 01 5a 03  64 02 5a 04 64 03 5a 05  |d.Z.d.Z.d.Z.d.Z.|
000001f0  64 0c 64 06 84 04 5a 06  64 07 65 07 64 08 65 08  |d.d...Z.d.e.d.e.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/inspect.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/install.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 29K 2025-06-01 01:28:14.135978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/install.cpython-312.pyc
de8e259478ba7e4f1919bd2f25b06307553cb245d652b9a96b086f88acfb0516  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/install.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 3d 74 00 00  |.........x3h=t..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0e 00 00  |................|
00000020  00 00 00 00 00 f3 7e 02  00 00 97 00 64 00 64 01  |......~.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 6d 07 5a 07 6d 08  5a 08 01 00 64 00 64 03  |l.m.Z.m.Z...d.d.|
00000070  6c 09 6d 0a 5a 0a 6d 0b  5a 0b 01 00 64 00 64 04  |l.m.Z.m.Z...d.d.|
00000080  6c 0c 6d 0d 5a 0d 01 00  64 00 64 05 6c 0e 6d 0f  |l.m.Z...d.d.l.m.|
00000090  5a 0f 01 00 64 00 64 06  6c 10 6d 11 5a 11 01 00  |Z...d.d.l.m.Z...|
000000a0  64 00 64 01 6c 12 5a 13  64 00 64 07 6c 14 6d 15  |d.d.l.Z.d.d.l.m.|
000000b0  5a 15 01 00 64 00 64 08  6c 16 6d 17 5a 17 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 09 6c 18 6d 19  5a 19 01 00 64 00 64 0a  |d.d.l.m.Z...d.d.|
000000d0  6c 1a 6d 1b 5a 1b 6d 1c  5a 1c 01 00 64 00 64 0b  |l.m.Z.m.Z...d.d.|
000000e0  6c 1d 6d 1e 5a 1e 6d 1f  5a 1f 01 00 64 00 64 0c  |l.m.Z.m.Z...d.d.|
000000f0  6c 20 6d 21 5a 21 6d 22  5a 22 01 00 64 00 64 0d  |l m!Z!m"Z"..d.d.|
00000100  6c 23 6d 24 5a 24 01 00  64 00 64 0e 6c 25 6d 26  |l#m$Z$..d.d.l%m&|
00000110  5a 26 01 00 64 00 64 0f  6c 27 6d 28 5a 28 01 00  |Z&..d.d.l'm(Z(..|
00000120  64 00 64 10 6c 29 6d 2a  5a 2a 01 00 64 00 64 11  |d.d.l)m*Z*..d.d.|
00000130  6c 2b 6d 2c 5a 2c 6d 2d  5a 2d 01 00 64 00 64 12  |l+m,Z,m-Z-..d.d.|
00000140  6c 2e 6d 2f 5a 2f 01 00  64 00 64 13 6c 30 6d 31  |l.m/Z/..d.d.l0m1|
00000150  5a 31 6d 32 5a 32 01 00  64 00 64 14 6c 33 6d 34  |Z1m2Z2..d.d.l3m4|
00000160  5a 34 01 00 64 00 64 15  6c 35 6d 36 5a 36 01 00  |Z4..d.d.l5m6Z6..|
00000170  64 00 64 16 6c 37 6d 38  5a 38 01 00 64 00 64 17  |d.d.l7m8Z8..d.d.|
00000180  6c 39 6d 3a 5a 3a 6d 3b  5a 3b 6d 3c 5a 3c 6d 3d  |l9m:Z:m;Z;m<Z<m=|
00000190  5a 3d 6d 3e 5a 3e 6d 3f  5a 3f 01 00 64 00 64 18  |Z=m>Z>m?Z?..d.d.|
000001a0  6c 40 6d 41 5a 41 01 00  64 00 64 19 6c 42 6d 43  |l@mAZA..d.d.lBmC|
000001b0  5a 43 6d 44 5a 44 01 00  64 00 64 1a 6c 45 6d 46  |ZCmDZD..d.d.lEmF|
000001c0  5a 46 6d 47 5a 47 01 00  02 00 65 38 65 48 ab 01  |ZFmGZG....e8eH..|
000001d0  00 00 00 00 00 00 5a 49  02 00 47 00 64 1b 84 00  |......ZI..G.d...|
000001e0  64 1c 65 1b ab 03 00 00  00 00 00 00 5a 4a 09 00  |d.e.........ZJ..|
000001f0  09 00 09 00 09 00 09 00  64 2f 64 1d 65 4b 64 1e  |........d/d.eKd.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/install.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/list.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 17K 2025-06-01 01:28:14.303978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/list.cpython-312.pyc
85a755b82462364166e44ca897538d11e652d47bd93f7438492a50e452a0949d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/list.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 da 33 00 00  |.........x3h.3..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 8a 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 6d 08  |Z...d.d.l.m.Z.m.|
00000060  5a 08 6d 09 5a 09 6d 0a  5a 0a 6d 0b 5a 0b 6d 0c  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 0c 6d 0d 5a 0d 01 00  64 00 64 05 6c 0e 6d 0f  |Z.m.Z...d.d.l.m.|
00000080  5a 0f 01 00 64 00 64 06  6c 10 6d 11 5a 11 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 07 6c 12 6d 13  5a 13 01 00 64 00 64 08  |d.d.l.m.Z...d.d.|
000000a0  6c 14 6d 15 5a 15 01 00  64 00 64 09 6c 16 6d 17  |l.m.Z...d.d.l.m.|
000000b0  5a 17 01 00 64 00 64 0a  6c 18 6d 19 5a 19 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 0b 6c 1a 6d 1b  5a 1b 6d 1c 5a 1c 01 00  |d.d.l.m.Z.m.Z...|
000000d0  64 00 64 0c 6c 1d 6d 1e  5a 1e 01 00 64 00 64 0d  |d.d.l.m.Z...d.d.|
000000e0  6c 1f 6d 20 5a 20 01 00  64 00 64 0e 6c 21 6d 22  |l.m Z ..d.d.l!m"|
000000f0  5a 22 6d 23 5a 23 01 00  65 07 72 1c 64 00 64 0f  |Z"m#Z#..e.r.d.d.|
00000100  6c 24 6d 25 5a 25 01 00  64 00 64 10 6c 26 6d 27  |l$m%Z%..d.d.l&m'|
00000110  5a 27 01 00 02 00 47 00  64 11 84 00 64 12 65 1b  |Z'....G.d...d.e.|
00000120  ab 03 00 00 00 00 00 00  5a 28 65 0b 65 28 19 00  |........Z(e.e(..|
00000130  00 00 5a 29 02 00 65 01  6a 54 00 00 00 00 00 00  |..Z)..e.jT......|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 65 2b ab 01  |............e+..|
00000150  00 00 00 00 00 00 5a 2c  02 00 47 00 64 13 84 00  |......Z,..G.d...|
00000160  64 14 65 15 ab 03 00 00  00 00 00 00 5a 2d 64 15  |d.e.........Z-d.|
00000170  64 16 64 17 65 05 64 18  65 0c 65 09 65 09 65 2e  |d.d.e.d.e.e.e.e.|
00000180  19 00 00 00 19 00 00 00  65 09 65 2e 19 00 00 00  |........e.e.....|
00000190  66 02 19 00 00 00 66 06  64 19 84 04 5a 2f 64 1a  |f.....f.d...Z/d.|
000001a0  64 16 64 17 65 05 64 18  65 2e 66 06 64 1b 84 04  |d.d.e.d.e.f.d...|
000001b0  5a 30 79 01 29 1c e9 00  00 00 00 4e 29 01 da 06  |Z0y.)......N)...|
000001c0  50 61 72 73 65 72 29 01  da 06 56 61 6c 75 65 73  |Parser)...Values|
000001d0  29 07 da 0d 54 59 50 45  5f 43 48 45 43 4b 49 4e  |)...TYPE_CHECKIN|
000001e0  47 da 09 47 65 6e 65 72  61 74 6f 72 da 04 4c 69  |G..Generator..Li|
000001f0  73 74 da 08 4f 70 74 69  6f 6e 61 6c da 08 53 65  |st..Optional..Se|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/list.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/lock.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.9K 2025-06-01 01:28:14.459978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/lock.cpython-312.pyc
dbbc998b9c7f3acda40e7418f7838ebaa8ab105bce9f96b3fb7daed08b6950f8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/lock.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 35 17 00 00  |.........x3h5...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d6 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 00 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 00 64 06  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 00 64 07 6c 0b 6d 0c  5a 0c 6d 0d 5a 0d 01 00  |d.d.l.m.Z.m.Z...|
00000080  64 00 64 08 6c 0e 6d 0f  5a 0f 01 00 64 00 64 09  |d.d.l.m.Z...d.d.|
00000090  6c 10 6d 11 5a 11 6d 12  5a 12 01 00 64 00 64 0a  |l.m.Z.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 01 00  64 00 64 0b 6c 15 6d 16  |l.m.Z...d.d.l.m.|
000000b0  5a 16 01 00 64 00 64 0c  6c 17 6d 18 5a 18 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 0d 6c 19 6d 1a  5a 1a 01 00 64 00 64 0e  |d.d.l.m.Z...d.d.|
000000d0  6c 1b 6d 1c 5a 1c 01 00  02 00 65 18 65 1d ab 01  |l.m.Z.....e.e...|
000000e0  00 00 00 00 00 00 5a 1e  02 00 47 00 64 0f 84 00  |......Z...G.d...|
000000f0  64 10 65 0c ab 03 00 00  00 00 00 00 5a 1f 79 01  |d.e.........Z.y.|
00000100  29 11 e9 00 00 00 00 4e  29 01 da 06 56 61 6c 75  |)......N)...Valu|
00000110  65 73 29 01 da 04 50 61  74 68 29 01 da 04 4c 69  |es)...Path)...Li|
00000120  73 74 29 01 da 0a 57 68  65 65 6c 43 61 63 68 65  |st)...WheelCache|
00000130  29 01 da 0a 63 6d 64 6f  70 74 69 6f 6e 73 29 02  |)...cmdoptions).|
00000140  da 12 52 65 71 75 69 72  65 6d 65 6e 74 43 6f 6d  |..RequirementCom|
00000150  6d 61 6e 64 da 0c 77 69  74 68 5f 63 6c 65 61 6e  |mand..with_clean|
00000160  75 70 29 01 da 07 53 55  43 43 45 53 53 29 02 da  |up)...SUCCESS)..|
00000170  06 50 79 6c 6f 63 6b da  19 69 73 5f 76 61 6c 69  |.Pylock..is_vali|
00000180  64 5f 70 79 6c 6f 63 6b  5f 66 69 6c 65 5f 6e 61  |d_pylock_file_na|
00000190  6d 65 29 01 da 11 67 65  74 5f 62 75 69 6c 64 5f  |me)...get_build_|
000001a0  74 72 61 63 6b 65 72 29  01 da 1d 63 68 65 63 6b  |tracker)...check|
000001b0  5f 6c 65 67 61 63 79 5f  73 65 74 75 70 5f 70 79  |_legacy_setup_py|
000001c0  5f 6f 70 74 69 6f 6e 73  29 01 da 09 67 65 74 4c  |_options)...getL|
000001d0  6f 67 67 65 72 29 01 da  0f 67 65 74 5f 70 69 70  |ogger)...get_pip|
000001e0  5f 76 65 72 73 69 6f 6e  29 01 da 0d 54 65 6d 70  |_version)...Temp|
000001f0  44 69 72 65 63 74 6f 72  79 63 00 00 00 00 00 00  |Directoryc......|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/lock.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/search.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.7K 2025-06-01 01:28:14.619978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/search.cpython-312.pyc
9df940e3c550b06adbfe6920c2f22e33e8268e76cdba4765ea96b4d70c971a82  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/search.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 af 16 00 00  |........R.5h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 d2 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 05 64 00 64 02  6c 06 6d 07 5a 07 01 00  |l.Z.d.d.l.m.Z...|
00000060  64 00 64 03 6c 08 6d 09  5a 09 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 6d 0c  5a 0c 6d 0d 5a 0d 6d 0e  |l.m.Z.m.Z.m.Z.m.|
00000080  5a 0e 01 00 64 00 64 05  6c 0f 6d 10 5a 11 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 06 6c 12 6d 13  5a 13 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000a0  6c 14 6d 15 5a 15 01 00  64 00 64 08 6c 16 6d 17  |l.m.Z...d.d.l.m.|
000000b0  5a 17 6d 18 5a 18 01 00  64 00 64 09 6c 19 6d 1a  |Z.m.Z...d.d.l.m.|
000000c0  5a 1a 01 00 64 00 64 0a  6c 1b 6d 1c 5a 1c 01 00  |Z...d.d.l.m.Z...|
000000d0  64 00 64 0b 6c 1d 6d 1e  5a 1e 01 00 64 00 64 0c  |d.d.l.m.Z...d.d.|
000000e0  6c 1f 6d 20 5a 20 01 00  64 00 64 0d 6c 21 6d 22  |l.m Z ..d.d.l!m"|
000000f0  5a 22 01 00 64 00 64 0e  6c 23 6d 24 5a 24 01 00  |Z"..d.d.l#m$Z$..|
00000100  64 00 64 0f 6c 25 6d 26  5a 26 01 00 02 00 47 00  |d.d.l%m&Z&....G.|
00000110  64 10 84 00 64 11 65 0e  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000120  5a 27 02 00 65 00 6a 50  00 00 00 00 00 00 00 00  |Z'..e.jP........|
00000130  00 00 00 00 00 00 00 00  00 00 65 29 ab 01 00 00  |..........e)....|
00000140  00 00 00 00 5a 2a 02 00  47 00 64 12 84 00 64 13  |....Z*..G.d...d.|
00000150  65 13 65 15 ab 04 00 00  00 00 00 00 5a 2b 64 14  |e.e.........Z+d.|
00000160  65 0c 65 0b 65 2c 65 2c  66 02 19 00 00 00 19 00  |e.e.e,e,f.......|
00000170  00 00 64 15 65 0c 64 11  19 00 00 00 66 04 64 16  |..d.e.d.....f.d.|
00000180  84 04 5a 2d 64 17 65 2c  64 18 65 0d 65 1e 19 00  |..Z-d.e,d.e.e...|
00000190  00 00 64 15 64 01 66 06  64 19 84 04 5a 2e 64 1a  |..d.d.f.d...Z.d.|
000001a0  65 2c 64 15 65 0d 65 1e  19 00 00 00 66 04 64 1b  |e,d.e.e.....f.d.|
000001b0  84 04 5a 2f 09 00 09 00  64 21 64 14 65 0c 64 11  |..Z/....d!d.e.d.|
000001c0  19 00 00 00 64 1c 65 0d  65 30 19 00 00 00 64 1d  |....d.e.e0....d.|
000001d0  65 0d 65 30 19 00 00 00  64 15 64 01 66 08 64 1e  |e.e0....d.d.f.d.|
000001e0  84 05 5a 31 64 1f 65 0c  65 2c 19 00 00 00 64 15  |..Z1d.e.e,....d.|
000001f0  65 2c 66 04 64 20 84 04  5a 32 79 01 29 22 e9 00  |e,f.d ..Z2y.)"..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/search.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/show.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 12K 2025-06-01 01:28:14.779978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/show.cpython-312.pyc
e7f0d0a80a891c07668690d770c28673376cd2225c6e4f06a19838d2bff32f0e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/show.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 5c 1f 00 00  |.........x3h\...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 30 01  00 00 97 00 64 00 64 01  |......0.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 6d 06 5a 06 6d 07  5a 07 6d 08 5a 08 6d 09  |Z.m.Z.m.Z.m.Z.m.|
00000060  5a 09 6d 0a 5a 0a 01 00  64 00 64 04 6c 0b 6d 0c  |Z.m.Z...d.d.l.m.|
00000070  5a 0c 01 00 64 00 64 05  6c 0d 6d 0e 5a 0e 01 00  |Z...d.d.l.m.Z...|
00000080  64 00 64 06 6c 0f 6d 10  5a 10 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
00000090  6c 11 6d 12 5a 12 6d 13  5a 13 01 00 64 00 64 08  |l.m.Z.m.Z...d.d.|
000000a0  6c 14 6d 15 5a 15 6d 16  5a 16 01 00 64 00 64 09  |l.m.Z.m.Z...d.d.|
000000b0  6c 17 6d 18 5a 18 01 00  02 00 65 00 6a 32 00 00  |l.m.Z.....e.j2..|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000d0  65 1a ab 01 00 00 00 00  00 00 5a 1b 64 0a 65 1c  |e.........Z.d.e.|
000000e0  64 0b 65 1c 66 04 64 0c  84 04 5a 1d 02 00 47 00  |d.e.f.d...Z...G.|
000000f0  64 0d 84 00 64 0e 65 10  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000100  5a 1e 02 00 47 00 64 0f  84 00 64 10 65 09 ab 03  |Z...G.d...d.e...|
00000110  00 00 00 00 00 00 5a 1f  64 11 65 08 65 1c 19 00  |......Z.d.e.e...|
00000120  00 00 64 0b 65 05 65 1f  64 01 64 01 66 03 19 00  |..d.e.e.d.d.f...|
00000130  00 00 66 04 64 12 84 04  5a 20 64 13 65 06 65 1f  |..f.d...Z d.e.e.|
00000140  19 00 00 00 64 14 65 21  64 15 65 21 64 0b 65 21  |....d.e!d.e!d.e!|
00000150  66 08 64 16 84 04 5a 22  79 01 29 17 e9 00 00 00  |f.d...Z"y.).....|
00000160  00 4e 29 01 da 06 56 61  6c 75 65 73 29 06 da 09  |.N)...Values)...|
00000170  47 65 6e 65 72 61 74 6f  72 da 08 49 74 65 72 61  |Generator..Itera|
00000180  62 6c 65 da 08 49 74 65  72 61 74 6f 72 da 04 4c  |ble..Iterator..L|
00000190  69 73 74 da 0a 4e 61 6d  65 64 54 75 70 6c 65 da  |ist..NamedTuple.|
000001a0  08 4f 70 74 69 6f 6e 61  6c 29 01 da 12 49 6e 76  |.Optional)...Inv|
000001b0  61 6c 69 64 52 65 71 75  69 72 65 6d 65 6e 74 29  |alidRequirement)|
000001c0  01 da 11 63 61 6e 6f 6e  69 63 61 6c 69 7a 65 5f  |...canonicalize_|
000001d0  6e 61 6d 65 29 01 da 07  43 6f 6d 6d 61 6e 64 29  |name)...Command)|
000001e0  02 da 05 45 52 52 4f 52  da 07 53 55 43 43 45 53  |...ERROR..SUCCES|
000001f0  53 29 02 da 10 42 61 73  65 44 69 73 74 72 69 62  |S)...BaseDistrib|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/show.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/uninstall.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.7K 2025-06-01 01:28:14.935978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/uninstall.cpython-312.pyc
17052180bfadd0eff1736d982df704ec66ea187f9615b57cfc25df4f81fef330  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/uninstall.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 34 0f 00 00  |.........x3h4...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 d8 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 00 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 00 64 06  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 00 64 07 6c 0b 6d 0c  5a 0c 01 00 64 00 64 08  |d.d.l.m.Z...d.d.|
00000080  6c 0d 6d 0e 5a 0e 01 00  64 00 64 09 6c 0f 6d 10  |l.m.Z...d.d.l.m.|
00000090  5a 10 01 00 64 00 64 0a  6c 11 6d 12 5a 12 01 00  |Z...d.d.l.m.Z...|
000000a0  64 00 64 0b 6c 13 6d 14  5a 14 6d 15 5a 15 01 00  |d.d.l.m.Z.m.Z...|
000000b0  64 00 64 0c 6c 16 6d 17  5a 17 6d 18 5a 18 6d 19  |d.d.l.m.Z.m.Z.m.|
000000c0  5a 19 01 00 02 00 65 00  6a 34 00 00 00 00 00 00  |Z.....e.j4......|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 65 1b ab 01  |............e...|
000000e0  00 00 00 00 00 00 5a 1c  02 00 47 00 64 0d 84 00  |......Z...G.d...|
000000f0  64 0e 65 0a 65 0c ab 04  00 00 00 00 00 00 5a 1d  |d.e.e.........Z.|
00000100  79 01 29 0f e9 00 00 00  00 4e 29 01 da 06 56 61  |y.)......N)...Va|
00000110  6c 75 65 73 29 01 da 04  4c 69 73 74 29 01 da 11  |lues)...List)...|
00000120  63 61 6e 6f 6e 69 63 61  6c 69 7a 65 5f 6e 61 6d  |canonicalize_nam|
00000130  65 29 01 da 0a 63 6d 64  6f 70 74 69 6f 6e 73 29  |e)...cmdoptions)|
00000140  01 da 07 43 6f 6d 6d 61  6e 64 29 01 da 13 53 65  |...Command)...Se|
00000150  73 73 69 6f 6e 43 6f 6d  6d 61 6e 64 4d 69 78 69  |ssionCommandMixi|
00000160  6e 29 01 da 07 53 55 43  43 45 53 53 29 01 da 11  |n)...SUCCESS)...|
00000170  49 6e 73 74 61 6c 6c 61  74 69 6f 6e 45 72 72 6f  |InstallationErro|
00000180  72 29 01 da 12 70 61 72  73 65 5f 72 65 71 75 69  |r)...parse_requi|
00000190  72 65 6d 65 6e 74 73 29  02 da 15 69 6e 73 74 61  |rements)...insta|
000001a0  6c 6c 5f 72 65 71 5f 66  72 6f 6d 5f 6c 69 6e 65  |ll_req_from_line|
000001b0  da 23 69 6e 73 74 61 6c  6c 5f 72 65 71 5f 66 72  |.#install_req_fr|
000001c0  6f 6d 5f 70 61 72 73 65  64 5f 72 65 71 75 69 72  |om_parsed_requir|
000001d0  65 6d 65 6e 74 29 03 da  18 63 68 65 63 6b 5f 65  |ement)...check_e|
000001e0  78 74 65 72 6e 61 6c 6c  79 5f 6d 61 6e 61 67 65  |xternally_manage|
000001f0  64 da 28 70 72 6f 74 65  63 74 5f 70 69 70 5f 66  |d.(protect_pip_f|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/uninstall.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/wheel.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 8.7K 2025-06-01 01:28:15.095978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/wheel.cpython-312.pyc
e41d4034359545e4a0e77a5d18d162c40f420bd8afba4fea17c96065f83117f8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/wheel.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 ca 18 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 f2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 02  6c 03 6d 04 5a 04 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 00 64 03 6c 05 6d 06  5a 06 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000060  6c 07 6d 08 5a 08 01 00  64 00 64 05 6c 09 6d 0a  |l.m.Z...d.d.l.m.|
00000070  5a 0a 01 00 64 00 64 06  6c 0b 6d 0c 5a 0c 6d 0d  |Z...d.d.l.m.Z.m.|
00000080  5a 0d 01 00 64 00 64 07  6c 0e 6d 0f 5a 0f 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 08 6c 10 6d 11  5a 11 01 00 64 00 64 09  |d.d.l.m.Z...d.d.|
000000a0  6c 12 6d 13 5a 13 01 00  64 00 64 0a 6c 14 6d 15  |l.m.Z...d.d.l.m.|
000000b0  5a 15 6d 16 5a 16 01 00  64 00 64 0b 6c 17 6d 18  |Z.m.Z...d.d.l.m.|
000000c0  5a 18 6d 19 5a 19 01 00  64 00 64 0c 6c 1a 6d 1b  |Z.m.Z...d.d.l.m.|
000000d0  5a 1b 01 00 64 00 64 0d  6c 1c 6d 1d 5a 1d 01 00  |Z...d.d.l.m.Z...|
000000e0  02 00 65 00 6a 3c 00 00  00 00 00 00 00 00 00 00  |..e.j<..........|
000000f0  00 00 00 00 00 00 00 00  65 1f ab 01 00 00 00 00  |........e.......|
00000100  00 00 5a 20 02 00 47 00  64 0e 84 00 64 0f 65 0c  |..Z ..G.d...d.e.|
00000110  ab 03 00 00 00 00 00 00  5a 21 79 01 29 10 e9 00  |........Z!y.)...|
00000120  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 01  |...N)...Values).|
00000130  da 04 4c 69 73 74 29 01  da 0a 57 68 65 65 6c 43  |..List)...WheelC|
00000140  61 63 68 65 29 01 da 0a  63 6d 64 6f 70 74 69 6f  |ache)...cmdoptio|
00000150  6e 73 29 02 da 12 52 65  71 75 69 72 65 6d 65 6e  |ns)...Requiremen|
00000160  74 43 6f 6d 6d 61 6e 64  da 0c 77 69 74 68 5f 63  |tCommand..with_c|
00000170  6c 65 61 6e 75 70 29 01  da 07 53 55 43 43 45 53  |leanup)...SUCCES|
00000180  53 29 01 da 0c 43 6f 6d  6d 61 6e 64 45 72 72 6f  |S)...CommandErro|
00000190  72 29 01 da 11 67 65 74  5f 62 75 69 6c 64 5f 74  |r)...get_build_t|
000001a0  72 61 63 6b 65 72 29 02  da 12 49 6e 73 74 61 6c  |racker)...Instal|
000001b0  6c 52 65 71 75 69 72 65  6d 65 6e 74 da 1d 63 68  |lRequirement..ch|
000001c0  65 63 6b 5f 6c 65 67 61  63 79 5f 73 65 74 75 70  |eck_legacy_setup|
000001d0  5f 70 79 5f 6f 70 74 69  6f 6e 73 29 02 da 0a 65  |_py_options)...e|
000001e0  6e 73 75 72 65 5f 64 69  72 da 0e 6e 6f 72 6d 61  |nsure_dir..norma|
000001f0  6c 69 7a 65 5f 70 61 74  68 29 01 da 0d 54 65 6d  |lize_path)...Tem|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/wheel.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/distributions/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 972 2025-06-01 01:28:15.247978182 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/distributions/__pycache__/__init__.cpython-312.pyc
baa2d31329a36cd3b1b440b5676b8633810588dcaa8bd8a2969bad3cb9a1c9e6  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/distributions/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 5a 03 00 00  |.........x3hZ...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 44 00  00 00 97 00 64 00 64 01  |......D.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 6d 03  |l.m.Z...d.d.l.m.|
00000040  5a 03 01 00 64 00 64 03  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 00 64 04 6c 06 6d 07  5a 07 01 00 64 05 65 07  |d.d.l.m.Z...d.e.|
00000060  64 06 65 01 66 04 64 07  84 04 5a 08 79 08 29 09  |d.e.f.d...Z.y.).|
00000070  e9 00 00 00 00 29 01 da  14 41 62 73 74 72 61 63  |.....)...Abstrac|
00000080  74 44 69 73 74 72 69 62  75 74 69 6f 6e 29 01 da  |tDistribution)..|
00000090  12 53 6f 75 72 63 65 44  69 73 74 72 69 62 75 74  |.SourceDistribut|
000000a0  69 6f 6e 29 01 da 11 57  68 65 65 6c 44 69 73 74  |ion)...WheelDist|
000000b0  72 69 62 75 74 69 6f 6e  29 01 da 12 49 6e 73 74  |ribution)...Inst|
000000c0  61 6c 6c 52 65 71 75 69  72 65 6d 65 6e 74 da 0b  |allRequirement..|
000000d0  69 6e 73 74 61 6c 6c 5f  72 65 71 da 06 72 65 74  |install_req..ret|
000000e0  75 72 6e 63 01 00 00 00  00 00 00 00 00 00 00 00  |urnc............|
000000f0  03 00 00 00 03 00 00 00  f3 74 00 00 00 97 00 7c  |.........t.....||
00000100  00 6a 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
00000110  00 00 00 00 00 72 0b 74  03 00 00 00 00 00 00 00  |.....r.t........|
00000120  00 7c 00 ab 01 00 00 00  00 00 00 53 00 7c 00 6a  |.|.........S.|.j|
00000130  04 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000140  00 00 00 72 0b 74 07 00  00 00 00 00 00 00 00 7c  |...r.t.........||
00000150  00 ab 01 00 00 00 00 00  00 53 00 74 03 00 00 00  |.........S.t....|
00000160  00 00 00 00 00 7c 00 ab  01 00 00 00 00 00 00 53  |.....|.........S|
00000170  00 29 01 7a 37 52 65 74  75 72 6e 73 20 61 20 44  |.).z7Returns a D|
00000180  69 73 74 72 69 62 75 74  69 6f 6e 20 66 6f 72 20  |istribution for |
00000190  74 68 65 20 67 69 76 65  6e 20 49 6e 73 74 61 6c  |the given Instal|
000001a0  6c 52 65 71 75 69 72 65  6d 65 6e 74 29 04 da 08  |lRequirement)...|
000001b0  65 64 69 74 61 62 6c 65  72 04 00 00 00 da 08 69  |editabler......i|
000001c0  73 5f 77 68 65 65 6c 72  05 00 00 00 29 01 72 07  |s_wheelr....).r.|
000001d0  00 00 00 73 01 00 00 00  20 fa 86 2f 64 61 74 61  |...s.... ../data|
000001e0  2f 64 61 74 61 2f 63 6f  6d 2e 74 65 72 6d 75 78  |/data/com.termux|
000001f0  2f 66 69 6c 65 73 2f 68  6f 6d 65 2f 52 41 46 41  |/files/home/RAFA|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/distributions/__pycache__/__init__.cpython-312.pyc -----