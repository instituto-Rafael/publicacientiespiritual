#!/bin/bash
# ∴ GODEX ∆ decodificador de intenção ∴ RAFAELIA

INPUT=$(cat entrada.txt | tr -d '\r')
OUTPUT="saida.txt"

echo "[GODEX] Decodificando intencionalidade..." >> "$OUTPUT"
echo "$INPUT" | rev | tr 'a-zA-Z' 'n-za-mN-ZA-M' >> "$OUTPUT"
echo "[GODEX] Resultado acima foi espelhado e cifrado (rot13 + reverso)." >> "$OUTPUT"

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/GODEX.sh -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/LACUNA.VISION.sh
-rwxrwxrwx. 1 u0_a292 u0_a292 371 2025-06-10 05:17:50.747988803 -0300 /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/LACUNA.VISION.sh
b8341acba90dcbd2dd89a15062c60709ce350ffcd0e536f13f5170a7aa164811  /data/data/com.termux/files/home/RAFAELIA/GODEX_CORE/RAFAELIA_VERBO_KERNEL_REAL/LACUNA.VISION.sh
MIME: text/x-shellscript
----- INÍCIO DO CONTEÚDO (extensão: .sh) -----