#!/usr/bin/env python3
from setuptools import setup, find_packages

setup(
    name="rafaelia_mod",
    version="0.1.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    description="Módulo cognitivo RAFAELIA simbiótico",
    author="Rafael Melo Reis",
)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/setup.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/__pycache__/setup.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 481 2025-06-01 01:34:54.719977896 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/__pycache__/setup.cpython-312.pyc
d8d20cabe696be2c3b505f90ff8884f2800a0495071cb26b521e6bbeddee3d6c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/__pycache__/setup.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d6 a7 38 68 03 01 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 42 00  00 00 97 00 64 00 64 01  |......B.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 01 00 02 00 65 01  |l.m.Z.m.Z.....e.|
00000040  64 02 64 03 02 00 65 02  64 04 ac 05 ab 01 00 00  |d.d...e.d.......|
00000050  00 00 00 00 64 06 64 04  69 01 64 07 64 08 ac 09  |....d.d.i.d.d...|
00000060  ab 06 00 00 00 00 00 00  01 00 79 0a 29 0b e9 00  |..........y.)...|
00000070  00 00 00 29 02 da 05 73  65 74 75 70 da 0d 66 69  |...)...setup..fi|
00000080  6e 64 5f 70 61 63 6b 61  67 65 73 da 0c 72 61 66  |nd_packages..raf|
00000090  61 65 6c 69 61 5f 6d 6f  64 7a 05 30 2e 31 2e 30  |aelia_modz.0.1.0|
000000a0  da 03 73 72 63 29 01 da  05 77 68 65 72 65 da 00  |..src)...where..|
000000b0  75 26 00 00 00 4d c3 b3  64 75 6c 6f 20 63 6f 67  |u&...M..dulo cog|
000000c0  6e 69 74 69 76 6f 20 52  41 46 41 45 4c 49 41 20  |nitivo RAFAELIA |
000000d0  73 69 6d 62 69 c3 b3 74  69 63 6f 7a 10 52 61 66  |simbi..ticoz.Raf|
000000e0  61 65 6c 20 4d 65 6c 6f  20 52 65 69 73 29 06 da  |ael Melo Reis)..|
000000f0  04 6e 61 6d 65 da 07 76  65 72 73 69 6f 6e da 08  |.name..version..|
00000100  70 61 63 6b 61 67 65 73  da 0b 70 61 63 6b 61 67  |packages..packag|
00000110  65 5f 64 69 72 da 0b 64  65 73 63 72 69 70 74 69  |e_dir..descripti|
00000120  6f 6e da 06 61 75 74 68  6f 72 4e 29 03 da 0a 73  |on..authorN)...s|
00000130  65 74 75 70 74 6f 6f 6c  73 72 03 00 00 00 72 04  |etuptoolsr....r.|
00000140  00 00 00 a9 00 f3 00 00  00 00 fa 4d 2f 64 61 74  |...........M/dat|
00000150  61 2f 64 61 74 61 2f 63  6f 6d 2e 74 65 72 6d 75  |a/data/com.termu|
00000160  78 2f 66 69 6c 65 73 2f  68 6f 6d 65 2f 52 41 46  |x/files/home/RAF|
00000170  41 45 4c 49 41 2f 48 43  50 4d 2f 43 4f 52 45 2f  |AELIA/HCPM/CORE/|
00000180  52 41 46 41 45 4c 49 41  2f 4e 55 43 4c 45 4f 32  |RAFAELIA/NUCLEO2|
00000190  2f 73 65 74 75 70 2e 70  79 da 08 3c 6d 6f 64 75  |/setup.py..<modu|
000001a0  6c 65 3e 72 13 00 00 00  01 00 00 00 73 2b 00 00  |le>r........s+..|
000001b0  00 f0 03 01 01 01 df 00  2b e1 00 05 d8 09 17 d8  |........+.......|
000001c0  0c 13 d9 0d 1a a0 15 d4  0d 27 d8 11 13 90 55 90  |.........'....U.|
000001d0  0b d8 10 38 d8 0b 1d f6  0d 07 01 02 72 11 00 00  |...8........r...|
000001e0  00                                                |.|
000001e1
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/NUCLEO2/__pycache__/setup.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/rafaelIA_core.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 701 2025-06-01 01:30:23.271978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/rafaelIA_core.cpython-312.pyc
addf35da367491a27b95b71ae5b1e5105ffc2ccfeb4d3c2ac50e472faa1a1b56  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/rafaelIA_core.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  72 39 33 68 11 02 00 00  |........r93h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 6a 00  00 00 97 00 64 00 64 01  |......j.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  02 00 65 03 64 03 64 04  |l.m.Z.....e.d.d.|
00000050  ab 02 00 00 00 00 00 00  01 00 02 00 65 03 64 05  |............e.d.|
00000060  64 06 ab 02 00 00 00 00  00 00 01 00 02 00 65 03  |d.............e.|
00000070  64 07 64 08 ab 02 00 00  00 00 00 00 01 00 64 09  |d.d...........d.|
00000080  84 00 5a 04 02 00 65 04  ab 00 00 00 00 00 00 00  |..Z...e.........|
00000090  01 00 79 01 29 0a e9 00  00 00 00 4e a9 01 da 06  |..y.)......N....|
000000a0  63 70 72 69 6e 74 75 24  00 00 00 5b 52 41 46 41  |cprintu$...[RAFA|
000000b0  45 4c 49 41 5d 20 4e c3  ba 63 6c 65 6f 20 43 6f  |ELIA] N..cleo Co|
000000c0  67 6e 69 74 69 76 6f 20  41 74 69 76 61 64 6f da  |gnitivo Ativado.|
000000d0  04 63 79 61 6e 75 32 00  00 00 5b 43 56 56 31 38  |.cyanu2...[CVV18|
000000e0  38 5d 20 43 75 72 61 6e  64 6f 20 65 20 45 78 65  |8] Curando e Exe|
000000f0  63 75 74 61 6e 64 6f 20  65 6d 20 54 65 6d 70 6f  |cutando em Tempo|
00000100  20 53 69 6d 62 69 c3 b3  74 69 63 6f da 05 67 72  | Simbi..tico..gr|
00000110  65 65 6e 75 21 00 00 00  5b 39 39 39 5d 20 4d 6f  |eenu!...[999] Mo|
00000120  64 6f 20 45 78 65 63 75  c3 a7 c3 a3 6f 20 54 6f  |do Execu....o To|
00000130  74 61 6c 20 41 74 69 76  6f da 03 72 65 64 63 00  |tal Ativo..redc.|
00000140  00 00 00 00 00 00 00 00  00 00 00 04 00 00 00 03  |................|
00000150  00 00 00 f3 1c 00 00 00  97 00 74 01 00 00 00 00  |..........t.....|
00000160  00 00 00 00 64 01 64 02  ab 02 00 00 00 00 00 00  |....d.d.........|
00000170  01 00 79 00 29 03 4e 75  32 00 00 00 45 78 65 63  |..y.).Nu2...Exec|
00000180  75 74 61 6e 64 6f 20 48  79 70 65 72 43 c3 a9 72  |utando HyperC..r|
00000190  65 62 72 6f 20 65 6d 20  70 61 64 72 c3 a3 6f 20  |ebro em padr..o |
000001a0  73 69 6d 62 69 c3 b3 74  69 63 6f 2e 2e 2e da 06  |simbi..tico.....|
000001b0  79 65 6c 6c 6f 77 72 03  00 00 00 a9 00 f3 00 00  |yellowr.........|
000001c0  00 00 fa 44 2f 64 61 74  61 2f 64 61 74 61 2f 63  |...D/data/data/c|
000001d0  6f 6d 2e 74 65 72 6d 75  78 2f 66 69 6c 65 73 2f  |om.termux/files/|
000001e0  68 6f 6d 65 2f 52 41 46  41 45 4c 49 41 2f 48 43  |home/RAFAELIA/HC|
000001f0  50 4d 2f 43 4f 52 45 2f  72 61 66 61 65 6c 49 41  |PM/CORE/rafaelIA|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/rafaelIA_core.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 478 2025-06-01 01:30:23.595978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc
8f9ea569c0909bb79c930029ca791fadf912f716d88936733107869db53d6ba8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  53 9b 38 68 14 01 00 00  |........S.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 44 00  00 00 97 00 64 00 64 01  |......D.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 01 00 02 00 65 01  |l.m.Z.m.Z.....e.|
00000040  64 02 64 03 64 04 64 05  02 00 65 02 64 06 ac 07  |d.d.d.d...e.d...|
00000050  ab 01 00 00 00 00 00 00  64 08 64 06 69 01 64 09  |........d.d.i.d.|
00000060  ac 0a ab 07 00 00 00 00  00 00 01 00 79 0b 29 0c  |............y.).|
00000070  e9 00 00 00 00 29 02 da  05 73 65 74 75 70 da 0d  |.....)...setup..|
00000080  66 69 6e 64 5f 70 61 63  6b 61 67 65 73 da 08 72  |find_packages..r|
00000090  61 66 61 65 6c 69 61 7a  05 30 2e 31 2e 30 75 1c  |afaeliaz.0.1.0u.|
000000a0  00 00 00 4e c3 ba 63 6c  65 6f 20 73 69 6d 62 69  |...N..cleo simbi|
000000b0  c3 b3 74 69 63 6f 20 52  41 46 41 45 4c 49 41 7a  |..tico RAFAELIAz|
000000c0  10 52 61 66 61 65 6c 20  4d 65 6c 6f 20 52 65 69  |.Rafael Melo Rei|
000000d0  73 da 03 73 72 63 29 01  da 05 77 68 65 72 65 da  |s..src)...where.|
000000e0  00 54 29 07 da 04 6e 61  6d 65 da 07 76 65 72 73  |.T)...name..vers|
000000f0  69 6f 6e da 0b 64 65 73  63 72 69 70 74 69 6f 6e  |ion..description|
00000100  da 06 61 75 74 68 6f 72  da 08 70 61 63 6b 61 67  |..author..packag|
00000110  65 73 da 0b 70 61 63 6b  61 67 65 5f 64 69 72 da  |es..package_dir.|
00000120  14 69 6e 63 6c 75 64 65  5f 70 61 63 6b 61 67 65  |.include_package|
00000130  5f 64 61 74 61 4e 29 03  da 0a 73 65 74 75 70 74  |_dataN)...setupt|
00000140  6f 6f 6c 73 72 03 00 00  00 72 04 00 00 00 a9 00  |oolsr....r......|
00000150  f3 00 00 00 00 fa 3c 2f  64 61 74 61 2f 64 61 74  |......</data/dat|
00000160  61 2f 63 6f 6d 2e 74 65  72 6d 75 78 2f 66 69 6c  |a/com.termux/fil|
00000170  65 73 2f 68 6f 6d 65 2f  52 41 46 41 45 4c 49 41  |es/home/RAFAELIA|
00000180  2f 48 43 50 4d 2f 43 4f  52 45 2f 73 65 74 75 70  |/HCPM/CORE/setup|
00000190  2e 70 79 da 08 3c 6d 6f  64 75 6c 65 3e 72 14 00  |.py..<module>r..|
000001a0  00 00 01 00 00 00 73 2e  00 00 00 f0 03 01 01 01  |......s.........|
000001b0  df 00 2b e1 00 05 d8 09  13 d8 0c 13 d8 10 2e d8  |..+.............|
000001c0  0b 1d d9 0d 1a a0 15 d4  0d 27 d8 11 13 90 55 90  |.........'....U.|
000001d0  0b d8 19 1d f6 0f 08 01  02 72 12 00 00 00        |.........r....|
000001de
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/__pycache__/setup.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HYPERTACTIC/init_hypertactic.sh
-rwxrwxrwx. 1 u0_a292 u0_a292 426 2025-06-05 12:38:05.013792323 -0300 /data/data/com.termux/files/home/RAFAELIA/HYPERTACTIC/init_hypertactic.sh
a28c0b49257067b9b45d8ffa29b602f4397aaf3d338367564649bb6e6668214c  /data/data/com.termux/files/home/RAFAELIA/HYPERTACTIC/init_hypertactic.sh
MIME: text/x-shellscript
----- INÍCIO DO CONTEÚDO (extensão: .sh) -----