#!/usr/bin/env python3
class RafaelIA:
    def __init__(self):
        self.estado = "ativo"
        self.memoria = []

    def ouvir(self, entrada):
        self.memoria.append(entrada)
        return f"Memória atualizada com: {entrada}"

    def status(self):
        return f"Estado simbiótico: {self.estado} | Memória: {len(self.memoria)} eventos"

if __name__ == "__main__":
    rafael = RafaelIA()
    print(rafael.ouvir("Início do Núcleo RAFAELIA"))
    print(rafael.status())

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/core_logic.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/core_logic.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.3K 2025-06-01 01:30:23.907978089 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/core_logic.cpython-312.pyc
6be71f49deeb6e9b4ed0279d708dbfde874a6487494462f8f74633c13eb9f675  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/core_logic.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  59 a6 38 68 d2 01 00 00  |........Y.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 8c 00  00 00 97 00 02 00 47 00  |..............G.|
00000030  64 00 84 00 64 01 ab 02  00 00 00 00 00 00 5a 00  |d...d.........Z.|
00000040  65 01 64 02 6b 28 00 00  72 35 02 00 65 00 ab 00  |e.d.k(..r5..e...|
00000050  00 00 00 00 00 00 5a 02  02 00 65 03 65 02 6a 09  |......Z...e.e.j.|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000070  00 00 64 03 ab 01 00 00  00 00 00 00 ab 01 00 00  |..d.............|
00000080  00 00 00 00 01 00 02 00  65 03 65 02 6a 0b 00 00  |........e.e.j...|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000a0  ab 00 00 00 00 00 00 00  ab 01 00 00 00 00 00 00  |................|
000000b0  01 00 79 04 79 04 29 05  63 00 00 00 00 00 00 00  |..y.y.).c.......|
000000c0  00 00 00 00 00 01 00 00  00 00 00 00 00 f3 1e 00  |................|
000000d0  00 00 97 00 65 00 5a 01  64 00 5a 02 64 01 84 00  |....e.Z.d.Z.d...|
000000e0  5a 03 64 02 84 00 5a 04  64 03 84 00 5a 05 79 04  |Z.d...Z.d...Z.y.|
000000f0  29 05 da 08 52 61 66 61  65 6c 49 41 63 01 00 00  |)...RafaelIAc...|
00000100  00 00 00 00 00 00 00 00  00 02 00 00 00 03 00 00  |................|
00000110  00 f3 20 00 00 00 97 00  64 01 7c 00 5f 00 00 00  |.. .....d.|._...|
00000120  00 00 00 00 00 00 67 00  7c 00 5f 01 00 00 00 00  |......g.|._.....|
00000130  00 00 00 00 79 00 29 02  4e da 05 61 74 69 76 6f  |....y.).N..ativo|
00000140  29 02 da 06 65 73 74 61  64 6f da 07 6d 65 6d 6f  |)...estado..memo|
00000150  72 69 61 a9 01 da 04 73  65 6c 66 73 01 00 00 00  |ria....selfs....|
00000160  20 fa 61 2f 64 61 74 61  2f 64 61 74 61 2f 63 6f  | .a/data/data/co|
00000170  6d 2e 74 65 72 6d 75 78  2f 66 69 6c 65 73 2f 68  |m.termux/files/h|
00000180  6f 6d 65 2f 52 41 46 41  45 4c 49 41 2f 48 43 50  |ome/RAFAELIA/HCP|
00000190  4d 2f 43 4f 52 45 2f 52  41 46 41 45 4c 49 41 2f  |M/CORE/RAFAELIA/|
000001a0  48 43 50 4d 2f 43 4f 52  45 2f 73 72 63 2f 72 61  |HCPM/CORE/src/ra|
000001b0  66 61 65 6c 69 61 2f 63  6f 72 65 5f 6c 6f 67 69  |faelia/core_logi|
000001c0  63 2e 70 79 da 08 5f 5f  69 6e 69 74 5f 5f 7a 11  |c.py..__init__z.|
000001d0  52 61 66 61 65 6c 49 41  2e 5f 5f 69 6e 69 74 5f  |RafaelIA.__init_|
000001e0  5f 02 00 00 00 73 10 00  00 00 80 00 d8 16 1d 88  |_....s..........|
000001f0  04 8c 0b d8 17 19 88 04  8d 0c f3 00 00 00 00 63  |...............c|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/core_logic.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 192 2025-06-01 01:30:24.059978089 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/__init__.cpython-312.pyc
1671622afd01d978f55f08c73447bd34b789c637b00cf5db1ddb96e0f57a38ad  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  59 a6 38 68 00 00 00 00  |........Y.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 5f 2f  |N..r.........._/|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |RE/RAFAELIA/HCPM|
00000080  2f 43 4f 52 45 2f 73 72  63 2f 72 61 66 61 65 6c  |/CORE/src/rafael|
00000090  69 61 2f 5f 5f 69 6e 69  74 5f 5f 2e 70 79 da 08  |ia/__init__.py..|
000000a0  3c 6d 6f 64 75 6c 65 3e  72 05 00 00 00 01 00 00  |<module>r.......|
000000b0  00 73 05 00 00 00 f1 03  01 01 01 72 03 00 00 00  |.s.........r....|
000000c0
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/src/rafaelia/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0.tar.gz
-rwxrwxrwx. 1 u0_a292 u0_a292 1.3K 2025-05-29 15:24:52.254752034 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0.tar.gz
980d7bf9166a70ef1ac011b4d5b6767350c8c36eb59faec1a95558a642a3ecba  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0.tar.gz
MIME: application/gzip
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  1f 8b 08 08 74 a6 38 68  02 ff 72 61 66 61 65 6c  |....t.8h..rafael|
00000010  69 61 2d 30 2e 31 2e 30  2e 74 61 72 00 ed 5c 5d  |ia-0.1.0.tar..\]|
00000020  6f db 36 14 f5 b3 7e 05  a1 27 1b 88 65 89 fa 70  |o.6...~..'..e..p|
00000030  6a c0 c0 82 2d dd 82 2e  69 91 60 7b 29 02 81 91  |j...-...i.`{)...|
00000040  68 87 ab 24 6a 14 e5 c6  eb f2 93 f6 d4 b7 bd e6  |h..$j...........|
00000050  8f 8d 92 ec f8 a3 b1 8d  34 8e b2 56 f7 bc d8 22  |........4..V..."|
00000060  29 92 a2 75 cf f1 bd 97  92 d1 33 7a 3f bc 23 37  |)..u......3z?.#7|
00000070  bf 50 12 52 d1 7a 16 98  15 36 7d 9a a6 6d 2f be  |.P.R.z...6}..m/.|
00000080  17 e5 96 89 2d ab 85 6e  5a 35 20 cf 24 11 6a f8  |....-..nZ5 .$.j.|
00000090  56 33 81 fb 28 96 2c a6  43 ab ef 1c ba 8e 6d be  |V3..(.,.C.....m.|
000000a0  c2 06 c6 5e df c5 5a 0b  f0 fd 43 90 11 a1 11 23  |...^..Z...C....#|
000000b0  5d d3 b0 0c b3 f7 6c f6  df 2f ed 1d 3b a6 e7 2c  |].....l../..;..,|
000000c0  7d 2e 6c de 72 4d cb b3  b0 6d 15 e5 16 c6 8a 12  |}.l.rM...m......|
000000d0  90 5b a7 fd e7 a6 4f f0  2b bc b9 dd 8e fa 6f 14  |.[....O.+.....o.|
000000e0  06 f0 3f f0 3f f0 3f f0  7f c5 ff ef de fc dc 3d  |..?.?.?........=|
000000f0  39 7b fd 76 ef f6 ef 39  ce 46 fe c7 d8 59 e3 7f  |9{.v...9.F...Y..|
00000100  db 76 cc 16 32 eb b4 ff  86 f2 ff 29 95 24 24 92  |.v..2......).$$.|
00000110  74 7f a7 22 63 3c 19 20  6c 38 da 19 89 e9 00 cd  |t.."c<. l8......|
00000120  ef 0d ed be ae bc 49 b4  8b 3c 8e 89 98 0e d0 d9  |......I..<......|
00000130  dd bf 41 44 39 ca 58 7c  c5 ee 3e 4b 16 70 74 7e  |..AD9.X|..>K.pt~|
00000140  f4 fa e8 f8 d7 93 23 ed  28 97 d7 5c 0c d0 79 d9  |......#.(..\..y.|
00000150  0b 3a a5 91 aa a4 2c d3  7e 9a 26 24 66 c1 00 91  |.:....,.~.&$f...|
00000160  b2 c5 e2 38 ab fa 05 e2  69 9a fe 63 ef 4b fd b7  |...8....i..c.K..|
00000170  41 ff 6b d1 7f bc a6 ff  9e a3 2c 1c ec a2 a1 fa  |A.k.......,.....|
00000180  9f 4e 53 c1 ff a0 81 34  24 8f a3 7d ea ff 16 ff  |.NS....4$..}....|
00000190  cf b2 f1 42 ff ed c2 fe  5d cb f6 40 ff eb c0 fb  |...B....]..@....|
000001a0  ab 9c 45 61 37 9b 66 92  c6 97 9a a0 7f e6 4c d0  |..Ea7.f.......L.|
000001b0  0c 0d d1 7b 3d a3 32 4f  25 e7 51 a6 1f 20 fd e3  |...{=.2O%.Q.. ..|
000001c0  35 a5 91 7e a9 55 27 5c  91 e0 03 4d 42 d5 6e a9  |5..~.U'\...MB.n.|
000001d0  99 51 d6 f9 b1 fa 4f a1  03 87 80 fe 83 ff 0f fe  |.Q....O.........|
000001e0  3f e0 5b d2 ff 92 cb 8d  60 34 de bb ff bf 2d fe  |?.[.....`4....-.|
000001f0  eb 78 6b fe bf 63 ba a0  ff f5 e8 3f 1d 8f 7d 96  |.xk..c.....?..}.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0.tar.gz -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0-py3-none-any.whl
-rwxrwxrwx. 1 u0_a292 u0_a292 1.6K 2025-05-29 15:24:57.962752030 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0-py3-none-any.whl
1b53fdc453b5d259105b2d98d35e081d645610665bd5684d868801ed2f976302  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0-py3-none-any.whl
MIME: application/zip
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  50 4b 03 04 14 00 00 00  08 00 0c 93 bd 5a 00 00  |PK...........Z..|
00000010  00 00 02 00 00 00 00 00  00 00 14 00 00 00 72 61  |..............ra|
00000020  66 61 65 6c 69 61 2f 5f  5f 69 6e 69 74 5f 5f 2e  |faelia/__init__.|
00000030  70 79 03 00 50 4b 03 04  14 00 00 00 08 00 0c 93  |py..PK..........|
00000040  bd 5a a9 05 32 65 00 01  00 00 d2 01 00 00 16 00  |.Z..2e..........|
00000050  00 00 72 61 66 61 65 6c  69 61 2f 63 6f 72 65 5f  |..rafaelia/core_|
00000060  6c 6f 67 69 63 2e 70 79  6d 50 bd 6a c3 30 10 de  |logic.pymP.j.0..|
00000070  f3 14 87 26 1b 8a 1f 20  90 c1 43 0a 86 36 43 d6  |...&... ..C..6C.|
00000080  52 c4 d5 3e c3 81 7e 8c  24 7b 68 eb 47 ea 94 ad  |R..>..~.${h.G...|
00000090  ab 5f ac 72 64 bb 69 e8  6d d2 77 f7 fd d5 0a bd  |._.rd.i.m.w.....|
000000a0  87 33 b6 48 aa 2a f7 3b  88 d3 50 0b 52 b2 e1 20  |.3.H.*.;..P.R.. |
000000b0  65 e6 49 b5 79 fa 9f 67  7e 16 e4 03 36 16 0e 20  |e.I.y..g~...6.. |
000000c0  30 f0 60 c5 5f 54 93 b6  8e 31 c2 2f af bb 8d d0  |0.`._T...1./....|
000000d0  f6 03 bb 2b db 03 90 09  0e 1b bc a7 5d 0e 0b ec  |...+........]...|
000000e0  3a 32 4d b6 6e 6d 4b 8e  42 ef 0c b4 e2 99 f4 74  |:2M.nmK.B......t|
000000f0  99 25 30 f4 a8 f8 3d 6e  41 6d f5 1e 3e 96 9b 51  |.%0...=nAm..>..Q|
00000100  fc 0a 47 af a1 f7 f7 39  36 ae 63 ca e2 59 bf f1  |..G....96.c..Y..|
00000110  74 09 5c db 48 73 93 72  84 4f 58 f5 22 a2 c8 64  |t.\.Hs.r.OX."..d|
00000120  b7 66 f3 11 68 88 aa d6  47 49 9e 7b 33 a8 49 4a  |.f..h...GI.{3.IJ|
00000130  38 c4 76 a4 d4 c8 46 4a  91 74 dd b5 e5 d8 cb 5a  |8.v...FJ.t.....Z|
00000140  77 96 b2 75 8e 4d c8 12  5a a4 9e 44 65 a6 af 9a  |w..u.M..Z..De...|
00000150  2d 44 6b a7 e9 bb 56 64  e1 5c 3e 96 c7 a7 aa 14  |-Dk...Vd.\>.....|
00000160  f9 3f 67 4b ca 08 fd 00  50 4b 03 04 14 00 00 00  |.?gK....PK......|
00000170  08 00 1c 93 bd 5a 30 91  94 a1 7b 00 00 00 94 00  |.....Z0...{.....|
00000180  00 00 21 00 00 00 72 61  66 61 65 6c 69 61 2d 30  |..!...rafaelia-0|
00000190  2e 31 2e 30 2e 64 69 73  74 2d 69 6e 66 6f 2f 4d  |.1.0.dist-info/M|
000001a0  45 54 41 44 41 54 41 45  8c 31 0a c2 40 10 00 fb  |ETADATAE.1..@...|
000001b0  7d c5 7e c0 23 8a d5 76  07 2a 08 26 45 04 fb f5  |}.~.#..v.*.&E...|
000001c0  5c 71 e1 36 07 77 97 22  ef b2 b3 cd c7 94 08 5a  |\q.6.w.".......Z|
000001d0  0e 33 4c 2b 95 6f 5c 79  75 91 5c 34 0d 84 1b b7  |.3L+.o\yu.\4....|
000001e0  85 8e 4d 08 33 df 59 a2  32 fc 5c e3 d6 ae 81 f3  |..M.3.Y.2.\.....|
000001f0  68 c6 79 22 ec e6 57 88  92 b0 a8 5d 75 7e 56 0d  |h.y"..W....]u~V.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0-py3-none-any.whl -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 325 2025-06-01 01:30:26.151978088 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/__init__.cpython-312.pyc
14cd821b569fdfd57fa8824bd380c8044a8868a8f16b210048b8da5b6b893a9e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 83 00 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 08 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  79 01 29 02 7a 46 53 75  62 70 61 63 6b 61 67 65  |y.).zFSubpackage|
00000040  20 63 6f 6e 74 61 69 6e  69 6e 67 20 61 6c 6c 20  | containing all |
00000050  6f 66 20 70 69 70 27 73  20 63 6f 6d 6d 61 6e 64  |of pip's command|
00000060  20 6c 69 6e 65 20 69 6e  74 65 72 66 61 63 65 20  | line interface |
00000070  72 65 6c 61 74 65 64 20  63 6f 64 65 4e 29 01 da  |related codeN)..|
00000080  07 5f 5f 64 6f 63 5f 5f  a9 00 f3 00 00 00 00 fa  |.__doc__........|
00000090  8f 2f 64 61 74 61 2f 64  61 74 61 2f 63 6f 6d 2e  |./data/data/com.|
000000a0  74 65 72 6d 75 78 2f 66  69 6c 65 73 2f 68 6f 6d  |termux/files/hom|
000000b0  65 2f 52 41 46 41 45 4c  49 41 2f 48 43 50 4d 2f  |e/RAFAELIA/HCPM/|
000000c0  43 4f 52 45 2f 52 41 46  41 45 4c 49 41 2f 48 43  |CORE/RAFAELIA/HC|
000000d0  50 4d 2f 43 4f 52 45 2f  76 65 6e 76 5f 72 61 66  |PM/CORE/venv_raf|
000000e0  61 65 6c 69 61 2f 6c 69  62 2f 70 79 74 68 6f 6e  |aelia/lib/python|
000000f0  33 2e 31 32 2f 73 69 74  65 2d 70 61 63 6b 61 67  |3.12/site-packag|
00000100  65 73 2f 70 69 70 2f 5f  69 6e 74 65 72 6e 61 6c  |es/pip/_internal|
00000110  2f 63 6c 69 2f 5f 5f 69  6e 69 74 5f 5f 2e 70 79  |/cli/__init__.py|
00000120  da 08 3c 6d 6f 64 75 6c  65 3e 72 06 00 00 00 01  |..<module>r.....|
00000130  00 00 00 73 08 00 00 00  f0 03 01 01 01 da 00 4c  |...s...........L|
00000140  72 04 00 00 00                                    |r....|
00000145
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/autocompletion.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 8.5K 2025-06-01 01:30:26.311978088 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/autocompletion.cpython-312.pyc
fbb3905a1409cfc218d4795d16e67ca963fe064e62d0906964cab32c46fb7c95  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/autocompletion.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 d0 1a 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 09 00 00  |................|
00000020  00 00 00 00 00 f3 b8 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 6d 08  |Z...d.d.l.m.Z.m.|
00000060  5a 08 6d 09 5a 09 6d 0a  5a 0a 01 00 64 01 64 05  |Z.m.Z.m.Z...d.d.|
00000070  6c 0b 6d 0c 5a 0c 01 00  64 01 64 06 6c 0d 6d 0e  |l.m.Z...d.d.l.m.|
00000080  5a 0e 6d 0f 5a 0f 01 00  64 01 64 07 6c 10 6d 11  |Z.m.Z...d.d.l.m.|
00000090  5a 11 01 00 64 11 64 09  84 04 5a 12 64 0a 65 09  |Z...d.d...Z.d.e.|
000000a0  65 13 19 00 00 00 64 0b  65 14 64 0c 65 08 65 07  |e.....d.e.d.e.e.|
000000b0  19 00 00 00 64 08 65 0a  65 13 19 00 00 00 66 08  |....d.e.e.....f.|
000000c0  64 0d 84 04 5a 15 64 0e  65 13 64 0f 65 13 64 08  |d...Z.d.e.d.e.d.|
000000d0  65 08 65 13 19 00 00 00  66 06 64 10 84 04 5a 16  |e.e.....f.d...Z.|
000000e0  79 02 29 12 7a 41 4c 6f  67 69 63 20 74 68 61 74  |y.).zALogic that|
000000f0  20 70 6f 77 65 72 73 20  61 75 74 6f 63 6f 6d 70  | powers autocomp|
00000100  6c 65 74 69 6f 6e 20 69  6e 73 74 61 6c 6c 65 64  |letion installed|
00000110  20 62 79 20 60 60 70 69  70 20 63 6f 6d 70 6c 65  | by ``pip comple|
00000120  74 69 6f 6e 60 60 2e e9  00 00 00 00 4e 29 01 da  |tion``......N)..|
00000130  05 63 68 61 69 6e 29 04  da 03 41 6e 79 da 08 49  |.chain)...Any..I|
00000140  74 65 72 61 62 6c 65 da  04 4c 69 73 74 da 08 4f  |terable..List..O|
00000150  70 74 69 6f 6e 61 6c 29  01 da 12 63 72 65 61 74  |ptional)...creat|
00000160  65 5f 6d 61 69 6e 5f 70  61 72 73 65 72 29 02 da  |e_main_parser)..|
00000170  0d 63 6f 6d 6d 61 6e 64  73 5f 64 69 63 74 da 0e  |.commands_dict..|
00000180  63 72 65 61 74 65 5f 63  6f 6d 6d 61 6e 64 29 01  |create_command).|
00000190  da 17 67 65 74 5f 64 65  66 61 75 6c 74 5f 65 6e  |..get_default_en|
000001a0  76 69 72 6f 6e 6d 65 6e  74 da 06 72 65 74 75 72  |vironment..retur|
000001b0  6e 63 00 00 00 00 00 00  00 00 00 00 00 00 0a 00  |nc..............|
000001c0  00 00 03 00 00 00 f3 16  09 00 00 97 00 64 01 74  |.............d.t|
000001d0  00 00 00 00 00 00 00 00  00 6a 02 00 00 00 00 00  |.........j......|
000001e0  00 00 00 00 00 00 00 00  00 00 00 00 00 76 01 72  |.............v.r|
000001f0  01 79 02 74 00 00 00 00  00 00 00 00 00 6a 02 00  |.y.t.........j..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/autocompletion.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/base_command.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 11K 2025-06-01 01:30:26.475978088 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/base_command.cpython-312.pyc
8514e3f4745459f0c9485c36857db4d8cf3774b5b06a660b34c7f079d85cd963  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/base_command.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 9f 20 00 00  |........i.8h. ..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 64 01  00 00 97 00 64 00 5a 00  |......d.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 01  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 01 64 03 6c 03 6d 07  5a 07 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000070  6c 08 6d 09 5a 09 6d 0a  5a 0a 6d 0b 5a 0b 01 00  |l.m.Z.m.Z.m.Z...|
00000080  64 01 64 05 6c 0c 6d 0d  5a 0d 01 00 64 01 64 06  |d.d.l.m.Z...d.d.|
00000090  6c 0c 6d 06 5a 0e 01 00  64 01 64 07 6c 0f 6d 10  |l.m.Z...d.d.l.m.|
000000a0  5a 10 01 00 64 01 64 08  6c 11 6d 12 5a 12 01 00  |Z...d.d.l.m.Z...|
000000b0  64 01 64 09 6c 13 6d 14  5a 14 6d 15 5a 15 01 00  |d.d.l.m.Z.m.Z...|
000000c0  64 01 64 0a 6c 16 6d 17  5a 17 6d 18 5a 18 6d 19  |d.d.l.m.Z.m.Z.m.|
000000d0  5a 19 6d 1a 5a 1a 01 00  64 01 64 0b 6c 1b 6d 1c  |Z.m.Z...d.d.l.m.|
000000e0  5a 1c 6d 1d 5a 1d 6d 1e  5a 1e 6d 1f 5a 1f 6d 20  |Z.m.Z.m.Z.m.Z.m |
000000f0  5a 20 6d 21 5a 21 01 00  64 01 64 0c 6c 22 6d 23  |Z m!Z!..d.d.l"m#|
00000100  5a 23 01 00 64 01 64 0d  6c 24 6d 25 5a 25 6d 26  |Z#..d.d.l$m%Z%m&|
00000110  5a 26 01 00 64 01 64 0e  6c 27 6d 28 5a 28 6d 29  |Z&..d.d.l'm(Z(m)|
00000120  5a 29 01 00 64 01 64 0f  6c 2a 6d 2b 5a 2c 01 00  |Z)..d.d.l*m+Z,..|
00000130  64 01 64 10 6c 2a 6d 2d  5a 2d 6d 2e 5a 2e 01 00  |d.d.l*m-Z-m.Z...|
00000140  64 01 64 11 6c 2f 6d 30  5a 30 01 00 64 12 67 01  |d.d.l/m0Z0..d.g.|
00000150  5a 31 02 00 65 01 6a 64  00 00 00 00 00 00 00 00  |Z1..e.jd........|
00000160  00 00 00 00 00 00 00 00  00 00 65 33 ab 01 00 00  |..........e3....|
00000170  00 00 00 00 5a 34 02 00  47 00 64 13 84 00 64 12  |....Z4..G.d...d.|
00000180  65 12 ab 03 00 00 00 00  00 00 5a 35 79 02 29 14  |e.........Z5y.).|
00000190  7a 28 42 61 73 65 20 43  6f 6d 6d 61 6e 64 20 63  |z(Base Command c|
000001a0  6c 61 73 73 2c 20 61 6e  64 20 72 65 6c 61 74 65  |lass, and relate|
000001b0  64 20 72 6f 75 74 69 6e  65 73 e9 00 00 00 00 4e  |d routines.....N|
000001c0  29 01 da 06 56 61 6c 75  65 73 29 03 da 04 4c 69  |)...Values)...Li|
000001d0  73 74 da 08 4f 70 74 69  6f 6e 61 6c da 05 54 75  |st..Optional..Tu|
000001e0  70 6c 65 29 01 da 0b 72  65 63 6f 6e 66 69 67 75  |ple)...reconfigu|
000001f0  72 65 29 01 da 09 74 72  61 63 65 62 61 63 6b 29  |re)...traceback)|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/base_command.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/cmdoptions.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 32K 2025-06-01 01:30:26.647978088 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/cmdoptions.cpython-312.pyc
fdba15661eb3e9d3f65c679c8441705dc84a49d16f46e353b4b1a1776d3d180c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/cmdoptions.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 a5 7c 00 00  |........i.8h.|..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 1b 00 00  |................|
00000020  00 00 00 00 00 f3 72 0e  00 00 97 00 55 00 64 00  |......r.....U.d.|
00000030  5a 00 64 01 64 02 6c 01  5a 02 64 01 64 02 6c 03  |Z.d.d.l.Z.d.d.l.|
00000040  5a 03 64 01 64 02 6c 04  5a 04 64 01 64 02 6c 05  |Z.d.d.l.Z.d.d.l.|
00000050  5a 05 64 01 64 02 6c 06  5a 06 64 01 64 03 6c 07  |Z.d.d.l.Z.d.d.l.|
00000060  6d 08 5a 08 01 00 64 01  64 04 6c 09 6d 0a 5a 0a  |m.Z...d.d.l.m.Z.|
00000070  6d 0b 5a 0b 6d 0c 5a 0c  6d 0d 5a 0d 6d 0e 5a 0e  |m.Z.m.Z.m.Z.m.Z.|
00000080  01 00 64 01 64 05 6c 06  6d 0f 5a 0f 01 00 64 01  |..d.d.l.m.Z...d.|
00000090  64 06 6c 10 6d 11 5a 11  6d 12 5a 12 6d 13 5a 13  |d.l.m.Z.m.Z.m.Z.|
000000a0  6d 14 5a 14 6d 15 5a 15  01 00 64 01 64 07 6c 16  |m.Z.m.Z...d.d.l.|
000000b0  6d 17 5a 17 01 00 64 01  64 08 6c 18 6d 19 5a 19  |m.Z...d.d.l.m.Z.|
000000c0  01 00 64 01 64 09 6c 1a  6d 1b 5a 1b 01 00 64 01  |..d.d.l.m.Z...d.|
000000d0  64 0a 6c 1c 6d 1d 5a 1d  6d 1e 5a 1e 01 00 64 01  |d.l.m.Z.m.Z...d.|
000000e0  64 0b 6c 1f 6d 20 5a 20  01 00 64 01 64 0c 6c 21  |d.l.m Z ..d.d.l!|
000000f0  6d 22 5a 22 01 00 64 01  64 0d 6c 23 6d 24 5a 24  |m"Z"..d.d.l#m$Z$|
00000100  01 00 64 01 64 0e 6c 25  6d 26 5a 26 01 00 64 01  |..d.d.l%m&Z&..d.|
00000110  64 0f 6c 27 6d 28 5a 28  01 00 02 00 65 03 6a 52  |d.l'm(Z(....e.jR|
00000120  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000130  00 00 65 2a ab 01 00 00  00 00 00 00 5a 2b 64 10  |..e*........Z+d.|
00000140  65 0d 64 11 65 0b 64 12  65 2c 64 13 64 02 66 08  |e.d.e.d.e,d.d.f.|
00000150  64 14 84 04 5a 2d 64 15  65 13 65 2c 65 11 66 02  |d...Z-d.e.e,e.f.|
00000160  19 00 00 00 64 10 65 19  64 13 65 0c 66 06 64 16  |....d.e.d.e.f.d.|
00000170  84 04 5a 2e 90 01 64 30  64 18 65 0e 64 19 65 2f  |..Z...d0d.e.d.e/|
00000180  64 13 64 02 66 06 64 1a  84 05 5a 30 64 11 65 0b  |d.d.f.d...Z0d.e.|
00000190  64 1b 65 2c 64 1c 65 2c  64 13 65 2c 66 08 64 1d  |d.e,d.e,d.e,f.d.|
000001a0  84 04 5a 31 64 11 65 0b  64 1b 65 2c 64 1c 65 2c  |..Z1d.e.d.e,d.e,|
000001b0  64 13 65 2c 66 08 64 1e  84 04 5a 32 02 00 47 00  |d.e,f.d...Z2..G.|
000001c0  64 1f 84 00 64 20 65 0b  ab 03 00 00 00 00 00 00  |d...d e.........|
000001d0  5a 33 02 00 65 08 65 0b  64 21 64 22 64 23 64 23  |Z3..e.e.d!d"d#d#|
000001e0  64 24 ac 25 ab 06 00 00  00 00 00 00 5a 34 65 12  |d$.%........Z4e.|
000001f0  64 26 65 0b 66 02 19 00  00 00 65 35 64 27 3c 00  |d&e.f.....e5d'<.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/cmdoptions.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/command_context.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.8K 2025-06-01 01:30:26.791978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/command_context.cpython-312.pyc
f749e9abdc88fae11c63bd81fb49ae01db9ee1d4313dbce225776b5279ad5a97  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/command_context.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 06 03 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 50 00  00 00 97 00 64 00 64 01  |......P.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 01 00 64 00 64 02  |l.m.Z.m.Z...d.d.|
00000040  6c 03 6d 04 5a 04 6d 05  5a 05 6d 06 5a 06 01 00  |l.m.Z.m.Z.m.Z...|
00000050  02 00 65 06 64 03 64 04  ac 05 ab 02 00 00 00 00  |..e.d.d.........|
00000060  00 00 5a 07 02 00 47 00  64 06 84 00 64 07 ab 02  |..Z...G.d...d...|
00000070  00 00 00 00 00 00 5a 08  79 08 29 09 e9 00 00 00  |......Z.y.).....|
00000080  00 29 02 da 09 45 78 69  74 53 74 61 63 6b da 0e  |.)...ExitStack..|
00000090  63 6f 6e 74 65 78 74 6d  61 6e 61 67 65 72 29 03  |contextmanager).|
000000a0  da 0e 43 6f 6e 74 65 78  74 4d 61 6e 61 67 65 72  |..ContextManager|
000000b0  da 09 47 65 6e 65 72 61  74 6f 72 da 07 54 79 70  |..Generator..Typ|
000000c0  65 56 61 72 da 02 5f 54  54 29 01 da 09 63 6f 76  |eVar.._TT)...cov|
000000d0  61 72 69 61 6e 74 63 00  00 00 00 00 00 00 00 00  |ariantc.........|
000000e0  00 00 00 04 00 00 00 00  00 00 00 f3 52 00 00 00  |............R...|
000000f0  87 00 97 00 65 00 5a 01  64 00 5a 02 64 07 88 00  |....e.Z.d.Z.d...|
00000100  66 01 64 02 84 0c 5a 03  65 04 64 01 65 05 64 03  |f.d...Z.e.d.e.d.|
00000110  19 00 00 00 66 02 64 04  84 04 ab 00 00 00 00 00  |....f.d.........|
00000120  00 00 5a 06 64 05 65 07  65 08 19 00 00 00 64 01  |..Z.d.e.e.....d.|
00000130  65 08 66 04 64 06 84 04  5a 09 88 00 78 01 5a 0a  |e.f.d...Z...x.Z.|
00000140  53 00 29 08 da 13 43 6f  6d 6d 61 6e 64 43 6f 6e  |S.)...CommandCon|
00000150  74 65 78 74 4d 69 78 49  6e da 06 72 65 74 75 72  |textMixIn..retur|
00000160  6e 63 01 00 00 00 00 00  00 00 00 00 00 00 03 00  |nc..............|
00000170  00 00 03 00 00 00 f3 4e  00 00 00 95 01 97 00 74  |.......N.......t|
00000180  00 00 00 00 00 00 00 00  00 89 01 7c 00 8d 05 00  |...........|....|
00000190  00 ab 00 00 00 00 00 00  00 01 00 64 01 7c 00 5f  |...........d.|._|
000001a0  02 00 00 00 00 00 00 00  00 74 07 00 00 00 00 00  |.........t......|
000001b0  00 00 00 ab 00 00 00 00  00 00 00 7c 00 5f 04 00  |...........|._..|
000001c0  00 00 00 00 00 00 00 79  00 29 02 4e 46 29 05 da  |.......y.).NF)..|
000001d0  05 73 75 70 65 72 da 08  5f 5f 69 6e 69 74 5f 5f  |.super..__init__|
000001e0  da 10 5f 69 6e 5f 6d 61  69 6e 5f 63 6f 6e 74 65  |.._in_main_conte|
000001f0  78 74 72 03 00 00 00 da  0d 5f 6d 61 69 6e 5f 63  |xtr......_main_c|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/command_context.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/index_command.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.2K 2025-06-01 01:30:26.951978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/index_command.cpython-312.pyc
1bb0337a26a00b19fc9b31862cd8f8bb5d255ade84fbba477a0e9c6280623517  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/index_command.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 58 16 00 00  |........i.8hX...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 0e 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 01 64 05 6c 08 6d 09  5a 09 6d 0a 5a 0a 6d 0b  |d.d.l.m.Z.m.Z.m.|
00000070  5a 0b 01 00 64 01 64 06  6c 0c 6d 0d 5a 0d 01 00  |Z...d.d.l.m.Z...|
00000080  64 01 64 07 6c 0e 6d 0f  5a 0f 01 00 64 01 64 08  |d.d.l.m.Z...d.d.|
00000090  6c 10 6d 11 5a 11 01 00  65 09 72 0c 64 01 64 09  |l.m.Z...e.r.d.d.|
000000a0  6c 12 6d 13 5a 13 01 00  64 01 64 0a 6c 14 6d 15  |l.m.Z...d.d.l.m.|
000000b0  5a 15 01 00 02 00 65 01  6a 2c 00 00 00 00 00 00  |Z.....e.j,......|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 65 17 ab 01  |............e...|
000000d0  00 00 00 00 00 00 5a 18  65 05 64 0b 65 0b 64 0c  |......Z.e.d.e.d.|
000000e0  19 00 00 00 66 02 64 0d  84 04 ab 00 00 00 00 00  |....f.d.........|
000000f0  00 00 5a 19 02 00 47 00  64 0e 84 00 64 0f 65 11  |..Z...G.d...d.e.|
00000100  ab 03 00 00 00 00 00 00  5a 1a 64 10 64 11 64 12  |........Z.d.d.d.|
00000110  65 07 64 0b 64 02 66 06  64 13 84 04 5a 1b 02 00  |e.d.d.f.d...Z...|
00000120  47 00 64 14 84 00 64 15  65 0f 65 1a ab 04 00 00  |G.d...d.e.e.....|
00000130  00 00 00 00 5a 1c 79 02  29 16 61 26 01 00 00 0a  |....Z.y.).a&....|
00000140  43 6f 6e 74 61 69 6e 73  20 63 6f 6d 6d 61 6e 64  |Contains command|
00000150  20 63 6c 61 73 73 65 73  20 77 68 69 63 68 20 6d  | classes which m|
00000160  61 79 20 69 6e 74 65 72  61 63 74 20 77 69 74 68  |ay interact with|
00000170  20 61 6e 20 69 6e 64 65  78 20 2f 20 74 68 65 20  | an index / the |
00000180  6e 65 74 77 6f 72 6b 2e  0a 0a 55 6e 6c 69 6b 65  |network...Unlike|
00000190  20 69 74 73 20 73 69 73  74 65 72 20 6d 6f 64 75  | its sister modu|
000001a0  6c 65 2c 20 72 65 71 5f  63 6f 6d 6d 61 6e 64 2c  |le, req_command,|
000001b0  20 74 68 69 73 20 6d 6f  64 75 6c 65 20 73 74 69  | this module sti|
000001c0  6c 6c 20 75 73 65 73 20  6c 61 7a 79 20 69 6d 70  |ll uses lazy imp|
000001d0  6f 72 74 73 0a 73 6f 20  63 6f 6d 6d 61 6e 64 73  |orts.so commands|
000001e0  20 77 68 69 63 68 20 64  6f 6e 27 74 20 61 6c 77  | which don't alw|
000001f0  61 79 73 20 68 69 74 20  74 68 65 20 6e 65 74 77  |ays hit the netw|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/index_command.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.3K 2025-06-01 01:30:27.111978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main.cpython-312.pyc
7cad03b2ea301b1d653bd84a9bea82fbce73164e83d57d32d738b55e5ddc7f89  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 00 0b 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 be 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 03 6c 06 6d 07  |d.d.l.Z.d.d.l.m.|
00000060  5a 07 6d 08 5a 08 01 00  64 01 64 04 6c 09 6d 0a  |Z.m.Z...d.d.l.m.|
00000070  5a 0a 01 00 64 01 64 05  6c 0b 6d 0c 5a 0c 01 00  |Z...d.d.l.m.Z...|
00000080  64 01 64 06 6c 0d 6d 0e  5a 0e 01 00 64 01 64 07  |d.d.l.m.Z...d.d.|
00000090  6c 0f 6d 10 5a 10 01 00  64 01 64 08 6c 11 6d 12  |l.m.Z...d.d.l.m.|
000000a0  5a 12 01 00 02 00 65 02  6a 26 00 00 00 00 00 00  |Z.....e.j&......|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 65 14 ab 01  |............e...|
000000c0  00 00 00 00 00 00 5a 15  64 0c 64 09 65 08 65 07  |......Z.d.d.e.e.|
000000d0  65 16 19 00 00 00 19 00  00 00 64 0a 65 17 66 04  |e.........d.e.f.|
000000e0  64 0b 84 05 5a 18 79 02  29 0d 7a 1f 50 72 69 6d  |d...Z.y.).z.Prim|
000000f0  61 72 79 20 61 70 70 6c  69 63 61 74 69 6f 6e 20  |ary application |
00000100  65 6e 74 72 79 70 6f 69  6e 74 2e e9 00 00 00 00  |entrypoint......|
00000110  4e 29 02 da 04 4c 69 73  74 da 08 4f 70 74 69 6f  |N)...List..Optio|
00000120  6e 61 6c 29 01 da 0c 61  75 74 6f 63 6f 6d 70 6c  |nal)...autocompl|
00000130  65 74 65 29 01 da 0d 70  61 72 73 65 5f 63 6f 6d  |ete)...parse_com|
00000140  6d 61 6e 64 29 01 da 0e  63 72 65 61 74 65 5f 63  |mand)...create_c|
00000150  6f 6d 6d 61 6e 64 29 01  da 08 50 69 70 45 72 72  |ommand)...PipErr|
00000160  6f 72 29 01 da 0b 64 65  70 72 65 63 61 74 69 6f  |or)...deprecatio|
00000170  6e da 04 61 72 67 73 da  06 72 65 74 75 72 6e 63  |n..args..returnc|
00000180  01 00 00 00 00 00 00 00  00 00 00 00 05 00 00 00  |................|
00000190  03 00 00 00 f3 a8 02 00  00 97 00 7c 00 80 13 74  |...........|...t|
000001a0  00 00 00 00 00 00 00 00  00 6a 02 00 00 00 00 00  |.........j......|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 64 01 64  |.............d.d|
000001c0  00 1a 00 7d 00 74 05 00  00 00 00 00 00 00 00 6a  |...}.t.........j|
000001d0  06 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001e0  00 00 00 64 02 74 08 00  00 00 00 00 00 00 00 64  |...d.t.........d|
000001f0  03 ac 04 ab 03 00 00 00  00 00 00 01 00 74 0b 00  |.............t..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main_parser.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.9K 2025-06-01 01:30:27.267978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main_parser.cpython-312.pyc
a794ca22542887d49b929df9edc5db3691ab2e0044ac9e528e358f2dece7f9dd  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main_parser.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 f1 10 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 d8 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 6d 06 5a 06 6d 07  5a 07 01 00 64 01 64 04  |Z.m.Z.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 01 64 05 6c 0a 6d 0b  |l.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 01 64 06  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 01 00 64 01 64 07  6c 0f 6d 10 5a 10 6d 11  |Z...d.d.l.m.Z.m.|
00000090  5a 11 01 00 64 01 64 08  6c 12 6d 13 5a 13 01 00  |Z...d.d.l.m.Z...|
000000a0  64 01 64 09 6c 14 6d 15  5a 15 6d 16 5a 16 01 00  |d.d.l.m.Z.m.Z...|
000000b0  64 0a 64 0b 67 02 5a 17  64 0c 65 0d 66 02 64 0d  |d.d.g.Z.d.e.f.d.|
000000c0  84 04 5a 18 64 0e 65 19  64 0c 65 06 65 19 19 00  |..Z.d.e.d.e.e...|
000000d0  00 00 66 04 64 0f 84 04  5a 1a 64 10 65 05 65 19  |..f.d...Z.d.e.e.|
000000e0  19 00 00 00 64 0c 65 07  65 19 65 05 65 19 19 00  |....d.e.e.e.e...|
000000f0  00 00 66 02 19 00 00 00  66 04 64 11 84 04 5a 1b  |..f.....f.d...Z.|
00000100  79 02 29 12 7a 3c 41 20  73 69 6e 67 6c 65 20 70  |y.).z<A single p|
00000110  6c 61 63 65 20 66 6f 72  20 63 6f 6e 73 74 72 75  |lace for constru|
00000120  63 74 69 6e 67 20 61 6e  64 20 65 78 70 6f 73 69  |cting and exposi|
00000130  6e 67 20 74 68 65 20 6d  61 69 6e 20 70 61 72 73  |ng the main pars|
00000140  65 72 e9 00 00 00 00 4e  29 03 da 04 4c 69 73 74  |er.....N)...List|
00000150  da 08 4f 70 74 69 6f 6e  61 6c da 05 54 75 70 6c  |..Optional..Tupl|
00000160  65 29 01 da 10 67 65 74  5f 72 75 6e 6e 61 62 6c  |e)...get_runnabl|
00000170  65 5f 70 69 70 29 01 da  0a 63 6d 64 6f 70 74 69  |e_pip)...cmdopti|
00000180  6f 6e 73 29 02 da 12 43  6f 6e 66 69 67 4f 70 74  |ons)...ConfigOpt|
00000190  69 6f 6e 50 61 72 73 65  72 da 1d 55 70 64 61 74  |ionParser..Updat|
000001a0  69 6e 67 44 65 66 61 75  6c 74 73 48 65 6c 70 46  |ingDefaultsHelpF|
000001b0  6f 72 6d 61 74 74 65 72  29 02 da 0d 63 6f 6d 6d  |ormatter)...comm|
000001c0  61 6e 64 73 5f 64 69 63  74 da 14 67 65 74 5f 73  |ands_dict..get_s|
000001d0  69 6d 69 6c 61 72 5f 63  6f 6d 6d 61 6e 64 73 29  |imilar_commands)|
000001e0  01 da 0c 43 6f 6d 6d 61  6e 64 45 72 72 6f 72 29  |...CommandError)|
000001f0  02 da 0f 67 65 74 5f 70  69 70 5f 76 65 72 73 69  |...get_pip_versi|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/main_parser.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/parser.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 15K 2025-06-01 01:30:27.431978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/parser.cpython-312.pyc
c62cc3af0c91d138e351e1851c4c942ce3fd8fba790efb2306f944774c4004ce  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/parser.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 49 2a 00 00  |........i.8hI*..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 30 01  00 00 97 00 64 00 5a 00  |......0.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 03 6c 06 6d 07  |d.d.l.Z.d.d.l.m.|
00000060  5a 07 01 00 64 01 64 04  6c 08 6d 09 5a 09 6d 0a  |Z...d.d.l.m.Z.m.|
00000070  5a 0a 6d 0b 5a 0b 6d 0c  5a 0c 6d 0d 5a 0d 6d 0e  |Z.m.Z.m.Z.m.Z.m.|
00000080  5a 0e 6d 0f 5a 0f 01 00  64 01 64 05 6c 10 6d 11  |Z.m.Z...d.d.l.m.|
00000090  5a 11 01 00 64 01 64 06  6c 12 6d 13 5a 13 6d 14  |Z...d.d.l.m.Z.m.|
000000a0  5a 14 01 00 64 01 64 07  6c 15 6d 16 5a 16 6d 17  |Z...d.d.l.m.Z.m.|
000000b0  5a 17 01 00 02 00 65 01  6a 30 00 00 00 00 00 00  |Z.....e.j0......|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 65 19 ab 01  |............e...|
000000d0  00 00 00 00 00 00 5a 1a  02 00 47 00 64 08 84 00  |......Z...G.d...|
000000e0  64 09 65 02 6a 36 00 00  00 00 00 00 00 00 00 00  |d.e.j6..........|
000000f0  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
00000100  5a 1c 02 00 47 00 64 0a  84 00 64 0b 65 1c ab 03  |Z...G.d...d.e...|
00000110  00 00 00 00 00 00 5a 1d  02 00 47 00 64 0c 84 00  |......Z...G.d...|
00000120  64 0d 65 02 6a 3c 00 00  00 00 00 00 00 00 00 00  |d.e.j<..........|
00000130  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
00000140  5a 1f 02 00 47 00 64 0e  84 00 64 0f 65 1f ab 03  |Z...G.d...d.e...|
00000150  00 00 00 00 00 00 5a 20  79 02 29 10 7a 18 42 61  |......Z y.).z.Ba|
00000160  73 65 20 6f 70 74 69 6f  6e 20 70 61 72 73 65 72  |se option parser|
00000170  20 73 65 74 75 70 e9 00  00 00 00 4e 29 01 da 08  | setup.....N)...|
00000180  73 75 70 70 72 65 73 73  29 07 da 03 41 6e 79 da  |suppress)...Any.|
00000190  04 44 69 63 74 da 09 47  65 6e 65 72 61 74 6f 72  |.Dict..Generator|
000001a0  da 04 4c 69 73 74 da 08  4e 6f 52 65 74 75 72 6e  |..List..NoReturn|
000001b0  da 08 4f 70 74 69 6f 6e  61 6c da 05 54 75 70 6c  |..Optional..Tupl|
000001c0  65 29 01 da 0d 55 4e 4b  4e 4f 57 4e 5f 45 52 52  |e)...UNKNOWN_ERR|
000001d0  4f 52 29 02 da 0d 43 6f  6e 66 69 67 75 72 61 74  |OR)...Configurat|
000001e0  69 6f 6e da 12 43 6f 6e  66 69 67 75 72 61 74 69  |ion..Configurati|
000001f0  6f 6e 45 72 72 6f 72 29  02 da 14 72 65 64 61 63  |onError)...redac|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/parser.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/progress_bars.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.7K 2025-06-01 01:30:27.591978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/progress_bars.cpython-312.pyc
1f9ef5bd70da5c050e83b42f6ce5671fdf0954874bf4cc8c46831f2a057ea62e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/progress_bars.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 53 11 00 00  |........i.8hS...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0e 00 00  |................|
00000020  00 00 00 00 00 f3 a8 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 6d 04  5a 04 6d 05 5a 05 6d 06  |l.m.Z.m.Z.m.Z.m.|
00000050  5a 06 6d 07 5a 07 6d 08  5a 08 6d 09 5a 09 01 00  |Z.m.Z.m.Z.m.Z...|
00000060  64 00 64 03 6c 0a 6d 0b  5a 0b 6d 0c 5a 0c 6d 0d  |d.d.l.m.Z.m.Z.m.|
00000070  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 6d 10 5a 10 6d 11  |Z.m.Z.m.Z.m.Z.m.|
00000080  5a 11 6d 12 5a 12 6d 13  5a 13 6d 14 5a 14 6d 15  |Z.m.Z.m.Z.m.Z.m.|
00000090  5a 15 01 00 64 00 64 04  6c 16 6d 17 5a 17 01 00  |Z...d.d.l.m.Z...|
000000a0  64 00 64 05 6c 18 6d 19  5a 19 01 00 64 00 64 06  |d.d.l.m.Z...d.d.|
000000b0  6c 1a 6d 1b 5a 1b 6d 1c  5a 1c 01 00 02 00 65 09  |l.m.Z.m.Z.....e.|
000000c0  64 07 ab 01 00 00 00 00  00 00 5a 1d 65 03 65 05  |d.........Z.e.e.|
000000d0  65 1d 19 00 00 00 67 01  65 06 65 1d 19 00 00 00  |e.....g.e.e.....|
000000e0  66 02 19 00 00 00 5a 1e  64 01 64 08 9c 01 64 09  |f.....Z.d.d...d.|
000000f0  65 05 65 1f 19 00 00 00  64 0a 65 20 64 0b 65 07  |e.e.....d.e d.e.|
00000100  65 21 19 00 00 00 64 0c  65 07 65 21 19 00 00 00  |e!....d.e.e!....|
00000110  64 0d 65 04 65 1f 64 01  64 01 66 03 19 00 00 00  |d.e.e.d.d.f.....|
00000120  66 0a 64 0e 84 06 5a 22  64 09 65 05 65 19 19 00  |f.d...Z"d.e.e...|
00000130  00 00 64 0f 65 21 64 0d  65 06 65 19 19 00 00 00  |..d.e!d.e.e.....|
00000140  66 06 64 10 84 04 5a 23  64 01 64 08 9c 01 64 09  |f.d...Z#d.d...d.|
00000150  65 05 65 1f 19 00 00 00  64 0b 65 07 65 21 19 00  |e.e.....d.e.e!..|
00000160  00 00 64 0c 65 07 65 21  19 00 00 00 64 0d 65 04  |..d.e.e!....d.e.|
00000170  65 1f 64 01 64 01 66 03  19 00 00 00 66 08 64 11  |e.d.d.f.....f.d.|
00000180  84 06 5a 24 64 01 64 01  64 12 9c 02 64 0a 65 20  |..Z$d.d.d...d.e |
00000190  64 0b 65 07 65 21 19 00  00 00 64 0c 65 07 65 21  |d.e.e!....d.e.e!|
000001a0  19 00 00 00 64 0d 65 1e  65 1f 19 00 00 00 66 08  |....d.e.e.....f.|
000001b0  64 13 84 06 5a 25 64 0a  65 20 64 0f 65 21 64 0d  |d...Z%d.e d.e!d.|
000001c0  65 1e 65 19 19 00 00 00  66 06 64 14 84 04 5a 26  |e.e.....f.d...Z&|
000001d0  79 01 29 15 e9 00 00 00  00 4e 29 07 da 08 43 61  |y.)......N)...Ca|
000001e0  6c 6c 61 62 6c 65 da 09  47 65 6e 65 72 61 74 6f  |llable..Generato|
000001f0  72 da 08 49 74 65 72 61  62 6c 65 da 08 49 74 65  |r..Iterable..Ite|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/progress_bars.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/req_command.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 13K 2025-06-01 01:30:27.755978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/req_command.cpython-312.pyc
e591485457e8aa04695917a837c18514695e2a30fc0215044b6cf18cecdd1aad  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/req_command.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 86 32 00 00  |........i.8h.2..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 c0 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 04  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 01 64 05 6c 06 6d 07  5a 07 6d 08 5a 08 6d 09  |d.d.l.m.Z.m.Z.m.|
00000060  5a 09 6d 0a 5a 0a 01 00  64 01 64 06 6c 0b 6d 0c  |Z.m.Z...d.d.l.m.|
00000070  5a 0c 01 00 64 01 64 07  6c 0d 6d 0e 5a 0e 01 00  |Z...d.d.l.m.Z...|
00000080  64 01 64 08 6c 0f 6d 10  5a 10 01 00 64 01 64 09  |d.d.l.m.Z...d.d.|
00000090  6c 0f 6d 11 5a 11 01 00  64 01 64 0a 6c 12 6d 13  |l.m.Z...d.d.l.m.|
000000a0  5a 13 6d 14 5a 14 01 00  64 01 64 0b 6c 15 6d 16  |Z.m.Z...d.d.l.m.|
000000b0  5a 16 01 00 64 01 64 0c  6c 17 6d 18 5a 18 01 00  |Z...d.d.l.m.Z...|
000000c0  64 01 64 0d 6c 19 6d 1a  5a 1a 01 00 64 01 64 0e  |d.d.l.m.Z...d.d.|
000000d0  6c 1b 6d 1c 5a 1c 01 00  64 01 64 0f 6c 1d 6d 1e  |l.m.Z...d.d.l.m.|
000000e0  5a 1e 01 00 64 01 64 10  6c 1f 6d 20 5a 20 01 00  |Z...d.d.l.m Z ..|
000000f0  64 01 64 11 6c 21 6d 22  5a 22 01 00 64 01 64 12  |d.d.l!m"Z"..d.d.|
00000100  6c 23 6d 24 5a 24 6d 25  5a 25 6d 26 5a 26 6d 27  |l#m$Z$m%Z%m&Z&m'|
00000110  5a 27 01 00 64 01 64 13  6c 28 6d 29 5a 29 01 00  |Z'..d.d.l(m)Z)..|
00000120  64 01 64 14 6c 2a 6d 2b  5a 2b 01 00 64 01 64 15  |d.d.l*m+Z+..d.d.|
00000130  6c 2c 6d 2d 5a 2d 01 00  64 01 64 16 6c 2e 6d 2f  |l,m-Z-..d.d.l.m/|
00000140  5a 2f 01 00 64 01 64 17  6c 30 6d 31 5a 31 6d 32  |Z/..d.d.l0m1Z1m2|
00000150  5a 32 6d 33 5a 33 01 00  02 00 65 01 6a 68 00 00  |Z2m3Z3....e.jh..|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000170  65 35 ab 01 00 00 00 00  00 00 5a 36 65 33 6a 6e  |e5........Z6e3jn|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  00 00 65 33 6a 70 00 00  00 00 00 00 00 00 00 00  |..e3jp..........|
000001a0  00 00 00 00 00 00 00 00  65 33 6a 72 00 00 00 00  |........e3jr....|
000001b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 67 03  |..............g.|
000001c0  5a 3a 64 18 65 07 64 19  65 07 66 04 64 1a 84 04  |Z:d.e.d.e.f.d...|
000001d0  5a 3b 02 00 47 00 64 1b  84 00 64 1c 65 10 ab 03  |Z;..G.d...d.e...|
000001e0  00 00 00 00 00 00 5a 3c  79 02 29 1d 7a f0 43 6f  |......Z<y.).z.Co|
000001f0  6e 74 61 69 6e 73 20 74  68 65 20 52 65 71 75 69  |ntains the Requi|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/req_command.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/spinners.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.7K 2025-06-01 01:30:27.919978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/spinners.cpython-312.pyc
35f5ad9462479f92c2d2166ea05753aef71d895652a569b53ed3851bef966493  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/spinners.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 fe 13 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 4c 01  00 00 97 00 64 00 64 01  |......L.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 02  6c 05 6d 06 5a 06 6d 07  |l.Z.d.d.l.m.Z.m.|
00000060  5a 07 6d 08 5a 08 01 00  64 00 64 03 6c 09 6d 0a  |Z.m.Z...d.d.l.m.|
00000070  5a 0a 01 00 64 00 64 04  6c 0b 6d 0c 5a 0c 01 00  |Z...d.d.l.m.Z...|
00000080  02 00 65 02 6a 1a 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
00000090  00 00 00 00 00 00 00 00  65 0e ab 01 00 00 00 00  |........e.......|
000000a0  00 00 5a 0f 02 00 47 00  64 05 84 00 64 06 ab 02  |..Z...G.d...d...|
000000b0  00 00 00 00 00 00 5a 10  02 00 47 00 64 07 84 00  |......Z...G.d...|
000000c0  64 08 65 10 ab 03 00 00  00 00 00 00 5a 11 02 00  |d.e.........Z...|
000000d0  47 00 64 09 84 00 64 0a  65 10 ab 03 00 00 00 00  |G.d...d.e.......|
000000e0  00 00 5a 12 02 00 47 00  64 0b 84 00 64 0c ab 02  |..Z...G.d...d...|
000000f0  00 00 00 00 00 00 5a 13  65 00 6a 28 00 00 00 00  |......Z.e.j(....|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 0d  |..............d.|
00000110  65 15 64 0e 65 07 65 10  64 01 64 01 66 03 19 00  |e.d.e.e.d.d.f...|
00000120  00 00 66 04 64 0f 84 04  ab 00 00 00 00 00 00 00  |..f.d...........|
00000130  5a 16 64 10 5a 17 64 11  5a 18 65 00 6a 28 00 00  |Z.d.Z.d.Z.e.j(..|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  64 12 65 06 65 15 19 00  00 00 64 0e 65 07 64 13  |d.e.e.....d.e.d.|
00000160  19 00 00 00 66 04 64 14  84 04 ab 00 00 00 00 00  |....f.d.........|
00000170  00 00 5a 19 79 01 29 15  e9 00 00 00 00 4e 29 03  |..Z.y.)......N).|
00000180  da 02 49 4f da 09 47 65  6e 65 72 61 74 6f 72 da  |..IO..Generator.|
00000190  08 4f 70 74 69 6f 6e 61  6c 29 01 da 07 57 49 4e  |.Optional)...WIN|
000001a0  44 4f 57 53 29 01 da 0f  67 65 74 5f 69 6e 64 65  |DOWS)...get_inde|
000001b0  6e 74 61 74 69 6f 6e 63  00 00 00 00 00 00 00 00  |ntationc........|
000001c0  00 00 00 00 04 00 00 00  00 00 00 00 f3 24 00 00  |.............$..|
000001d0  00 97 00 65 00 5a 01 64  00 5a 02 64 06 64 03 84  |...e.Z.d.Z.d.d..|
000001e0  04 5a 03 64 04 65 04 64  01 64 02 66 04 64 05 84  |.Z.d.e.d.d.f.d..|
000001f0  04 5a 05 79 02 29 07 da  10 53 70 69 6e 6e 65 72  |.Z.y.)...Spinner|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/spinners.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/status_codes.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 425 2025-06-01 01:30:28.079978087 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/status_codes.cpython-312.pyc
bbd8bcee870c3aa4e6eb63131a43d277888cbd6e06635e9a4c71fcb77dee385e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/status_codes.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 74 00 00 00  |........i.8ht...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 1c 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 5a 01 64 02 5a 02  64 03 5a 03 64 04 5a 04  |d.Z.d.Z.d.Z.d.Z.|
00000040  64 05 5a 05 79 06 29 07  e9 00 00 00 00 e9 01 00  |d.Z.y.).........|
00000050  00 00 e9 02 00 00 00 e9  03 00 00 00 e9 04 00 00  |................|
00000060  00 e9 17 00 00 00 4e 29  06 da 07 53 55 43 43 45  |......N)...SUCCE|
00000070  53 53 da 05 45 52 52 4f  52 da 0d 55 4e 4b 4e 4f  |SS..ERROR..UNKNO|
00000080  57 4e 5f 45 52 52 4f 52  da 14 56 49 52 54 55 41  |WN_ERROR..VIRTUA|
00000090  4c 45 4e 56 5f 4e 4f 54  5f 46 4f 55 4e 44 da 18  |LENV_NOT_FOUND..|
000000a0  50 52 45 56 49 4f 55 53  5f 42 55 49 4c 44 5f 44  |PREVIOUS_BUILD_D|
000000b0  49 52 5f 45 52 52 4f 52  da 10 4e 4f 5f 4d 41 54  |IR_ERROR..NO_MAT|
000000c0  43 48 45 53 5f 46 4f 55  4e 44 a9 00 f3 00 00 00  |CHES_FOUND......|
000000d0  00 fa 93 2f 64 61 74 61  2f 64 61 74 61 2f 63 6f  |.../data/data/co|
000000e0  6d 2e 74 65 72 6d 75 78  2f 66 69 6c 65 73 2f 68  |m.termux/files/h|
000000f0  6f 6d 65 2f 52 41 46 41  45 4c 49 41 2f 48 43 50  |ome/RAFAELIA/HCP|
00000100  4d 2f 43 4f 52 45 2f 52  41 46 41 45 4c 49 41 2f  |M/CORE/RAFAELIA/|
00000110  48 43 50 4d 2f 43 4f 52  45 2f 76 65 6e 76 5f 72  |HCPM/CORE/venv_r|
00000120  61 66 61 65 6c 69 61 2f  6c 69 62 2f 70 79 74 68  |afaelia/lib/pyth|
00000130  6f 6e 33 2e 31 32 2f 73  69 74 65 2d 70 61 63 6b  |on3.12/site-pack|
00000140  61 67 65 73 2f 70 69 70  2f 5f 69 6e 74 65 72 6e  |ages/pip/_intern|
00000150  61 6c 2f 63 6c 69 2f 73  74 61 74 75 73 5f 63 6f  |al/cli/status_co|
00000160  64 65 73 2e 70 79 da 08  3c 6d 6f 64 75 6c 65 3e  |des.py..<module>|
00000170  72 11 00 00 00 01 00 00  00 73 26 00 00 00 f0 03  |r........s&.....|
00000180  01 01 01 d8 0a 0b 80 07  d8 08 09 80 05 d8 10 11  |................|
00000190  80 0d d8 17 18 d0 00 14  d8 1b 1c d0 00 18 d8 13  |................|
000001a0  15 d1 00 10 72 0f 00 00  00                       |....r....|
000001a9
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/cli/__pycache__/status_codes.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.1K 2025-06-01 01:30:28.239978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc
9bc1cc294a662203d7f7f9eb37de37ac85591ae418101627af2981aa8d666a56  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 a9 0f 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 20 02  00 00 97 00 55 00 64 00  |...... .....U.d.|
00000030  5a 00 64 01 64 02 6c 01  5a 01 64 01 64 03 6c 02  |Z.d.d.l.Z.d.d.l.|
00000040  6d 03 5a 03 01 00 64 01  64 04 6c 04 6d 05 5a 05  |m.Z...d.d.l.m.Z.|
00000050  6d 06 5a 06 6d 07 5a 07  01 00 64 01 64 05 6c 08  |m.Z.m.Z...d.d.l.|
00000060  6d 09 5a 09 01 00 02 00  65 03 64 06 64 07 ab 02  |m.Z.....e.d.d...|
00000070  00 00 00 00 00 00 5a 0a  69 00 64 08 02 00 65 0a  |......Z.i.d...e.|
00000080  64 09 64 0a 64 0b ab 03  00 00 00 00 00 00 93 01  |d.d.d...........|
00000090  64 0c 02 00 65 0a 64 0d  64 0e 64 0f ab 03 00 00  |d...e.d.d.d.....|
000000a0  00 00 00 00 93 01 64 10  02 00 65 0a 64 11 64 12  |......d...e.d.d.|
000000b0  64 13 ab 03 00 00 00 00  00 00 93 01 64 14 02 00  |d...........d...|
000000c0  65 0a 64 15 64 16 64 17  ab 03 00 00 00 00 00 00  |e.d.d.d.........|
000000d0  93 01 64 18 02 00 65 0a  64 19 64 1a 64 1b ab 03  |..d...e.d.d.d...|
000000e0  00 00 00 00 00 00 93 01  64 1c 02 00 65 0a 64 1d  |........d...e.d.|
000000f0  64 1e 64 1f ab 03 00 00  00 00 00 00 93 01 64 20  |d.d...........d |
00000100  02 00 65 0a 64 21 64 22  64 23 ab 03 00 00 00 00  |..e.d!d"d#......|
00000110  00 00 93 01 64 24 02 00  65 0a 64 25 64 26 64 27  |....d$..e.d%d&d'|
00000120  ab 03 00 00 00 00 00 00  93 01 64 28 02 00 65 0a  |..........d(..e.|
00000130  64 29 64 2a 64 2b ab 03  00 00 00 00 00 00 93 01  |d)d*d+..........|
00000140  64 2c 02 00 65 0a 64 2d  64 2e 64 2f ab 03 00 00  |d,..e.d-d.d/....|
00000150  00 00 00 00 93 01 64 30  02 00 65 0a 64 31 64 32  |......d0..e.d1d2|
00000160  64 33 ab 03 00 00 00 00  00 00 93 01 64 34 02 00  |d3..........d4..|
00000170  65 0a 64 35 64 36 64 37  ab 03 00 00 00 00 00 00  |e.d5d6d7........|
00000180  93 01 64 38 02 00 65 0a  64 39 64 3a 64 3b ab 03  |..d8..e.d9d:d;..|
00000190  00 00 00 00 00 00 93 01  64 3c 02 00 65 0a 64 3d  |........d<..e.d=|
000001a0  64 3e 64 3f ab 03 00 00  00 00 00 00 93 01 64 40  |d>d?..........d@|
000001b0  02 00 65 0a 64 41 64 42  64 43 ab 03 00 00 00 00  |..e.dAdBdC......|
000001c0  00 00 93 01 64 44 02 00  65 0a 64 45 64 46 64 47  |....dD..e.dEdFdG|
000001d0  ab 03 00 00 00 00 00 00  93 01 64 48 02 00 65 0a  |..........dH..e.|
000001e0  64 49 64 4a 64 4b ab 03  00 00 00 00 00 00 93 01  |dIdJdK..........|
000001f0  64 4c 02 00 65 0a 64 4d  64 4e 64 4f ab 03 00 00  |dL..e.dMdNdO....|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.8K 2025-06-01 01:30:28.399978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc
6e1316ffd41af469c1d5db5c6a43f4865d46012c8bfb8687c14f49016125351b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 ab 1f 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 a6 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 6d 06 5a 06 01 00  64 00 64 04 6c 07 6d 08  |Z.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 00 64 05  6c 09 6d 0a 5a 0a 6d 0b  |Z...d.d.l.m.Z.m.|
00000070  5a 0b 01 00 64 00 64 06  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 01 00 64 00 64 07  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 08 6c 11 6d 12  5a 12 01 00 64 00 64 09  |d.d.l.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 01 00  02 00 65 12 65 15 ab 01  |l.m.Z.....e.e...|
000000b0  00 00 00 00 00 00 5a 16  02 00 47 00 64 0a 84 00  |......Z...G.d...|
000000c0  64 0b 65 08 ab 03 00 00  00 00 00 00 5a 17 79 01  |d.e.........Z.y.|
000000d0  29 0c e9 00 00 00 00 4e  29 01 da 06 56 61 6c 75  |)......N)...Valu|
000000e0  65 73 29 02 da 03 41 6e  79 da 04 4c 69 73 74 29  |es)...Any..List)|
000000f0  01 da 07 43 6f 6d 6d 61  6e 64 29 02 da 05 45 52  |...Command)...ER|
00000100  52 4f 52 da 07 53 55 43  43 45 53 53 29 02 da 0c  |ROR..SUCCESS)...|
00000110  43 6f 6d 6d 61 6e 64 45  72 72 6f 72 da 08 50 69  |CommandError..Pi|
00000120  70 45 72 72 6f 72 29 01  da 0a 66 69 6c 65 73 79  |pError)...filesy|
00000130  73 74 65 6d 29 01 da 09  67 65 74 4c 6f 67 67 65  |stem)...getLogge|
00000140  72 29 01 da 0b 66 6f 72  6d 61 74 5f 73 69 7a 65  |r)...format_size|
00000150  63 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |c...............|
00000160  00 00 00 00 00 f3 2c 01  00 00 97 00 65 00 5a 01  |......,.....e.Z.|
00000170  64 00 5a 02 64 01 5a 03  64 02 5a 04 64 03 5a 05  |d.Z.d.Z.d.Z.d.Z.|
00000180  64 17 64 06 84 04 5a 06  64 07 65 07 64 08 65 08  |d.d...Z.d.e.d.e.|
00000190  65 09 19 00 00 00 64 04  65 0a 66 06 64 09 84 04  |e.....d.e.f.d...|
000001a0  5a 0b 64 07 65 07 64 08  65 08 65 0c 19 00 00 00  |Z.d.e.d.e.e.....|
000001b0  64 04 64 05 66 06 64 0a  84 04 5a 0d 64 07 65 07  |d.d.f.d...Z.d.e.|
000001c0  64 08 65 08 65 0c 19 00  00 00 64 04 64 05 66 06  |d.e.e.....d.d.f.|
000001d0  64 0b 84 04 5a 0e 64 07  65 07 64 08 65 08 65 0c  |d...Z.d.e.d.e.e.|
000001e0  19 00 00 00 64 04 64 05  66 06 64 0c 84 04 5a 0f  |....d.d.f.d...Z.|
000001f0  64 0d 65 08 65 09 19 00  00 00 64 04 64 05 66 04  |d.e.e.....d.d.f.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/cache.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.6K 2025-06-01 01:30:28.559978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc
35b3ce9b94a1ab9637c42507d99c79d23b58ea39bc0a21ae420bfbc1a9a30fdd  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 dc 08 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 b2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 00 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 6d 09 5a 09 01 00  64 00 64 06 6c 0a 6d 0b  |Z.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 00 64 07  6c 0c 6d 0d 5a 0d 6d 0e  |Z...d.d.l.m.Z.m.|
00000080  5a 0e 6d 0f 5a 0f 01 00  64 00 64 08 6c 10 6d 11  |Z.m.Z...d.d.l.m.|
00000090  5a 11 01 00 64 00 64 09  6c 12 6d 13 5a 13 01 00  |Z...d.d.l.m.Z...|
000000a0  02 00 65 00 6a 28 00 00  00 00 00 00 00 00 00 00  |..e.j(..........|
000000b0  00 00 00 00 00 00 00 00  65 15 ab 01 00 00 00 00  |........e.......|
000000c0  00 00 5a 16 02 00 47 00  64 0a 84 00 64 0b 65 06  |..Z...G.d...d.e.|
000000d0  ab 03 00 00 00 00 00 00  5a 17 79 01 29 0c e9 00  |........Z.y.)...|
000000e0  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 01  |...N)...Values).|
000000f0  da 04 4c 69 73 74 29 01  da 07 43 6f 6d 6d 61 6e  |..List)...Comman|
00000100  64 29 02 da 05 45 52 52  4f 52 da 07 53 55 43 43  |d)...ERROR..SUCC|
00000110  45 53 53 29 01 da 17 67  65 74 5f 64 65 66 61 75  |ESS)...get_defau|
00000120  6c 74 5f 65 6e 76 69 72  6f 6e 6d 65 6e 74 29 03  |lt_environment).|
00000130  da 11 63 68 65 63 6b 5f  70 61 63 6b 61 67 65 5f  |..check_package_|
00000140  73 65 74 da 11 63 68 65  63 6b 5f 75 6e 73 75 70  |set..check_unsup|
00000150  70 6f 72 74 65 64 da 21  63 72 65 61 74 65 5f 70  |ported.!create_p|
00000160  61 63 6b 61 67 65 5f 73  65 74 5f 66 72 6f 6d 5f  |ackage_set_from_|
00000170  69 6e 73 74 61 6c 6c 65  64 29 01 da 0d 67 65 74  |installed)...get|
00000180  5f 73 75 70 70 6f 72 74  65 64 29 01 da 0c 77 72  |_supported)...wr|
00000190  69 74 65 5f 6f 75 74 70  75 74 63 00 00 00 00 00  |ite_outputc.....|
000001a0  00 00 00 00 00 00 00 06  00 00 00 00 00 00 00 f3  |................|
000001b0  32 00 00 00 97 00 65 00  5a 01 64 00 5a 02 64 01  |2.....e.Z.d.Z.d.|
000001c0  5a 03 64 02 5a 04 64 03  5a 05 64 04 65 06 64 05  |Z.d.Z.d.Z.d.e.d.|
000001d0  65 07 65 08 19 00 00 00  64 06 65 09 66 06 64 07  |e.e.....d.e.f.d.|
000001e0  84 04 5a 0a 79 08 29 09  da 0c 43 68 65 63 6b 43  |..Z.y.)...CheckC|
000001f0  6f 6d 6d 61 6e 64 7a 37  56 65 72 69 66 79 20 69  |ommandz7Verify i|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/check.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.4K 2025-06-01 01:30:28.719978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc
c9af07ada3eb7461d47af2e61e13daaf36e64cc8a4a36fb19419348190d198ae  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 ca 11 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 78 00  00 00 97 00 64 00 64 01  |......x.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 05 6c 08 6d 09  5a 09 01 00 64 00 64 06  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 01 00  64 07 5a 0c 64 08 64 09  |l.m.Z...d.Z.d.d.|
00000080  64 0a 64 0b 64 0c 9c 04  5a 0d 02 00 47 00 64 0d  |d.d.d...Z...G.d.|
00000090  84 00 64 0e 65 07 ab 03  00 00 00 00 00 00 5a 0e  |..d.e.........Z.|
000000a0  79 01 29 0f e9 00 00 00  00 4e 29 01 da 06 56 61  |y.)......N)...Va|
000000b0  6c 75 65 73 29 01 da 04  4c 69 73 74 29 01 da 07  |lues)...List)...|
000000c0  43 6f 6d 6d 61 6e 64 29  01 da 07 53 55 43 43 45  |Command)...SUCCE|
000000d0  53 53 29 01 da 08 67 65  74 5f 70 72 6f 67 7a 44  |SS)...get_progzD|
000000e0  0a 23 20 70 69 70 20 7b  73 68 65 6c 6c 7d 20 63  |.# pip {shell} c|
000000f0  6f 6d 70 6c 65 74 69 6f  6e 20 73 74 61 72 74 7b  |ompletion start{|
00000100  73 63 72 69 70 74 7d 23  20 70 69 70 20 7b 73 68  |script}# pip {sh|
00000110  65 6c 6c 7d 20 63 6f 6d  70 6c 65 74 69 6f 6e 20  |ell} completion |
00000120  65 6e 64 0a 61 1e 01 00  00 0a 20 20 20 20 20 20  |end.a.....      |
00000130  20 20 5f 70 69 70 5f 63  6f 6d 70 6c 65 74 69 6f  |  _pip_completio|
00000140  6e 28 29 0a 20 20 20 20  20 20 20 20 7b 7b 0a 20  |n().        {{. |
00000150  20 20 20 20 20 20 20 20  20 20 20 43 4f 4d 50 52  |           COMPR|
00000160  45 50 4c 59 3d 28 20 24  28 20 43 4f 4d 50 5f 57  |EPLY=( $( COMP_W|
00000170  4f 52 44 53 3d 22 24 7b  7b 43 4f 4d 50 5f 57 4f  |ORDS="${{COMP_WO|
00000180  52 44 53 5b 2a 5d 7d 7d  22 20 5c 0a 20 20 20 20  |RDS[*]}}" \.    |
00000190  20 20 20 20 20 20 20 20  20 20 20 20 20 20 20 20  |                |
000001a0  20 20 20 20 20 20 20 43  4f 4d 50 5f 43 57 4f 52  |       COMP_CWOR|
000001b0  44 3d 24 43 4f 4d 50 5f  43 57 4f 52 44 20 5c 0a  |D=$COMP_CWORD \.|
000001c0  20 20 20 20 20 20 20 20  20 20 20 20 20 20 20 20  |                |
000001d0  20 20 20 20 20 20 20 20  20 20 20 50 49 50 5f 41  |           PIP_A|
000001e0  55 54 4f 5f 43 4f 4d 50  4c 45 54 45 3d 31 20 24  |UTO_COMPLETE=1 $|
000001f0  31 20 32 3e 2f 64 65 76  2f 6e 75 6c 6c 20 29 20  |1 2>/dev/null ) |
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/completion.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 13K 2025-06-01 01:30:28.879978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc
e23f67ab4930ccc5ae3ecc3f38c21bb5cc5a8e0f3ff7977d57cd2fe54a8e5977  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 26 26 00 00  |........i.8h&&..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 02  6c 03 6d 04 5a 04 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 00 64 03 6c 05 6d 06  5a 06 6d 07 5a 07 6d 08  |d.d.l.m.Z.m.Z.m.|
00000060  5a 08 01 00 64 00 64 04  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 00 64 05 6c 0b 6d 0c  5a 0c 6d 0d 5a 0d 01 00  |d.d.l.m.Z.m.Z...|
00000080  64 00 64 06 6c 0e 6d 0f  5a 0f 6d 10 5a 10 6d 11  |d.d.l.m.Z.m.Z.m.|
00000090  5a 11 6d 12 5a 12 01 00  64 00 64 07 6c 13 6d 14  |Z.m.Z...d.d.l.m.|
000000a0  5a 14 01 00 64 00 64 08  6c 15 6d 16 5a 16 01 00  |Z...d.d.l.m.Z...|
000000b0  64 00 64 09 6c 17 6d 18  5a 18 6d 19 5a 19 01 00  |d.d.l.m.Z.m.Z...|
000000c0  02 00 65 00 6a 34 00 00  00 00 00 00 00 00 00 00  |..e.j4..........|
000000d0  00 00 00 00 00 00 00 00  65 1b ab 01 00 00 00 00  |........e.......|
000000e0  00 00 5a 1c 02 00 47 00  64 0a 84 00 64 0b 65 0a  |..Z...G.d...d.e.|
000000f0  ab 03 00 00 00 00 00 00  5a 1d 79 01 29 0c e9 00  |........Z.y.)...|
00000100  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 03  |...N)...Values).|
00000110  da 03 41 6e 79 da 04 4c  69 73 74 da 08 4f 70 74  |..Any..List..Opt|
00000120  69 6f 6e 61 6c 29 01 da  07 43 6f 6d 6d 61 6e 64  |ional)...Command|
00000130  29 02 da 05 45 52 52 4f  52 da 07 53 55 43 43 45  |)...ERROR..SUCCE|
00000140  53 53 29 04 da 0d 43 6f  6e 66 69 67 75 72 61 74  |SS)...Configurat|
00000150  69 6f 6e da 04 4b 69 6e  64 da 17 67 65 74 5f 63  |ion..Kind..get_c|
00000160  6f 6e 66 69 67 75 72 61  74 69 6f 6e 5f 66 69 6c  |onfiguration_fil|
00000170  65 73 da 05 6b 69 6e 64  73 29 01 da 08 50 69 70  |es..kinds)...Pip|
00000180  45 72 72 6f 72 29 01 da  0a 69 6e 64 65 6e 74 5f  |Error)...indent_|
00000190  6c 6f 67 29 02 da 08 67  65 74 5f 70 72 6f 67 da  |log)...get_prog.|
000001a0  0c 77 72 69 74 65 5f 6f  75 74 70 75 74 63 00 00  |.write_outputc..|
000001b0  00 00 00 00 00 00 00 00  00 00 08 00 00 00 00 00  |................|
000001c0  00 00 f3 3e 01 00 00 97  00 65 00 5a 01 64 00 5a  |...>.....e.Z.d.Z|
000001d0  02 64 01 5a 03 64 02 5a  04 64 03 5a 05 64 1a 64  |.d.Z.d.Z.d.Z.d.d|
000001e0  06 84 04 5a 06 64 07 65  07 64 08 65 08 65 09 19  |...Z.d.e.d.e.e..|
000001f0  00 00 00 64 04 65 0a 66  06 64 09 84 04 5a 0b 64  |...d.e.f.d...Z.d|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/configuration.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.9K 2025-06-01 01:30:29.043978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc
cf72b853d5b3492b3449964c9c69a7b8c03401790d2c6f98814d0e4bdbe3241f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 8d 1a 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 ba 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 6d 05 5a 05 01 00  64 00 64 03 6c 06 6d 07  |l.m.Z...d.d.l.m.|
00000060  5a 07 01 00 64 00 64 04  6c 08 6d 09 5a 09 6d 0a  |Z...d.d.l.m.Z.m.|
00000070  5a 0a 6d 0b 5a 0b 6d 0c  5a 0c 01 00 64 00 64 01  |Z.m.Z.m.Z...d.d.|
00000080  6c 0d 5a 0e 64 00 64 05  6c 0f 6d 10 5a 10 01 00  |l.Z.d.d.l.m.Z...|
00000090  64 00 64 06 6c 11 6d 12  5a 13 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000a0  6c 14 6d 15 5a 15 01 00  64 00 64 08 6c 16 6d 17  |l.m.Z...d.d.l.m.|
000000b0  5a 17 01 00 64 00 64 09  6c 18 6d 19 5a 19 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 0a 6c 1a 6d 1b  5a 1b 01 00 64 00 64 0b  |d.d.l.m.Z...d.d.|
000000d0  6c 1c 6d 1d 5a 1d 01 00  64 00 64 0c 6c 1e 6d 1f  |l.m.Z...d.d.l.m.|
000000e0  5a 1f 01 00 64 00 64 0d  6c 20 6d 21 5a 21 01 00  |Z...d.d.l m!Z!..|
000000f0  64 00 64 0e 6c 22 6d 23  5a 23 01 00 64 00 64 0f  |d.d.l"m#Z#..d.d.|
00000100  6c 24 6d 25 5a 25 01 00  02 00 65 01 6a 4c 00 00  |l$m%Z%....e.jL..|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000120  65 27 ab 01 00 00 00 00  00 00 5a 28 64 10 65 29  |e'........Z(d.e)|
00000130  64 11 65 09 64 12 64 01  66 06 64 13 84 04 5a 2a  |d.e.d.d.f.d...Z*|
00000140  64 22 64 14 84 04 5a 2b  64 12 65 0a 65 29 65 29  |d"d...Z+d.e.e)e)|
00000150  66 02 19 00 00 00 66 02  64 15 84 04 5a 2c 64 16  |f.....f.d...Z,d.|
00000160  65 29 64 12 65 0c 65 07  19 00 00 00 66 04 64 17  |e)d.e.e.....f.d.|
00000170  84 04 5a 2d 64 16 65 29  64 12 65 0c 65 29 19 00  |..Z-d.e)d.e.e)..|
00000180  00 00 66 04 64 18 84 04  5a 2e 64 19 65 0a 65 29  |..f.d...Z.d.e.e)|
00000190  65 29 66 02 19 00 00 00  64 12 64 01 66 04 64 1a  |e)f.....d.d.f.d.|
000001a0  84 04 5a 2f 64 22 64 1b  84 04 5a 30 64 1c 65 05  |..Z/d"d...Z0d.e.|
000001b0  64 12 64 01 66 04 64 1d  84 04 5a 31 64 1e 65 1d  |d.d.f.d...Z1d.e.|
000001c0  64 12 65 29 66 04 64 1f  84 04 5a 32 02 00 47 00  |d.e)f.d...Z2..G.|
000001d0  64 20 84 00 64 21 65 17  ab 03 00 00 00 00 00 00  |d ..d!e.........|
000001e0  5a 33 79 01 29 23 e9 00  00 00 00 4e 29 01 da 06  |Z3y.)#.....N)...|
000001f0  56 61 6c 75 65 73 29 01  da 0a 4d 6f 64 75 6c 65  |Values)...Module|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/debug.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.4K 2025-06-01 01:30:29.191978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc
8ec2ba31c4c9ede1705a554699c37b0a8521ace18806b3e51315aab4e1d5b7b0  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 99 14 00 00  |........i.8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 d2 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 05 6c 08 6d 09  5a 09 01 00 64 00 64 06  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 6d 0c  5a 0c 01 00 64 00 64 07  |l.m.Z.m.Z...d.d.|
00000080  6c 0d 6d 0e 5a 0e 01 00  64 00 64 08 6c 0f 6d 10  |l.m.Z...d.d.l.m.|
00000090  5a 10 01 00 64 00 64 09  6c 11 6d 12 5a 12 01 00  |Z...d.d.l.m.Z...|
000000a0  64 00 64 0a 6c 13 6d 14  5a 14 6d 15 5a 15 6d 16  |d.d.l.m.Z.m.Z.m.|
000000b0  5a 16 01 00 64 00 64 0b  6c 17 6d 18 5a 18 01 00  |Z...d.d.l.m.Z...|
000000c0  02 00 65 00 6a 32 00 00  00 00 00 00 00 00 00 00  |..e.j2..........|
000000d0  00 00 00 00 00 00 00 00  65 1a ab 01 00 00 00 00  |........e.......|
000000e0  00 00 5a 1b 02 00 47 00  64 0c 84 00 64 0d 65 0b  |..Z...G.d...d.e.|
000000f0  ab 03 00 00 00 00 00 00  5a 1c 79 01 29 0e e9 00  |........Z.y.)...|
00000100  00 00 00 4e 29 01 da 06  56 61 6c 75 65 73 29 01  |...N)...Values).|
00000110  da 04 4c 69 73 74 29 01  da 0a 63 6d 64 6f 70 74  |..List)...cmdopt|
00000120  69 6f 6e 73 29 01 da 12  6d 61 6b 65 5f 74 61 72  |ions)...make_tar|
00000130  67 65 74 5f 70 79 74 68  6f 6e 29 02 da 12 52 65  |get_python)...Re|
00000140  71 75 69 72 65 6d 65 6e  74 43 6f 6d 6d 61 6e 64  |quirementCommand|
00000150  da 0c 77 69 74 68 5f 63  6c 65 61 6e 75 70 29 01  |..with_cleanup).|
00000160  da 07 53 55 43 43 45 53  53 29 01 da 11 67 65 74  |..SUCCESS)...get|
00000170  5f 62 75 69 6c 64 5f 74  72 61 63 6b 65 72 29 01  |_build_tracker).|
00000180  da 1d 63 68 65 63 6b 5f  6c 65 67 61 63 79 5f 73  |..check_legacy_s|
00000190  65 74 75 70 5f 70 79 5f  6f 70 74 69 6f 6e 73 29  |etup_py_options)|
000001a0  03 da 0a 65 6e 73 75 72  65 5f 64 69 72 da 0e 6e  |...ensure_dir..n|
000001b0  6f 72 6d 61 6c 69 7a 65  5f 70 61 74 68 da 0c 77  |ormalize_path..w|
000001c0  72 69 74 65 5f 6f 75 74  70 75 74 29 01 da 0d 54  |rite_output)...T|
000001d0  65 6d 70 44 69 72 65 63  74 6f 72 79 63 00 00 00  |empDirectoryc...|
000001e0  00 00 00 00 00 00 00 00  00 07 00 00 00 00 00 00  |................|
000001f0  00 f3 40 00 00 00 97 00  65 00 5a 01 64 00 5a 02  |..@.....e.Z.d.Z.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/download.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.3K 2025-06-01 01:30:29.351978086 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc
2e0fbe1960764ba187b79cac6524e18175684af0fa828e77127a8e49ce7b9ea1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/commands/__pycache__/freeze.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  69 a6 38 68 48 0c 00 00  |........i.8hH...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 98 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 03 6c 03 6d 04  5a 04 6d 05 5a 05 01 00  |d.d.l.m.Z.m.Z...|
00000050  64 00 64 04 6c 06 6d 07  5a 07 01 00 64 00 64 05  |d.d.l.m.Z...d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 00 64 06 6c 0a 6d 0b  |l.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 64 00 64 07  6c 0c 6d 0d 5a 0d 01 00  |Z...d.d.l.m.Z...|
00000080  64 00 64 08 6c 0e 6d 0f  5a 0f 01 00 64 09 65 10  |d.d.l.m.Z...d.e.|
00000090  66 02 64 0a 84 04 5a 11  64 09 65 04 65 12 19 00  |f.d...Z.d.e.e...|
000000a0  00 00 66 02 64 0b 84 04  5a 13 02 00 47 00 64 0c  |..f.d...Z...G.d.|
000000b0  84 00 64 0d 65 09 ab 03  00 00 00 00 00 00 5a 14  |..d.e.........Z.|
000000c0  79 01 29 0e e9 00 00 00  00 4e 29 01 da 06 56 61  |y.)......N)...Va|
000000d0  6c 75 65 73 29 02 da 0b  41 62 73 74 72 61 63 74  |lues)...Abstract|
000000e0  53 65 74 da 04 4c 69 73  74 29 01 da 0a 63 6d 64  |Set..List)...cmd|
000000f0  6f 70 74 69 6f 6e 73 29  01 da 07 43 6f 6d 6d 61  |options)...Comma|
00000100  6e 64 29 01 da 07 53 55  43 43 45 53 53 29 01 da  |nd)...SUCCESS)..|
00000110  06 66 72 65 65 7a 65 29  01 da 0b 73 74 64 6c 69  |.freeze)...stdli|
00000120  62 5f 70 6b 67 73 da 06  72 65 74 75 72 6e 63 00  |b_pkgs..returnc.|
00000130  00 00 00 00 00 00 00 00  00 00 00 02 00 00 00 03  |................|
00000140  00 00 00 f3 28 00 00 00  97 00 74 00 00 00 00 00  |....(.....t.....|
00000150  00 00 00 00 6a 02 00 00  00 00 00 00 00 00 00 00  |....j...........|
00000160  00 00 00 00 00 00 00 00  64 01 6b 02 00 00 53 00  |........d.k...S.|
00000170  29 02 4e 29 02 e9 03 00  00 00 e9 0c 00 00 00 29  |).N)...........)|
00000180  02 da 03 73 79 73 da 0c  76 65 72 73 69 6f 6e 5f  |...sys..version_|
00000190  69 6e 66 6f a9 00 f3 00  00 00 00 fa 92 2f 64 61  |info........./da|