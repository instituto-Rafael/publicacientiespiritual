#!/usr/bin/env python3
# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

import re
from typing import FrozenSet, NewType, Tuple, Union, cast

from .tags import Tag, parse_tag
from .version import InvalidVersion, Version

BuildTag = Union[Tuple[()], Tuple[int, str]]
NormalizedName = NewType("NormalizedName", str)


class InvalidName(ValueError):
    """
    An invalid distribution name; users should refer to the packaging user guide.
    """


class InvalidWheelFilename(ValueError):
    """
    An invalid wheel filename was found, users should refer to PEP 427.
    """


class InvalidSdistFilename(ValueError):
    """
    An invalid sdist filename was found, users should refer to the packaging user guide.
    """


# Core metadata spec for `Name`
_validate_regex = re.compile(
    r"^([A-Z0-9]|[A-Z0-9][A-Z0-9._-]*[A-Z0-9])$", re.IGNORECASE
)
_canonicalize_regex = re.compile(r"[-_.]+")
_normalized_regex = re.compile(r"^([a-z0-9]|[a-z0-9]([a-z0-9-](?!--))*[a-z0-9])$")
# PEP 427: The build number must start with a digit.
_build_tag_regex = re.compile(r"(\d+)(.*)")


def canonicalize_name(name: str, *, validate: bool = False) -> NormalizedName:
    if validate and not _validate_regex.match(name):
        raise InvalidName(f"name is invalid: {name!r}")
    # This is taken from PEP 503.
    value = _canonicalize_regex.sub("-", name).lower()
    return cast(NormalizedName, value)


def is_normalized_name(name: str) -> bool:
    return _normalized_regex.match(name) is not None


def canonicalize_version(
    version: Union[Version, str], *, strip_trailing_zero: bool = True
) -> str:
    """
    This is very similar to Version.__str__, but has one subtle difference
    with the way it handles the release segment.
    """
    if isinstance(version, str):
        try:
            parsed = Version(version)
        except InvalidVersion:
            # Legacy versions cannot be normalized
            return version
    else:
        parsed = version

    parts = []

    # Epoch
    if parsed.epoch != 0:
        parts.append(f"{parsed.epoch}!")

    # Release segment
    release_segment = ".".join(str(x) for x in parsed.release)
    if strip_trailing_zero:
        # NB: This strips trailing '.0's to normalize
        release_segment = re.sub(r"(\.0)+$", "", release_segment)
    parts.append(release_segment)

    # Pre-release
    if parsed.pre is not None:
        parts.append("".join(str(x) for x in parsed.pre))

    # Post-release
    if parsed.post is not None:
        parts.append(f".post{parsed.post}")

    # Development release
    if parsed.dev is not None:
        parts.append(f".dev{parsed.dev}")

    # Local version segment
    if parsed.local is not None:
        parts.append(f"+{parsed.local}")

    return "".join(parts)


def parse_wheel_filename(
    filename: str,
) -> Tuple[NormalizedName, Version, BuildTag, FrozenSet[Tag]]:
    if not filename.endswith(".whl"):
        raise InvalidWheelFilename(
            f"Invalid wheel filename (extension must be '.whl'): {filename}"
        )

    filename = filename[:-4]
    dashes = filename.count("-")
    if dashes not in (4, 5):
        raise InvalidWheelFilename(
            f"Invalid wheel filename (wrong number of parts): {filename}"
        )

    parts = filename.split("-", dashes - 2)
    name_part = parts[0]
    # See PEP 427 for the rules on escaping the project name.
    if "__" in name_part or re.match(r"^[\w\d._]*$", name_part, re.UNICODE) is None:
        raise InvalidWheelFilename(f"Invalid project name: {filename}")
    name = canonicalize_name(name_part)

    try:
        version = Version(parts[1])
    except InvalidVersion as e:
        raise InvalidWheelFilename(
            f"Invalid wheel filename (invalid version): {filename}"
        ) from e

    if dashes == 5:
        build_part = parts[2]
        build_match = _build_tag_regex.match(build_part)
        if build_match is None:
            raise InvalidWheelFilename(
                f"Invalid build number: {build_part} in '{filename}'"
            )
        build = cast(BuildTag, (int(build_match.group(1)), build_match.group(2)))
    else:
        build = ()
    tags = parse_tag(parts[-1])
    return (name, version, build, tags)


def parse_sdist_filename(filename: str) -> Tuple[NormalizedName, Version]:
    if filename.endswith(".tar.gz"):
        file_stem = filename[: -len(".tar.gz")]
    elif filename.endswith(".zip"):
        file_stem = filename[: -len(".zip")]
    else:
        raise InvalidSdistFilename(
            f"Invalid sdist filename (extension must be '.tar.gz' or '.zip'):"
            f" {filename}"
        )

    # We are requiring a PEP 440 version, which cannot contain dashes,
    # so we split on the last dash.
    name_part, sep, version_part = file_stem.rpartition("-")
    if not sep:
        raise InvalidSdistFilename(f"Invalid sdist filename: {filename}")

    name = canonicalize_name(name_part)

    try:
        version = Version(version_part)
    except InvalidVersion as e:
        raise InvalidSdistFilename(
            f"Invalid sdist filename (invalid version): {filename}"
        ) from e

    return (name, version)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/utils.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/version.py
-rwxrwxrwx. 1 u0_a292 u0_a292 16K 2025-05-25 17:08:57.436414720 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/version.py
3c525a6190f1060cb191f6211f7490c38a9f13d202096ad39a2b6fab5e32ddbb  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/version.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----
# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.
"""
.. testsetup::

    from packaging.version import parse, Version
"""

import itertools
import re
from typing import Any, Callable, NamedTuple, Optional, SupportsInt, Tuple, Union

from ._structures import Infinity, InfinityType, NegativeInfinity, NegativeInfinityType

__all__ = ["VERSION_PATTERN", "parse", "Version", "InvalidVersion"]

LocalType = Tuple[Union[int, str], ...]

CmpPrePostDevType = Union[InfinityType, NegativeInfinityType, Tuple[str, int]]
CmpLocalType = Union[
    NegativeInfinityType,
    Tuple[Union[Tuple[int, str], Tuple[NegativeInfinityType, Union[int, str]]], ...],
]
CmpKey = Tuple[
    int,
    Tuple[int, ...],
    CmpPrePostDevType,
    CmpPrePostDevType,
    CmpPrePostDevType,
    CmpLocalType,
]
VersionComparisonMethod = Callable[[CmpKey, CmpKey], bool]


class _Version(NamedTuple):
    epoch: int
    release: Tuple[int, ...]
    dev: Optional[Tuple[str, int]]
    pre: Optional[Tuple[str, int]]
    post: Optional[Tuple[str, int]]
    local: Optional[LocalType]


def parse(version: str) -> "Version":
    """Parse the given version string.

    >>> parse('1.0.dev1')
    <Version('1.0.dev1')>

    :param version: The version string to parse.
    :raises InvalidVersion: When the version string is not a valid version.
    """
    return Version(version)


class InvalidVersion(ValueError):
    """Raised when a version string is not a valid version.

    >>> Version("invalid")
    Traceback (most recent call last):
        ...
    packaging.version.InvalidVersion: Invalid version: 'invalid'
    """


class _BaseVersion:
    _key: Tuple[Any, ...]

    def __hash__(self) -> int:
        return hash(self._key)

    # Please keep the duplicated `isinstance` check
    # in the six comparisons hereunder
    # unless you find a way to avoid adding overhead function calls.
    def __lt__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key < other._key

    def __le__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key <= other._key

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key == other._key

    def __ge__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key >= other._key

    def __gt__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key > other._key

    def __ne__(self, other: object) -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key != other._key


# Deliberately not anchored to the start and end of the string, to make it
# easier for 3rd party code to reuse
_VERSION_PATTERN = r"""
    v?
    (?:
        (?:(?P<epoch>[0-9]+)!)?                           # epoch
        (?P<release>[0-9]+(?:\.[0-9]+)*)                  # release segment
        (?P<pre>                                          # pre-release
            [-_\.]?
            (?P<pre_l>alpha|a|beta|b|preview|pre|c|rc)
            [-_\.]?
            (?P<pre_n>[0-9]+)?
        )?
        (?P<post>                                         # post release
            (?:-(?P<post_n1>[0-9]+))
            |
            (?:
                [-_\.]?
                (?P<post_l>post|rev|r)
                [-_\.]?
                (?P<post_n2>[0-9]+)?
            )
        )?
        (?P<dev>                                          # dev release
            [-_\.]?
            (?P<dev_l>dev)
            [-_\.]?
            (?P<dev_n>[0-9]+)?
        )?
    )
    (?:\+(?P<local>[a-z0-9]+(?:[-_\.][a-z0-9]+)*))?       # local version
"""

VERSION_PATTERN = _VERSION_PATTERN
"""
A string containing the regular expression used to match a valid version.

The pattern is not anchored at either end, and is intended for embedding in larger
expressions (for example, matching a version number as part of a file name). The
regular expression should be compiled with the ``re.VERBOSE`` and ``re.IGNORECASE``
flags set.

:meta hide-value:
"""


class Version(_BaseVersion):
    """This class abstracts handling of a project's versions.

    A :class:`Version` instance is comparison aware and can be compared and
    sorted using the standard Python interfaces.

    >>> v1 = Version("1.0a5")
    >>> v2 = Version("1.0")
    >>> v1
    <Version('1.0a5')>
    >>> v2
    <Version('1.0')>
    >>> v1 < v2
    True
    >>> v1 == v2
    False
    >>> v1 > v2
    False
    >>> v1 >= v2
    False
    >>> v1 <= v2
    True
    """

    _regex = re.compile(r"^\s*" + VERSION_PATTERN + r"\s*$", re.VERBOSE | re.IGNORECASE)
    _key: CmpKey

    def __init__(self, version: str) -> None:
        """Initialize a Version object.

        :param version:
            The string representation of a version which will be parsed and normalized
            before use.
        :raises InvalidVersion:
            If the ``version`` does not conform to PEP 440 in any way then this
            exception will be raised.
        """

        # Validate the version and parse it into pieces
        match = self._regex.search(version)
        if not match:
            raise InvalidVersion(f"Invalid version: '{version}'")

        # Store the parsed out pieces of the version
        self._version = _Version(
            epoch=int(match.group("epoch")) if match.group("epoch") else 0,
            release=tuple(int(i) for i in match.group("release").split(".")),
            pre=_parse_letter_version(match.group("pre_l"), match.group("pre_n")),
            post=_parse_letter_version(
                match.group("post_l"), match.group("post_n1") or match.group("post_n2")
            ),
            dev=_parse_letter_version(match.group("dev_l"), match.group("dev_n")),
            local=_parse_local_version(match.group("local")),
        )

        # Generate a key which will be used for sorting
        self._key = _cmpkey(
            self._version.epoch,
            self._version.release,
            self._version.pre,
            self._version.post,
            self._version.dev,
            self._version.local,
        )

    def __repr__(self) -> str:
        """A representation of the Version that shows all internal state.

        >>> Version('1.0.0')
        <Version('1.0.0')>
        """
        return f"<Version('{self}')>"

    def __str__(self) -> str:
        """A string representation of the version that can be rounded-tripped.

        >>> str(Version("1.0a5"))
        '1.0a5'
        """
        parts = []

        # Epoch
        if self.epoch != 0:
            parts.append(f"{self.epoch}!")

        # Release segment
        parts.append(".".join(str(x) for x in self.release))

        # Pre-release
        if self.pre is not None:
            parts.append("".join(str(x) for x in self.pre))

        # Post-release
        if self.post is not None:
            parts.append(f".post{self.post}")

        # Development release
        if self.dev is not None:
            parts.append(f".dev{self.dev}")

        # Local version segment
        if self.local is not None:
            parts.append(f"+{self.local}")

        return "".join(parts)

    @property
    def epoch(self) -> int:
        """The epoch of the version.

        >>> Version("2.0.0").epoch
        0
        >>> Version("1!2.0.0").epoch
        1
        """
        return self._version.epoch

    @property
    def release(self) -> Tuple[int, ...]:
        """The components of the "release" segment of the version.

        >>> Version("1.2.3").release
        (1, 2, 3)
        >>> Version("2.0.0").release
        (2, 0, 0)
        >>> Version("1!2.0.0.post0").release
        (2, 0, 0)

        Includes trailing zeroes but not the epoch or any pre-release / development /
        post-release suffixes.
        """
        return self._version.release

    @property
    def pre(self) -> Optional[Tuple[str, int]]:
        """The pre-release segment of the version.

        >>> print(Version("1.2.3").pre)
        None
        >>> Version("1.2.3a1").pre
        ('a', 1)
        >>> Version("1.2.3b1").pre
        ('b', 1)
        >>> Version("1.2.3rc1").pre
        ('rc', 1)
        """
        return self._version.pre

    @property
    def post(self) -> Optional[int]:
        """The post-release number of the version.

        >>> print(Version("1.2.3").post)
        None
        >>> Version("1.2.3.post1").post
        1
        """
        return self._version.post[1] if self._version.post else None

    @property
    def dev(self) -> Optional[int]:
        """The development number of the version.

        >>> print(Version("1.2.3").dev)
        None
        >>> Version("1.2.3.dev1").dev
        1
        """
        return self._version.dev[1] if self._version.dev else None

    @property
    def local(self) -> Optional[str]:
        """The local version segment of the version.

        >>> print(Version("1.2.3").local)
        None
        >>> Version("1.2.3+abc").local
        'abc'
        """
        if self._version.local:
            return ".".join(str(x) for x in self._version.local)
        else:
            return None

    @property
    def public(self) -> str:
        """The public portion of the version.

        >>> Version("1.2.3").public
        '1.2.3'
        >>> Version("1.2.3+abc").public
        '1.2.3'
        >>> Version("1.2.3+abc.dev1").public
        '1.2.3'
        """
        return str(self).split("+", 1)[0]

    @property
    def base_version(self) -> str:
        """The "base version" of the version.

        >>> Version("1.2.3").base_version
        '1.2.3'
        >>> Version("1.2.3+abc").base_version
        '1.2.3'
        >>> Version("1!1.2.3+abc.dev1").base_version
        '1!1.2.3'

        The "base version" is the public version of the project without any pre or post
        release markers.
        """
        parts = []

        # Epoch
        if self.epoch != 0:
            parts.append(f"{self.epoch}!")

        # Release segment
        parts.append(".".join(str(x) for x in self.release))

        return "".join(parts)

    @property
    def is_prerelease(self) -> bool:
        """Whether this version is a pre-release.

        >>> Version("1.2.3").is_prerelease
        False
        >>> Version("1.2.3a1").is_prerelease
        True
        >>> Version("1.2.3b1").is_prerelease
        True
        >>> Version("1.2.3rc1").is_prerelease
        True
        >>> Version("1.2.3dev1").is_prerelease
        True
        """
        return self.dev is not None or self.pre is not None

    @property
    def is_postrelease(self) -> bool:
        """Whether this version is a post-release.

        >>> Version("1.2.3").is_postrelease
        False
        >>> Version("1.2.3.post1").is_postrelease
        True
        """
        return self.post is not None

    @property
    def is_devrelease(self) -> bool:
        """Whether this version is a development release.

        >>> Version("1.2.3").is_devrelease
        False
        >>> Version("1.2.3.dev1").is_devrelease
        True
        """
        return self.dev is not None

    @property
    def major(self) -> int:
        """The first item of :attr:`release` or ``0`` if unavailable.

        >>> Version("1.2.3").major
        1
        """
        return self.release[0] if len(self.release) >= 1 else 0

    @property
    def minor(self) -> int:
        """The second item of :attr:`release` or ``0`` if unavailable.

        >>> Version("1.2.3").minor
        2
        >>> Version("1").minor
        0
        """
        return self.release[1] if len(self.release) >= 2 else 0

    @property
    def micro(self) -> int:
        """The third item of :attr:`release` or ``0`` if unavailable.

        >>> Version("1.2.3").micro
        3
        >>> Version("1").micro
        0
        """
        return self.release[2] if len(self.release) >= 3 else 0


def _parse_letter_version(
    letter: Optional[str], number: Union[str, bytes, SupportsInt, None]
) -> Optional[Tuple[str, int]]:
    if letter:
        # We consider there to be an implicit 0 in a pre-release if there is
        # not a numeral associated with it.
        if number is None:
            number = 0

        # We normalize any letters to their lower case form
        letter = letter.lower()

        # We consider some words to be alternate spellings of other words and
        # in those cases we want to normalize the spellings to our preferred
        # spelling.
        if letter == "alpha":
            letter = "a"
        elif letter == "beta":
            letter = "b"
        elif letter in ["c", "pre", "preview"]:
            letter = "rc"
        elif letter in ["rev", "r"]:
            letter = "post"

        return letter, int(number)
    if not letter and number:
        # We assume if we are given a number, but we are not given a letter
        # then this is using the implicit post release syntax (e.g. 1.0-1)
        letter = "post"

        return letter, int(number)

    return None


_local_version_separators = re.compile(r"[\._-]")


def _parse_local_version(local: Optional[str]) -> Optional[LocalType]:
    """
    Takes a string like abc.1.twelve and turns it into ("abc", 1, "twelve").
    """
    if local is not None:
        return tuple(
            part.lower() if not part.isdigit() else int(part)
            for part in _local_version_separators.split(local)
        )
    return None


def _cmpkey(
    epoch: int,
    release: Tuple[int, ...],
    pre: Optional[Tuple[str, int]],
    post: Optional[Tuple[str, int]],
    dev: Optional[Tuple[str, int]],
    local: Optional[LocalType],
) -> CmpKey:
    # When we compare a release version, we want to compare it with all of the
    # trailing zeros removed. So we'll use a reverse the list, drop all the now
    # leading zeros until we come to something non zero, then take the rest
    # re-reverse it back into the correct order and make it a tuple and use
    # that for our sorting key.
    _release = tuple(
        reversed(list(itertools.dropwhile(lambda x: x == 0, reversed(release))))
    )

    # We need to "trick" the sorting algorithm to put 1.0.dev0 before 1.0a0.
    # We'll do this by abusing the pre segment, but we _only_ want to do this
    # if there is not a pre or a post segment. If we have one of those then
    # the normal sorting rules will handle this case correctly.
    if pre is None and post is None and dev is not None:
        _pre: CmpPrePostDevType = NegativeInfinity
    # Versions without a pre-release (except as noted above) should sort after
    # those with one.
    elif pre is None:
        _pre = Infinity
    else:
        _pre = pre

    # Versions without a post segment should sort before those with one.
    if post is None:
        _post: CmpPrePostDevType = NegativeInfinity

    else:
        _post = post

    # Versions without a development segment should sort after those with one.
    if dev is None:
        _dev: CmpPrePostDevType = Infinity

    else:
        _dev = dev

    if local is None:
        # Versions without a local segment should sort before those with one.
        _local: CmpLocalType = NegativeInfinity
    else:
        # Versions with a local segment need that segment parsed to implement
        # the sorting rules in PEP440.
        # - Alpha numeric segments sort before numeric segments
        # - Alpha numeric segments sort lexicographically
        # - Numeric segments sort numerically
        # - Shorter versions sort before longer versions when the prefixes
        #   match exactly
        _local = tuple(
            (i, "") if isinstance(i, int) else (NegativeInfinity, i) for i in local
        )

    return epoch, _release, _pre, _post, _dev, _local

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/version.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 228 2025-06-01 01:29:20.927978135 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/__init__.cpython-312.pyc
82ccd46d743ba8a073697b01dbfa0ff51c9d8cca9efa1c27076ab131385266b3  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 00 00 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 83 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 77 68  |site-packages/wh|
000000a0  65 65 6c 2f 76 65 6e 64  6f 72 65 64 2f 70 61 63  |eel/vendored/pac|
000000b0  6b 61 67 69 6e 67 2f 5f  5f 69 6e 69 74 5f 5f 2e  |kaging/__init__.|
000000c0  70 79 da 08 3c 6d 6f 64  75 6c 65 3e 72 05 00 00  |py..<module>r...|
000000d0  00 01 00 00 00 73 05 00  00 00 f1 03 01 01 01 72  |.....s.........r|
000000e0  03 00 00 00                                       |....|
000000e4
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_elffile.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.0K 2025-06-01 01:29:21.087978134 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_elffile.cpython-312.pyc
5ebef0a00f6bb44ef3da1de4f5261cc6f75c728a7ca62f8ec54349e30e3ad543  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_elffile.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 c2 0c 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 dc 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 6d 06 5a 06 6d 07  5a 07 01 00 02 00 47 00  |Z.m.Z.m.Z.....G.|
00000060  64 04 84 00 64 05 65 08  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000070  5a 09 02 00 47 00 64 06  84 00 64 07 65 01 6a 14  |Z...G.d...d.e.j.|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000090  00 00 ab 03 00 00 00 00  00 00 5a 0b 02 00 47 00  |..........Z...G.|
000000a0  64 08 84 00 64 09 65 01  6a 14 00 00 00 00 00 00  |d...d.e.j.......|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 ab 03 00 00  |................|
000000c0  00 00 00 00 5a 0c 02 00  47 00 64 0a 84 00 64 0b  |....Z...G.d...d.|
000000d0  65 01 6a 14 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
000000e0  00 00 00 00 00 00 ab 03  00 00 00 00 00 00 5a 0d  |..............Z.|
000000f0  02 00 47 00 64 0c 84 00  64 0d ab 02 00 00 00 00  |..G.d...d.......|
00000100  00 00 5a 0e 79 02 29 0e  61 3b 01 00 00 0a 45 4c  |..Z.y.).a;....EL|
00000110  46 20 66 69 6c 65 20 70  61 72 73 65 72 2e 0a 0a  |F file parser...|
00000120  54 68 69 73 20 70 72 6f  76 69 64 65 73 20 61 20  |This provides a |
00000130  63 6c 61 73 73 20 60 60  45 4c 46 46 69 6c 65 60  |class ``ELFFile`|
00000140  60 20 74 68 61 74 20 70  61 72 73 65 73 20 61 6e  |` that parses an|
00000150  20 45 4c 46 20 65 78 65  63 75 74 61 62 6c 65 20  | ELF executable |
00000160  69 6e 20 61 20 73 69 6d  69 6c 61 72 0a 69 6e 74  |in a similar.int|
00000170  65 72 66 61 63 65 20 74  6f 20 60 60 5a 69 70 46  |erface to ``ZipF|
00000180  69 6c 65 60 60 2e 20 4f  6e 6c 79 20 74 68 65 20  |ile``. Only the |
00000190  72 65 61 64 20 69 6e 74  65 72 66 61 63 65 20 69  |read interface i|
000001a0  73 20 69 6d 70 6c 65 6d  65 6e 74 65 64 2e 0a 0a  |s implemented...|
000001b0  42 61 73 65 64 20 6f 6e  3a 20 68 74 74 70 73 3a  |Based on: https:|
000001c0  2f 2f 67 69 73 74 2e 67  69 74 68 75 62 2e 63 6f  |//gist.github.co|
000001d0  6d 2f 6c 79 73 73 64 6f  64 2f 66 35 31 35 37 39  |m/lyssdod/f51579|
000001e0  61 65 38 64 39 33 63 38  36 35 37 61 35 35 36 34  |ae8d93c8657a5564|
000001f0  61 65 66 63 32 66 66 62  63 61 0a 45 4c 46 20 68  |aefc2ffbca.ELF h|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_elffile.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_manylinux.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.7K 2025-06-01 01:29:21.251978134 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_manylinux.cpython-312.pyc
180ac0de8735f67919b2afb7d29b4c6cd3fa3e7e42cd527201eaebbb0f923d7b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_manylinux.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 74 25 00 00  |.........x3ht%..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 10 02  00 00 97 00 55 00 64 00  |............U.d.|
00000030  64 01 6c 00 5a 00 64 00  64 01 6c 01 5a 01 64 00  |d.l.Z.d.d.l.Z.d.|
00000040  64 01 6c 02 5a 02 64 00  64 01 6c 03 5a 03 64 00  |d.l.Z.d.d.l.Z.d.|
00000050  64 01 6c 04 5a 04 64 00  64 01 6c 05 5a 05 64 00  |d.l.Z.d.d.l.Z.d.|
00000060  64 01 6c 06 5a 06 64 00  64 02 6c 07 6d 08 5a 08  |d.l.Z.d.d.l.m.Z.|
00000070  6d 09 5a 09 6d 0a 5a 0a  6d 0b 5a 0b 6d 0c 5a 0c  |m.Z.m.Z.m.Z.m.Z.|
00000080  6d 0d 5a 0d 6d 0e 5a 0e  01 00 64 03 64 04 6c 0f  |m.Z.m.Z...d.d.l.|
00000090  6d 10 5a 10 6d 11 5a 11  6d 12 5a 12 6d 13 5a 13  |m.Z.m.Z.m.Z.m.Z.|
000000a0  01 00 64 05 5a 14 64 06  5a 15 64 07 5a 16 65 01  |..d.Z.d.Z.d.Z.e.|
000000b0  6a 2e 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000c0  00 00 00 00 64 08 65 18  64 09 65 09 65 0c 65 12  |....d.e.d.e.e.e.|
000000d0  19 00 00 00 64 01 64 01  66 03 19 00 00 00 66 04  |....d.d.f.....f.|
000000e0  64 0a 84 04 ab 00 00 00  00 00 00 00 5a 19 64 0b  |d...........Z.d.|
000000f0  65 18 64 09 65 1a 66 04  64 0c 84 04 5a 1b 64 0b  |e.d.e.f.d...Z.d.|
00000100  65 18 64 09 65 1a 66 04  64 0d 84 04 5a 1c 64 0b  |e.d.e.f.d...Z.d.|
00000110  65 18 64 0e 65 0d 65 18  19 00 00 00 64 09 65 1a  |e.d.e.e.....d.e.|
00000120  66 06 64 0f 84 04 5a 1d  02 00 65 00 6a 3c 00 00  |f.d...Z...e.j<..|
00000130  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000140  64 10 84 00 ab 01 00 00  00 00 00 00 5a 1f 65 08  |d...........Z.e.|
00000150  65 20 65 20 66 02 19 00  00 00 65 21 64 11 3c 00  |e e f.....e!d.<.|
00000160  00 00 02 00 47 00 64 12  84 00 64 13 65 0b ab 03  |....G.d...d.e...|
00000170  00 00 00 00 00 00 5a 22  64 09 65 0c 65 18 19 00  |......Z"d.e.e...|
00000180  00 00 66 02 64 14 84 04  5a 23 64 09 65 0c 65 18  |..f.d...Z#d.e.e.|
00000190  19 00 00 00 66 02 64 15  84 04 5a 24 64 09 65 0c  |....f.d...Z$d.e.|
000001a0  65 18 19 00 00 00 66 02  64 16 84 04 5a 25 64 17  |e.....f.d...Z%d.|
000001b0  65 18 64 09 65 0e 65 20  65 20 66 02 19 00 00 00  |e.d.e.e e f.....|
000001c0  66 04 64 18 84 04 5a 26  65 02 6a 4e 00 00 00 00  |f.d...Z&e.jN....|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 09  |..............d.|
000001e0  65 0e 65 20 65 20 66 02  19 00 00 00 66 02 64 19  |e.e e f.....f.d.|
000001f0  84 04 ab 00 00 00 00 00  00 00 5a 28 64 1a 65 18  |..........Z(d.e.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_manylinux.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_musllinux.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.5K 2025-06-01 01:29:21.411978134 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_musllinux.cpython-312.pyc
70408d91e22c24a7127fe2d097ffe60fae87adaf7be847dd9607aea1388480e9  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_musllinux.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 72 0a 00 00  |.........x3hr...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0a 00 00  |................|
00000020  00 00 00 00 00 f3 fe 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 03 6c 05 6d 06  5a 06 6d 07 5a 07 6d 08  |d.d.l.m.Z.m.Z.m.|
00000060  5a 08 6d 09 5a 09 01 00  64 04 64 05 6c 0a 6d 0b  |Z.m.Z...d.d.l.m.|
00000070  5a 0b 01 00 02 00 47 00  64 06 84 00 64 07 65 07  |Z.....G.d...d.e.|
00000080  ab 03 00 00 00 00 00 00  5a 0c 64 08 65 0d 64 09  |........Z.d.e.d.|
00000090  65 08 65 0c 19 00 00 00  66 04 64 0a 84 04 5a 0e  |e.e.....f.d...Z.|
000000a0  65 01 6a 1e 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
000000b0  00 00 00 00 00 00 64 0b  65 0d 64 09 65 08 65 0c  |......d.e.d.e.e.|
000000c0  19 00 00 00 66 04 64 0c  84 04 ab 00 00 00 00 00  |....f.d.........|
000000d0  00 00 5a 10 64 0d 65 09  65 0d 19 00 00 00 64 09  |..Z.d.e.e.....d.|
000000e0  65 06 65 0d 19 00 00 00  66 04 64 0e 84 04 5a 11  |e.e.....f.d...Z.|
000000f0  65 12 64 0f 6b 28 00 00  72 96 64 01 64 02 6c 13  |e.d.k(..r.d.d.l.|
00000100  5a 13 02 00 65 13 6a 28  00 00 00 00 00 00 00 00  |Z...e.j(........|
00000110  00 00 00 00 00 00 00 00  00 00 ab 00 00 00 00 00  |................|
00000120  00 00 5a 15 65 15 6a 2d  00 00 00 00 00 00 00 00  |..Z.e.j-........|
00000130  00 00 00 00 00 00 00 00  00 00 64 10 ab 01 00 00  |..........d.....|
00000140  00 00 00 00 73 07 4a 00  64 11 ab 00 00 00 00 00  |....s.J.d.......|
00000150  00 00 82 01 02 00 65 17  64 12 65 15 ab 02 00 00  |......e.d.e.....|
00000160  00 00 00 00 01 00 02 00  65 17 64 13 02 00 65 10  |........e.d...e.|
00000170  65 04 6a 30 00 00 00 00  00 00 00 00 00 00 00 00  |e.j0............|
00000180  00 00 00 00 00 00 ab 01  00 00 00 00 00 00 ab 02  |................|
00000190  00 00 00 00 00 00 01 00  02 00 65 17 64 14 64 15  |..........e.d.d.|
000001a0  ac 16 ab 02 00 00 00 00  00 00 01 00 02 00 65 11  |..............e.|
000001b0  02 00 65 02 6a 32 00 00  00 00 00 00 00 00 00 00  |..e.j2..........|
000001c0  00 00 00 00 00 00 00 00  64 17 64 18 65 15 6a 35  |........d.d.e.j5|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001e0  00 00 64 19 64 04 ab 02  00 00 00 00 00 00 64 1a  |..d.d.........d.|
000001f0  19 00 00 00 ab 03 00 00  00 00 00 00 ab 01 00 00  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_musllinux.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_parser.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 14K 2025-06-01 01:29:21.575978134 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_parser.cpython-312.pyc
6517c554cc7c2ae9ae577fff75add847f227c677af4708b0266baa540c5fe84a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_parser.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 6b 28 00 00  |.........x3hk(..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 08 00 00  |................|
00000020  00 00 00 00 00 f3 0e 02  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 6d 04 5a 04 6d 05  5a 05 6d 06 5a 06 6d 07  |Z.m.Z.m.Z.m.Z.m.|
00000050  5a 07 6d 08 5a 08 01 00  64 04 64 05 6c 09 6d 0a  |Z.m.Z...d.d.l.m.|
00000060  5a 0a 6d 0b 5a 0b 01 00  02 00 47 00 64 06 84 00  |Z.m.Z.....G.d...|
00000070  64 07 ab 02 00 00 00 00  00 00 5a 0c 02 00 47 00  |d.........Z...G.|
00000080  64 08 84 00 64 09 65 0c  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000090  5a 0d 02 00 47 00 64 0a  84 00 64 0b 65 0c ab 03  |Z...G.d...d.e...|
000000a0  00 00 00 00 00 00 5a 0e  02 00 47 00 64 0c 84 00  |......Z...G.d...|
000000b0  64 0d 65 0c ab 03 00 00  00 00 00 00 5a 0f 65 08  |d.e.........Z.e.|
000000c0  65 0d 65 0e 66 02 19 00  00 00 5a 10 65 07 65 10  |e.e.f.....Z.e.e.|
000000d0  65 0f 65 10 66 03 19 00  00 00 5a 11 65 03 5a 12  |e.e.f.....Z.e.Z.|
000000e0  65 04 65 03 19 00 00 00  5a 13 02 00 47 00 64 0e  |e.e.....Z...G.d.|
000000f0  84 00 64 0f 65 05 ab 03  00 00 00 00 00 00 5a 14  |..d.e.........Z.|
00000100  64 10 65 15 64 11 65 14  66 04 64 12 84 04 5a 16  |d.e.d.e.f.d...Z.|
00000110  64 13 65 0b 64 11 65 14  66 04 64 14 84 04 5a 17  |d.e.d.e.f.d...Z.|
00000120  64 13 65 0b 64 11 65 07  65 15 65 15 65 06 65 13  |d.e.d.e.e.e.e.e.|
00000130  19 00 00 00 66 03 19 00  00 00 66 04 64 15 84 04  |....f.....f.d...|
00000140  5a 18 64 13 65 0b 64 16  65 19 64 17 65 15 64 11  |Z.d.e.d.e.d.e.d.|
00000150  65 13 66 08 64 18 84 04  5a 1a 64 13 65 0b 64 11  |e.f.d...Z.d.e.d.|
00000160  65 04 65 15 19 00 00 00  66 04 64 19 84 04 5a 1b  |e.e.....f.d...Z.|
00000170  64 13 65 0b 64 11 65 04  65 15 19 00 00 00 66 04  |d.e.d.e.e.....f.|
00000180  64 1a 84 04 5a 1c 64 13  65 0b 64 11 65 15 66 04  |d...Z.d.e.d.e.f.|
00000190  64 1b 84 04 5a 1d 64 13  65 0b 64 11 65 15 66 04  |d...Z.d.e.d.e.f.|
000001a0  64 1c 84 04 5a 1e 64 10  65 15 64 11 65 13 66 04  |d...Z.d.e.d.e.f.|
000001b0  64 1d 84 04 5a 1f 64 13  65 0b 64 11 65 13 66 04  |d...Z.d.e.d.e.f.|
000001c0  64 1e 84 04 5a 20 64 13  65 0b 64 11 65 13 66 04  |d...Z d.e.d.e.f.|
000001d0  64 1f 84 04 5a 21 64 13  65 0b 64 11 65 12 66 04  |d...Z!d.e.d.e.f.|
000001e0  64 20 84 04 5a 22 64 13  65 0b 64 11 65 11 66 04  |d ..Z"d.e.d.e.f.|
000001f0  64 21 84 04 5a 23 64 13  65 0b 64 11 65 10 66 04  |d!..Z#d.e.d.e.f.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_parser.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_structures.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.2K 2025-06-01 01:29:21.731978134 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_structures.cpython-312.pyc
884975c0ae506a56a231a2c6310ba75848bf9579a0b71e865c01f4abeebc10cc  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_structures.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 97 05 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 48 00  00 00 97 00 02 00 47 00  |......H.......G.|
00000030  64 00 84 00 64 01 ab 02  00 00 00 00 00 00 5a 00  |d...d.........Z.|
00000040  02 00 65 00 ab 00 00 00  00 00 00 00 5a 01 02 00  |..e.........Z...|
00000050  47 00 64 02 84 00 64 03  ab 02 00 00 00 00 00 00  |G.d...d.........|
00000060  5a 02 02 00 65 02 ab 00  00 00 00 00 00 00 5a 03  |Z...e.........Z.|
00000070  79 04 29 05 63 00 00 00  00 00 00 00 00 00 00 00  |y.).c...........|
00000080  00 04 00 00 00 00 00 00  00 f3 84 00 00 00 97 00  |................|
00000090  65 00 5a 01 64 00 5a 02  64 01 65 03 66 02 64 02  |e.Z.d.Z.d.e.f.d.|
000000a0  84 04 5a 04 64 01 65 05  66 02 64 03 84 04 5a 06  |..Z.d.e.f.d...Z.|
000000b0  64 04 65 07 64 01 65 08  66 04 64 05 84 04 5a 09  |d.e.d.e.f.d...Z.|
000000c0  64 04 65 07 64 01 65 08  66 04 64 06 84 04 5a 0a  |d.e.d.e.f.d...Z.|
000000d0  64 04 65 07 64 01 65 08  66 04 64 07 84 04 5a 0b  |d.e.d.e.f.d...Z.|
000000e0  64 04 65 07 64 01 65 08  66 04 64 08 84 04 5a 0c  |d.e.d.e.f.d...Z.|
000000f0  64 04 65 07 64 01 65 08  66 04 64 09 84 04 5a 0d  |d.e.d.e.f.d...Z.|
00000100  64 0a 65 07 64 01 64 0b  66 04 64 0c 84 04 5a 0e  |d.e.d.d.f.d...Z.|
00000110  79 0d 29 0e da 0c 49 6e  66 69 6e 69 74 79 54 79  |y.)...InfinityTy|
00000120  70 65 da 06 72 65 74 75  72 6e 63 01 00 00 00 00  |pe..returnc.....|
00000130  00 00 00 00 00 00 00 00  00 00 00 03 00 00 00 f3  |................|
00000140  04 00 00 00 97 00 79 01  29 02 4e da 08 49 6e 66  |......y.).N..Inf|
00000150  69 6e 69 74 79 a9 00 a9  01 da 04 73 65 6c 66 73  |inity......selfs|
00000160  01 00 00 00 20 fa 86 2f  64 61 74 61 2f 64 61 74  |.... ../data/dat|
00000170  61 2f 63 6f 6d 2e 74 65  72 6d 75 78 2f 66 69 6c  |a/com.termux/fil|
00000180  65 73 2f 68 6f 6d 65 2f  52 41 46 41 45 4c 49 41  |es/home/RAFAELIA|
00000190  2f 48 43 50 4d 2f 43 4f  52 45 2f 76 65 6e 76 5f  |/HCPM/CORE/venv_|
000001a0  72 61 66 61 65 6c 69 61  2f 6c 69 62 2f 70 79 74  |rafaelia/lib/pyt|
000001b0  68 6f 6e 33 2e 31 32 2f  73 69 74 65 2d 70 61 63  |hon3.12/site-pac|
000001c0  6b 61 67 65 73 2f 77 68  65 65 6c 2f 76 65 6e 64  |kages/wheel/vend|
000001d0  6f 72 65 64 2f 70 61 63  6b 61 67 69 6e 67 2f 5f  |ored/packaging/_|
000001e0  73 74 72 75 63 74 75 72  65 73 2e 70 79 da 08 5f  |structures.py.._|
000001f0  5f 72 65 70 72 5f 5f 7a  15 49 6e 66 69 6e 69 74  |_repr__z.Infinit|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_structures.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_tokenizer.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.8K 2025-06-01 01:29:21.891978134 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_tokenizer.cpython-312.pyc
7b8c706eada793d895b3a4913bc235e546143070054545ee3015e3d50a855359  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/wheel/vendored/packaging/__pycache__/_tokenizer.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  d9 78 33 68 ac 14 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 00 02  00 00 97 00 55 00 64 00  |............U.d.|
00000030  64 01 6c 00 5a 00 64 00  64 01 6c 01 5a 01 64 00  |d.l.Z.d.d.l.Z.d.|
00000040  64 02 6c 02 6d 03 5a 03  01 00 64 00 64 03 6c 04  |d.l.m.Z...d.d.l.|
00000050  6d 05 5a 05 6d 06 5a 06  6d 07 5a 07 6d 08 5a 08  |m.Z.m.Z.m.Z.m.Z.|
00000060  6d 09 5a 09 6d 0a 5a 0a  01 00 64 04 64 05 6c 0b  |m.Z.m.Z...d.d.l.|
00000070  6d 0c 5a 0c 01 00 65 03  02 00 47 00 64 06 84 00  |m.Z...e...G.d...|
00000080  64 07 ab 02 00 00 00 00  00 00 ab 00 00 00 00 00  |d...............|
00000090  00 00 5a 0d 02 00 47 00  64 08 84 00 64 09 65 0e  |..Z...G.d...d.e.|
000000a0  ab 03 00 00 00 00 00 00  5a 0f 69 00 64 0a 64 0b  |........Z.i.d.d.|
000000b0  93 01 64 0c 64 0d 93 01  64 0e 64 0f 93 01 64 10  |..d.d...d.d...d.|
000000c0  64 11 93 01 64 12 64 13  93 01 64 14 64 15 93 01  |d...d.d...d.d...|
000000d0  64 16 02 00 65 01 6a 20  00 00 00 00 00 00 00 00  |d...e.j ........|
000000e0  00 00 00 00 00 00 00 00  00 00 64 17 65 01 6a 22  |..........d.e.j"|
000000f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000100  00 00 ab 02 00 00 00 00  00 00 93 01 64 18 64 19  |............d.d.|
00000110  93 01 64 1a 64 1b 93 01  64 1c 64 1d 93 01 64 1e  |..d.d...d.d...d.|
00000120  64 1f 93 01 64 20 02 00  65 01 6a 20 00 00 00 00  |d...d ..e.j ....|