#!/usr/bin/env python3
"""Tests for distutils.command.install_scripts."""

import os
from distutils.command.install_scripts import install_scripts
from distutils.core import Distribution
from distutils.tests import support

from . import test_build_scripts


class TestInstallScripts(support.TempdirManager):
    def test_default_settings(self):
        dist = Distribution()
        dist.command_obj["build"] = support.DummyCommand(build_scripts="/foo/bar")
        dist.command_obj["install"] = support.DummyCommand(
            install_scripts="/splat/funk",
            force=True,
            skip_build=True,
        )
        cmd = install_scripts(dist)
        assert not cmd.force
        assert not cmd.skip_build
        assert cmd.build_dir is None
        assert cmd.install_dir is None

        cmd.finalize_options()

        assert cmd.force
        assert cmd.skip_build
        assert cmd.build_dir == "/foo/bar"
        assert cmd.install_dir == "/splat/funk"

    def test_installation(self):
        source = self.mkdtemp()

        expected = test_build_scripts.TestBuildScripts.write_sample_scripts(source)

        target = self.mkdtemp()
        dist = Distribution()
        dist.command_obj["build"] = support.DummyCommand(build_scripts=source)
        dist.command_obj["install"] = support.DummyCommand(
            install_scripts=target,
            force=True,
            skip_build=True,
        )
        cmd = install_scripts(dist)
        cmd.finalize_options()
        cmd.run()

        installed = os.listdir(target)
        for name in expected:
            assert name in installed

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/test_install_scripts.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/test_sdist.py
-rwxrwxrwx. 1 u0_a292 u0_a292 15K 2025-06-02 22:55:14.990164467 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/test_sdist.py
79525c3e87defac84210945ad8c0c1bd83353614f5d24ecf67ad55088b0081e8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/_distutils/tests/test_sdist.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----