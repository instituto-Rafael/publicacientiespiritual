#!/usr/bin/env python3
import itertools
import os
import platform
import string
import sys

import pytest
from packaging.specifiers import SpecifierSet

import pkg_resources
from pkg_resources import (
    Distribution,
    EntryPoint,
    Requirement,
    VersionConflict,
    WorkingSet,
    parse_requirements,
    parse_version,
    safe_name,
    safe_version,
)


# from Python 3.6 docs. Available from itertools on Python 3.10
def pairwise(iterable):
    "s -> (s0,s1), (s1,s2), (s2, s3), ..."
    a, b = itertools.tee(iterable)
    next(b, None)
    return zip(a, b)


class Metadata(pkg_resources.EmptyProvider):
    """Mock object to return metadata as if from an on-disk distribution"""

    def __init__(self, *pairs) -> None:
        self.metadata = dict(pairs)

    def has_metadata(self, name) -> bool:
        return name in self.metadata

    def get_metadata(self, name):
        return self.metadata[name]

    def get_metadata_lines(self, name):
        return pkg_resources.yield_lines(self.get_metadata(name))


dist_from_fn = pkg_resources.Distribution.from_filename


class TestDistro:
    def testCollection(self):
        # empty path should produce no distributions
        ad = pkg_resources.Environment([], platform=None, python=None)
        assert list(ad) == []
        assert ad['FooPkg'] == []
        ad.add(dist_from_fn("FooPkg-1.3_1.egg"))
        ad.add(dist_from_fn("FooPkg-1.4-py2.4-win32.egg"))
        ad.add(dist_from_fn("FooPkg-1.2-py2.4.egg"))

        # Name is in there now
        assert ad['FooPkg']
        # But only 1 package
        assert list(ad) == ['foopkg']

        # Distributions sort by version
        expected = ['1.4', '1.3-1', '1.2']
        assert [dist.version for dist in ad['FooPkg']] == expected

        # Removing a distribution leaves sequence alone
        ad.remove(ad['FooPkg'][1])
        assert [dist.version for dist in ad['FooPkg']] == ['1.4', '1.2']

        # And inserting adds them in order
        ad.add(dist_from_fn("FooPkg-1.9.egg"))
        assert [dist.version for dist in ad['FooPkg']] == ['1.9', '1.4', '1.2']

        ws = WorkingSet([])
        foo12 = dist_from_fn("FooPkg-1.2-py2.4.egg")
        foo14 = dist_from_fn("FooPkg-1.4-py2.4-win32.egg")
        (req,) = parse_requirements("FooPkg>=1.3")

        # Nominal case: no distros on path, should yield all applicable
        assert ad.best_match(req, ws).version == '1.9'
        # If a matching distro is already installed, should return only that
        ws.add(foo14)
        assert ad.best_match(req, ws).version == '1.4'

        # If the first matching distro is unsuitable, it's a version conflict
        ws = WorkingSet([])
        ws.add(foo12)
        ws.add(foo14)
        with pytest.raises(VersionConflict):
            ad.best_match(req, ws)

        # If more than one match on the path, the first one takes precedence
        ws = WorkingSet([])
        ws.add(foo14)
        ws.add(foo12)
        ws.add(foo14)
        assert ad.best_match(req, ws).version == '1.4'

    def checkFooPkg(self, d):
        assert d.project_name == "FooPkg"
        assert d.key == "foopkg"
        assert d.version == "1.3.post1"
        assert d.py_version == "2.4"
        assert d.platform == "win32"
        assert d.parsed_version == parse_version("1.3-1")

    def testDistroBasics(self):
        d = Distribution(
            "/some/path",
            project_name="FooPkg",
            version="1.3-1",
            py_version="2.4",
            platform="win32",
        )
        self.checkFooPkg(d)

        d = Distribution("/some/path")
        assert d.py_version == f'{sys.version_info.major}.{sys.version_info.minor}'
        assert d.platform is None

    def testDistroParse(self):
        d = dist_from_fn("FooPkg-1.3.post1-py2.4-win32.egg")
        self.checkFooPkg(d)
        d = dist_from_fn("FooPkg-1.3.post1-py2.4-win32.egg-info")
        self.checkFooPkg(d)

    def testDistroMetadata(self):
        d = Distribution(
            "/some/path",
            project_name="FooPkg",
            py_version="2.4",
            platform="win32",
            metadata=Metadata(('PKG-INFO', "Metadata-Version: 1.0\nVersion: 1.3-1\n")),
        )
        self.checkFooPkg(d)

    def distRequires(self, txt):
        return Distribution("/foo", metadata=Metadata(('depends.txt', txt)))

    def checkRequires(self, dist, txt, extras=()):
        assert list(dist.requires(extras)) == list(parse_requirements(txt))

    def testDistroDependsSimple(self):
        for v in "Twisted>=1.5", "Twisted>=1.5\nZConfig>=2.0":
            self.checkRequires(self.distRequires(v), v)

    needs_object_dir = pytest.mark.skipif(
        not hasattr(object, '__dir__'),
        reason='object.__dir__ necessary for self.__dir__ implementation',
    )

    def test_distribution_dir(self):
        d = pkg_resources.Distribution()
        dir(d)

    @needs_object_dir
    def test_distribution_dir_includes_provider_dir(self):
        d = pkg_resources.Distribution()
        before = d.__dir__()
        assert 'test_attr' not in before
        d._provider.test_attr = None
        after = d.__dir__()
        assert len(after) == len(before) + 1
        assert 'test_attr' in after

    @needs_object_dir
    def test_distribution_dir_ignores_provider_dir_leading_underscore(self):
        d = pkg_resources.Distribution()
        before = d.__dir__()
        assert '_test_attr' not in before
        d._provider._test_attr = None
        after = d.__dir__()
        assert len(after) == len(before)
        assert '_test_attr' not in after

    def testResolve(self):
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        # Resolving no requirements -> nothing to install
        assert list(ws.resolve([], ad)) == []
        # Request something not in the collection -> DistributionNotFound
        with pytest.raises(pkg_resources.DistributionNotFound):
            ws.resolve(parse_requirements("Foo"), ad)

        Foo = Distribution.from_filename(
            "/foo_dir/Foo-1.2.egg",
            metadata=Metadata(('depends.txt', "[bar]\nBaz>=2.0")),
        )
        ad.add(Foo)
        ad.add(Distribution.from_filename("Foo-0.9.egg"))

        # Request thing(s) that are available -> list to activate
        for i in range(3):
            targets = list(ws.resolve(parse_requirements("Foo"), ad))
            assert targets == [Foo]
            list(map(ws.add, targets))
        with pytest.raises(VersionConflict):
            ws.resolve(parse_requirements("Foo==0.9"), ad)
        ws = WorkingSet([])  # reset

        # Request an extra that causes an unresolved dependency for "Baz"
        with pytest.raises(pkg_resources.DistributionNotFound):
            ws.resolve(parse_requirements("Foo[bar]"), ad)
        Baz = Distribution.from_filename(
            "/foo_dir/Baz-2.1.egg", metadata=Metadata(('depends.txt', "Foo"))
        )
        ad.add(Baz)

        # Activation list now includes resolved dependency
        assert list(ws.resolve(parse_requirements("Foo[bar]"), ad)) == [Foo, Baz]
        # Requests for conflicting versions produce VersionConflict
        with pytest.raises(VersionConflict) as vc:
            ws.resolve(parse_requirements("Foo==1.2\nFoo!=1.2"), ad)

        msg = 'Foo 0.9 is installed but Foo==1.2 is required'
        assert vc.value.report() == msg

    def test_environment_marker_evaluation_negative(self):
        """Environment markers are evaluated at resolution time."""
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        res = ws.resolve(parse_requirements("Foo;python_version<'2'"), ad)
        assert list(res) == []

    def test_environment_marker_evaluation_positive(self):
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        Foo = Distribution.from_filename("/foo_dir/Foo-1.2.dist-info")
        ad.add(Foo)
        res = ws.resolve(parse_requirements("Foo;python_version>='2'"), ad)
        assert list(res) == [Foo]

    def test_environment_marker_evaluation_called(self):
        """
        If one package foo requires bar without any extras,
        markers should pass for bar without extras.
        """
        (parent_req,) = parse_requirements("foo")
        (req,) = parse_requirements("bar;python_version>='2'")
        req_extras = pkg_resources._ReqExtras({req: parent_req.extras})
        assert req_extras.markers_pass(req)

        (parent_req,) = parse_requirements("foo[]")
        (req,) = parse_requirements("bar;python_version>='2'")
        req_extras = pkg_resources._ReqExtras({req: parent_req.extras})
        assert req_extras.markers_pass(req)

    def test_marker_evaluation_with_extras(self):
        """Extras are also evaluated as markers at resolution time."""
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        Foo = Distribution.from_filename(
            "/foo_dir/Foo-1.2.dist-info",
            metadata=Metadata((
                "METADATA",
                "Provides-Extra: baz\nRequires-Dist: quux; extra=='baz'",
            )),
        )
        ad.add(Foo)
        assert list(ws.resolve(parse_requirements("Foo"), ad)) == [Foo]
        quux = Distribution.from_filename("/foo_dir/quux-1.0.dist-info")
        ad.add(quux)
        res = list(ws.resolve(parse_requirements("Foo[baz]"), ad))
        assert res == [Foo, quux]

    def test_marker_evaluation_with_extras_normlized(self):
        """Extras are also evaluated as markers at resolution time."""
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        Foo = Distribution.from_filename(
            "/foo_dir/Foo-1.2.dist-info",
            metadata=Metadata((
                "METADATA",
                "Provides-Extra: baz-lightyear\n"
                "Requires-Dist: quux; extra=='baz-lightyear'",
            )),
        )
        ad.add(Foo)
        assert list(ws.resolve(parse_requirements("Foo"), ad)) == [Foo]
        quux = Distribution.from_filename("/foo_dir/quux-1.0.dist-info")
        ad.add(quux)
        res = list(ws.resolve(parse_requirements("Foo[baz-lightyear]"), ad))
        assert res == [Foo, quux]

    def test_marker_evaluation_with_multiple_extras(self):
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        Foo = Distribution.from_filename(
            "/foo_dir/Foo-1.2.dist-info",
            metadata=Metadata((
                "METADATA",
                "Provides-Extra: baz\n"
                "Requires-Dist: quux; extra=='baz'\n"
                "Provides-Extra: bar\n"
                "Requires-Dist: fred; extra=='bar'\n",
            )),
        )
        ad.add(Foo)
        quux = Distribution.from_filename("/foo_dir/quux-1.0.dist-info")
        ad.add(quux)
        fred = Distribution.from_filename("/foo_dir/fred-0.1.dist-info")
        ad.add(fred)
        res = list(ws.resolve(parse_requirements("Foo[baz,bar]"), ad))
        assert sorted(res) == [fred, quux, Foo]

    def test_marker_evaluation_with_extras_loop(self):
        ad = pkg_resources.Environment([])
        ws = WorkingSet([])
        a = Distribution.from_filename(
            "/foo_dir/a-0.2.dist-info",
            metadata=Metadata(("METADATA", "Requires-Dist: c[a]")),
        )
        b = Distribution.from_filename(
            "/foo_dir/b-0.3.dist-info",
            metadata=Metadata(("METADATA", "Requires-Dist: c[b]")),
        )
        c = Distribution.from_filename(
            "/foo_dir/c-1.0.dist-info",
            metadata=Metadata((
                "METADATA",
                "Provides-Extra: a\n"
                "Requires-Dist: b;extra=='a'\n"
                "Provides-Extra: b\n"
                "Requires-Dist: foo;extra=='b'",
            )),
        )
        foo = Distribution.from_filename("/foo_dir/foo-0.1.dist-info")
        for dist in (a, b, c, foo):
            ad.add(dist)
        res = list(ws.resolve(parse_requirements("a"), ad))
        assert res == [a, c, b, foo]

    @pytest.mark.xfail(
        sys.version_info[:2] == (3, 12) and sys.version_info.releaselevel != 'final',
        reason="https://github.com/python/cpython/issues/103632",
    )
    def testDistroDependsOptions(self):
        d = self.distRequires(
            """
            Twisted>=1.5
            [docgen]
            ZConfig>=2.0
            docutils>=0.3
            [fastcgi]
            fcgiapp>=0.1"""
        )
        self.checkRequires(d, "Twisted>=1.5")
        self.checkRequires(
            d, "Twisted>=1.5 ZConfig>=2.0 docutils>=0.3".split(), ["docgen"]
        )
        self.checkRequires(d, "Twisted>=1.5 fcgiapp>=0.1".split(), ["fastcgi"])
        self.checkRequires(
            d,
            "Twisted>=1.5 ZConfig>=2.0 docutils>=0.3 fcgiapp>=0.1".split(),
            ["docgen", "fastcgi"],
        )
        self.checkRequires(
            d,
            "Twisted>=1.5 fcgiapp>=0.1 ZConfig>=2.0 docutils>=0.3".split(),
            ["fastcgi", "docgen"],
        )
        with pytest.raises(pkg_resources.UnknownExtra):
            d.requires(["foo"])


class TestWorkingSet:
    def test_find_conflicting(self):
        ws = WorkingSet([])
        Foo = Distribution.from_filename("/foo_dir/Foo-1.2.egg")
        ws.add(Foo)

        # create a requirement that conflicts with Foo 1.2
        req = next(parse_requirements("Foo<1.2"))

        with pytest.raises(VersionConflict) as vc:
            ws.find(req)

        msg = 'Foo 1.2 is installed but Foo<1.2 is required'
        assert vc.value.report() == msg

    def test_resolve_conflicts_with_prior(self):
        """
        A ContextualVersionConflict should be raised when a requirement
        conflicts with a prior requirement for a different package.
        """
        # Create installation where Foo depends on Baz 1.0 and Bar depends on
        # Baz 2.0.
        ws = WorkingSet([])
        md = Metadata(('depends.txt', "Baz==1.0"))
        Foo = Distribution.from_filename("/foo_dir/Foo-1.0.egg", metadata=md)
        ws.add(Foo)
        md = Metadata(('depends.txt', "Baz==2.0"))
        Bar = Distribution.from_filename("/foo_dir/Bar-1.0.egg", metadata=md)
        ws.add(Bar)
        Baz = Distribution.from_filename("/foo_dir/Baz-1.0.egg")
        ws.add(Baz)
        Baz = Distribution.from_filename("/foo_dir/Baz-2.0.egg")
        ws.add(Baz)

        with pytest.raises(VersionConflict) as vc:
            ws.resolve(parse_requirements("Foo\nBar\n"))

        msg = "Baz 1.0 is installed but Baz==2.0 is required by "
        msg += repr(set(['Bar']))
        assert vc.value.report() == msg


class TestEntryPoints:
    def assertfields(self, ep):
        assert ep.name == "foo"
        assert ep.module_name == "pkg_resources.tests.test_resources"
        assert ep.attrs == ("TestEntryPoints",)
        assert ep.extras == ("x",)
        assert ep.load() is TestEntryPoints
        expect = "foo = pkg_resources.tests.test_resources:TestEntryPoints [x]"
        assert str(ep) == expect

    def setup_method(self, method):
        self.dist = Distribution.from_filename(
            "FooPkg-1.2-py2.4.egg", metadata=Metadata(('requires.txt', '[x]'))
        )

    def testBasics(self):
        ep = EntryPoint(
            "foo",
            "pkg_resources.tests.test_resources",
            ["TestEntryPoints"],
            ["x"],
            self.dist,
        )
        self.assertfields(ep)

    def testParse(self):
        s = "foo = pkg_resources.tests.test_resources:TestEntryPoints [x]"
        ep = EntryPoint.parse(s, self.dist)
        self.assertfields(ep)

        ep = EntryPoint.parse("bar baz=  spammity[PING]")
        assert ep.name == "bar baz"
        assert ep.module_name == "spammity"
        assert ep.attrs == ()
        assert ep.extras == ("ping",)

        ep = EntryPoint.parse(" fizzly =  wocka:foo")
        assert ep.name == "fizzly"
        assert ep.module_name == "wocka"
        assert ep.attrs == ("foo",)
        assert ep.extras == ()

        # plus in the name
        spec = "html+mako = mako.ext.pygmentplugin:MakoHtmlLexer"
        ep = EntryPoint.parse(spec)
        assert ep.name == 'html+mako'

    reject_specs = "foo", "x=a:b:c", "q=x/na", "fez=pish:tush-z", "x=f[a]>2"

    @pytest.mark.parametrize("reject_spec", reject_specs)
    def test_reject_spec(self, reject_spec):
        with pytest.raises(ValueError):
            EntryPoint.parse(reject_spec)

    def test_printable_name(self):
        """
        Allow any printable character in the name.
        """
        # Create a name with all printable characters; strip the whitespace.
        name = string.printable.strip()
        spec = "{name} = module:attr".format(**locals())
        ep = EntryPoint.parse(spec)
        assert ep.name == name

    def checkSubMap(self, m):
        assert len(m) == len(self.submap_expect)
        for key, ep in self.submap_expect.items():
            assert m.get(key).name == ep.name
            assert m.get(key).module_name == ep.module_name
            assert sorted(m.get(key).attrs) == sorted(ep.attrs)
            assert sorted(m.get(key).extras) == sorted(ep.extras)

    submap_expect = dict(
        feature1=EntryPoint('feature1', 'somemodule', ['somefunction']),
        feature2=EntryPoint(
            'feature2', 'another.module', ['SomeClass'], ['extra1', 'extra2']
        ),
        feature3=EntryPoint('feature3', 'this.module', extras=['something']),
    )
    submap_str = """
            # define features for blah blah
            feature1 = somemodule:somefunction
            feature2 = another.module:SomeClass [extra1,extra2]
            feature3 = this.module [something]
    """

    def testParseList(self):
        self.checkSubMap(EntryPoint.parse_group("xyz", self.submap_str))
        with pytest.raises(ValueError):
            EntryPoint.parse_group("x a", "foo=bar")
        with pytest.raises(ValueError):
            EntryPoint.parse_group("x", ["foo=baz", "foo=bar"])

    def testParseMap(self):
        m = EntryPoint.parse_map({'xyz': self.submap_str})
        self.checkSubMap(m['xyz'])
        assert list(m.keys()) == ['xyz']
        m = EntryPoint.parse_map("[xyz]\n" + self.submap_str)
        self.checkSubMap(m['xyz'])
        assert list(m.keys()) == ['xyz']
        with pytest.raises(ValueError):
            EntryPoint.parse_map(["[xyz]", "[xyz]"])
        with pytest.raises(ValueError):
            EntryPoint.parse_map(self.submap_str)

    def testDeprecationWarnings(self):
        ep = EntryPoint(
            "foo", "pkg_resources.tests.test_resources", ["TestEntryPoints"], ["x"]
        )
        with pytest.warns(pkg_resources.PkgResourcesDeprecationWarning):
            ep.load(require=False)


class TestRequirements:
    def testBasics(self):
        r = Requirement.parse("Twisted>=1.2")
        assert str(r) == "Twisted>=1.2"
        assert repr(r) == "Requirement.parse('Twisted>=1.2')"
        assert r == Requirement("Twisted>=1.2")
        assert r == Requirement("twisTed>=1.2")
        assert r != Requirement("Twisted>=2.0")
        assert r != Requirement("Zope>=1.2")
        assert r != Requirement("Zope>=3.0")
        assert r != Requirement("Twisted[extras]>=1.2")

    def testOrdering(self):
        r1 = Requirement("Twisted==1.2c1,>=1.2")
        r2 = Requirement("Twisted>=1.2,==1.2c1")
        assert r1 == r2
        assert str(r1) == str(r2)
        assert str(r2) == "Twisted==1.2c1,>=1.2"
        assert Requirement("Twisted") != Requirement(
            "Twisted @ https://localhost/twisted.zip"
        )

    def testBasicContains(self):
        r = Requirement("Twisted>=1.2")
        foo_dist = Distribution.from_filename("FooPkg-1.3_1.egg")
        twist11 = Distribution.from_filename("Twisted-1.1.egg")
        twist12 = Distribution.from_filename("Twisted-1.2.egg")
        assert parse_version('1.2') in r
        assert parse_version('1.1') not in r
        assert '1.2' in r
        assert '1.1' not in r
        assert foo_dist not in r
        assert twist11 not in r
        assert twist12 in r

    def testOptionsAndHashing(self):
        r1 = Requirement.parse("Twisted[foo,bar]>=1.2")
        r2 = Requirement.parse("Twisted[bar,FOO]>=1.2")
        assert r1 == r2
        assert set(r1.extras) == set(("foo", "bar"))
        assert set(r2.extras) == set(("foo", "bar"))
        assert hash(r1) == hash(r2)
        assert hash(r1) == hash((
            "twisted",
            None,
            SpecifierSet(">=1.2"),
            frozenset(["foo", "bar"]),
            None,
        ))
        assert hash(
            Requirement.parse("Twisted @ https://localhost/twisted.zip")
        ) == hash((
            "twisted",
            "https://localhost/twisted.zip",
            SpecifierSet(),
            frozenset(),
            None,
        ))

    def testVersionEquality(self):
        r1 = Requirement.parse("foo==0.3a2")
        r2 = Requirement.parse("foo!=0.3a4")
        d = Distribution.from_filename

        assert d("foo-0.3a4.egg") not in r1
        assert d("foo-0.3a1.egg") not in r1
        assert d("foo-0.3a4.egg") not in r2

        assert d("foo-0.3a2.egg") in r1
        assert d("foo-0.3a2.egg") in r2
        assert d("foo-0.3a3.egg") in r2
        assert d("foo-0.3a5.egg") in r2

    def testSetuptoolsProjectName(self):
        """
        The setuptools project should implement the setuptools package.
        """

        assert Requirement.parse('setuptools').project_name == 'setuptools'
        # setuptools 0.7 and higher means setuptools.
        assert Requirement.parse('setuptools == 0.7').project_name == 'setuptools'
        assert Requirement.parse('setuptools == 0.7a1').project_name == 'setuptools'
        assert Requirement.parse('setuptools >= 0.7').project_name == 'setuptools'


class TestParsing:
    def testEmptyParse(self):
        assert list(parse_requirements('')) == []

    def testYielding(self):
        for inp, out in [
            ([], []),
            ('x', ['x']),
            ([[]], []),
            (' x\n y', ['x', 'y']),
            (['x\n\n', 'y'], ['x', 'y']),
        ]:
            assert list(pkg_resources.yield_lines(inp)) == out

    def testSplitting(self):
        sample = """
                    x
                    [Y]
                    z

                    a
                    [b ]
                    # foo
                    c
                    [ d]
                    [q]
                    v
                    """
        assert list(pkg_resources.split_sections(sample)) == [
            (None, ["x"]),
            ("Y", ["z", "a"]),
            ("b", ["c"]),
            ("d", []),
            ("q", ["v"]),
        ]
        with pytest.raises(ValueError):
            list(pkg_resources.split_sections("[foo"))

    def testSafeName(self):
        assert safe_name("adns-python") == "adns-python"
        assert safe_name("WSGI Utils") == "WSGI-Utils"
        assert safe_name("WSGI  Utils") == "WSGI-Utils"
        assert safe_name("Money$$$Maker") == "Money-Maker"
        assert safe_name("peak.web") != "peak-web"

    def testSafeVersion(self):
        assert safe_version("1.2-1") == "1.2.post1"
        assert safe_version("1.2 alpha") == "1.2.alpha"
        assert safe_version("2.3.4 20050521") == "2.3.4.20050521"
        assert safe_version("Money$$$Maker") == "Money-Maker"
        assert safe_version("peak.web") == "peak.web"

    def testSimpleRequirements(self):
        assert list(parse_requirements('Twis-Ted>=1.2-1')) == [
            Requirement('Twis-Ted>=1.2-1')
        ]
        assert list(parse_requirements('Twisted >=1.2, \\ # more\n<2.0')) == [
            Requirement('Twisted>=1.2,<2.0')
        ]
        assert Requirement.parse("FooBar==1.99a3") == Requirement("FooBar==1.99a3")
        with pytest.raises(ValueError):
            Requirement.parse(">=2.3")
        with pytest.raises(ValueError):
            Requirement.parse("x\\")
        with pytest.raises(ValueError):
            Requirement.parse("x==2 q")
        with pytest.raises(ValueError):
            Requirement.parse("X==1\nY==2")
        with pytest.raises(ValueError):
            Requirement.parse("#")

    def test_requirements_with_markers(self):
        assert Requirement.parse("foobar;os_name=='a'") == Requirement.parse(
            "foobar;os_name=='a'"
        )
        assert Requirement.parse(
            "name==1.1;python_version=='2.7'"
        ) != Requirement.parse("name==1.1;python_version=='3.6'")
        assert Requirement.parse(
            "name==1.0;python_version=='2.7'"
        ) != Requirement.parse("name==1.2;python_version=='2.7'")
        assert Requirement.parse(
            "name[foo]==1.0;python_version=='3.6'"
        ) != Requirement.parse("name[foo,bar]==1.0;python_version=='3.6'")

    def test_local_version(self):
        parse_requirements('foo==1.0+org1')

    def test_spaces_between_multiple_versions(self):
        parse_requirements('foo>=1.0, <3')
        parse_requirements('foo >= 1.0, < 3')

    @pytest.mark.parametrize(
        ("lower", "upper"),
        [
            ('1.2-rc1', '1.2rc1'),
            ('0.4', '0.4.0'),
            ('0.4.0.0', '0.4.0'),
            ('0.4.0-0', '0.4-0'),
            ('0post1', '0.0post1'),
            ('0pre1', '0.0c1'),
            ('0.0.0preview1', '0c1'),
            ('0.0c1', '0-rc1'),
            ('1.2a1', '1.2.a.1'),
            ('1.2.a', '1.2a'),
        ],
    )
    def testVersionEquality(self, lower, upper):
        assert parse_version(lower) == parse_version(upper)

    torture = """
        0.80.1-3 0.80.1-2 0.80.1-1 0.79.9999+0.80.0pre4-1
        0.79.9999+0.80.0pre2-3 0.79.9999+0.80.0pre2-2
        0.77.2-1 0.77.1-1 0.77.0-1
        """

    @pytest.mark.parametrize(
        ("lower", "upper"),
        [
            ('2.1', '2.1.1'),
            ('2a1', '2b0'),
            ('2a1', '2.1'),
            ('2.3a1', '2.3'),
            ('2.1-1', '2.1-2'),
            ('2.1-1', '2.1.1'),
            ('2.1', '2.1post4'),
            ('2.1a0-20040501', '2.1'),
            ('1.1', '02.1'),
            ('3.2', '3.2.post0'),
            ('3.2post1', '3.2post2'),
            ('0.4', '4.0'),
            ('0.0.4', '0.4.0'),
            ('0post1', '0.4post1'),
            ('2.1.0-rc1', '2.1.0'),
            ('2.1dev', '2.1a0'),
        ]
        + list(pairwise(reversed(torture.split()))),
    )
    def testVersionOrdering(self, lower, upper):
        assert parse_version(lower) < parse_version(upper)

    def testVersionHashable(self):
        """
        Ensure that our versions stay hashable even though we've subclassed
        them and added some shim code to them.
        """
        assert hash(parse_version("1.0")) == hash(parse_version("1.0"))


class TestNamespaces:
    ns_str = "__import__('pkg_resources').declare_namespace(__name__)\n"

    @pytest.fixture
    def symlinked_tmpdir(self, tmpdir):
        """
        Where available, return the tempdir as a symlink,
        which as revealed in #231 is more fragile than
        a natural tempdir.
        """
        if not hasattr(os, 'symlink'):
            yield str(tmpdir)
            return

        link_name = str(tmpdir) + '-linked'
        os.symlink(str(tmpdir), link_name)
        try:
            yield type(tmpdir)(link_name)
        finally:
            os.unlink(link_name)

    @pytest.fixture(autouse=True)
    def patched_path(self, tmpdir):
        """
        Patch sys.path to include the 'site-pkgs' dir. Also
        restore pkg_resources._namespace_packages to its
        former state.
        """
        saved_ns_pkgs = pkg_resources._namespace_packages.copy()
        saved_sys_path = sys.path[:]
        site_pkgs = tmpdir.mkdir('site-pkgs')
        sys.path.append(str(site_pkgs))
        try:
            yield
        finally:
            pkg_resources._namespace_packages = saved_ns_pkgs
            sys.path = saved_sys_path

    issue591 = pytest.mark.xfail(platform.system() == 'Windows', reason="#591")

    @issue591
    def test_two_levels_deep(self, symlinked_tmpdir):
        """
        Test nested namespace packages
        Create namespace packages in the following tree :
            site-packages-1/pkg1/pkg2
            site-packages-2/pkg1/pkg2
        Check both are in the _namespace_packages dict and that their __path__
        is correct
        """
        real_tmpdir = symlinked_tmpdir.realpath()
        tmpdir = symlinked_tmpdir
        sys.path.append(str(tmpdir / 'site-pkgs2'))
        site_dirs = tmpdir / 'site-pkgs', tmpdir / 'site-pkgs2'
        for site in site_dirs:
            pkg1 = site / 'pkg1'
            pkg2 = pkg1 / 'pkg2'
            pkg2.ensure_dir()
            (pkg1 / '__init__.py').write_text(self.ns_str, encoding='utf-8')
            (pkg2 / '__init__.py').write_text(self.ns_str, encoding='utf-8')
        with pytest.warns(DeprecationWarning, match="pkg_resources.declare_namespace"):
            import pkg1  # pyright: ignore[reportMissingImports] # Temporary package for test
        assert "pkg1" in pkg_resources._namespace_packages
        # attempt to import pkg2 from site-pkgs2
        with pytest.warns(DeprecationWarning, match="pkg_resources.declare_namespace"):
            import pkg1.pkg2  # pyright: ignore[reportMissingImports] # Temporary package for test
        # check the _namespace_packages dict
        assert "pkg1.pkg2" in pkg_resources._namespace_packages
        assert pkg_resources._namespace_packages["pkg1"] == ["pkg1.pkg2"]
        # check the __path__ attribute contains both paths
        expected = [
            str(real_tmpdir / "site-pkgs" / "pkg1" / "pkg2"),
            str(real_tmpdir / "site-pkgs2" / "pkg1" / "pkg2"),
        ]
        assert pkg1.pkg2.__path__ == expected

    @issue591
    def test_path_order(self, symlinked_tmpdir):
        """
        Test that if multiple versions of the same namespace package subpackage
        are on different sys.path entries, that only the one earliest on
        sys.path is imported, and that the namespace package's __path__ is in
        the correct order.

        Regression test for https://github.com/pypa/setuptools/issues/207
        """

        tmpdir = symlinked_tmpdir
        site_dirs = (
            tmpdir / "site-pkgs",
            tmpdir / "site-pkgs2",
            tmpdir / "site-pkgs3",
        )

        vers_str = "__version__ = %r"

        for number, site in enumerate(site_dirs, 1):
            if number > 1:
                sys.path.append(str(site))
            nspkg = site / 'nspkg'
            subpkg = nspkg / 'subpkg'
            subpkg.ensure_dir()
            (nspkg / '__init__.py').write_text(self.ns_str, encoding='utf-8')
            (subpkg / '__init__.py').write_text(vers_str % number, encoding='utf-8')

        with pytest.warns(DeprecationWarning, match="pkg_resources.declare_namespace"):
            import nspkg  # pyright: ignore[reportMissingImports] # Temporary package for test
            import nspkg.subpkg  # pyright: ignore[reportMissingImports] # Temporary package for test
        expected = [str(site.realpath() / 'nspkg') for site in site_dirs]
        assert nspkg.__path__ == expected
        assert nspkg.subpkg.__version__ == 1

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/test_resources.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/data/my-test-package-source/__pycache__/setup.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 397 2025-06-01 01:29:26.895978130 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/data/my-test-package-source/__pycache__/setup.cpython-312.pyc
23cd93c90cf443cb9491c5dfbc8d5a85508616ba63ef34cf8d6f1c73299ced3c  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/data/my-test-package-source/__pycache__/setup.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 69 00 00 00  |..........8hi...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 36 00  00 00 97 00 64 00 64 01  |......6.....d.d.|
00000030  6c 00 5a 00 02 00 65 00  6a 02 00 00 00 00 00 00  |l.Z...e.j.......|
00000040  00 00 00 00 00 00 00 00  00 00 00 00 64 02 64 03  |............d.d.|
00000050  64 04 ac 05 ab 03 00 00  00 00 00 00 01 00 79 01  |d.............y.|
00000060  29 06 e9 00 00 00 00 4e  7a 0f 6d 79 2d 74 65 73  |)......Nz.my-tes|
00000070  74 2d 70 61 63 6b 61 67  65 7a 03 31 2e 30 54 29  |t-packagez.1.0T)|
00000080  03 da 04 6e 61 6d 65 da  07 76 65 72 73 69 6f 6e  |...name..version|
00000090  da 08 7a 69 70 5f 73 61  66 65 29 02 da 0a 73 65  |..zip_safe)...se|
000000a0  74 75 70 74 6f 6f 6c 73  da 05 73 65 74 75 70 a9  |tuptools..setup.|
000000b0  00 f3 00 00 00 00 fa 97  2f 64 61 74 61 2f 64 61  |......../data/da|
000000c0  74 61 2f 63 6f 6d 2e 74  65 72 6d 75 78 2f 66 69  |ta/com.termux/fi|
000000d0  6c 65 73 2f 68 6f 6d 65  2f 52 41 46 41 45 4c 49  |les/home/RAFAELI|
000000e0  41 2f 48 43 50 4d 2f 43  4f 52 45 2f 76 65 6e 76  |A/HCPM/CORE/venv|
000000f0  5f 72 61 66 61 65 6c 69  61 2f 6c 69 62 2f 70 79  |_rafaelia/lib/py|
00000100  74 68 6f 6e 33 2e 31 32  2f 73 69 74 65 2d 70 61  |thon3.12/site-pa|
00000110  63 6b 61 67 65 73 2f 70  6b 67 5f 72 65 73 6f 75  |ckages/pkg_resou|
00000120  72 63 65 73 2f 74 65 73  74 73 2f 64 61 74 61 2f  |rces/tests/data/|
00000130  6d 79 2d 74 65 73 74 2d  70 61 63 6b 61 67 65 2d  |my-test-package-|
00000140  73 6f 75 72 63 65 2f 73  65 74 75 70 2e 70 79 da  |source/setup.py.|
00000150  08 3c 6d 6f 64 75 6c 65  3e 72 0b 00 00 00 01 00  |.<module>r......|
00000160  00 00 73 21 00 00 00 f0  03 01 01 01 db 00 11 e0  |..s!............|
00000170  00 10 80 0a d7 00 10 d1  00 10 d8 09 1a d8 0c 11  |................|
00000180  d8 0d 11 f6 07 04 01 02  72 09 00 00 00           |........r....|
0000018d
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/data/my-test-package-source/__pycache__/setup.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_find_distributions.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.3K 2025-06-01 01:29:25.943978131 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_find_distributions.cpython-312.pyc
0d4e7a1182b99bdb160a102c191c1f0db0753f5aff0d0ee458daf0c118dd3ac8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_find_distributions.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 b4 07 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 66 00  00 00 97 00 64 00 64 01  |......f.....d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 01 6c 03 5a 03  64 00 64 01 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  02 00 65 02 65 05 ab 01  00 00 00 00 00 00 6a 0c  |..e.e.........j.|
00000060  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000070  00 00 64 03 7a 0b 00 00  5a 07 02 00 47 00 64 04  |..d.z...Z...G.d.|
00000080  84 00 64 05 ab 02 00 00  00 00 00 00 5a 08 79 01  |..d.........Z.y.|
00000090  29 06 e9 00 00 00 00 4e  29 01 da 04 50 61 74 68  |)......N)...Path|
000000a0  da 04 64 61 74 61 63 00  00 00 00 00 00 00 00 00  |..datac.........|
000000b0  00 00 00 02 00 00 00 00  00 00 00 f3 48 00 00 00  |............H...|
000000c0  97 00 65 00 5a 01 64 00  5a 02 65 03 6a 08 00 00  |..e.Z.d.Z.e.j...|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  64 01 84 00 ab 00 00 00  00 00 00 00 5a 05 64 02  |d...........Z.d.|
000000f0  84 00 5a 06 64 03 84 00  5a 07 64 04 84 00 5a 08  |..Z.d...Z.d...Z.|
00000100  64 05 84 00 5a 09 79 06  29 07 da 15 54 65 73 74  |d...Z.y.)...Test|
00000110  46 69 6e 64 44 69 73 74  72 69 62 75 74 69 6f 6e  |FindDistribution|
00000120  73 63 02 00 00 00 00 00  00 00 00 00 00 00 03 00  |sc..............|
00000130  00 00 03 00 00 00 f3 4a  00 00 00 97 00 7c 01 6a  |.......J.....|.j|
00000140  01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  00 00 00 64 01 ab 01 00  00 00 00 00 00 7d 02 7c  |...d.........}.||
00000160  02 6a 01 00 00 00 00 00  00 00 00 00 00 00 00 00  |.j..............|
00000170  00 00 00 00 00 64 02 ab  01 00 00 00 00 00 00 01  |.....d..........|
00000180  00 7c 02 53 00 29 03 4e  da 06 74 61 72 67 65 74  |.|.S.).N..target|
00000190  7a 0a 6e 6f 74 2e 61 6e  2e 65 67 67 29 01 da 05  |z.not.an.egg)...|
000001a0  6d 6b 64 69 72 29 03 da  04 73 65 6c 66 da 06 74  |mkdir)...self..t|
000001b0  6d 70 64 69 72 da 0a 74  61 72 67 65 74 5f 64 69  |mpdir..target_di|
000001c0  72 73 03 00 00 00 20 20  20 fa 8d 2f 64 61 74 61  |rs....   ../data|
000001d0  2f 64 61 74 61 2f 63 6f  6d 2e 74 65 72 6d 75 78  |/data/com.termux|
000001e0  2f 66 69 6c 65 73 2f 68  6f 6d 65 2f 52 41 46 41  |/files/home/RAFA|
000001f0  45 4c 49 41 2f 48 43 50  4d 2f 43 4f 52 45 2f 76  |ELIA/HCPM/CORE/v|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_find_distributions.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 223 2025-06-01 01:29:25.799978131 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/__init__.cpython-312.pyc
122ba1fd1e7fba4cc7506fb3a1b11865fa0c7ace11eacbce41a894c4076a3467  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 7e 2f  |N..r..........~/|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 70 6b  |site-packages/pk|
000000a0  67 5f 72 65 73 6f 75 72  63 65 73 2f 74 65 73 74  |g_resources/test|
000000b0  73 2f 5f 5f 69 6e 69 74  5f 5f 2e 70 79 da 08 3c  |s/__init__.py..<|
000000c0  6d 6f 64 75 6c 65 3e 72  05 00 00 00 01 00 00 00  |module>r........|
000000d0  73 05 00 00 00 f1 03 01  01 01 72 03 00 00 00     |s.........r....|
000000df
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_integration_zope_interface.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.0K 2025-06-01 01:29:26.099978131 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_integration_zope_interface.cpython-312.pyc
5aa556f9860b4263487e641d745835912e4cefea30139744be2c4d0a7d9b43c0  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pkg_resources/tests/__pycache__/test_integration_zope_interface.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 74 06 00 00  |..........8ht...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 be 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 01 6c 03 5a 04  64 00 64 01 6c 05 5a 05  |d.d.l.Z.d.d.l.Z.|
00000050  65 05 6a 0c 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000060  00 00 00 00 00 00 6a 0e  00 00 00 00 00 00 00 00  |......j.........|
00000070  00 00 00 00 00 00 00 00  00 00 5a 08 65 05 6a 0c  |..........Z.e.j.|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000090  00 00 6a 13 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
000000a0  00 00 00 00 00 00 02 00  65 00 6a 14 00 00 00 00  |........e.j.....|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 00  |................|
000000c0  00 00 00 00 00 00 64 03  6b 37 00 00 64 04 ac 05  |......d.k7..d...|
000000d0  ab 02 00 00 00 00 00 00  64 06 84 00 ab 00 00 00  |........d.......|
000000e0  00 00 00 00 5a 0b 79 01  29 07 e9 00 00 00 00 4e  |....Z.y.)......N|
000000f0  29 01 da 08 63 6c 65 61  6e 64 6f 63 da 05 4c 69  |)...cleandoc..Li|
00000100  6e 75 78 7a 2b 6f 6e 6c  79 20 64 65 6d 6f 6e 73  |nuxz+only demons|
00000110  74 72 61 74 65 64 20 74  6f 20 66 61 69 6c 20 6f  |trated to fail o|
00000120  6e 20 4c 69 6e 75 78 20  69 6e 20 23 34 33 39 39  |n Linux in #4399|
00000130  29 01 da 06 72 65 61 73  6f 6e 63 02 00 00 00 00  |)...reasonc.....|
00000140  00 00 00 00 00 00 00 05  00 00 00 03 00 00 00 f3  |................|
00000150  dc 00 00 00 97 00 64 01  74 01 00 00 00 00 00 00  |......d.t.......|
00000160  00 00 64 02 ab 01 00 00  00 00 00 00 74 01 00 00  |..d.........t...|