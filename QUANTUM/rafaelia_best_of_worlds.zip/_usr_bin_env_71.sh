#!/usr/bin/env python3
"""
The functions in this module are used to validate schemas with the
`format JSON Schema keyword
<https://json-schema.org/understanding-json-schema/reference/string#format>`_.

The correspondence is given by replacing the ``_`` character in the name of the
function with a ``-`` to obtain the format name and vice versa.
"""

import builtins
import logging
import os
import re
import string
import typing
from itertools import chain as _chain

if typing.TYPE_CHECKING:
    from typing_extensions import Literal

_logger = logging.getLogger(__name__)

# -------------------------------------------------------------------------------------
# PEP 440

VERSION_PATTERN = r"""
    v?
    (?:
        (?:(?P<epoch>[0-9]+)!)?                           # epoch
        (?P<release>[0-9]+(?:\.[0-9]+)*)                  # release segment
        (?P<pre>                                          # pre-release
            [-_\.]?
            (?P<pre_l>alpha|a|beta|b|preview|pre|c|rc)
            [-_\.]?
            (?P<pre_n>[0-9]+)?
        )?
        (?P<post>                                         # post release
            (?:-(?P<post_n1>[0-9]+))
            |
            (?:
                [-_\.]?
                (?P<post_l>post|rev|r)
                [-_\.]?
                (?P<post_n2>[0-9]+)?
            )
        )?
        (?P<dev>                                          # dev release
            [-_\.]?
            (?P<dev_l>dev)
            [-_\.]?
            (?P<dev_n>[0-9]+)?
        )?
    )
    (?:\+(?P<local>[a-z0-9]+(?:[-_\.][a-z0-9]+)*))?       # local version
"""

VERSION_REGEX = re.compile(r"^\s*" + VERSION_PATTERN + r"\s*$", re.X | re.I)


def pep440(version: str) -> bool:
    """See :ref:`PyPA's version specification <pypa:version-specifiers>`
    (initially introduced in :pep:`440`).
    """
    return VERSION_REGEX.match(version) is not None


# -------------------------------------------------------------------------------------
# PEP 508

PEP508_IDENTIFIER_PATTERN = r"([A-Z0-9]|[A-Z0-9][A-Z0-9._-]*[A-Z0-9])"
PEP508_IDENTIFIER_REGEX = re.compile(f"^{PEP508_IDENTIFIER_PATTERN}$", re.I)


def pep508_identifier(name: str) -> bool:
    """See :ref:`PyPA's name specification <pypa:name-format>`
    (initially introduced in :pep:`508#names`).
    """
    return PEP508_IDENTIFIER_REGEX.match(name) is not None


try:
    try:
        from packaging import requirements as _req
    except ImportError:  # pragma: no cover
        # let's try setuptools vendored version
        from setuptools._vendor.packaging import (  # type: ignore[no-redef]
            requirements as _req,
        )

    def pep508(value: str) -> bool:
        """See :ref:`PyPA's dependency specifiers <pypa:dependency-specifiers>`
        (initially introduced in :pep:`508`).
        """
        try:
            _req.Requirement(value)
            return True
        except _req.InvalidRequirement:
            return False

except ImportError:  # pragma: no cover
    _logger.warning(
        "Could not find an installation of `packaging`. Requirements, dependencies and "
        "versions might not be validated. "
        "To enforce validation, please install `packaging`."
    )

    def pep508(value: str) -> bool:
        return True


def pep508_versionspec(value: str) -> bool:
    """Expression that can be used to specify/lock versions (including ranges)
    See ``versionspec`` in :ref:`PyPA's dependency specifiers
    <pypa:dependency-specifiers>` (initially introduced in :pep:`508`).
    """
    if any(c in value for c in (";", "]", "@")):
        # In PEP 508:
        # conditional markers, extras and URL specs are not included in the
        # versionspec
        return False
    # Let's pretend we have a dependency called `requirement` with the given
    # version spec, then we can reuse the pep508 function for validation:
    return pep508(f"requirement{value}")


# -------------------------------------------------------------------------------------
# PEP 517


def pep517_backend_reference(value: str) -> bool:
    """See PyPA's specification for defining build-backend references
    introduced in :pep:`517#source-trees`.

    This is similar to an entry-point reference (e.g., ``package.module:object``).
    """
    module, _, obj = value.partition(":")
    identifiers = (i.strip() for i in _chain(module.split("."), obj.split(".")))
    return all(python_identifier(i) for i in identifiers if i)


# -------------------------------------------------------------------------------------
# Classifiers - PEP 301


def _download_classifiers() -> str:
    import ssl
    from email.message import Message
    from urllib.request import urlopen

    url = "https://pypi.org/pypi?:action=list_classifiers"
    context = ssl.create_default_context()
    with urlopen(url, context=context) as response:  # noqa: S310 (audit URLs)
        headers = Message()
        headers["content_type"] = response.getheader("content-type", "text/plain")
        return response.read().decode(headers.get_param("charset", "utf-8"))  # type: ignore[no-any-return]


class _TroveClassifier:
    """The ``trove_classifiers`` package is the official way of validating classifiers,
    however this package might not be always available.
    As a workaround we can still download a list from PyPI.
    We also don't want to be over strict about it, so simply skipping silently is an
    option (classifiers will be validated anyway during the upload to PyPI).
    """

    downloaded: typing.Union[None, "Literal[False]", typing.Set[str]]
    """
    None => not cached yet
    False => unavailable
    set => cached values
    """

    def __init__(self) -> None:
        self.downloaded = None
        self._skip_download = False
        self.__name__ = "trove_classifier"  # Emulate a public function

    def _disable_download(self) -> None:
        # This is a private API. Only setuptools has the consent of using it.
        self._skip_download = True

    def __call__(self, value: str) -> bool:
        if self.downloaded is False or self._skip_download is True:
            return True

        if os.getenv("NO_NETWORK") or os.getenv("VALIDATE_PYPROJECT_NO_NETWORK"):
            self.downloaded = False
            msg = (
                "Install ``trove-classifiers`` to ensure proper validation. "
                "Skipping download of classifiers list from PyPI (NO_NETWORK)."
            )
            _logger.debug(msg)
            return True

        if self.downloaded is None:
            msg = (
                "Install ``trove-classifiers`` to ensure proper validation. "
                "Meanwhile a list of classifiers will be downloaded from PyPI."
            )
            _logger.debug(msg)
            try:
                self.downloaded = set(_download_classifiers().splitlines())
            except Exception:
                self.downloaded = False
                _logger.debug("Problem with download, skipping validation")
                return True

        return value in self.downloaded or value.lower().startswith("private ::")


try:
    from trove_classifiers import classifiers as _trove_classifiers

    def trove_classifier(value: str) -> bool:
        """See https://pypi.org/classifiers/"""
        return value in _trove_classifiers or value.lower().startswith("private ::")

except ImportError:  # pragma: no cover
    trove_classifier = _TroveClassifier()


# -------------------------------------------------------------------------------------
# Stub packages - PEP 561


def pep561_stub_name(value: str) -> bool:
    """Name of a directory containing type stubs.
    It must follow the name scheme ``<package>-stubs`` as defined in
    :pep:`561#stub-only-packages`.
    """
    top, *children = value.split(".")
    if not top.endswith("-stubs"):
        return False
    return python_module_name(".".join([top[: -len("-stubs")], *children]))


# -------------------------------------------------------------------------------------
# Non-PEP related


def url(value: str) -> bool:
    """Valid URL (validation uses :obj:`urllib.parse`).
    For maximum compatibility please make sure to include a ``scheme`` prefix
    in your URL (e.g. ``http://``).
    """
    from urllib.parse import urlparse

    try:
        parts = urlparse(value)
        if not parts.scheme:
            _logger.warning(
                "For maximum compatibility please make sure to include a "
                "`scheme` prefix in your URL (e.g. 'http://'). "
                f"Given value: {value}"
            )
            if not (value.startswith("/") or value.startswith("\\") or "@" in value):
                parts = urlparse(f"http://{value}")

        return bool(parts.scheme and parts.netloc)
    except Exception:
        return False


# https://packaging.python.org/specifications/entry-points/
ENTRYPOINT_PATTERN = r"[^\[\s=]([^=]*[^\s=])?"
ENTRYPOINT_REGEX = re.compile(f"^{ENTRYPOINT_PATTERN}$", re.I)
RECOMMEDED_ENTRYPOINT_PATTERN = r"[\w.-]+"
RECOMMEDED_ENTRYPOINT_REGEX = re.compile(f"^{RECOMMEDED_ENTRYPOINT_PATTERN}$", re.I)
ENTRYPOINT_GROUP_PATTERN = r"\w+(\.\w+)*"
ENTRYPOINT_GROUP_REGEX = re.compile(f"^{ENTRYPOINT_GROUP_PATTERN}$", re.I)


def python_identifier(value: str) -> bool:
    """Can be used as identifier in Python.
    (Validation uses :obj:`str.isidentifier`).
    """
    return value.isidentifier()


def python_qualified_identifier(value: str) -> bool:
    """
    Python "dotted identifier", i.e. a sequence of :obj:`python_identifier`
    concatenated with ``"."`` (e.g.: ``package.module.submodule``).
    """
    if value.startswith(".") or value.endswith("."):
        return False
    return all(python_identifier(m) for m in value.split("."))


def python_module_name(value: str) -> bool:
    """Module name that can be used in an ``import``-statement in Python.
    See :obj:`python_qualified_identifier`.
    """
    return python_qualified_identifier(value)


def python_module_name_relaxed(value: str) -> bool:
    """Similar to :obj:`python_module_name`, but relaxed to also accept
    dash characters (``-``) and cover special cases like ``pip-run``.

    It is recommended, however, that beginners avoid dash characters,
    as they require advanced knowledge about Python internals.

    The following are disallowed:

    * names starting/ending in dashes,
    * names ending in ``-stubs`` (potentially collide with :obj:`pep561_stub_name`).
    """
    if value.startswith("-") or value.endswith("-"):
        return False
    if value.endswith("-stubs"):
        return False  # Avoid collision with PEP 561
    return python_module_name(value.replace("-", "_"))


def python_entrypoint_group(value: str) -> bool:
    """See ``Data model > group`` in the :ref:`PyPA's entry-points specification
    <pypa:entry-points>`.
    """
    return ENTRYPOINT_GROUP_REGEX.match(value) is not None


def python_entrypoint_name(value: str) -> bool:
    """See ``Data model > name`` in the :ref:`PyPA's entry-points specification
    <pypa:entry-points>`.
    """
    if not ENTRYPOINT_REGEX.match(value):
        return False
    if not RECOMMEDED_ENTRYPOINT_REGEX.match(value):
        msg = f"Entry point `{value}` does not follow recommended pattern: "
        msg += RECOMMEDED_ENTRYPOINT_PATTERN
        _logger.warning(msg)
    return True


def python_entrypoint_reference(value: str) -> bool:
    """Reference to a Python object using in the format::

        importable.module:object.attr

    See ``Data model >object reference`` in the :ref:`PyPA's entry-points specification
    <pypa:entry-points>`.
    """
    module, _, rest = value.partition(":")
    if "[" in rest:
        obj, _, extras_ = rest.partition("[")
        if extras_.strip()[-1] != "]":
            return False
        extras = (x.strip() for x in extras_.strip(string.whitespace + "[]").split(","))
        if not all(pep508_identifier(e) for e in extras):
            return False
        _logger.warning(f"`{value}` - using extras for entry points is not recommended")
    else:
        obj = rest

    module_parts = module.split(".")
    identifiers = _chain(module_parts, obj.split(".")) if rest else iter(module_parts)
    return all(python_identifier(i.strip()) for i in identifiers)


def uint8(value: builtins.int) -> bool:
    r"""Unsigned 8-bit integer (:math:`0 \leq x < 2^8`)"""
    return 0 <= value < 2**8


def uint16(value: builtins.int) -> bool:
    r"""Unsigned 16-bit integer (:math:`0 \leq x < 2^{16}`)"""
    return 0 <= value < 2**16


def uint(value: builtins.int) -> bool:
    r"""Unsigned 64-bit integer (:math:`0 \leq x < 2^{64}`)"""
    return 0 <= value < 2**64


def int(value: builtins.int) -> bool:
    r"""Signed 64-bit integer (:math:`-2^{63} \leq x < 2^{63}`)"""
    return -(2**63) <= value < 2**63


try:
    from packaging import licenses as _licenses

    def SPDX(value: str) -> bool:
        """See :ref:`PyPA's License-Expression specification
        <pypa:core-metadata-license-expression>` (added in :pep:`639`).
        """
        try:
            _licenses.canonicalize_license_expression(value)
            return True
        except _licenses.InvalidLicenseExpression:
            return False

except ImportError:  # pragma: no cover
    _logger.warning(
        "Could not find an up-to-date installation of `packaging`. "
        "License expressions might not be validated. "
        "To enforce validation, please install `packaging>=24.2`."
    )

    def SPDX(value: str) -> bool:
        return True

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/formats.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_exceptions.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.9K 2025-06-01 01:30:12.983978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_exceptions.cpython-312.pyc
318743025dae4975f940153e118ca918a123e7acfaaf0febdec27e91ec8d91af  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_exceptions.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 4c 06 00 00  |..........8hL...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 72 00  00 00 97 00 64 00 64 01  |......r.....d.d.|
00000030  6c 00 5a 00 02 00 65 00  6a 02 00 00 00 00 00 00  |l.Z...e.j.......|
00000040  00 00 00 00 00 00 00 00  00 00 00 00 64 02 ab 01  |............d...|
00000050  00 00 00 00 00 00 5a 02  02 00 47 00 64 03 84 00  |......Z...G.d...|
00000060  64 04 65 03 ab 03 00 00  00 00 00 00 5a 04 02 00  |d.e.........Z...|
00000070  47 00 64 05 84 00 64 06  65 04 ab 03 00 00 00 00  |G.d...d.e.......|
00000080  00 00 5a 05 02 00 47 00  64 07 84 00 64 08 65 04  |..Z...G.d...d.e.|
00000090  ab 03 00 00 00 00 00 00  5a 06 79 01 29 09 e9 00  |........Z.y.)...|
000000a0  00 00 00 4e 7a 09 5b 5c  2e 5c 5b 5c 5d 5d 2b 63  |...Nz.[\.\[\]]+c|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 01 00 00 00  |................|
000000c0  00 00 00 00 f3 10 00 00  00 97 00 65 00 5a 01 64  |...........e.Z.d|
000000d0  00 5a 02 64 01 5a 03 79  02 29 03 da 13 4a 73 6f  |.Z.d.Z.y.)...Jso|
000000e0  6e 53 63 68 65 6d 61 45  78 63 65 70 74 69 6f 6e  |nSchemaException|
000000f0  7a 37 0a 20 20 20 20 42  61 73 65 20 65 78 63 65  |z7.    Base exce|
00000100  70 74 69 6f 6e 20 6f 66  20 60 60 66 61 73 74 6a  |ption of ``fastj|
00000110  73 6f 6e 73 63 68 65 6d  61 60 60 20 6c 69 62 72  |sonschema`` libr|
00000120  61 72 79 2e 0a 20 20 20  20 4e a9 04 da 08 5f 5f  |ary..    N....__|
00000130  6e 61 6d 65 5f 5f da 0a  5f 5f 6d 6f 64 75 6c 65  |name__..__module|
00000140  5f 5f da 0c 5f 5f 71 75  61 6c 6e 61 6d 65 5f 5f  |__..__qualname__|
00000150  da 07 5f 5f 64 6f 63 5f  5f a9 00 f3 00 00 00 00  |..__doc__.......|
00000160  fa a1 2f 64 61 74 61 2f  64 61 74 61 2f 63 6f 6d  |../data/data/com|
00000170  2e 74 65 72 6d 75 78 2f  66 69 6c 65 73 2f 68 6f  |.termux/files/ho|
00000180  6d 65 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |me/RAFAELIA/HCPM|
00000190  2f 43 4f 52 45 2f 76 65  6e 76 5f 72 61 66 61 65  |/CORE/venv_rafae|
000001a0  6c 69 61 2f 6c 69 62 2f  70 79 74 68 6f 6e 33 2e  |lia/lib/python3.|
000001b0  31 32 2f 73 69 74 65 2d  70 61 63 6b 61 67 65 73  |12/site-packages|
000001c0  2f 73 65 74 75 70 74 6f  6f 6c 73 2f 63 6f 6e 66  |/setuptools/conf|
000001d0  69 67 2f 5f 76 61 6c 69  64 61 74 65 5f 70 79 70  |ig/_validate_pyp|
000001e0  72 6f 6a 65 63 74 2f 66  61 73 74 6a 73 6f 6e 73  |roject/fastjsons|
000001f0  63 68 65 6d 61 5f 65 78  63 65 70 74 69 6f 6e 73  |chema_exceptions|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_exceptions.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.9K 2025-06-01 01:30:12.503978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/__init__.cpython-312.pyc
49e6601df1de8dace05692c8e3934c79dc2526a04b7ae47d8a7ffd0d8a593a5e  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 12 04 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 78 01  00 00 97 00 55 00 64 00  |......x.....U.d.|
00000030  64 01 6c 00 6d 01 5a 01  01 00 64 00 64 02 6c 02  |d.l.m.Z...d.d.l.|
00000040  6d 03 5a 03 6d 04 5a 04  6d 05 5a 05 01 00 64 03  |m.Z.m.Z.m.Z...d.|
00000050  64 04 6c 06 6d 07 5a 07  01 00 64 03 64 05 6c 08  |d.l.m.Z...d.d.l.|
00000060  6d 09 5a 09 6d 0a 5a 0a  01 00 64 03 64 06 6c 0b  |m.Z.m.Z...d.d.l.|
00000070  6d 0c 5a 0c 01 00 64 03  64 07 6c 0d 6d 0e 5a 0e  |m.Z...d.d.l.m.Z.|
00000080  6d 0f 5a 0f 01 00 64 03  64 08 6c 10 6d 11 5a 12  |m.Z...d.d.l.m.Z.|
00000090  01 00 67 00 64 09 a2 01  5a 13 65 07 6a 28 00 00  |..g.d...Z.e.j(..|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  6a 2b 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j+..............|
000000c0  00 00 00 00 ab 00 00 00  00 00 00 00 44 00 8f 00  |............D...|
000000d0  63 02 69 00 63 02 5d 42  00 00 7d 00 02 00 65 16  |c.i.c.]B..}...e.|
000000e0  7c 00 ab 01 00 00 00 00  00 00 72 38 7c 00 6a 2e  ||.........r8|.j.|
000000f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000100  00 00 6a 31 00 00 00 00  00 00 00 00 00 00 00 00  |..j1............|
00000110  00 00 00 00 00 00 64 0a  ab 01 00 00 00 00 00 00  |......d.........|
00000120  73 1d 7c 00 6a 2e 00 00  00 00 00 00 00 00 00 00  |s.|.j...........|
00000130  00 00 00 00 00 00 00 00  6a 33 00 00 00 00 00 00  |........j3......|
00000140  00 00 00 00 00 00 00 00  00 00 00 00 64 0a 64 0b  |............d.d.|
00000150  ab 02 00 00 00 00 00 00  7c 00 93 02 8c 44 04 00  |........|....D..|
00000160  63 02 7d 00 5a 1a 65 05  65 1b 65 04 65 1b 67 01  |c.}.Z.e.e.e.e.g.|
00000170  65 1c 66 02 19 00 00 00  66 02 19 00 00 00 65 1d  |e.f.....f.....e.|
00000180  64 0c 3c 00 00 00 64 0d  65 03 64 0e 65 1c 66 04  |d.<...d.e.d.e.f.|
00000190  64 0f 84 04 5a 11 79 10  63 02 01 00 63 02 7d 00  |d...Z.y.c...c.}.|
000001a0  77 00 29 11 e9 00 00 00  00 29 01 da 06 72 65 64  |w.)......)...red|
000001b0  75 63 65 29 03 da 03 41  6e 79 da 08 43 61 6c 6c  |uce)...Any..Call|
000001c0  61 62 6c 65 da 04 44 69  63 74 e9 01 00 00 00 29  |able..Dict.....)|
000001d0  01 da 07 66 6f 72 6d 61  74 73 29 02 da 0f 64 65  |...formats)...de|
000001e0  74 61 69 6c 65 64 5f 65  72 72 6f 72 73 da 0f 56  |tailed_errors..V|
000001f0  61 6c 69 64 61 74 69 6f  6e 45 72 72 6f 72 29 01  |alidationError).|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/error_reporting.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 18K 2025-06-01 01:30:12.667978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/error_reporting.cpython-312.pyc
23bd1352258606e0751adb86937fcbdbc9ffac0109a8107154f6e3bae552e121  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/error_reporting.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 25 2e 00 00  |..........8h%...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 fa 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 6d 07 5a 07 01 00  64 00 64 03 6c 08 6d 09  |l.m.Z...d.d.l.m.|
00000070  5a 09 6d 0a 5a 0a 01 00  64 00 64 04 6c 05 6d 0b  |Z.m.Z...d.d.l.m.|
00000080  5a 0b 6d 0c 5a 0c 6d 0d  5a 0d 6d 0e 5a 0e 6d 0f  |Z.m.Z.m.Z.m.Z.m.|
00000090  5a 0f 6d 10 5a 10 6d 11  5a 11 6d 12 5a 12 01 00  |Z.m.Z.m.Z.m.Z...|
000000a0  64 05 64 06 6c 13 6d 14  5a 14 01 00 65 05 6a 2a  |d.d.l.m.Z...e.j*|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  00 00 72 20 64 00 64 01  6c 16 5a 16 65 16 6a 2e  |..r d.d.l.Z.e.j.|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  00 00 64 07 6b 02 00 00  72 07 64 00 64 08 6c 18  |..d.k...r.d.d.l.|
000000f0  6d 19 5a 19 01 00 6e 06  64 00 64 08 6c 05 6d 19  |m.Z...n.d.d.l.m.|
00000100  5a 19 01 00 02 00 65 02  6a 34 00 00 00 00 00 00  |Z.....e.j4......|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 65 1b ab 01  |............e...|
00000120  00 00 00 00 00 00 5a 1c  64 09 64 0a 64 0b 64 0c  |......Z.d.d.d.d.|
00000130  64 0d 9c 04 5a 1d 64 0e  5a 1e 68 00 64 0f a3 01  |d...Z.d.Z.h.d...|
00000140  5a 1f 02 00 65 04 6a 40  00 00 00 00 00 00 00 00  |Z...e.j@........|
00000150  00 00 00 00 00 00 00 00  00 00 64 10 ab 01 00 00  |..........d.....|
00000160  00 00 00 00 5a 21 02 00  65 04 6a 40 00 00 00 00  |....Z!..e.j@....|
00000170  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 11  |..............d.|
00000180  65 04 6a 44 00 00 00 00  00 00 00 00 00 00 00 00  |e.jD............|
00000190  00 00 00 00 00 00 ab 02  00 00 00 00 00 00 5a 23  |..............Z#|
000001a0  64 12 64 13 64 14 64 14  64 15 9c 04 5a 24 64 16  |d.d.d.d.d...Z$d.|
000001b0  5a 25 02 00 47 00 64 17  84 00 64 18 65 14 ab 03  |Z%..G.d...d.e...|
000001c0  00 00 00 00 00 00 5a 26  65 07 64 19 65 0d 64 1a  |......Z&e.d.e.d.|
000001d0  19 00 00 00 66 02 64 1b  84 04 ab 00 00 00 00 00  |....f.d.........|
000001e0  00 00 5a 27 02 00 47 00  64 1c 84 00 64 1d ab 02  |..Z'..G.d...d...|
000001f0  00 00 00 00 00 00 5a 28  02 00 47 00 64 1e 84 00  |......Z(..G.d...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/error_reporting.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/extra_validations.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.1K 2025-06-01 01:30:12.823978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/extra_validations.cpython-312.pyc
af266f1e6382eb32f41c4afc8ae1ce8fa218f9ca94330e285146e24ffc04f082  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/extra_validations.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 2a 0b 00 00  |..........8h*...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 98 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 6d 04 5a 04 6d 05  5a 05 01 00 64 04 64 05  |l.m.Z.m.Z...d.d.|
00000050  6c 06 6d 07 5a 07 01 00  02 00 65 05 64 06 65 04  |l.m.Z.....e.d.e.|
00000060  ac 07 ab 02 00 00 00 00  00 00 5a 08 02 00 47 00  |..........Z...G.|
00000070  64 08 84 00 64 09 65 07  ab 03 00 00 00 00 00 00  |d...d.e.........|
00000080  5a 09 02 00 47 00 64 0a  84 00 64 0b 65 07 ab 03  |Z...G.d...d.e...|
00000090  00 00 00 00 00 00 5a 0a  64 0c 65 08 64 0d 65 08  |......Z.d.e.d.e.|
000000a0  66 04 64 0e 84 04 5a 0b  64 0c 65 08 64 0d 65 08  |f.d...Z.d.e.d.e.|
000000b0  66 04 64 0f 84 04 5a 0c  65 0b 65 0c 66 02 5a 0d  |f.d...Z.e.e.f.Z.|
000000c0  79 10 29 11 7a ab 54 68  65 20 70 75 72 70 6f 73  |y.).z.The purpos|
000000d0  65 20 6f 66 20 74 68 69  73 20 6d 6f 64 75 6c 65  |e of this module|
000000e0  20 69 73 20 69 6d 70 6c  65 6d 65 6e 74 20 50 45  | is implement PE|
000000f0  50 20 36 32 31 20 76 61  6c 69 64 61 74 69 6f 6e  |P 621 validation|
00000100  73 20 74 68 61 74 20 61  72 65 0a 64 69 66 66 69  |s that are.diffi|
00000110  63 75 6c 74 20 74 6f 20  65 78 70 72 65 73 73 20  |cult to express |
00000120  61 73 20 61 20 4a 53 4f  4e 20 53 63 68 65 6d 61  |as a JSON Schema|
00000130  20 28 6f 72 20 74 68 61  74 20 61 72 65 20 6e 6f  | (or that are no|
00000140  74 20 73 75 70 70 6f 72  74 65 64 20 62 79 20 74  |t supported by t|
00000150  68 65 20 63 75 72 72 65  6e 74 0a 4a 53 4f 4e 20  |he current.JSON |
00000160  53 63 68 65 6d 61 20 6c  69 62 72 61 72 79 29 2e  |Schema library).|
00000170  0a e9 00 00 00 00 29 01  da 08 63 6c 65 61 6e 64  |......)...cleand|
00000180  6f 63 29 02 da 07 4d 61  70 70 69 6e 67 da 07 54  |oc)...Mapping..T|
00000190  79 70 65 56 61 72 e9 01  00 00 00 29 01 da 0f 56  |ypeVar.....)...V|
000001a0  61 6c 69 64 61 74 69 6f  6e 45 72 72 6f 72 da 01  |alidationError..|
000001b0  54 29 01 da 05 62 6f 75  6e 64 63 00 00 00 00 00  |T)...boundc.....|
000001c0  00 00 00 00 00 00 00 01  00 00 00 00 00 00 00 f3  |................|
000001d0  18 00 00 00 97 00 65 00  5a 01 64 00 5a 02 64 01  |......e.Z.d.Z.d.|
000001e0  5a 03 65 03 5a 04 64 02  5a 05 79 03 29 04 da 1e  |Z.e.Z.d.Z.y.)...|
000001f0  52 65 64 65 66 69 6e 69  6e 67 53 74 61 74 69 63  |RedefiningStatic|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/extra_validations.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_validations.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 228K 2025-06-01 01:30:13.315978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_validations.cpython-312.pyc
1691f8ef737cdc9e8a4bed045139fc0d39fef9cc982330827a0f5b6e4dd669b2  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_validations.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 7a 69 05 00  |..........8hzi..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 9c 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 04 64 05  6c 04 6d 05 5a 05 01 00  |l.Z.d.d.l.m.Z...|
00000050  02 00 65 03 6a 0c 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
00000060  00 00 00 00 00 00 00 00  64 06 ab 01 00 00 00 00  |........d.......|
00000070  00 00 02 00 65 03 6a 0c  00 00 00 00 00 00 00 00  |....e.j.........|
00000080  00 00 00 00 00 00 00 00  00 00 64 07 ab 01 00 00  |..........d.....|
00000090  00 00 00 00 02 00 65 03  6a 0c 00 00 00 00 00 00  |......e.j.......|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 64 08 ab 01  |............d...|
000000b0  00 00 00 00 00 00 02 00  65 03 6a 0c 00 00 00 00  |........e.j.....|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 09  |..............d.|
000000d0  ab 01 00 00 00 00 00 00  02 00 65 03 6a 0c 00 00  |..........e.j...|
000000e0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000f0  64 0a ab 01 00 00 00 00  00 00 64 0b 9c 05 5a 07  |d.........d...Z.|
00000100  02 00 65 08 64 03 ab 01  00 00 00 00 00 00 5a 09  |..e.d.........Z.|
00000110  69 00 64 03 66 02 64 0c  84 01 5a 0a 69 00 64 03  |i.d.f.d...Z.i.d.|
00000120  66 02 64 0d 84 01 5a 0b  69 00 64 03 66 02 64 0e  |f.d...Z.i.d.f.d.|
00000130  84 01 5a 0c 69 00 64 03  66 02 64 0f 84 01 5a 0d  |..Z.i.d.f.d...Z.|
00000140  69 00 64 03 66 02 64 10  84 01 5a 0e 69 00 64 03  |i.d.f.d...Z.i.d.|
00000150  66 02 64 11 84 01 5a 0f  69 00 64 03 66 02 64 12  |f.d...Z.i.d.f.d.|
00000160  84 01 5a 10 69 00 64 03  66 02 64 13 84 01 5a 11  |..Z.i.d.f.d...Z.|
00000170  69 00 64 03 66 02 64 14  84 01 5a 12 69 00 64 03  |i.d.f.d...Z.i.d.|
00000180  66 02 64 15 84 01 5a 13  69 00 64 03 66 02 64 16  |f.d...Z.i.d.f.d.|
00000190  84 01 5a 14 69 00 64 03  66 02 64 17 84 01 5a 15  |..Z.i.d.f.d...Z.|
000001a0  69 00 64 03 66 02 64 18  84 01 5a 16 69 00 64 03  |i.d.f.d...Z.i.d.|
000001b0  66 02 64 19 84 01 5a 17  69 00 64 03 66 02 64 1a  |f.d...Z.i.d.f.d.|
000001c0  84 01 5a 18 79 03 29 1b  7a 06 32 2e 32 30 2e 30  |..Z.y.).z.2.20.0|
000001d0  e9 00 00 00 00 29 01 da  07 44 65 63 69 6d 61 6c  |.....)...Decimal|
000001e0  4e e9 01 00 00 00 29 01  da 18 4a 73 6f 6e 53 63  |N.....)...JsonSc|
000001f0  68 65 6d 61 56 61 6c 75  65 45 78 63 65 70 74 69  |hemaValueExcepti|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/fastjsonschema_validations.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/formats.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 19K 2025-06-01 01:30:13.483978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/formats.cpython-312.pyc
c7292690f598f7584bfe9f72ccfc3853a9c085be2dd5051c5ab73f65a650642a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/formats.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 fc 34 00 00  |..........8h.4..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 c0 04  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 02 6c 05 5a 05  64 01 64 02 6c 06 5a 06  |d.d.l.Z.d.d.l.Z.|
00000060  64 01 64 03 6c 07 6d 08  5a 09 01 00 65 06 6a 14  |d.d.l.m.Z...e.j.|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000080  00 00 72 06 64 01 64 04  6c 0b 6d 0c 5a 0c 01 00  |..r.d.d.l.m.Z...|
00000090  02 00 65 02 6a 1a 00 00  00 00 00 00 00 00 00 00  |..e.j...........|
000000a0  00 00 00 00 00 00 00 00  65 0e ab 01 00 00 00 00  |........e.......|
000000b0  00 00 5a 0f 64 05 5a 10  02 00 65 04 6a 22 00 00  |..Z.d.Z...e.j"..|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000d0  64 06 65 10 7a 00 00 00  64 07 7a 00 00 00 65 04  |d.e.z...d.z...e.|
000000e0  6a 24 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j$..............|
000000f0  00 00 00 00 65 04 6a 26  00 00 00 00 00 00 00 00  |....e.j&........|
00000100  00 00 00 00 00 00 00 00  00 00 7a 07 00 00 ab 02  |..........z.....|
00000110  00 00 00 00 00 00 5a 14  64 08 65 15 64 09 65 16  |......Z.d.e.d.e.|
00000120  66 04 64 0a 84 04 5a 17  64 0b 5a 18 02 00 65 04  |f.d...Z.d.Z...e.|
00000130  6a 22 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j"..............|
00000140  00 00 00 00 64 0c 65 18  9b 00 64 0d 9d 03 65 04  |....d.e...d...e.|
00000150  6a 26 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j&..............|
00000160  00 00 00 00 ab 02 00 00  00 00 00 00 5a 19 64 0e  |............Z.d.|
00000170  65 15 64 09 65 16 66 04  64 0f 84 04 5a 1a 09 00  |e.d.e.f.d...Z...|
00000180  09 00 64 01 64 10 6c 1b  6d 1c 5a 1d 01 00 64 11  |..d.d.l.m.Z...d.|
00000190  65 15 64 09 65 16 66 04  64 12 84 04 5a 20 64 11  |e.d.e.f.d...Z d.|
000001a0  65 15 64 09 65 16 66 04  64 15 84 04 5a 22 64 11  |e.d.e.f.d...Z"d.|
000001b0  65 15 64 09 65 16 66 04  64 16 84 04 5a 23 64 09  |e.d.e.f.d...Z#d.|
000001c0  65 15 66 02 64 17 84 04  5a 24 02 00 47 00 64 18  |e.f.d...Z$..G.d.|
000001d0  84 00 64 19 ab 02 00 00  00 00 00 00 5a 25 09 00  |..d.........Z%..|
000001e0  64 01 64 1a 6c 26 6d 27  5a 28 01 00 64 11 65 15  |d.d.l&m'Z(..d.e.|
000001f0  64 09 65 16 66 04 64 1b  84 04 5a 29 64 11 65 15  |d.e.f.d...Z)d.e.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/_validate_pyproject/__pycache__/formats.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/_apply_pyprojecttoml.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 25K 2025-06-01 01:30:11.855978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/_apply_pyprojecttoml.cpython-312.pyc
40cb4b6ed12ca990807280d08d591d5c3e72f61610bfe77de78cddc405f0afb5  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/_apply_pyprojecttoml.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 b0 4a 00 00  |..........8h.J..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0c 00 00  |................|
00000020  00 00 00 00 01 f3 40 05  00 00 97 00 55 00 64 00  |......@.....U.d.|
00000030  5a 00 64 01 64 02 6c 01  6d 02 5a 02 01 00 64 01  |Z.d.d.l.m.Z...d.|
00000040  64 03 6c 03 5a 03 64 01  64 03 6c 04 5a 04 64 01  |d.l.Z.d.d.l.Z.d.|
00000050  64 04 6c 05 6d 06 5a 06  01 00 64 01 64 05 6c 07  |d.l.m.Z...d.d.l.|
00000060  6d 08 5a 08 01 00 64 01  64 06 6c 09 6d 0a 5a 0a  |m.Z...d.d.l.m.Z.|
00000070  6d 0b 5a 0b 01 00 64 01  64 07 6c 0c 6d 0d 5a 0d  |m.Z...d.d.l.m.Z.|
00000080  01 00 64 01 64 08 6c 0e  6d 0f 5a 0f 01 00 64 01  |..d.d.l.m.Z...d.|
00000090  64 09 6c 10 6d 11 5a 11  01 00 64 01 64 0a 6c 12  |d.l.m.Z...d.d.l.|
000000a0  6d 13 5a 13 6d 14 5a 14  6d 15 5a 15 6d 16 5a 16  |m.Z.m.Z.m.Z.m.Z.|
000000b0  6d 17 5a 17 01 00 64 0b  64 0c 6c 18 6d 19 5a 19  |m.Z...d.d.l.m.Z.|
000000c0  01 00 64 0b 64 0d 6c 1a  6d 1b 5a 1b 01 00 64 0b  |..d.d.l.m.Z...d.|
000000d0  64 0e 6c 1c 6d 1d 5a 1d  6d 1e 5a 1e 01 00 64 0b  |d.l.m.Z.m.Z...d.|
000000e0  64 0f 6c 1f 6d 20 5a 20  01 00 64 0b 64 10 6c 21  |d.l.m Z ..d.d.l!|
000000f0  6d 22 5a 22 6d 23 5a 23  01 00 65 13 72 18 64 01  |m"Z"m#Z#..e.r.d.|
00000100  64 11 6c 24 6d 25 5a 25  01 00 64 01 64 12 6c 26  |d.l$m%Z%..d.d.l&|
00000110  6d 27 5a 27 01 00 64 01  64 13 6c 28 6d 29 5a 29  |m'Z'..d.d.l(m)Z)|
00000120  01 00 64 01 64 14 6c 2a  6d 2b 5a 2b 01 00 02 00  |..d.d.l*m+Z+....|
00000130  65 11 69 00 ab 01 00 00  00 00 00 00 5a 2c 64 15  |e.i.........Z,d.|
00000140  65 2d 64 16 3c 00 00 00  65 17 65 2e 65 2f 65 2e  |e-d.<...e.e.e/e.|
00000150  65 2e 66 02 19 00 00 00  66 02 19 00 00 00 5a 30  |e.f.....f.....Z0|
00000160  64 17 65 2d 64 18 3c 00  00 00 65 15 64 19 65 14  |d.e-d.<...e.d.e.|
00000170  65 17 65 1b 64 03 66 02  19 00 00 00 67 03 64 03  |e.e.d.f.....g.d.|
00000180  66 02 19 00 00 00 5a 31  64 17 65 2d 64 1a 3c 00  |f.....Z1d.e-d.<.|
00000190  00 00 02 00 65 16 64 1b  ab 01 00 00 00 00 00 00  |....e.d.........|
000001a0  5a 32 02 00 65 03 6a 66  00 00 00 00 00 00 00 00  |Z2..e.jf........|
000001b0  00 00 00 00 00 00 00 00  00 00 65 34 ab 01 00 00  |..........e4....|
000001c0  00 00 00 00 5a 35 64 73  64 1d 84 04 5a 36 64 74  |....Z5dsd...Z6dt|
000001d0  64 1e 84 04 5a 37 64 75  64 1f 84 04 5a 38 64 76  |d...Z7dud...Z8dv|
000001e0  64 20 84 04 5a 39 64 77  64 21 84 04 5a 3a 64 78  |d ..Z9dwd!..Z:dx|
000001f0  64 22 84 04 5a 3b 64 23  64 24 64 25 64 26 9c 03  |d"..Z;d#d$d%d&..|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/_apply_pyprojecttoml.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.0K 2025-06-01 01:30:11.683978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/__init__.cpython-312.pyc
e89dd83817095023516574577f6d74ed9756e11106bf021b3d4b5318d9466717  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 db 05 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 b0 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 6d 04 5a 04 6d 05  5a 05 6d 06 5a 06 01 00  |l.m.Z.m.Z.m.Z...|
00000050  64 04 64 05 6c 07 6d 08  5a 08 01 00 64 06 64 07  |d.d.l.m.Z...d.d.|
00000060  6c 09 6d 0a 5a 0a 01 00  02 00 65 05 64 08 65 04  |l.m.Z.....e.d.e.|
00000070  ac 09 ab 02 00 00 00 00  00 00 5a 0b 64 0a 5a 0c  |..........Z.d.Z.|
00000080  64 0b 65 0b 64 0c 65 0b  66 04 64 0d 84 04 5a 0d  |d.e.d.e.f.d...Z.|
00000090  02 00 65 0d 65 0a 6a 1c  00 00 00 00 00 00 00 00  |..e.e.j.........|
000000a0  00 00 00 00 00 00 00 00  00 00 ab 01 00 00 00 00  |................|
000000b0  00 00 5a 0e 02 00 65 0d  65 0a 6a 1e 00 00 00 00  |..Z...e.e.j.....|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 ab 01  |................|
000000d0  00 00 00 00 00 00 5a 0f  79 0e 29 0f 7a 56 46 6f  |......Z.y.).zVFo|
000000e0  72 20 62 61 63 6b 77 61  72 64 20 63 6f 6d 70 61  |r backward compa|
000000f0  74 69 62 69 6c 69 74 79  2c 20 65 78 70 6f 73 65  |tibility, expose|
00000100  20 6d 61 69 6e 20 66 75  6e 63 74 69 6f 6e 73 20  | main functions |
00000110  66 72 6f 6d 0a 60 60 73  65 74 75 70 74 6f 6f 6c  |from.``setuptool|
00000120  73 2e 63 6f 6e 66 69 67  2e 73 65 74 75 70 63 66  |s.config.setupcf|
00000130  67 60 60 0a e9 00 00 00  00 29 01 da 05 77 72 61  |g``......)...wra|
00000140  70 73 29 03 da 08 43 61  6c 6c 61 62 6c 65 da 07  |ps)...Callable..|
00000150  54 79 70 65 56 61 72 da  04 63 61 73 74 e9 02 00  |TypeVar..cast...|
00000160  00 00 29 01 da 1c 53 65  74 75 70 74 6f 6f 6c 73  |..)...Setuptools|
00000170  44 65 70 72 65 63 61 74  69 6f 6e 57 61 72 6e 69  |DeprecationWarni|
00000180  6e 67 e9 01 00 00 00 29  01 da 08 73 65 74 75 70  |ng.....)...setup|
00000190  63 66 67 da 02 46 6e 29  01 da 05 62 6f 75 6e 64  |cfg..Fn)...bound|
000001a0  29 02 da 13 70 61 72 73  65 5f 63 6f 6e 66 69 67  |)...parse_config|
000001b0  75 72 61 74 69 6f 6e da  12 72 65 61 64 5f 63 6f  |uration..read_co|
000001c0  6e 66 69 67 75 72 61 74  69 6f 6e da 02 66 6e da  |nfiguration..fn.|
000001d0  06 72 65 74 75 72 6e 63  01 00 00 00 00 00 00 00  |.returnc........|
000001e0  00 00 00 00 04 00 00 00  03 00 00 00 f3 4a 00 00  |.............J..|
000001f0  00 87 00 97 00 74 01 00  00 00 00 00 00 00 00 89  |.....t..........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/expand.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 25K 2025-06-01 01:30:12.011978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/expand.cpython-312.pyc
dedb812112bea927f99f8b36c986cae47d700596277ee3928a24b8abc50530ff  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/expand.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 a9 3e 00 00  |..........8h.>..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 01 f3 a0 02  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 5a 05 64 01 64 03  6c 06 5a 06 64 01 64 03  |l.Z.d.d.l.Z.d.d.|
00000060  6c 07 5a 07 64 01 64 04  6c 08 6d 09 5a 09 6d 0a  |l.Z.d.d.l.m.Z.m.|
00000070  5a 0a 6d 0b 5a 0b 01 00  64 01 64 05 6c 0c 6d 0d  |Z.m.Z...d.d.l.m.|
00000080  5a 0d 01 00 64 01 64 06  6c 0e 6d 0f 5a 0f 01 00  |Z...d.d.l.m.Z...|
00000090  64 01 64 07 6c 10 6d 11  5a 11 6d 12 5a 12 01 00  |d.d.l.m.Z.m.Z...|
000000a0  64 01 64 08 6c 13 6d 14  5a 14 01 00 64 01 64 09  |d.d.l.m.Z...d.d.|
000000b0  6c 06 6d 15 5a 15 01 00  64 01 64 0a 6c 16 6d 17  |l.m.Z...d.d.l.m.|
000000c0  5a 17 6d 18 5a 18 01 00  64 01 64 0b 6c 19 6d 1a  |Z.m.Z...d.d.l.m.|
000000d0  5a 1a 6d 1b 5a 1b 6d 1c  5a 1c 6d 1d 5a 1d 01 00  |Z.m.Z.m.Z.m.Z...|
000000e0  64 0c 64 0d 6c 1e 6d 1f  5a 1f 01 00 64 0c 64 0e  |d.d.l.m.Z...d.d.|
000000f0  6c 20 6d 21 5a 21 6d 22  5a 23 01 00 64 0c 64 0f  |l m!Z!m"Z#..d.d.|
00000100  6c 24 6d 25 5a 25 01 00  64 0c 64 10 6c 26 6d 27  |l$m%Z%..d.d.l&m'|
00000110  5a 27 01 00 64 01 64 11  6c 28 6d 29 5a 29 01 00  |Z'..d.d.l(m)Z)..|
00000120  65 1a 72 0c 64 01 64 12  6c 2a 6d 2b 5a 2b 01 00  |e.r.d.d.l*m+Z+..|
00000130  64 01 64 13 6c 2c 6d 2d  5a 2d 01 00 02 00 65 1d  |d.d.l,m-Z-....e.|
00000140  64 14 ab 01 00 00 00 00  00 00 5a 2e 02 00 65 1d  |d.........Z...e.|
00000150  64 15 64 16 ac 17 ab 02  00 00 00 00 00 00 5a 2f  |d.d...........Z/|
00000160  02 00 47 00 64 18 84 00  64 19 ab 02 00 00 00 00  |..G.d...d.......|
00000170  00 00 5a 30 09 00 64 30  09 00 09 00 09 00 09 00  |..Z0..d0........|
00000180  09 00 64 31 64 1a 84 05  5a 31 09 00 64 30 09 00  |..d1d...Z1..d0..|
00000190  09 00 09 00 09 00 09 00  64 32 64 1b 84 05 5a 32  |........d2d...Z2|
000001a0  64 33 64 1c 84 04 5a 33  64 34 64 1d 84 04 5a 34  |d3d...Z3d4d...Z4|
000001b0  64 35 64 1e 84 04 5a 35  09 00 09 00 64 36 09 00  |d5d...Z5....d6..|
000001c0  09 00 09 00 09 00 09 00  09 00 09 00 64 37 64 1f  |............d7d.|
000001d0  84 05 5a 36 64 38 64 20  84 04 5a 37 64 39 64 21  |..Z6d8d ..Z7d9d!|
000001e0  84 04 5a 38 09 00 09 00  09 00 09 00 09 00 09 00  |..Z8............|
000001f0  09 00 09 00 64 3a 64 22  84 04 5a 39 09 00 09 00  |....d:d"..Z9....|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/expand.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/pyprojecttoml.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 23K 2025-06-01 01:30:12.183978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/pyprojecttoml.cpython-312.pyc
92112e5d4a792fb2737acfd16b68b674cb7b18ae48b01111b8674a44056c354b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/pyprojecttoml.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 90 47 00 00  |..........8h.G..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 01 f3 e0 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 64 01 64 03  |d.d.l.m.Z...d.d.|
00000040  6c 03 5a 03 64 01 64 03  6c 04 5a 04 64 01 64 04  |l.Z.d.d.l.Z.d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 64 01 64 06  6c 09 6d 0a 5a 0a 01 00  |Z...d.d.l.m.Z...|
00000070  64 01 64 07 6c 0b 6d 0c  5a 0c 01 00 64 01 64 08  |d.d.l.m.Z...d.d.|
00000080  6c 0d 6d 0e 5a 0e 6d 0f  5a 0f 6d 10 5a 10 01 00  |l.m.Z.m.Z.m.Z...|
00000090  64 09 64 0a 6c 11 6d 12  5a 12 01 00 64 09 64 0b  |d.d.l.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 6d 15  5a 15 01 00 64 09 64 0c  |l.m.Z.m.Z...d.d.|
000000b0  6c 16 6d 17 5a 17 01 00  64 0d 64 0e 6c 18 6d 19  |l.m.Z...d.d.l.m.|
000000c0  5a 1a 01 00 64 0d 64 0f  6c 1b 6d 1c 5a 1c 6d 1d  |Z...d.d.l.m.Z.m.|
000000d0  5a 1d 6d 1e 5a 1f 01 00  65 0e 72 0c 64 01 64 10  |Z.m.Z...e.r.d.d.|
000000e0  6c 20 6d 21 5a 21 01 00  64 01 64 11 6c 22 6d 23  |l m!Z!..d.d.l"m#|
000000f0  5a 23 01 00 02 00 65 03  6a 48 00 00 00 00 00 00  |Z#....e.jH......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 65 25 ab 01  |............e%..|
00000110  00 00 00 00 00 00 5a 26  64 21 64 12 84 04 5a 27  |......Z&d!d...Z'|
00000120  64 22 64 13 84 04 5a 28  09 00 64 23 09 00 09 00  |d"d...Z(..d#....|
00000130  09 00 09 00 09 00 09 00  09 00 64 24 64 14 84 05  |..........d$d...|
00000140  5a 29 09 00 09 00 09 00  64 25 09 00 09 00 09 00  |Z)......d%......|
00000150  09 00 09 00 09 00 09 00  09 00 09 00 64 26 64 15  |............d&d.|
00000160  84 05 5a 2a 09 00 09 00  09 00 64 27 09 00 09 00  |..Z*......d'....|
00000170  09 00 09 00 09 00 09 00  09 00 09 00 09 00 64 28  |..............d(|
00000180  64 16 84 05 5a 2b 02 00  47 00 64 17 84 00 64 18  |d...Z+..G.d...d.|
00000190  ab 02 00 00 00 00 00 00  5a 2c 64 19 84 00 5a 2d  |........Z,d...Z-|
000001a0  65 08 64 29 64 1a 84 04  ab 00 00 00 00 00 00 00  |e.d)d...........|
000001b0  5a 2e 02 00 47 00 64 1b  84 00 64 1c 65 1a 6a 5e  |Z...G.d...d.e.j^|
000001c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001d0  00 00 ab 03 00 00 00 00  00 00 5a 30 02 00 47 00  |..........Z0..G.|
000001e0  64 1d 84 00 64 1e 65 17  ab 03 00 00 00 00 00 00  |d...d.e.........|
000001f0  5a 31 02 00 47 00 64 1f  84 00 64 20 65 17 ab 03  |Z1..G.d...d e...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/pyprojecttoml.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/setupcfg.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 33K 2025-06-01 01:30:12.347978098 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/setupcfg.cpython-312.pyc
f0e87145a34d252d1ead59a873b9167be434991bf66035c7fe59f25fe3f670ae  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/setupcfg.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 cf 67 00 00  |..........8h.g..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 01 f3 60 02  00 00 97 00 55 00 64 00  |......`.....U.d.|
00000030  5a 00 64 01 64 02 6c 01  6d 02 5a 02 01 00 64 01  |Z.d.d.l.m.Z...d.|
00000040  64 03 6c 03 5a 03 64 01  64 03 6c 04 5a 04 64 01  |d.l.Z.d.d.l.Z.d.|
00000050  64 03 6c 05 5a 05 64 01  64 04 6c 06 6d 07 5a 07  |d.l.Z.d.d.l.m.Z.|
00000060  01 00 64 01 64 05 6c 08  6d 09 5a 09 6d 0a 5a 0a  |..d.d.l.m.Z.m.Z.|
00000070  01 00 64 01 64 06 6c 04  6d 0b 5a 0b 6d 0c 5a 0c  |..d.d.l.m.Z.m.Z.|
00000080  01 00 64 01 64 07 6c 0d  6d 0e 5a 0e 6d 0f 5a 0f  |..d.d.l.m.Z.m.Z.|
00000090  6d 10 5a 10 6d 11 5a 11  6d 12 5a 12 6d 13 5a 13  |m.Z.m.Z.m.Z.m.Z.|
000000a0  6d 14 5a 14 01 00 64 01  64 08 6c 15 6d 16 5a 17  |m.Z...d.d.l.m.Z.|
000000b0  01 00 64 01 64 09 6c 18  6d 19 5a 19 6d 1a 5a 1a  |..d.d.l.m.Z.m.Z.|
000000c0  01 00 64 01 64 0a 6c 1b  6d 1c 5a 1c 6d 1d 5a 1d  |..d.d.l.m.Z.m.Z.|
000000d0  01 00 64 0b 64 0c 6c 1e  6d 1f 5a 1f 01 00 64 0b  |..d.d.l.m.Z...d.|
000000e0  64 0d 6c 20 6d 21 5a 21  01 00 64 0b 64 0e 6c 22  |d.l m!Z!..d.d.l"|
000000f0  6d 23 5a 23 6d 24 5a 24  01 00 64 0b 64 0f 6c 25  |m#Z#m$Z$..d.d.l%|
00000100  6d 26 5a 26 01 00 64 10  64 11 6c 1e 6d 27 5a 27  |m&Z&..d.d.l.m'Z'|
00000110  01 00 65 0e 72 12 64 01  64 12 6c 28 6d 29 5a 29  |..e.r.d.d.l(m)Z)|
00000120  01 00 64 01 64 13 6c 2a  6d 2b 5a 2b 01 00 64 01  |..d.d.l*m+Z+..d.|
00000130  64 14 6c 2c 6d 2d 5a 2d  01 00 65 2e 65 2f 65 30  |d.l,m-Z-..e.e/e0|
00000140  65 2f 65 0f 66 02 19 00  00 00 66 02 19 00 00 00  |e/e.f.....f.....|
00000150  5a 31 64 15 65 32 64 16  3c 00 00 00 09 00 65 2e  |Z1d.e2d.<.....e.|
00000160  65 2f 65 31 66 02 19 00  00 00 5a 33 64 15 65 32  |e/e1f.....Z3d.e2|
00000170  64 17 3c 00 00 00 09 00  02 00 65 13 64 18 64 19  |d.<.......e.d.d.|
00000180  64 1a ab 03 00 00 00 00  00 00 5a 34 09 00 64 2c  |d.........Z4..d,|
00000190  09 00 09 00 09 00 09 00  09 00 09 00 09 00 64 2d  |..............d-|
000001a0  64 1b 84 05 5a 35 64 2e  64 1c 84 04 5a 36 09 00  |d...Z5d.d...Z6..|
000001b0  09 00 64 2f 09 00 09 00  09 00 09 00 09 00 09 00  |..d/............|
000001c0  09 00 09 00 09 00 64 30  64 1d 84 05 5a 37 64 31  |......d0d...Z7d1|
000001d0  64 1e 84 04 5a 38 09 00  09 00 09 00 09 00 64 32  |d...Z8........d2|
000001e0  64 1f 84 04 5a 39 09 00  64 33 09 00 09 00 09 00  |d...Z9..d3......|
000001f0  09 00 09 00 09 00 09 00  64 34 64 20 84 05 5a 3a  |........d4d ..Z:|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/config/__pycache__/setupcfg.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/test_bdist_wheel.py
-rwxrwxrwx. 1 u0_a292 u0_a292 23K 2025-06-02 22:55:15.750164467 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/test_bdist_wheel.py
adf512c661f53e954ed708fd5c0692c2bfad3ac91d8575744b20bfc6d9ad08e3  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/test_bdist_wheel.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----