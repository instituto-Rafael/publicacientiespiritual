#!/usr/bin/env python3
def ativar(): print("RAFAELIA ativada com núcleo cognitivo!")

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia/__init__.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 383 2025-06-01 01:30:23.115978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia/__pycache__/__init__.cpython-312.pyc
73a4e71d41d5afc0fdcbfbceab3108852c29251421b064383bee6058c3f3a6cb  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  7e 9b 38 68 3f 00 00 00  |........~.8h?...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 0a 00  00 00 97 00 64 00 84 00  |............d...|
00000030  5a 00 79 01 29 02 63 00  00 00 00 00 00 00 00 00  |Z.y.).c.........|
00000040  00 00 00 03 00 00 00 03  00 00 00 f3 1a 00 00 00  |................|
00000050  97 00 74 01 00 00 00 00  00 00 00 00 64 01 ab 01  |..t.........d...|
00000060  00 00 00 00 00 00 01 00  79 00 29 02 4e 75 27 00  |........y.).Nu'.|
00000070  00 00 52 41 46 41 45 4c  49 41 20 61 74 69 76 61  |..RAFAELIA ativa|
00000080  64 61 20 63 6f 6d 20 6e  c3 ba 63 6c 65 6f 20 63  |da com n..cleo c|
00000090  6f 67 6e 69 74 69 76 6f  21 29 01 da 05 70 72 69  |ognitivo!)...pri|
000000a0  6e 74 a9 00 f3 00 00 00  00 fa 73 2f 64 61 74 61  |nt........s/data|
000000b0  2f 64 61 74 61 2f 63 6f  6d 2e 74 65 72 6d 75 78  |/data/com.termux|
000000c0  2f 66 69 6c 65 73 2f 68  6f 6d 65 2f 52 41 46 41  |/files/home/RAFA|
000000d0  45 4c 49 41 2f 48 43 50  4d 2f 43 4f 52 45 2f 76  |ELIA/HCPM/CORE/v|
000000e0  65 6e 76 5f 72 61 66 61  65 6c 69 61 2f 6c 69 62  |env_rafaelia/lib|
000000f0  2f 70 79 74 68 6f 6e 33  2e 31 32 2f 73 69 74 65  |/python3.12/site|
00000100  2d 70 61 63 6b 61 67 65  73 2f 72 61 66 61 65 6c  |-packages/rafael|
00000110  69 61 2f 5f 5f 69 6e 69  74 5f 5f 2e 70 79 da 06  |ia/__init__.py..|
00000120  61 74 69 76 61 72 72 07  00 00 00 01 00 00 00 73  |ativarr........s|
00000130  0a 00 00 00 80 00 8c 65  d0 14 3d d5 0e 3e 72 05  |.......e..=..>r.|
00000140  00 00 00 4e 29 01 72 07  00 00 00 72 04 00 00 00  |...N).r....r....|
00000150  72 05 00 00 00 72 06 00  00 00 da 08 3c 6d 6f 64  |r....r......<mod|
00000160  75 6c 65 3e 72 08 00 00  00 01 00 00 00 73 08 00  |ule>r........s..|
00000170  00 00 f0 03 01 01 01 db  00 3e 72 05 00 00 00     |.........>r....|
0000017f
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip-25.1.1.dist-info/RECORD
-rwxrwxrwx. 1 u0_a292 u0_a292 65K 2025-05-25 17:09:04.272414715 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip-25.1.1.dist-info/RECORD
064d4be15827e9983fc784b5792e87b68819f9266cd7bad7317fb1a3943a6eaf  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip-25.1.1.dist-info/RECORD
MIME: text/csv
----- INÍCIO DO CONTEÚDO (texto detectado: text/csv) -----
../../../bin/pip,sha256=tAktwJ1EGIebvsYiZqRlWXsRGxAhkkKd-fhxS6alzso,281
../../../bin/pip3,sha256=tAktwJ1EGIebvsYiZqRlWXsRGxAhkkKd-fhxS6alzso,281
../../../bin/pip3.12,sha256=tAktwJ1EGIebvsYiZqRlWXsRGxAhkkKd-fhxS6alzso,281
pip-25.1.1.dist-info/INSTALLER,sha256=zuuue4knoyJ-UwPPXg8fezS7VCrXJQrAP7zeNuwvFQg,4
pip-25.1.1.dist-info/METADATA,sha256=QFxj1tLpk8hGWrgQLRhJYUpwo_1FqBr43OT0srIZcmU,3649
pip-25.1.1.dist-info/RECORD,,
pip-25.1.1.dist-info/REQUESTED,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip-25.1.1.dist-info/WHEEL,sha256=pxyMxgL8-pra_rKaQ4drOZAegBVuX-G_4nRHjjgWbmo,91
pip-25.1.1.dist-info/entry_points.txt,sha256=eeIjuzfnfR2PrhbjnbzFU6MnSS70kZLxwaHHq6M-bD0,87
pip-25.1.1.dist-info/licenses/AUTHORS.txt,sha256=YzDFTYpeYnwpmODDFTgyKZNKWcfdO10L5Ex_U6kJLRc,11223
pip-25.1.1.dist-info/licenses/LICENSE.txt,sha256=Y0MApmnUmurmWxLGxIySTFGkzfPR_whtw0VtyLyqIQQ,1093
pip-25.1.1.dist-info/top_level.txt,sha256=zuuue4knoyJ-UwPPXg8fezS7VCrXJQrAP7zeNuwvFQg,4
pip/__init__.py,sha256=zQQ7Na8YWi0IN86IUKEzDAJtyVpXdJXYDkQ536caUiQ,357
pip/__main__.py,sha256=WzbhHXTbSE6gBY19mNN9m4s5o_365LOvTYSgqgbdBhE,854
pip/__pip-runner__.py,sha256=JOoEZTwrtv7jRaXBkgSQKAE04yNyfFmGHxqpHiGHvL0,1450
pip/__pycache__/__init__.cpython-312.pyc,,
pip/__pycache__/__main__.cpython-312.pyc,,
pip/__pycache__/__pip-runner__.cpython-312.pyc,,
pip/_internal/__init__.py,sha256=MfcoOluDZ8QMCFYal04IqOJ9q6m2V7a0aOsnI-WOxUo,513
pip/_internal/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/__pycache__/build_env.cpython-312.pyc,,
pip/_internal/__pycache__/cache.cpython-312.pyc,,
pip/_internal/__pycache__/configuration.cpython-312.pyc,,
pip/_internal/__pycache__/exceptions.cpython-312.pyc,,
pip/_internal/__pycache__/main.cpython-312.pyc,,
pip/_internal/__pycache__/pyproject.cpython-312.pyc,,
pip/_internal/__pycache__/self_outdated_check.cpython-312.pyc,,
pip/_internal/__pycache__/wheel_builder.cpython-312.pyc,,
pip/_internal/build_env.py,sha256=60_espLI9X3C2db3Ww2gIcyjNk2cAPNcc5gsVO4DOqg,10924
pip/_internal/cache.py,sha256=SjhJK1C6NbonrU4AyYXKTOH0CGOk5cJrYt60mRANnPM,10368
pip/_internal/cli/__init__.py,sha256=Iqg_tKA771XuMO1P4t_sDHnSKPzkUb9D0DqunAmw_ko,131
pip/_internal/cli/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/cli/__pycache__/autocompletion.cpython-312.pyc,,
pip/_internal/cli/__pycache__/base_command.cpython-312.pyc,,
pip/_internal/cli/__pycache__/cmdoptions.cpython-312.pyc,,
pip/_internal/cli/__pycache__/command_context.cpython-312.pyc,,
pip/_internal/cli/__pycache__/index_command.cpython-312.pyc,,
pip/_internal/cli/__pycache__/main.cpython-312.pyc,,
pip/_internal/cli/__pycache__/main_parser.cpython-312.pyc,,
pip/_internal/cli/__pycache__/parser.cpython-312.pyc,,
pip/_internal/cli/__pycache__/progress_bars.cpython-312.pyc,,
pip/_internal/cli/__pycache__/req_command.cpython-312.pyc,,
pip/_internal/cli/__pycache__/spinners.cpython-312.pyc,,
pip/_internal/cli/__pycache__/status_codes.cpython-312.pyc,,
pip/_internal/cli/autocompletion.py,sha256=fs0Wy16Ga5tX1IZKvww5BDi7i5zyzfCPvu7cgXlgXys,6864
pip/_internal/cli/base_command.py,sha256=0A8YuJVJh2YyXU8pdW0eidLg1eklCW5cU01mpI-FAxA,8351
pip/_internal/cli/cmdoptions.py,sha256=-_V4gjMa0c3U8-vXKAyb5xVViJNzFAxBI3Zx_6Ds5-g,31909
pip/_internal/cli/command_context.py,sha256=RHgIPwtObh5KhMrd3YZTkl8zbVG-6Okml7YbFX4Ehg0,774
pip/_internal/cli/index_command.py,sha256=kplkusUgCZy75jNCo-etaDmSG8UvqcR2W50ALDdm6dk,5720
pip/_internal/cli/main.py,sha256=1bXC7uL3tdb_EZlGVKs6_TgzC9tlKU7zhAZsbZA-IzY,2816
pip/_internal/cli/main_parser.py,sha256=chZqNmCuO_JYt8ynBCumh4crURaRoXBZ0RxoSYQIwCw,4337
pip/_internal/cli/parser.py,sha256=VCMtduzECUV87KaHNu-xJ-wLNL82yT3x16V4XBxOAqI,10825
pip/_internal/cli/progress_bars.py,sha256=r9BD4T2-egcInB1Uh9Jjw3EP9F3INy5kZhGwSePm9jo,4435
pip/_internal/cli/req_command.py,sha256=1yfssBvnUKNer8D7iT3OHqdJJNdCqRhwDqUFWgieppk,12934
pip/_internal/cli/spinners.py,sha256=hIJ83GerdFgFCdobIA23Jggetegl_uC4Sp586nzFbPE,5118
pip/_internal/cli/status_codes.py,sha256=sEFHUaUJbqv8iArL3HAtcztWZmGOFX01hTesSytDEh0,116
pip/_internal/commands/__init__.py,sha256=3405KyFv4l0ruxeF69oosFanxNQcC_fHBGv7Rpt0PXg,4009
pip/_internal/commands/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/commands/__pycache__/cache.cpython-312.pyc,,
pip/_internal/commands/__pycache__/check.cpython-312.pyc,,
pip/_internal/commands/__pycache__/completion.cpython-312.pyc,,
pip/_internal/commands/__pycache__/configuration.cpython-312.pyc,,
pip/_internal/commands/__pycache__/debug.cpython-312.pyc,,
pip/_internal/commands/__pycache__/download.cpython-312.pyc,,
pip/_internal/commands/__pycache__/freeze.cpython-312.pyc,,
pip/_internal/commands/__pycache__/hash.cpython-312.pyc,,
pip/_internal/commands/__pycache__/help.cpython-312.pyc,,
pip/_internal/commands/__pycache__/index.cpython-312.pyc,,
pip/_internal/commands/__pycache__/inspect.cpython-312.pyc,,
pip/_internal/commands/__pycache__/install.cpython-312.pyc,,
pip/_internal/commands/__pycache__/list.cpython-312.pyc,,
pip/_internal/commands/__pycache__/lock.cpython-312.pyc,,
pip/_internal/commands/__pycache__/search.cpython-312.pyc,,
pip/_internal/commands/__pycache__/show.cpython-312.pyc,,
pip/_internal/commands/__pycache__/uninstall.cpython-312.pyc,,
pip/_internal/commands/__pycache__/wheel.cpython-312.pyc,,
pip/_internal/commands/cache.py,sha256=IOezTicHjGE5sWdBx2nwPVgbjuJHM3s-BZEkpZLemuY,8107
pip/_internal/commands/check.py,sha256=Hr_4eiMd9cgVDgEvjtIdw915NmL7ROIWW8enkr8slPQ,2268
pip/_internal/commands/completion.py,sha256=W9QFQTPLjy2tPACJ_y3g9EgB1pbsh7pvCUX8ocuIdPg,4554
pip/_internal/commands/configuration.py,sha256=n98enwp6y0b5G6fiRQjaZo43FlJKYve_daMhN-4BRNc,9766
pip/_internal/commands/debug.py,sha256=DNDRgE9YsKrbYzU0s3VKi8rHtKF4X13CJ_br_8PUXO0,6797
pip/_internal/commands/download.py,sha256=0qB0nys6ZEPsog451lDsjL5Bx7Z97t-B80oFZKhpzKM,5273
pip/_internal/commands/freeze.py,sha256=YW-aMmAzzOaBWWobo9g4DPKuWp0dTC32lWMqXzKFLzE,3144
pip/_internal/commands/hash.py,sha256=EVVOuvGtoPEdFi8SNnmdqlCQrhCxV-kJsdwtdcCnXGQ,1703
pip/_internal/commands/help.py,sha256=gcc6QDkcgHMOuAn5UxaZwAStsRBrnGSn_yxjS57JIoM,1132
pip/_internal/commands/index.py,sha256=8UucFVwx6FmM8cNbaPY8iI5kZdV3f6jhqDa-S8aGgpg,5068
pip/_internal/commands/inspect.py,sha256=PGrY9TRTRCM3y5Ml8Bdk8DEOXquWRfscr4DRo1LOTPc,3189
pip/_internal/commands/install.py,sha256=SRsiLpead7A8bLdxMqxTAJM3sUFHtgN9zgBT98UQz5E,29757
pip/_internal/commands/list.py,sha256=Rwtf8B0d0-WrkM7Qsv41-dWg8I_r9BLuZV30wSWnzgU,13274
pip/_internal/commands/lock.py,sha256=bUYrryKa769UXM61imojoeVVgc_1ZHK-9a0hIJmmlCg,5941
pip/_internal/commands/search.py,sha256=IrfvxcRCSoZY9A5XAlCF1wtl_y2HPcXslQdHcjzwMNk,5784
pip/_internal/commands/show.py,sha256=Yh5rGYhR2Io5TkL0fFCMWE1VqqM4xhPHjhbdS3QgEac,8028
pip/_internal/commands/uninstall.py,sha256=7pOR7enK76gimyxQbzxcG1OsyLXL3DvX939xmM8Fvtg,3892
pip/_internal/commands/wheel.py,sha256=NEfaVF4f41VBNSn93RL8gkfCEDmdGhbP9xu_dE6cdUk,6346
pip/_internal/configuration.py,sha256=-KOok6jh3hFzXMPQFPJ1_EFjBpAsge-RSreQuLHLmzo,14005
pip/_internal/distributions/__init__.py,sha256=Hq6kt6gXBgjNit5hTTWLAzeCNOKoB-N0pGYSqehrli8,858
pip/_internal/distributions/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/distributions/__pycache__/base.cpython-312.pyc,,
pip/_internal/distributions/__pycache__/installed.cpython-312.pyc,,
pip/_internal/distributions/__pycache__/sdist.cpython-312.pyc,,
pip/_internal/distributions/__pycache__/wheel.cpython-312.pyc,,
pip/_internal/distributions/base.py,sha256=QeB9qvKXDIjLdPBDE5fMgpfGqMMCr-govnuoQnGuiF8,1783
pip/_internal/distributions/installed.py,sha256=QinHFbWAQ8oE0pbD8MFZWkwlnfU1QYTccA1vnhrlYOU,842
pip/_internal/distributions/sdist.py,sha256=PlcP4a6-R6c98XnOM-b6Lkb3rsvh9iG4ok8shaanrzs,6751
pip/_internal/distributions/wheel.py,sha256=THBYfnv7VVt8mYhMYUtH13S1E7FDwtDyDfmUcl8ai0E,1317
pip/_internal/exceptions.py,sha256=wpE11H0e4L9G6AH70sRG149z82X7wX530HK-9eA_DIQ,28464
pip/_internal/index/__init__.py,sha256=tzwMH_fhQeubwMqHdSivasg1cRgTSbNg2CiMVnzMmyU,29
pip/_internal/index/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/index/__pycache__/collector.cpython-312.pyc,,
pip/_internal/index/__pycache__/package_finder.cpython-312.pyc,,
pip/_internal/index/__pycache__/sources.cpython-312.pyc,,
pip/_internal/index/collector.py,sha256=RdPO0JLAlmyBWPAWYHPyRoGjz3GNAeTngCNkbGey_mE,16265
pip/_internal/index/package_finder.py,sha256=RohRzzLExoXl7QDdTiqyxIaQEcHUn6UNOr9KzC1vjL0,38446
pip/_internal/index/sources.py,sha256=lPBLK5Xiy8Q6IQMio26Wl7ocfZOKkgGklIBNyUJ23fI,8632
pip/_internal/locations/__init__.py,sha256=vvTMNxghT0aEXrSdqpNtuRDGx08bzJxfDAUUfQ0Vb0A,14309
pip/_internal/locations/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/locations/__pycache__/_distutils.cpython-312.pyc,,
pip/_internal/locations/__pycache__/_sysconfig.cpython-312.pyc,,
pip/_internal/locations/__pycache__/base.cpython-312.pyc,,
pip/_internal/locations/_distutils.py,sha256=x6nyVLj7X11Y4khIdf-mFlxMl2FWadtVEgeb8upc_WI,6013
pip/_internal/locations/_sysconfig.py,sha256=IGzds60qsFneRogC-oeBaY7bEh3lPt_v47kMJChQXsU,7724
pip/_internal/locations/base.py,sha256=RQiPi1d4FVM2Bxk04dQhXZ2PqkeljEL2fZZ9SYqIQ78,2556
pip/_internal/main.py,sha256=r-UnUe8HLo5XFJz8inTcOOTiu_sxNhgHb6VwlGUllOI,340
pip/_internal/metadata/__init__.py,sha256=nGWuZvjQlIHudlMz_-bsUs2LDA2ZKNPGevZoEGcd64Y,5723
pip/_internal/metadata/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/metadata/__pycache__/_json.cpython-312.pyc,,
pip/_internal/metadata/__pycache__/base.cpython-312.pyc,,
pip/_internal/metadata/__pycache__/pkg_resources.cpython-312.pyc,,
pip/_internal/metadata/_json.py,sha256=ezrIYazHCINM2QUk1eA9wEAMj3aeGWeDVgGalgUzKpc,2707
pip/_internal/metadata/base.py,sha256=jCbzdIc8MgWnPR4rfrvSQhSVzSoOyKOXhj3xe8BoG8c,25467
pip/_internal/metadata/importlib/__init__.py,sha256=jUUidoxnHcfITHHaAWG1G2i5fdBYklv_uJcjo2x7VYE,135
pip/_internal/metadata/importlib/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/metadata/importlib/__pycache__/_compat.cpython-312.pyc,,
pip/_internal/metadata/importlib/__pycache__/_dists.cpython-312.pyc,,
pip/_internal/metadata/importlib/__pycache__/_envs.cpython-312.pyc,,
pip/_internal/metadata/importlib/_compat.py,sha256=c6av8sP8BBjAZuFSJow1iWfygUXNM3xRTCn5nqw6B9M,2796
pip/_internal/metadata/importlib/_dists.py,sha256=ftmYiyfUGUIjnVwt6W-Ijsimy5c28KgmXly5Q5IQ2P4,8279
pip/_internal/metadata/importlib/_envs.py,sha256=X63CkdAPJCYPhefYSLiQzPf9ijMXm5nL_A_Z68yp2-w,5297
pip/_internal/metadata/pkg_resources.py,sha256=U07ETAINSGeSRBfWUG93E4tZZbaW_f7PGzEqZN0hulc,10542
pip/_internal/models/__init__.py,sha256=AjmCEBxX_MH9f_jVjIGNCFJKYCYeSEe18yyvNx4uRKQ,62
pip/_internal/models/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/models/__pycache__/candidate.cpython-312.pyc,,
pip/_internal/models/__pycache__/direct_url.cpython-312.pyc,,
pip/_internal/models/__pycache__/format_control.cpython-312.pyc,,
pip/_internal/models/__pycache__/index.cpython-312.pyc,,
pip/_internal/models/__pycache__/installation_report.cpython-312.pyc,,
pip/_internal/models/__pycache__/link.cpython-312.pyc,,
pip/_internal/models/__pycache__/pylock.cpython-312.pyc,,
pip/_internal/models/__pycache__/scheme.cpython-312.pyc,,
pip/_internal/models/__pycache__/search_scope.cpython-312.pyc,,
pip/_internal/models/__pycache__/selection_prefs.cpython-312.pyc,,
pip/_internal/models/__pycache__/target_python.cpython-312.pyc,,
pip/_internal/models/__pycache__/wheel.cpython-312.pyc,,
pip/_internal/models/candidate.py,sha256=zzgFRuw_kWPjKpGw7LC0ZUMD2CQ2EberUIYs8izjdCA,753
pip/_internal/models/direct_url.py,sha256=lJ1fIVTgk5UG5SzTNR0FpgSGAQjChlH-3otgiEJAhIs,6576
pip/_internal/models/format_control.py,sha256=wtsQqSK9HaUiNxQEuB-C62eVimw6G4_VQFxV9-_KDBE,2486
pip/_internal/models/index.py,sha256=tYnL8oxGi4aSNWur0mG8DAP7rC6yuha_MwJO8xw0crI,1030
pip/_internal/models/installation_report.py,sha256=zRVZoaz-2vsrezj_H3hLOhMZCK9c7TbzWgC-jOalD00,2818
pip/_internal/models/link.py,sha256=wIAgxhiu05ycLhbtAibknXX5L6X9ju_PPLVnMcvh9B4,21511
pip/_internal/models/pylock.py,sha256=n3-I26bf2v-Kn6qcx4ATB_Zel2SLhaUxZBmsMeGgYAo,6196
pip/_internal/models/scheme.py,sha256=PakmHJM3e8OOWSZFtfz1Az7f1meONJnkGuQxFlt3wBE,575
pip/_internal/models/search_scope.py,sha256=67NEnsYY84784S-MM7ekQuo9KXLH-7MzFntXjapvAo0,4531
pip/_internal/models/selection_prefs.py,sha256=qaFfDs3ciqoXPg6xx45N1jPLqccLJw4N0s4P0PyHTQ8,2015
pip/_internal/models/target_python.py,sha256=2XaH2rZ5ZF-K5wcJbEMGEl7SqrTToDDNkrtQ2v_v_-Q,4271
pip/_internal/models/wheel.py,sha256=10NUTXIRjf2P8oe1Wzolv8oUv7-YurrOduVFUIaDhdM,5506
pip/_internal/network/__init__.py,sha256=FMy06P__y6jMjUc8z3ZcQdKF-pmZ2zM14_vBeHPGhUI,49
pip/_internal/network/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/network/__pycache__/auth.cpython-312.pyc,,
pip/_internal/network/__pycache__/cache.cpython-312.pyc,,
pip/_internal/network/__pycache__/download.cpython-312.pyc,,
pip/_internal/network/__pycache__/lazy_wheel.cpython-312.pyc,,
pip/_internal/network/__pycache__/session.cpython-312.pyc,,
pip/_internal/network/__pycache__/utils.cpython-312.pyc,,
pip/_internal/network/__pycache__/xmlrpc.cpython-312.pyc,,
pip/_internal/network/auth.py,sha256=D4gASjUrqoDFlSt6gQ767KAAjv6PUyJU0puDlhXNVRE,20809
pip/_internal/network/cache.py,sha256=JGYT-BUaSMdEBwII_K1UE6qyBItz7hzGkyLl_JRzkBY,4613
pip/_internal/network/download.py,sha256=6IdZyoERWIsXXFUFL_h_e_xi8Z0G0UlpkodPy8qKv2U,11078
pip/_internal/network/lazy_wheel.py,sha256=PBdoMoNQQIA84Fhgne38jWF52W4x_KtsHjxgv4dkRKA,7622
pip/_internal/network/session.py,sha256=msM4es16LmmNEYNkrYyg8fTc7gAHbKFltawfKP27LOI,18771
pip/_internal/network/utils.py,sha256=Inaxel-NxBu4PQWkjyErdnfewsFCcgHph7dzR1-FboY,4088
pip/_internal/network/xmlrpc.py,sha256=jW9oDSWamMld3iZOO9RbonVC8ZStkHyppCszoevkuJg,1837
pip/_internal/operations/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_internal/operations/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/operations/__pycache__/check.cpython-312.pyc,,
pip/_internal/operations/__pycache__/freeze.cpython-312.pyc,,
pip/_internal/operations/__pycache__/prepare.cpython-312.pyc,,
pip/_internal/operations/build/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_internal/operations/build/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/build_tracker.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/metadata.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/metadata_editable.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/metadata_legacy.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/wheel.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/wheel_editable.cpython-312.pyc,,
pip/_internal/operations/build/__pycache__/wheel_legacy.cpython-312.pyc,,
pip/_internal/operations/build/build_tracker.py,sha256=-ARW_TcjHCOX7D2NUOGntB4Fgc6b4aolsXkAK6BWL7w,4774
pip/_internal/operations/build/metadata.py,sha256=INHaeiRfOiLYCXApfDNRo9Cw2xI4VwTc0KItvfdfOjk,1421
pip/_internal/operations/build/metadata_editable.py,sha256=oWudMsnjy4loO_Jy7g4N9nxsnaEX_iDlVRgCy7pu1rs,1509
pip/_internal/operations/build/metadata_legacy.py,sha256=wv8cFA0wTqF62Jlm9QwloYZsofOyQ7sWBBmvCcVvn1k,2189
pip/_internal/operations/build/wheel.py,sha256=sT12FBLAxDC6wyrDorh8kvcZ1jG5qInCRWzzP-UkJiQ,1075
pip/_internal/operations/build/wheel_editable.py,sha256=yOtoH6zpAkoKYEUtr8FhzrYnkNHQaQBjWQ2HYae1MQg,1417
pip/_internal/operations/build/wheel_legacy.py,sha256=KXpyGYoCQYcudXNZvohLXgWHaCk4Gf3z0dbS9ol4uu0,3620
pip/_internal/operations/check.py,sha256=4cnD_2eglsDe5s2CoYkxDt4HcRitTywzLMfTZ-tGQ4U,5911
pip/_internal/operations/freeze.py,sha256=1_M79jAQKnCxWr-KCCmHuVXOVFGaUJHmoWLfFzgh7K4,9843
pip/_internal/operations/install/__init__.py,sha256=ak-UETcQPKlFZaWoYKWu5QVXbpFBvg0sXc3i0O4vSYY,50
pip/_internal/operations/install/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/operations/install/__pycache__/editable_legacy.cpython-312.pyc,,
pip/_internal/operations/install/__pycache__/wheel.cpython-312.pyc,,
pip/_internal/operations/install/editable_legacy.py,sha256=TI6wT8sLqDTprWZLYEOBOe7a6-1B9uwKb7kTBxLIaWY,1282
pip/_internal/operations/install/wheel.py,sha256=4NYSQ9ypl69iiduh5gUPCK3WNYqouTHZ0rMXoVgkiZw,27553
pip/_internal/operations/prepare.py,sha256=-i9dYwwJJjN7h6sZTabcz84tizgn7EAsY0sHnLAfs3Q,28363
pip/_internal/pyproject.py,sha256=GLJ6rWRS5_2noKdajohoLyDty57Z7QXhcUAYghmTnWc,7286
pip/_internal/req/__init__.py,sha256=dX2QGlfDwEqE5pLjOeM-f2qEgXFn6f2Vdi_zIHAYy1k,3096
pip/_internal/req/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/req/__pycache__/constructors.cpython-312.pyc,,
pip/_internal/req/__pycache__/req_dependency_group.cpython-312.pyc,,
pip/_internal/req/__pycache__/req_file.cpython-312.pyc,,
pip/_internal/req/__pycache__/req_install.cpython-312.pyc,,
pip/_internal/req/__pycache__/req_set.cpython-312.pyc,,
pip/_internal/req/__pycache__/req_uninstall.cpython-312.pyc,,
pip/_internal/req/constructors.py,sha256=v1qzCN1mIldwx-nCrPc8JO4lxkm3Fv8M5RWvt8LISjc,18430
pip/_internal/req/req_dependency_group.py,sha256=5PGuZidqwDeTHZkP4tnNrlPrasfvJBONd1B5S0146zs,2677
pip/_internal/req/req_file.py,sha256=eys82McgaICOGic2UZRHjD720piKJPwmeSYdXlWwl6w,20234
pip/_internal/req/req_install.py,sha256=gMoFak9zrhjHlHaOQxPFheHKtIobppFgq1WrKel_nTE,35788
pip/_internal/req/req_set.py,sha256=j3esG0s6SzoVReX9rWn4rpYNtyET_fwxbwJPRimvRxo,2858
pip/_internal/req/req_uninstall.py,sha256=PQ6SyocDycUYsLAsTpjkbdwO_qjdo-y8BvQfZ5Avdrw,24075
pip/_internal/resolution/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_internal/resolution/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/resolution/__pycache__/base.cpython-312.pyc,,
pip/_internal/resolution/base.py,sha256=qlmh325SBVfvG6Me9gc5Nsh5sdwHBwzHBq6aEXtKsLA,583
pip/_internal/resolution/legacy/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_internal/resolution/legacy/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/resolution/legacy/__pycache__/resolver.cpython-312.pyc,,
pip/_internal/resolution/legacy/resolver.py,sha256=3HZiJBRd1FTN6jQpI4qRO8-TbLYeIbUTS6PFvXnXs2w,24068
pip/_internal/resolution/resolvelib/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_internal/resolution/resolvelib/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/base.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/candidates.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/factory.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/found_candidates.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/provider.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/reporter.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/requirements.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/__pycache__/resolver.cpython-312.pyc,,
pip/_internal/resolution/resolvelib/base.py,sha256=DCf669FsqyQY5uqXeePDHQY1e4QO-pBzWH8O0s9-K94,5023
pip/_internal/resolution/resolvelib/candidates.py,sha256=U3Qp83jhM_RiJviyrlPCijbps6wYO6VsTDaTnCf_B3o,20241
pip/_internal/resolution/resolvelib/factory.py,sha256=FCvHc9M8UJ_7iU63QtPiHuq_BmfdnBiMJ8WaDBJNFxk,32668
pip/_internal/resolution/resolvelib/found_candidates.py,sha256=6lAF_pLQ2_Z0CBOHIFxGp6NfvT1uwIpCui6e-GgI5tk,6000
pip/_internal/resolution/resolvelib/provider.py,sha256=8ptYOOjfa336D4FZ751EQHR0LDq8jJhIGJXDou8Cv8Y,11190
pip/_internal/resolution/resolvelib/reporter.py,sha256=EwJAHOjWZ8eTHQWss7zJjmQEj6ooP6oWSwwVXFtgpqQ,3260
pip/_internal/resolution/resolvelib/requirements.py,sha256=7JG4Z72e5Yk4vU0S5ulGvbqTy4FMQGYhY5zQhX9zTtY,8065
pip/_internal/resolution/resolvelib/resolver.py,sha256=9zcR4c7UZV1j2ILTmb68Ck_5HdvQvf4cmTBE2bWHkKg,12785
pip/_internal/self_outdated_check.py,sha256=1PFtttvLAeyCVR3tPoBq2sOlPD0IJ-KSqU6bc1HUk9c,8318
pip/_internal/utils/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_internal/utils/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/utils/__pycache__/_jaraco_text.cpython-312.pyc,,
pip/_internal/utils/__pycache__/_log.cpython-312.pyc,,
pip/_internal/utils/__pycache__/appdirs.cpython-312.pyc,,
pip/_internal/utils/__pycache__/compat.cpython-312.pyc,,
pip/_internal/utils/__pycache__/compatibility_tags.cpython-312.pyc,,
pip/_internal/utils/__pycache__/datetime.cpython-312.pyc,,
pip/_internal/utils/__pycache__/deprecation.cpython-312.pyc,,
pip/_internal/utils/__pycache__/direct_url_helpers.cpython-312.pyc,,
pip/_internal/utils/__pycache__/egg_link.cpython-312.pyc,,
pip/_internal/utils/__pycache__/entrypoints.cpython-312.pyc,,
pip/_internal/utils/__pycache__/filesystem.cpython-312.pyc,,
pip/_internal/utils/__pycache__/filetypes.cpython-312.pyc,,
pip/_internal/utils/__pycache__/glibc.cpython-312.pyc,,
pip/_internal/utils/__pycache__/hashes.cpython-312.pyc,,
pip/_internal/utils/__pycache__/logging.cpython-312.pyc,,
pip/_internal/utils/__pycache__/misc.cpython-312.pyc,,
pip/_internal/utils/__pycache__/packaging.cpython-312.pyc,,
pip/_internal/utils/__pycache__/retry.cpython-312.pyc,,
pip/_internal/utils/__pycache__/setuptools_build.cpython-312.pyc,,
pip/_internal/utils/__pycache__/subprocess.cpython-312.pyc,,
pip/_internal/utils/__pycache__/temp_dir.cpython-312.pyc,,
pip/_internal/utils/__pycache__/unpacking.cpython-312.pyc,,
pip/_internal/utils/__pycache__/urls.cpython-312.pyc,,
pip/_internal/utils/__pycache__/virtualenv.cpython-312.pyc,,
pip/_internal/utils/__pycache__/wheel.cpython-312.pyc,,
pip/_internal/utils/_jaraco_text.py,sha256=M15uUPIh5NpP1tdUGBxRau6q1ZAEtI8-XyLEETscFfE,3350
pip/_internal/utils/_log.py,sha256=-jHLOE_THaZz5BFcCnoSL9EYAtJ0nXem49s9of4jvKw,1015
pip/_internal/utils/appdirs.py,sha256=zrIISCn2QxlXYw-zJZZBTrFNTyy_0WNKiI-TOoN6wJo,1705
pip/_internal/utils/compat.py,sha256=ckkFveBiYQjRWjkNsajt_oWPS57tJvE8XxoC4OIYgCY,2399
pip/_internal/utils/compatibility_tags.py,sha256=q5W7IrNlqC5ke0AqWRG6aX5pimiqh--xuPCCNwCKPsU,6662
pip/_internal/utils/datetime.py,sha256=Gt29Ml4ToPSM88j54iu43WKtrU9A-moP4QmMiiqzedU,241
pip/_internal/utils/deprecation.py,sha256=k7Qg_UBAaaTdyq82YVARA6D7RmcGTXGv7fnfcgigj4Q,3707
pip/_internal/utils/direct_url_helpers.py,sha256=r2MRtkVDACv9AGqYODBUC9CjwgtsUU1s68hmgfCJMtA,3196
pip/_internal/utils/egg_link.py,sha256=0FePZoUYKv4RGQ2t6x7w5Z427wbA_Uo3WZnAkrgsuqo,2463
pip/_internal/utils/entrypoints.py,sha256=4CheZ81OBPPLb3Gn-X_WEPtllUibpwDVzlVQ4RFh7PM,3325
pip/_internal/utils/filesystem.py,sha256=ajvA-q4ocliW9kPp8Yquh-4vssXbu-UKbo5FV9V4X64,4950
pip/_internal/utils/filetypes.py,sha256=OCPzUxq3Aa6k_95MiI8DYgkOzutTs47fA-v-vYUJp9E,715
pip/_internal/utils/glibc.py,sha256=vUkWq_1pJuzcYNcGKLlQmABoUiisK8noYY1yc8Wq4w4,3734
pip/_internal/utils/hashes.py,sha256=XGGLL0AG8-RhWnyz87xF6MFZ--BKadHU35D47eApCKI,4972
pip/_internal/utils/logging.py,sha256=zMZK1NxfhM4QMGUyaU9q1grNuDhLSVbSkGCvZBKmaPw,12076
pip/_internal/utils/misc.py,sha256=DWnYxBUItjRp7hhxEg4ih6P6YpKrykM86dbi_EcU8SQ,23450
pip/_internal/utils/packaging.py,sha256=CjJOqLNENW-U88ojOllVL40f1ab2W2Bm3KHCavwNNfw,1603
pip/_internal/utils/retry.py,sha256=mhFbykXjhTnZfgzeuy-vl9c8nECnYn_CMtwNJX2tYzQ,1392
pip/_internal/utils/setuptools_build.py,sha256=J9EyRantVgu4V-xS_qfQy2mcPLVUM7A-227QdKGUZCA,4482
pip/_internal/utils/subprocess.py,sha256=EsvqSRiSMHF98T8Txmu6NLU3U--MpTTQjtNgKP0P--M,8988
pip/_internal/utils/temp_dir.py,sha256=5qOXe8M4JeY6vaFQM867d5zkp1bSwMZ-KT5jymmP0Zg,9310
pip/_internal/utils/unpacking.py,sha256=4yCqlRAI2zxl5tfxlnLoWLNcEn-k1c3vaet_oaJ42iI,11926
pip/_internal/utils/urls.py,sha256=qceSOZb5lbNDrHNsv7_S4L4Ytszja5NwPKUMnZHbYnM,1599
pip/_internal/utils/virtualenv.py,sha256=S6f7csYorRpiD6cvn3jISZYc3I8PJC43H5iMFpRAEDU,3456
pip/_internal/utils/wheel.py,sha256=MHObYn6d7VyZL10i-W1xoJZ2hT5-wB1WkII70AsYUE8,4493
pip/_internal/vcs/__init__.py,sha256=UAqvzpbi0VbZo3Ub6skEeZAw-ooIZR-zX_WpCbxyCoU,596
pip/_internal/vcs/__pycache__/__init__.cpython-312.pyc,,
pip/_internal/vcs/__pycache__/bazaar.cpython-312.pyc,,
pip/_internal/vcs/__pycache__/git.cpython-312.pyc,,
pip/_internal/vcs/__pycache__/mercurial.cpython-312.pyc,,
pip/_internal/vcs/__pycache__/subversion.cpython-312.pyc,,
pip/_internal/vcs/__pycache__/versioncontrol.cpython-312.pyc,,
pip/_internal/vcs/bazaar.py,sha256=EKStcQaKpNu0NK4p5Q10Oc4xb3DUxFw024XrJy40bFQ,3528
pip/_internal/vcs/git.py,sha256=3KLPrKsDL9xZchmz4H1Obo8fM2Fh8ChrhtDHWjbkj-I,18591
pip/_internal/vcs/mercurial.py,sha256=oULOhzJ2Uie-06d1omkL-_Gc6meGaUkyogvqG9ZCyPs,5249
pip/_internal/vcs/subversion.py,sha256=ddTugHBqHzV3ebKlU5QXHPN4gUqlyXbOx8q8NgXKvs8,11735
pip/_internal/vcs/versioncontrol.py,sha256=cvf_-hnTAjQLXJ3d17FMNhQfcO1AcKWUF10tfrYyP-c,22440
pip/_internal/wheel_builder.py,sha256=Z5Z2ANADbKdSHY9BHqw9zG5-1AxstO6YM6m9yLWe7Vw,11212
pip/_vendor/__init__.py,sha256=WzusPTGWIMeQQWSVJ0h2rafGkVTa9WKJ2HT-2-EoZrU,4907
pip/_vendor/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/__pycache__/typing_extensions.cpython-312.pyc,,
pip/_vendor/cachecontrol/__init__.py,sha256=x9ecUkiwNvAGfE3g0eaRx3VrJZnZWAluA2LRcvab3HQ,677
pip/_vendor/cachecontrol/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/_cmd.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/adapter.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/cache.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/controller.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/filewrapper.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/heuristics.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/serialize.cpython-312.pyc,,
pip/_vendor/cachecontrol/__pycache__/wrapper.cpython-312.pyc,,
pip/_vendor/cachecontrol/_cmd.py,sha256=iist2EpzJvDVIhMAxXq8iFnTBsiZAd6iplxfmNboNyk,1737
pip/_vendor/cachecontrol/adapter.py,sha256=8y6rTPXOzVHmDKCW5CR9sivLVuDv-cpdGcZYdRWNaPw,6599
pip/_vendor/cachecontrol/cache.py,sha256=OXwv7Fn2AwnKNiahJHnjtvaKLndvVLv_-zO-ltlV9qI,1953
pip/_vendor/cachecontrol/caches/__init__.py,sha256=dtrrroK5BnADR1GWjCZ19aZ0tFsMfvFBtLQQU1sp_ag,303
pip/_vendor/cachecontrol/caches/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/cachecontrol/caches/__pycache__/file_cache.cpython-312.pyc,,
pip/_vendor/cachecontrol/caches/__pycache__/redis_cache.cpython-312.pyc,,
pip/_vendor/cachecontrol/caches/file_cache.py,sha256=d8upFmy_zwaCmlbWEVBlLXFddt8Zw8c5SFpxeOZsdfw,4117
pip/_vendor/cachecontrol/caches/redis_cache.py,sha256=9rmqwtYu_ljVkW6_oLqbC7EaX_a8YT_yLuna-eS0dgo,1386
pip/_vendor/cachecontrol/controller.py,sha256=cx0Hl8xLZgUuXuy78Gih9AYjCtqurmYjVJxyA4yWt7w,19101
pip/_vendor/cachecontrol/filewrapper.py,sha256=2ktXNPE0KqnyzF24aOsKCA58HQq1xeC6l2g6_zwjghc,4291
pip/_vendor/cachecontrol/heuristics.py,sha256=gqMXU8w0gQuEQiSdu3Yg-0vd9kW7nrWKbLca75rheGE,4881
pip/_vendor/cachecontrol/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/cachecontrol/serialize.py,sha256=HQd2IllQ05HzPkVLMXTF2uX5mjEQjDBkxCqUJUODpZk,5163
pip/_vendor/cachecontrol/wrapper.py,sha256=hsGc7g8QGQTT-4f8tgz3AM5qwScg6FO0BSdLSRdEvpU,1417
pip/_vendor/certifi/__init__.py,sha256=neIaAf7BM36ygmQCmy-ZsSyjnvjWghFeu13wwEAnjj0,94
pip/_vendor/certifi/__main__.py,sha256=1k3Cr95vCxxGRGDljrW3wMdpZdL3Nhf0u1n-k2qdsCY,255
pip/_vendor/certifi/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/certifi/__pycache__/__main__.cpython-312.pyc,,
pip/_vendor/certifi/__pycache__/core.cpython-312.pyc,,
pip/_vendor/certifi/cacert.pem,sha256=xVsh-Qf3-G1IrdCTVS-1ZRdJ_1-GBQjMu0I9bB-9gMc,297255
pip/_vendor/certifi/core.py,sha256=2SRT5rIcQChFDbe37BQa-kULxAgJ8qN6l1jfqTp4HIs,4486
pip/_vendor/certifi/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/dependency_groups/__init__.py,sha256=C3OFu0NGwDzQ4LOmmSOFPsRSvkbBn-mdd4j_5YqJw-s,250
pip/_vendor/dependency_groups/__main__.py,sha256=UNTM7P5mfVtT7wDi9kOTXWgV3fu3e8bTrt1Qp1jvjKo,1709
pip/_vendor/dependency_groups/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/dependency_groups/__pycache__/__main__.cpython-312.pyc,,
pip/_vendor/dependency_groups/__pycache__/_implementation.cpython-312.pyc,,
pip/_vendor/dependency_groups/__pycache__/_lint_dependency_groups.cpython-312.pyc,,
pip/_vendor/dependency_groups/__pycache__/_pip_wrapper.cpython-312.pyc,,
pip/_vendor/dependency_groups/__pycache__/_toml_compat.cpython-312.pyc,,
pip/_vendor/dependency_groups/_implementation.py,sha256=Gqb2DlQELRakeHlKf6QtQSW0M-bcEomxHw4JsvID1ls,8041
pip/_vendor/dependency_groups/_lint_dependency_groups.py,sha256=yp-DDqKXtbkDTNa0ifa-FmOA8ra24lPZEXftW-R5AuI,1710
pip/_vendor/dependency_groups/_pip_wrapper.py,sha256=nuVW_w_ntVxpE26ELEvngMY0N04sFLsijXRyZZROFG8,1865
pip/_vendor/dependency_groups/_toml_compat.py,sha256=BHnXnFacm3DeolsA35GjI6qkDApvua-1F20kv3BfZWE,285
pip/_vendor/dependency_groups/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/distlib/__init__.py,sha256=dcwgYGYGQqAEawBXPDtIx80DO_3cOmFv8HTc8JMzknQ,625
pip/_vendor/distlib/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/compat.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/database.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/index.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/locators.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/manifest.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/markers.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/metadata.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/resources.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/scripts.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/util.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/version.cpython-312.pyc,,
pip/_vendor/distlib/__pycache__/wheel.cpython-312.pyc,,
pip/_vendor/distlib/compat.py,sha256=2jRSjRI4o-vlXeTK2BCGIUhkc6e9ZGhSsacRM5oseTw,41467
pip/_vendor/distlib/database.py,sha256=mHy_LxiXIsIVRb-T0-idBrVLw3Ffij5teHCpbjmJ9YU,51160
pip/_vendor/distlib/index.py,sha256=lTbw268rRhj8dw1sib3VZ_0EhSGgoJO3FKJzSFMOaeA,20797
pip/_vendor/distlib/locators.py,sha256=oBeAZpFuPQSY09MgNnLfQGGAXXvVO96BFpZyKMuK4tM,51026
pip/_vendor/distlib/manifest.py,sha256=3qfmAmVwxRqU1o23AlfXrQGZzh6g_GGzTAP_Hb9C5zQ,14168
pip/_vendor/distlib/markers.py,sha256=X6sDvkFGcYS8gUW8hfsWuKEKAqhQZAJ7iXOMLxRYjYk,5164
pip/_vendor/distlib/metadata.py,sha256=zil3sg2EUfLXVigljY2d_03IJt-JSs7nX-73fECMX2s,38724
pip/_vendor/distlib/resources.py,sha256=LwbPksc0A1JMbi6XnuPdMBUn83X7BPuFNWqPGEKI698,10820
pip/_vendor/distlib/scripts.py,sha256=BJliaDAZaVB7WAkwokgC3HXwLD2iWiHaVI50H7C6eG8,18608
pip/_vendor/distlib/t32.exe,sha256=a0GV5kCoWsMutvliiCKmIgV98eRZ33wXoS-XrqvJQVs,97792
pip/_vendor/distlib/t64-arm.exe,sha256=68TAa32V504xVBnufojh0PcenpR3U4wAqTqf-MZqbPw,182784
pip/_vendor/distlib/t64.exe,sha256=gaYY8hy4fbkHYTTnA4i26ct8IQZzkBG2pRdy0iyuBrc,108032
pip/_vendor/distlib/util.py,sha256=vMPGvsS4j9hF6Y9k3Tyom1aaHLb0rFmZAEyzeAdel9w,66682
pip/_vendor/distlib/version.py,sha256=s5VIs8wBn0fxzGxWM_aA2ZZyx525HcZbMvcTlTyZ3Rg,23727
pip/_vendor/distlib/w32.exe,sha256=R4csx3-OGM9kL4aPIzQKRo5TfmRSHZo6QWyLhDhNBks,91648
pip/_vendor/distlib/w64-arm.exe,sha256=xdyYhKj0WDcVUOCb05blQYvzdYIKMbmJn2SZvzkcey4,168448
pip/_vendor/distlib/w64.exe,sha256=ejGf-rojoBfXseGLpya6bFTFPWRG21X5KvU8J5iU-K0,101888
pip/_vendor/distlib/wheel.py,sha256=DFIVguEQHCdxnSdAO0dfFsgMcvVZitg7bCOuLwZ7A_s,43979
pip/_vendor/distro/__init__.py,sha256=2fHjF-SfgPvjyNZ1iHh_wjqWdR_Yo5ODHwZC0jLBPhc,981
pip/_vendor/distro/__main__.py,sha256=bu9d3TifoKciZFcqRBuygV3GSuThnVD_m2IK4cz96Vs,64
pip/_vendor/distro/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/distro/__pycache__/__main__.cpython-312.pyc,,
pip/_vendor/distro/__pycache__/distro.cpython-312.pyc,,
pip/_vendor/distro/distro.py,sha256=XqbefacAhDT4zr_trnbA15eY8vdK4GTghgmvUGrEM_4,49430
pip/_vendor/distro/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/idna/__init__.py,sha256=MPqNDLZbXqGaNdXxAFhiqFPKEQXju2jNQhCey6-5eJM,868
pip/_vendor/idna/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/codec.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/compat.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/core.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/idnadata.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/intranges.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/package_data.cpython-312.pyc,,
pip/_vendor/idna/__pycache__/uts46data.cpython-312.pyc,,
pip/_vendor/idna/codec.py,sha256=PEew3ItwzjW4hymbasnty2N2OXvNcgHB-JjrBuxHPYY,3422
pip/_vendor/idna/compat.py,sha256=RzLy6QQCdl9784aFhb2EX9EKGCJjg0P3PilGdeXXcx8,316
pip/_vendor/idna/core.py,sha256=YJYyAMnwiQEPjVC4-Fqu_p4CJ6yKKuDGmppBNQNQpFs,13239
pip/_vendor/idna/idnadata.py,sha256=W30GcIGvtOWYwAjZj4ZjuouUutC6ffgNuyjJy7fZ-lo,78306
pip/_vendor/idna/intranges.py,sha256=amUtkdhYcQG8Zr-CoMM_kVRacxkivC1WgxN1b63KKdU,1898
pip/_vendor/idna/package_data.py,sha256=q59S3OXsc5VI8j6vSD0sGBMyk6zZ4vWFREE88yCJYKs,21
pip/_vendor/idna/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/idna/uts46data.py,sha256=rt90K9J40gUSwppDPCrhjgi5AA6pWM65dEGRSf6rIhM,239289
pip/_vendor/msgpack/__init__.py,sha256=reRaiOtEzSjPnr7TpxjgIvbfln5pV66FhricAs2eC-g,1109
pip/_vendor/msgpack/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/msgpack/__pycache__/exceptions.cpython-312.pyc,,
pip/_vendor/msgpack/__pycache__/ext.cpython-312.pyc,,
pip/_vendor/msgpack/__pycache__/fallback.cpython-312.pyc,,
pip/_vendor/msgpack/exceptions.py,sha256=dCTWei8dpkrMsQDcjQk74ATl9HsIBH0ybt8zOPNqMYc,1081
pip/_vendor/msgpack/ext.py,sha256=kteJv03n9tYzd5oo3xYopVTo4vRaAxonBQQJhXohZZo,5726
pip/_vendor/msgpack/fallback.py,sha256=0g1Pzp0vtmBEmJ5w9F3s_-JMVURP8RS4G1cc5TRaAsI,32390
pip/_vendor/packaging/__init__.py,sha256=_0cDiPVf2S-bNfVmZguxxzmrIYWlyASxpqph4qsJWUc,494
pip/_vendor/packaging/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/_elffile.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/_manylinux.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/_musllinux.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/_parser.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/_structures.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/_tokenizer.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/markers.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/metadata.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/requirements.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/specifiers.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/tags.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/utils.cpython-312.pyc,,
pip/_vendor/packaging/__pycache__/version.cpython-312.pyc,,
pip/_vendor/packaging/_elffile.py,sha256=UkrbDtW7aeq3qqoAfU16ojyHZ1xsTvGke_WqMTKAKd0,3286
pip/_vendor/packaging/_manylinux.py,sha256=t4y_-dTOcfr36gLY-ztiOpxxJFGO2ikC11HgfysGxiM,9596
pip/_vendor/packaging/_musllinux.py,sha256=p9ZqNYiOItGee8KcZFeHF_YcdhVwGHdK6r-8lgixvGQ,2694
pip/_vendor/packaging/_parser.py,sha256=gYfnj0pRHflVc4RHZit13KNTyN9iiVcU2RUCGi22BwM,10221
pip/_vendor/packaging/_structures.py,sha256=q3eVNmbWJGG_S0Dit_S3Ao8qQqz_5PYTXFAKBZe5yr4,1431
pip/_vendor/packaging/_tokenizer.py,sha256=OYzt7qKxylOAJ-q0XyK1qAycyPRYLfMPdGQKRXkZWyI,5310
pip/_vendor/packaging/licenses/__init__.py,sha256=3bx-gryo4sRv5LsrwApouy65VIs3u6irSORJzALkrzU,5727
pip/_vendor/packaging/licenses/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/packaging/licenses/__pycache__/_spdx.cpython-312.pyc,,
pip/_vendor/packaging/licenses/_spdx.py,sha256=oAm1ztPFwlsmCKe7lAAsv_OIOfS1cWDu9bNBkeu-2ns,48398
pip/_vendor/packaging/markers.py,sha256=P0we27jm1xUzgGMJxBjtUFCIWeBxTsMeJTOJ6chZmAY,12049
pip/_vendor/packaging/metadata.py,sha256=8IZErqQQnNm53dZZuYq4FGU4_dpyinMeH1QFBIWIkfE,34739
pip/_vendor/packaging/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/packaging/requirements.py,sha256=gYyRSAdbrIyKDY66ugIDUQjRMvxkH2ALioTmX3tnL6o,2947
pip/_vendor/packaging/specifiers.py,sha256=yc9D_MycJEmwUpZvcs1OZL9HfiNFmyw0RZaeHRNHkPw,40079
pip/_vendor/packaging/tags.py,sha256=41s97W9Zatrq2Ed7Rc3qeBDaHe8pKKvYq2mGjwahfXk,22745
pip/_vendor/packaging/utils.py,sha256=0F3Hh9OFuRgrhTgGZUl5K22Fv1YP2tZl1z_2gO6kJiA,5050
pip/_vendor/packaging/version.py,sha256=oiHqzTUv_p12hpjgsLDVcaF5hT7pDaSOViUNMD4GTW0,16688
pip/_vendor/pkg_resources/__init__.py,sha256=jrhDRbOubP74QuPXxd7U7Po42PH2l-LZ2XfcO7llpZ4,124463
pip/_vendor/pkg_resources/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/platformdirs/__init__.py,sha256=UfeSHWl8AeTtbOBOoHAxK4dODOWkZtfy-m_i7cWdJ8c,22344
pip/_vendor/platformdirs/__main__.py,sha256=jBJ8zb7Mpx5ebcqF83xrpO94MaeCpNGHVf9cvDN2JLg,1505
pip/_vendor/platformdirs/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/__main__.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/android.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/api.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/macos.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/unix.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/version.cpython-312.pyc,,
pip/_vendor/platformdirs/__pycache__/windows.cpython-312.pyc,,
pip/_vendor/platformdirs/android.py,sha256=r0DshVBf-RO1jXJGX8C4Til7F1XWt-bkdWMgmvEiaYg,9013
pip/_vendor/platformdirs/api.py,sha256=U9EzI3EYxcXWUCtIGRllqrcN99i2LSY1mq2-GtsUwEQ,9277
pip/_vendor/platformdirs/macos.py,sha256=UlbyFZ8Rzu3xndCqQEHrfsYTeHwYdFap1Ioz-yxveT4,6154
pip/_vendor/platformdirs/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/platformdirs/unix.py,sha256=WZmkUA--L3JNRGmz32s35YfoD3ica6xKIPdCV_HhLcs,10458
pip/_vendor/platformdirs/version.py,sha256=0fnw4ljascx7O5PfIeZ2yj6w3pAkqwp099vDcivxuvY,511
pip/_vendor/platformdirs/windows.py,sha256=IFpiohUBwxPtCzlyKwNtxyW4Jk8haa6W8o59mfrDXVo,10125
pip/_vendor/pygments/__init__.py,sha256=qMm7-KYqNpMrmjymZaqfH-_9iJtjnexAKodkb9G5D5g,2983
pip/_vendor/pygments/__main__.py,sha256=WrndpSe6i1ckX_SQ1KaxD9CTKGzD0EuCOFxcbwFpoLU,353
pip/_vendor/pygments/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/__main__.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/console.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/filter.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/formatter.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/lexer.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/modeline.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/plugin.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/regexopt.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/scanner.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/sphinxext.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/style.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/token.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/unistring.cpython-312.pyc,,
pip/_vendor/pygments/__pycache__/util.cpython-312.pyc,,
pip/_vendor/pygments/console.py,sha256=AagDWqwea2yBWf10KC9ptBgMpMjxKp8yABAmh-NQOVk,1718
pip/_vendor/pygments/filter.py,sha256=YLtpTnZiu07nY3oK9nfR6E9Y1FBHhP5PX8gvkJWcfag,1910
pip/_vendor/pygments/filters/__init__.py,sha256=4U4jtA0X3iP83uQnB9-TI-HDSw8E8y8zMYHa0UjbbaI,40392
pip/_vendor/pygments/filters/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pygments/formatter.py,sha256=KZQMmyo_xkOIkQG8g66LYEkBh1bx7a0HyGCBcvhI9Ew,4390
pip/_vendor/pygments/formatters/__init__.py,sha256=KTwBmnXlaopJhQDOemVHYHskiDghuq-08YtP6xPNJPg,5385
pip/_vendor/pygments/formatters/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pygments/formatters/__pycache__/_mapping.cpython-312.pyc,,
pip/_vendor/pygments/formatters/_mapping.py,sha256=1Cw37FuQlNacnxRKmtlPX4nyLoX9_ttko5ZwscNUZZ4,4176
pip/_vendor/pygments/lexer.py,sha256=_kBrOJ_NT5Tl0IVM0rA9c8eysP6_yrlGzEQI0eVYB-A,35349
pip/_vendor/pygments/lexers/__init__.py,sha256=wbIME35GH7bI1B9rNPJFqWT-ij_RApZDYPUlZycaLzA,12115
pip/_vendor/pygments/lexers/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pygments/lexers/__pycache__/_mapping.cpython-312.pyc,,
pip/_vendor/pygments/lexers/__pycache__/python.cpython-312.pyc,,
pip/_vendor/pygments/lexers/_mapping.py,sha256=l4tCXM8e9aPC2BD6sjIr0deT-J-z5tHgCwL-p1fS0PE,77602
pip/_vendor/pygments/lexers/python.py,sha256=vxjn1cOHclIKJKxoyiBsQTY65GHbkZtZRuKQ2AVCKaw,53853
pip/_vendor/pygments/modeline.py,sha256=K5eSkR8GS1r5OkXXTHOcV0aM_6xpk9eWNEIAW-OOJ2g,1005
pip/_vendor/pygments/plugin.py,sha256=tPx0rJCTIZ9ioRgLNYG4pifCbAwTRUZddvLw-NfAk2w,1891
pip/_vendor/pygments/regexopt.py,sha256=wXaP9Gjp_hKAdnICqoDkRxAOQJSc4v3X6mcxx3z-TNs,3072
pip/_vendor/pygments/scanner.py,sha256=nNcETRR1tRuiTaHmHSTTECVYFPcLf6mDZu1e4u91A9E,3092
pip/_vendor/pygments/sphinxext.py,sha256=5x7Zh9YlU6ISJ31dMwduiaanb5dWZnKg3MyEQsseNnQ,7981
pip/_vendor/pygments/style.py,sha256=PlOZqlsnTVd58RGy50vkA2cXQ_lP5bF5EGMEBTno6DA,6420
pip/_vendor/pygments/styles/__init__.py,sha256=x9ebctfyvCAFpMTlMJ5YxwcNYBzjgq6zJaKkNm78r4M,2042
pip/_vendor/pygments/styles/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pygments/styles/__pycache__/_mapping.cpython-312.pyc,,
pip/_vendor/pygments/styles/_mapping.py,sha256=6lovFUE29tz6EsV3XYY4hgozJ7q1JL7cfO3UOlgnS8w,3312
pip/_vendor/pygments/token.py,sha256=WbdWGhYm_Vosb0DDxW9lHNPgITXfWTsQmHt6cy9RbcM,6226
pip/_vendor/pygments/unistring.py,sha256=al-_rBemRuGvinsrM6atNsHTmJ6DUbw24q2O2Ru1cBc,63208
pip/_vendor/pygments/util.py,sha256=oRtSpiAo5jM9ulntkvVbgXUdiAW57jnuYGB7t9fYuhc,10031
pip/_vendor/pyproject_hooks/__init__.py,sha256=cPB_a9LXz5xvsRbX1o2qyAdjLatZJdQ_Lc5McNX-X7Y,691
pip/_vendor/pyproject_hooks/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pyproject_hooks/__pycache__/_impl.cpython-312.pyc,,
pip/_vendor/pyproject_hooks/_impl.py,sha256=jY-raxnmyRyB57ruAitrJRUzEexuAhGTpgMygqx67Z4,14936
pip/_vendor/pyproject_hooks/_in_process/__init__.py,sha256=MJNPpfIxcO-FghxpBbxkG1rFiQf6HOUbV4U5mq0HFns,557
pip/_vendor/pyproject_hooks/_in_process/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/pyproject_hooks/_in_process/__pycache__/_in_process.cpython-312.pyc,,
pip/_vendor/pyproject_hooks/_in_process/_in_process.py,sha256=qcXMhmx__MIJq10gGHW3mA4Tl8dy8YzHMccwnNoKlw0,12216
pip/_vendor/pyproject_hooks/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/requests/__init__.py,sha256=HlB_HzhrzGtfD_aaYUwUh1zWXLZ75_YCLyit75d0Vz8,5057
pip/_vendor/requests/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/__version__.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/_internal_utils.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/adapters.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/api.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/auth.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/certs.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/compat.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/cookies.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/exceptions.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/help.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/hooks.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/models.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/packages.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/sessions.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/status_codes.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/structures.cpython-312.pyc,,
pip/_vendor/requests/__pycache__/utils.cpython-312.pyc,,
pip/_vendor/requests/__version__.py,sha256=FVfglgZmNQnmYPXpOohDU58F5EUb_-VnSTaAesS187g,435
pip/_vendor/requests/_internal_utils.py,sha256=nMQymr4hs32TqVo5AbCrmcJEhvPUh7xXlluyqwslLiQ,1495
pip/_vendor/requests/adapters.py,sha256=J7VeVxKBvawbtlX2DERVo05J9BXTcWYLMHNd1Baa-bk,27607
pip/_vendor/requests/api.py,sha256=_Zb9Oa7tzVIizTKwFrPjDEY9ejtm_OnSRERnADxGsQs,6449
pip/_vendor/requests/auth.py,sha256=kF75tqnLctZ9Mf_hm9TZIj4cQWnN5uxRz8oWsx5wmR0,10186
pip/_vendor/requests/certs.py,sha256=kHDlkK_beuHXeMPc5jta2wgl8gdKeUWt5f2nTDVrvt8,441
pip/_vendor/requests/compat.py,sha256=Mo9f9xZpefod8Zm-n9_StJcVTmwSukXR2p3IQyyVXvU,1485
pip/_vendor/requests/cookies.py,sha256=bNi-iqEj4NPZ00-ob-rHvzkvObzN3lEpgw3g6paS3Xw,18590
pip/_vendor/requests/exceptions.py,sha256=D1wqzYWne1mS2rU43tP9CeN1G7QAy7eqL9o1god6Ejw,4272
pip/_vendor/requests/help.py,sha256=hRKaf9u0G7fdwrqMHtF3oG16RKktRf6KiwtSq2Fo1_0,3813
pip/_vendor/requests/hooks.py,sha256=CiuysiHA39V5UfcCBXFIx83IrDpuwfN9RcTUgv28ftQ,733
pip/_vendor/requests/models.py,sha256=x4K4CmH-lC0l2Kb-iPfMN4dRXxHEcbOaEWBL_i09AwI,35483
pip/_vendor/requests/packages.py,sha256=_ZQDCJTJ8SP3kVWunSqBsRZNPzj2c1WFVqbdr08pz3U,1057
pip/_vendor/requests/sessions.py,sha256=ykTI8UWGSltOfH07HKollH7kTBGw4WhiBVaQGmckTw4,30495
pip/_vendor/requests/status_codes.py,sha256=iJUAeA25baTdw-6PfD0eF4qhpINDJRJI-yaMqxs4LEI,4322
pip/_vendor/requests/structures.py,sha256=-IbmhVz06S-5aPSZuUthZ6-6D9XOjRuTXHOabY041XM,2912
pip/_vendor/requests/utils.py,sha256=L79vnFbzJ3SFLKtJwpoWe41Tozi3RlZv94pY1TFIyow,33631
pip/_vendor/resolvelib/__init__.py,sha256=4LcBWHMH317EKEkpV5XLVnqiU1lrmCiygjsADuCgz4s,541
pip/_vendor/resolvelib/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/resolvelib/__pycache__/providers.cpython-312.pyc,,
pip/_vendor/resolvelib/__pycache__/reporters.cpython-312.pyc,,
pip/_vendor/resolvelib/__pycache__/structs.cpython-312.pyc,,
pip/_vendor/resolvelib/providers.py,sha256=pIWJbIdJJ9GFtNbtwTH0Ia43Vj6hYCEJj2DOLue15FM,8914
pip/_vendor/resolvelib/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/resolvelib/reporters.py,sha256=8BNa7G9cKW4Lie4BhDhd7Z57J_Vlb1CYPGSgVN2erMA,2038
pip/_vendor/resolvelib/resolvers/__init__.py,sha256=GMYuhrbSsYTIjOij0tuJKLvlk6UXmp3nXQetn2sOvpQ,640
pip/_vendor/resolvelib/resolvers/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/resolvelib/resolvers/__pycache__/abstract.cpython-312.pyc,,
pip/_vendor/resolvelib/resolvers/__pycache__/criterion.cpython-312.pyc,,
pip/_vendor/resolvelib/resolvers/__pycache__/exceptions.cpython-312.pyc,,
pip/_vendor/resolvelib/resolvers/__pycache__/resolution.cpython-312.pyc,,
pip/_vendor/resolvelib/resolvers/abstract.py,sha256=jZOBVigE4PUub9i3F-bTvBwaIXX8S9EU3CGASBvFqEU,1558
pip/_vendor/resolvelib/resolvers/criterion.py,sha256=lcmZGv5sKHOnFD_RzZwvlGSj19MeA-5rCMpdf2Sgw7Y,1768
pip/_vendor/resolvelib/resolvers/exceptions.py,sha256=ln_jaQtgLlRUSFY627yiHG2gD7AgaXzRKaElFVh7fDQ,1768
pip/_vendor/resolvelib/resolvers/resolution.py,sha256=yQegMuOmlzAElLLpgD-k6NbPDMCQf29rWhiFC26OdkM,20671
pip/_vendor/resolvelib/structs.py,sha256=pu-EJiR2IBITr2SQeNPRa0rXhjlStfmO_GEgAhr3004,6420
pip/_vendor/rich/__init__.py,sha256=dRxjIL-SbFVY0q3IjSMrfgBTHrm1LZDgLOygVBwiYZc,6090
pip/_vendor/rich/__main__.py,sha256=eO7Cq8JnrgG8zVoeImiAs92q3hXNMIfp0w5lMsO7Q2Y,8477
pip/_vendor/rich/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/__main__.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_cell_widths.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_emoji_codes.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_emoji_replace.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_export_format.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_extension.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_fileno.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_inspect.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_log_render.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_loop.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_null_file.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_palettes.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_pick.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_ratio.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_spinners.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_stack.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_timer.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_win32_console.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_windows.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_windows_renderer.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/_wrap.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/abc.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/align.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/ansi.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/bar.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/box.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/cells.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/color.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/color_triplet.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/columns.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/console.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/constrain.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/containers.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/control.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/default_styles.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/diagnose.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/emoji.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/errors.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/file_proxy.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/filesize.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/highlighter.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/json.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/jupyter.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/layout.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/live.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/live_render.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/logging.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/markup.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/measure.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/padding.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/pager.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/palette.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/panel.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/pretty.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/progress.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/progress_bar.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/prompt.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/protocol.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/region.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/repr.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/rule.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/scope.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/screen.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/segment.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/spinner.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/status.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/style.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/styled.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/syntax.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/table.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/terminal_theme.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/text.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/theme.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/themes.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/traceback.cpython-312.pyc,,
pip/_vendor/rich/__pycache__/tree.cpython-312.pyc,,
pip/_vendor/rich/_cell_widths.py,sha256=fbmeyetEdHjzE_Vx2l1uK7tnPOhMs2X1lJfO3vsKDpA,10209
pip/_vendor/rich/_emoji_codes.py,sha256=hu1VL9nbVdppJrVoijVshRlcRRe_v3dju3Mmd2sKZdY,140235
pip/_vendor/rich/_emoji_replace.py,sha256=n-kcetsEUx2ZUmhQrfeMNc-teeGhpuSQ5F8VPBsyvDo,1064
pip/_vendor/rich/_export_format.py,sha256=RI08pSrm5tBSzPMvnbTqbD9WIalaOoN5d4M1RTmLq1Y,2128
pip/_vendor/rich/_extension.py,sha256=Xt47QacCKwYruzjDi-gOBq724JReDj9Cm9xUi5fr-34,265
pip/_vendor/rich/_fileno.py,sha256=HWZxP5C2ajMbHryvAQZseflVfQoGzsKOHzKGsLD8ynQ,799
pip/_vendor/rich/_inspect.py,sha256=QM05lEFnFoTaFqpnbx-zBEI6k8oIKrD3cvjEOQNhKig,9655
pip/_vendor/rich/_log_render.py,sha256=1ByI0PA1ZpxZY3CGJOK54hjlq4X-Bz_boIjIqCd8Kns,3225
pip/_vendor/rich/_loop.py,sha256=hV_6CLdoPm0va22Wpw4zKqM0RYsz3TZxXj0PoS-9eDQ,1236
pip/_vendor/rich/_null_file.py,sha256=ADGKp1yt-k70FMKV6tnqCqecB-rSJzp-WQsD7LPL-kg,1394
pip/_vendor/rich/_palettes.py,sha256=cdev1JQKZ0JvlguV9ipHgznTdnvlIzUFDBb0It2PzjI,7063
pip/_vendor/rich/_pick.py,sha256=evDt8QN4lF5CiwrUIXlOJCntitBCOsI3ZLPEIAVRLJU,423
pip/_vendor/rich/_ratio.py,sha256=Zt58apszI6hAAcXPpgdWKpu3c31UBWebOeR4mbyptvU,5471
pip/_vendor/rich/_spinners.py,sha256=U2r1_g_1zSjsjiUdAESc2iAMc3i4ri_S8PYP6kQ5z1I,19919
pip/_vendor/rich/_stack.py,sha256=-C8OK7rxn3sIUdVwxZBBpeHhIzX0eI-VM3MemYfaXm0,351
pip/_vendor/rich/_timer.py,sha256=zelxbT6oPFZnNrwWPpc1ktUeAT-Vc4fuFcRZLQGLtMI,417
pip/_vendor/rich/_win32_console.py,sha256=BSaDRIMwBLITn_m0mTRLPqME5q-quGdSMuYMpYeYJwc,22755
pip/_vendor/rich/_windows.py,sha256=aBwaD_S56SbgopIvayVmpk0Y28uwY2C5Bab1wl3Bp-I,1925
pip/_vendor/rich/_windows_renderer.py,sha256=t74ZL3xuDCP3nmTp9pH1L5LiI2cakJuQRQleHCJerlk,2783
pip/_vendor/rich/_wrap.py,sha256=FlSsom5EX0LVkA3KWy34yHnCfLtqX-ZIepXKh-70rpc,3404
pip/_vendor/rich/abc.py,sha256=ON-E-ZqSSheZ88VrKX2M3PXpFbGEUUZPMa_Af0l-4f0,890
pip/_vendor/rich/align.py,sha256=Rh-3adnDaN1Ao07EjR2PhgE62PGLPgO8SMwJBku1urQ,10469
pip/_vendor/rich/ansi.py,sha256=Avs1LHbSdcyOvDOdpELZUoULcBiYewY76eNBp6uFBhs,6921
pip/_vendor/rich/bar.py,sha256=ldbVHOzKJOnflVNuv1xS7g6dLX2E3wMnXkdPbpzJTcs,3263
pip/_vendor/rich/box.py,sha256=nr5fYIUghB_iUCEq6y0Z3LlCT8gFPDrzN9u2kn7tJl4,10831
pip/_vendor/rich/cells.py,sha256=KrQkj5-LghCCpJLSNQIyAZjndc4bnEqOEmi5YuZ9UCY,5130
pip/_vendor/rich/color.py,sha256=3HSULVDj7qQkXUdFWv78JOiSZzfy5y1nkcYhna296V0,18211
pip/_vendor/rich/color_triplet.py,sha256=3lhQkdJbvWPoLDO-AnYImAWmJvV5dlgYNCVZ97ORaN4,1054
pip/_vendor/rich/columns.py,sha256=HUX0KcMm9dsKNi11fTbiM_h2iDtl8ySCaVcxlalEzq8,7131
pip/_vendor/rich/console.py,sha256=_RJizBQIn9qxr4Ln7Q_SC5N9ekPWPAxH0KGVxsgg69Y,100565
pip/_vendor/rich/constrain.py,sha256=1VIPuC8AgtKWrcncQrjBdYqA3JVWysu6jZo1rrh7c7Q,1288
pip/_vendor/rich/containers.py,sha256=c_56TxcedGYqDepHBMTuZdUIijitAQgnox-Qde0Z1qo,5502
pip/_vendor/rich/control.py,sha256=DSkHTUQLorfSERAKE_oTAEUFefZnZp4bQb4q8rHbKws,6630
pip/_vendor/rich/default_styles.py,sha256=khQFqqaoDs3bprMqWpHw8nO5UpG2DN6QtuTd6LzZwYc,8257
pip/_vendor/rich/diagnose.py,sha256=WNPjU2pEdrPICJ24KOaTD_hzP839qArpmF1JIM5x_EQ,998
pip/_vendor/rich/emoji.py,sha256=omTF9asaAnsM4yLY94eR_9dgRRSm1lHUszX20D1yYCQ,2501
pip/_vendor/rich/errors.py,sha256=5pP3Kc5d4QJ_c0KFsxrfyhjiPVe7J1zOqSFbFAzcV-Y,642
pip/_vendor/rich/file_proxy.py,sha256=Tl9THMDZ-Pk5Wm8sI1gGg_U5DhusmxD-FZ0fUbcU0W0,1683
pip/_vendor/rich/filesize.py,sha256=_iz9lIpRgvW7MNSeCZnLg-HwzbP4GETg543WqD8SFs0,2484
pip/_vendor/rich/highlighter.py,sha256=G_sn-8DKjM1sEjLG_oc4ovkWmiUpWvj8bXi0yed2LnY,9586
pip/_vendor/rich/json.py,sha256=vVEoKdawoJRjAFayPwXkMBPLy7RSTs-f44wSQDR2nJ0,5031
pip/_vendor/rich/jupyter.py,sha256=QyoKoE_8IdCbrtiSHp9TsTSNyTHY0FO5whE7jOTd9UE,3252
pip/_vendor/rich/layout.py,sha256=ajkSFAtEVv9EFTcFs-w4uZfft7nEXhNzL7ZVdgrT5rI,14004
pip/_vendor/rich/live.py,sha256=DhzAPEnjTxQuq9_0Y2xh2MUwQcP_aGPkenLfKETslwM,14270
pip/_vendor/rich/live_render.py,sha256=zJtB471jGziBtEwxc54x12wEQtH4BuQr1SA8v9kU82w,3666
pip/_vendor/rich/logging.py,sha256=ZgpKMMBY_BuMAI_BYzo-UtXak6t5oH9VK8m9Q2Lm0f4,12458
pip/_vendor/rich/markup.py,sha256=3euGKP5s41NCQwaSjTnJxus5iZMHjxpIM0W6fCxra38,8451
pip/_vendor/rich/measure.py,sha256=HmrIJX8sWRTHbgh8MxEay_83VkqNW_70s8aKP5ZcYI8,5305
pip/_vendor/rich/padding.py,sha256=KVEI3tOwo9sgK1YNSuH__M1_jUWmLZwRVV_KmOtVzyM,4908
pip/_vendor/rich/pager.py,sha256=SO_ETBFKbg3n_AgOzXm41Sv36YxXAyI3_R-KOY2_uSc,828
pip/_vendor/rich/palette.py,sha256=lInvR1ODDT2f3UZMfL1grq7dY_pDdKHw4bdUgOGaM4Y,3396
pip/_vendor/rich/panel.py,sha256=SUDaa3z4MU7vIjzvbi0SXuc6BslDzADwdY1AX4TbTdY,11225
pip/_vendor/rich/pretty.py,sha256=gy3S72u4FRg2ytoo7N1ZDWDIvB4unbzd5iUGdgm-8fc,36391
pip/_vendor/rich/progress.py,sha256=MtmCjTk5zYU_XtRHxRHTAEHG6hF9PeF7EMWbEPleIC0,60357
pip/_vendor/rich/progress_bar.py,sha256=mZTPpJUwcfcdgQCTTz3kyY-fc79ddLwtx6Ghhxfo064,8162
pip/_vendor/rich/prompt.py,sha256=l0RhQU-0UVTV9e08xW1BbIj0Jq2IXyChX4lC0lFNzt4,12447
pip/_vendor/rich/protocol.py,sha256=5hHHDDNHckdk8iWH5zEbi-zuIVSF5hbU2jIo47R7lTE,1391
pip/_vendor/rich/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/rich/region.py,sha256=rNT9xZrVZTYIXZC0NYn41CJQwYNbR-KecPOxTgQvB8Y,166
pip/_vendor/rich/repr.py,sha256=5MZJZmONgC6kud-QW-_m1okXwL2aR6u6y-pUcUCJz28,4431
pip/_vendor/rich/rule.py,sha256=0fNaS_aERa3UMRc3T5WMpN_sumtDxfaor2y3of1ftBk,4602
pip/_vendor/rich/scope.py,sha256=TMUU8qo17thyqQCPqjDLYpg_UU1k5qVd-WwiJvnJVas,2843
pip/_vendor/rich/screen.py,sha256=YoeReESUhx74grqb0mSSb9lghhysWmFHYhsbMVQjXO8,1591
pip/_vendor/rich/segment.py,sha256=otnKeKGEV-WRlQVosfJVeFDcDxAKHpvJ_hLzSu5lumM,24743
pip/_vendor/rich/spinner.py,sha256=PT5qgXPG3ZpqRj7n3EZQ6NW56mx3ldZqZCU7gEMyZk4,4364
pip/_vendor/rich/status.py,sha256=kkPph3YeAZBo-X-4wPp8gTqZyU466NLwZBA4PZTTewo,4424
pip/_vendor/rich/style.py,sha256=xpj4uMBZMtuNuNomfUiamigl3p1sDvTCZwrG1tcTVeg,27059
pip/_vendor/rich/styled.py,sha256=eZNnzGrI4ki_54pgY3Oj0T-x3lxdXTYh4_ryDB24wBU,1258
pip/_vendor/rich/syntax.py,sha256=qqAnEUZ4K57Po81_5RBxnsuU4KRzSdvDPAhKw8ma_3E,35763
pip/_vendor/rich/table.py,sha256=ZmT7V7MMCOYKw7TGY9SZLyYDf6JdM-WVf07FdVuVhTI,40049
pip/_vendor/rich/terminal_theme.py,sha256=1j5-ufJfnvlAo5Qsi_ACZiXDmwMXzqgmFByObT9-yJY,3370
pip/_vendor/rich/text.py,sha256=AO7JPCz6-gaN1thVLXMBntEmDPVYFgFNG1oM61_sanU,47552
pip/_vendor/rich/theme.py,sha256=oNyhXhGagtDlbDye3tVu3esWOWk0vNkuxFw-_unlaK0,3771
pip/_vendor/rich/themes.py,sha256=0xgTLozfabebYtcJtDdC5QkX5IVUEaviqDUJJh4YVFk,102
pip/_vendor/rich/traceback.py,sha256=ZA8Q67DyP5a_stpIh6GPf9IiXj_s3dAhDIr6Zbfkahk,35170
pip/_vendor/rich/tree.py,sha256=yWnQ6rAvRGJ3qZGqBrxS2SW2TKBTNrP0SdY8QxOFPuw,9451
pip/_vendor/tomli/__init__.py,sha256=PhNw_eyLgdn7McJ6nrAN8yIm3dXC75vr1sVGVVwDSpA,314
pip/_vendor/tomli/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/tomli/__pycache__/_parser.cpython-312.pyc,,
pip/_vendor/tomli/__pycache__/_re.cpython-312.pyc,,
pip/_vendor/tomli/__pycache__/_types.cpython-312.pyc,,
pip/_vendor/tomli/_parser.py,sha256=9w8LG0jB7fwmZZWB0vVXbeejDHcl4ANIJxB2scEnDlA,25591
pip/_vendor/tomli/_re.py,sha256=sh4sBDRgO94KJZwNIrgdcyV_qQast50YvzOAUGpRDKA,3171
pip/_vendor/tomli/_types.py,sha256=-GTG2VUqkpxwMqzmVO4F7ybKddIbAnuAHXfmWQcTi3Q,254
pip/_vendor/tomli/py.typed,sha256=8PjyZ1aVoQpRVvt71muvuq5qE-jTFZkK-GLHkhdebmc,26
pip/_vendor/tomli_w/__init__.py,sha256=0F8yDtXx3Uunhm874KrAcP76srsM98y7WyHQwCulZbo,169
pip/_vendor/tomli_w/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/tomli_w/__pycache__/_writer.cpython-312.pyc,,
pip/_vendor/tomli_w/_writer.py,sha256=dsifFS2xYf1i76mmRyfz9y125xC7Z_HQ845ZKhJsYXs,6961
pip/_vendor/tomli_w/py.typed,sha256=8PjyZ1aVoQpRVvt71muvuq5qE-jTFZkK-GLHkhdebmc,26
pip/_vendor/truststore/__init__.py,sha256=2wRSVijjRzPLVXUzWqvdZLNsEOhDfopKLd2EKAYLwKU,1320
pip/_vendor/truststore/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/truststore/__pycache__/_api.cpython-312.pyc,,
pip/_vendor/truststore/__pycache__/_macos.cpython-312.pyc,,
pip/_vendor/truststore/__pycache__/_openssl.cpython-312.pyc,,
pip/_vendor/truststore/__pycache__/_ssl_constants.cpython-312.pyc,,
pip/_vendor/truststore/__pycache__/_windows.cpython-312.pyc,,
pip/_vendor/truststore/_api.py,sha256=40I0ojO2DnITiHvOnUYvJ1bfQMBKHOkci14noNxEnCs,11246
pip/_vendor/truststore/_macos.py,sha256=nZlLkOmszUE0g6ryRwBVGY5COzPyudcsiJtDWarM5LQ,20503
pip/_vendor/truststore/_openssl.py,sha256=LLUZ7ZGaio-i5dpKKjKCSeSufmn6T8pi9lDcFnvSyq0,2324
pip/_vendor/truststore/_ssl_constants.py,sha256=NUD4fVKdSD02ri7-db0tnO0VqLP9aHuzmStcW7tAl08,1130
pip/_vendor/truststore/_windows.py,sha256=rAHyKYD8M7t-bXfG8VgOVa3TpfhVhbt4rZQlO45YuP8,17993
pip/_vendor/truststore/py.typed,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/typing_extensions.py,sha256=ipKHUPtZCqL6c-HfvGl-9t0opsXcSL72y4GYjyJXs_g,172702
pip/_vendor/urllib3/__init__.py,sha256=iXLcYiJySn0GNbWOOZDDApgBL1JgP44EZ8i1760S8Mc,3333
pip/_vendor/urllib3/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/_collections.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/_version.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/connection.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/connectionpool.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/exceptions.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/fields.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/filepost.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/poolmanager.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/request.cpython-312.pyc,,
pip/_vendor/urllib3/__pycache__/response.cpython-312.pyc,,
pip/_vendor/urllib3/_collections.py,sha256=pyASJJhW7wdOpqJj9QJA8FyGRfr8E8uUUhqUvhF0728,11372
pip/_vendor/urllib3/_version.py,sha256=t9wGB6ooOTXXgiY66K1m6BZS1CJyXHAU8EoWDTe6Shk,64
pip/_vendor/urllib3/connection.py,sha256=ttIA909BrbTUzwkqEe_TzZVh4JOOj7g61Ysei2mrwGg,20314
pip/_vendor/urllib3/connectionpool.py,sha256=e2eiAwNbFNCKxj4bwDKNK-w7HIdSz3OmMxU_TIt-evQ,40408
pip/_vendor/urllib3/contrib/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/urllib3/contrib/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/__pycache__/_appengine_environ.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/__pycache__/appengine.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/__pycache__/ntlmpool.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/__pycache__/pyopenssl.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/__pycache__/securetransport.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/__pycache__/socks.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/_appengine_environ.py,sha256=bDbyOEhW2CKLJcQqAKAyrEHN-aklsyHFKq6vF8ZFsmk,957
pip/_vendor/urllib3/contrib/_securetransport/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/urllib3/contrib/_securetransport/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/_securetransport/__pycache__/bindings.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/_securetransport/__pycache__/low_level.cpython-312.pyc,,
pip/_vendor/urllib3/contrib/_securetransport/bindings.py,sha256=4Xk64qIkPBt09A5q-RIFUuDhNc9mXilVapm7WnYnzRw,17632
pip/_vendor/urllib3/contrib/_securetransport/low_level.py,sha256=B2JBB2_NRP02xK6DCa1Pa9IuxrPwxzDzZbixQkb7U9M,13922
pip/_vendor/urllib3/contrib/appengine.py,sha256=VR68eAVE137lxTgjBDwCna5UiBZTOKa01Aj_-5BaCz4,11036
pip/_vendor/urllib3/contrib/ntlmpool.py,sha256=NlfkW7WMdW8ziqudopjHoW299og1BTWi0IeIibquFwk,4528
pip/_vendor/urllib3/contrib/pyopenssl.py,sha256=hDJh4MhyY_p-oKlFcYcQaVQRDv6GMmBGuW9yjxyeejM,17081
pip/_vendor/urllib3/contrib/securetransport.py,sha256=Fef1IIUUFHqpevzXiDPbIGkDKchY2FVKeVeLGR1Qq3g,34446
pip/_vendor/urllib3/contrib/socks.py,sha256=aRi9eWXo9ZEb95XUxef4Z21CFlnnjbEiAo9HOseoMt4,7097
pip/_vendor/urllib3/exceptions.py,sha256=0Mnno3KHTNfXRfY7638NufOPkUb6mXOm-Lqj-4x2w8A,8217
pip/_vendor/urllib3/fields.py,sha256=kvLDCg_JmH1lLjUUEY_FLS8UhY7hBvDPuVETbY8mdrM,8579
pip/_vendor/urllib3/filepost.py,sha256=5b_qqgRHVlL7uLtdAYBzBh-GHmU5AfJVt_2N0XS3PeY,2440
pip/_vendor/urllib3/packages/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/urllib3/packages/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/urllib3/packages/__pycache__/six.cpython-312.pyc,,
pip/_vendor/urllib3/packages/backports/__init__.py,sha256=47DEQpj8HBSa-_TImW-5JCeuQeRkm5NMpJWZG3hSuFU,0
pip/_vendor/urllib3/packages/backports/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/urllib3/packages/backports/__pycache__/makefile.cpython-312.pyc,,
pip/_vendor/urllib3/packages/backports/__pycache__/weakref_finalize.cpython-312.pyc,,
pip/_vendor/urllib3/packages/backports/makefile.py,sha256=nbzt3i0agPVP07jqqgjhaYjMmuAi_W5E0EywZivVO8E,1417
pip/_vendor/urllib3/packages/backports/weakref_finalize.py,sha256=tRCal5OAhNSRyb0DhHp-38AtIlCsRP8BxF3NX-6rqIA,5343
pip/_vendor/urllib3/packages/six.py,sha256=b9LM0wBXv7E7SrbCjAm4wwN-hrH-iNxv18LgWNMMKPo,34665
pip/_vendor/urllib3/poolmanager.py,sha256=aWyhXRtNO4JUnCSVVqKTKQd8EXTvUm1VN9pgs2bcONo,19990
pip/_vendor/urllib3/request.py,sha256=YTWFNr7QIwh7E1W9dde9LM77v2VWTJ5V78XuTTw7D1A,6691
pip/_vendor/urllib3/response.py,sha256=fmDJAFkG71uFTn-sVSTh2Iw0WmcXQYqkbRjihvwBjU8,30641
pip/_vendor/urllib3/util/__init__.py,sha256=JEmSmmqqLyaw8P51gUImZh8Gwg9i1zSe-DoqAitn2nc,1155
pip/_vendor/urllib3/util/__pycache__/__init__.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/connection.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/proxy.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/queue.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/request.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/response.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/retry.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/ssl_.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/ssl_match_hostname.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/ssltransport.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/timeout.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/url.cpython-312.pyc,,
pip/_vendor/urllib3/util/__pycache__/wait.cpython-312.pyc,,
pip/_vendor/urllib3/util/connection.py,sha256=5Lx2B1PW29KxBn2T0xkN1CBgRBa3gGVJBKoQoRogEVk,4901
pip/_vendor/urllib3/util/proxy.py,sha256=zUvPPCJrp6dOF0N4GAVbOcl6o-4uXKSrGiTkkr5vUS4,1605
pip/_vendor/urllib3/util/queue.py,sha256=nRgX8_eX-_VkvxoX096QWoz8Ps0QHUAExILCY_7PncM,498
pip/_vendor/urllib3/util/request.py,sha256=C0OUt2tcU6LRiQJ7YYNP9GvPrSvl7ziIBekQ-5nlBZk,3997
pip/_vendor/urllib3/util/response.py,sha256=GJpg3Egi9qaJXRwBh5wv-MNuRWan5BIu40oReoxWP28,3510
pip/_vendor/urllib3/util/retry.py,sha256=6ENvOZ8PBDzh8kgixpql9lIrb2dxH-k7ZmBanJF2Ng4,22050
pip/_vendor/urllib3/util/ssl_.py,sha256=QDuuTxPSCj1rYtZ4xpD7Ux-r20TD50aHyqKyhQ7Bq4A,17460
pip/_vendor/urllib3/util/ssl_match_hostname.py,sha256=Ir4cZVEjmAk8gUAIHWSi7wtOO83UCYABY2xFD1Ql_WA,5758
pip/_vendor/urllib3/util/ssltransport.py,sha256=NA-u5rMTrDFDFC8QzRKUEKMG0561hOD4qBTr3Z4pv6E,6895
pip/_vendor/urllib3/util/timeout.py,sha256=cwq4dMk87mJHSBktK1miYJ-85G-3T3RmT20v7SFCpno,10168
pip/_vendor/urllib3/util/url.py,sha256=lCAE7M5myA8EDdW0sJuyyZhVB9K_j38ljWhHAnFaWoE,14296
pip/_vendor/urllib3/util/wait.py,sha256=fOX0_faozG2P7iVojQoE1mbydweNyTcm-hXEfFrTtLI,5403
pip/_vendor/vendor.txt,sha256=Fym1hhuw75IJOl33NPi5nIJJc66DioBSUWrVRIVtRUE,373
pip/py.typed,sha256=EBVvvPRTn_eIpz5e5QztSCdrMX7Qwd7VP93RSoIlZ2I,286
----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip-25.1.1.dist-info/RECORD -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/LICENSE
-rwxrwxrwx. 1 u0_a292 u0_a292 1.1K 2025-05-29 14:26:55.482754521 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/LICENSE
aaf9a29ca5907971ccf07de025375db34539a8d5eeebce20b46099805722106f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/LICENSE
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----
Copyright © 2019 Filipe Laíns <filipe.lains@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice (including the next
paragraph) shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/LICENSE -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/METADATA
-rwxrwxrwx. 1 u0_a292 u0_a292 6.3K 2025-05-29 14:26:55.482754521 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/METADATA
4307952d5774a9406010a389b04e89b4845ba9bda8ce439ee21c8801f7973937  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/build-1.2.2.post1.dist-info/METADATA
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----
Metadata-Version: 2.1
Name: build
Version: 1.2.2.post1
Summary: A simple, correct Python build frontend
Author-email: Filipe Laíns <lains@riseup.net>, Bernát Gábor <gaborjbernat@gmail.com>, layday <layday@protonmail.com>, Henry Schreiner <henryschreineriii@gmail.com>
Requires-Python: >= 3.8
Description-Content-Type: text/markdown
Classifier: License :: OSI Approved :: MIT License
Classifier: Programming Language :: Python :: 3
Classifier: Programming Language :: Python :: 3 :: Only
Classifier: Programming Language :: Python :: 3.8
Classifier: Programming Language :: Python :: 3.9
Classifier: Programming Language :: Python :: 3.10
Classifier: Programming Language :: Python :: 3.11
Classifier: Programming Language :: Python :: 3.12
Classifier: Programming Language :: Python :: 3.13
Classifier: Programming Language :: Python :: Implementation :: CPython
Classifier: Programming Language :: Python :: Implementation :: PyPy
Requires-Dist: packaging >= 19.1
Requires-Dist: pyproject_hooks
Requires-Dist: colorama; os_name == "nt"
Requires-Dist: importlib-metadata >= 4.6; python_full_version < "3.10.2"
Requires-Dist: tomli >= 1.1.0; python_version < "3.11"
Requires-Dist: furo >= 2023.08.17 ; extra == "docs"
Requires-Dist: sphinx ~= 7.0 ; extra == "docs"
Requires-Dist: sphinx-argparse-cli >= 1.5 ; extra == "docs"
Requires-Dist: sphinx-autodoc-typehints >= 1.10 ; extra == "docs"
Requires-Dist: sphinx-issues >= 3.0.0 ; extra == "docs"
Requires-Dist: build[uv, virtualenv] ; extra == "test"
Requires-Dist: filelock >= 3 ; extra == "test"
Requires-Dist: pytest >= 6.2.4 ; extra == "test"
Requires-Dist: pytest-cov >= 2.12 ; extra == "test"
Requires-Dist: pytest-mock >= 2 ; extra == "test"
Requires-Dist: pytest-rerunfailures >= 9.1 ; extra == "test"
Requires-Dist: pytest-xdist >= 1.34 ; extra == "test"
Requires-Dist: wheel >= 0.36.0 ; extra == "test"
Requires-Dist: setuptools >= 42.0.0 ; extra == "test" and ( python_version < "3.10")
Requires-Dist: setuptools >= 56.0.0 ; extra == "test" and ( python_version == "3.10")
Requires-Dist: setuptools >= 56.0.0 ; extra == "test" and ( python_version == "3.11")
Requires-Dist: setuptools >= 67.8.0 ; extra == "test" and ( python_version >= "3.12")
Requires-Dist: build[uv] ; extra == "typing"
Requires-Dist: importlib-metadata >= 5.1 ; extra == "typing"
Requires-Dist: mypy ~= 1.9.0 ; extra == "typing"
Requires-Dist: tomli ; extra == "typing"
Requires-Dist: typing-extensions >= 3.7.4.3 ; extra == "typing"
Requires-Dist: uv >= 0.1.18 ; extra == "uv"
Requires-Dist: virtualenv >= 20.0.35 ; extra == "virtualenv"
Project-URL: changelog, https://build.pypa.io/en/stable/changelog.html
Project-URL: homepage, https://build.pypa.io
Project-URL: issues, https://github.com/pypa/build/issues
Project-URL: source, https://github.com/pypa/build
Provides-Extra: docs
Provides-Extra: test
Provides-Extra: typing
Provides-Extra: uv
Provides-Extra: virtualenv

# build

[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/pypa/build/main.svg)](https://results.pre-commit.ci/latest/github/pypa/build/main)
[![CI test](https://github.com/pypa/build/actions/workflows/test.yml/badge.svg)](https://github.com/pypa/build/actions/workflows/test.yml)
[![codecov](https://codecov.io/gh/pypa/build/branch/main/graph/badge.svg)](https://codecov.io/gh/pypa/build)

[![Documentation Status](https://readthedocs.org/projects/pypa-build/badge/?version=latest)](https://build.pypa.io/en/latest/?badge=latest)