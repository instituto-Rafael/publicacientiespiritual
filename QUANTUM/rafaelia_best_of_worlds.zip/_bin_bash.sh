#!/bin/bash
{"archive_info": {"hash": "sha256=a4ae2426556b8863af8ff0d3749348be6085b0d558949b0ae81dc31406760c60", "hashes": {"sha256": "a4ae2426556b8863af8ff0d3749348be6085b0d558949b0ae81dc31406760c60"}}, "url": "file:///data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0-py3-none-any.whl"}

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia-0.1.0.dist-info/direct_url.json -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/bin/wheel
-rwxrwxrwx. 1 u0_a292 u0_a292 268 2025-05-25 17:08:57.580414719 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/bin/wheel
51d4df223ccbdc7793db195f1cfa139e629ba224d8334d7e1cbf61aa31994f9f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/bin/wheel
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----