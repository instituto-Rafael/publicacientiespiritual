#!/bin/bash
{"archive_info": {"hash": "sha256=1b53fdc453b5d259105b2d98d35e081d645610665bd5684d868801ed2f976302", "hashes": {"sha256": "1b53fdc453b5d259105b2d98d35e081d645610665bd5684d868801ed2f976302"}}, "url": "file:///data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/dist/rafaelia-0.1.0-py3-none-any.whl"}

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/rafaelia-0.1.0.dist-info/direct_url.json -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/bin/pip
-rwxrwxrwx. 1 u0_a292 u0_a292 301 2025-05-29 15:24:45.294752039 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/bin/pip
bbf1f4e4b6d846cd6dd02de1a57474bdfad730d80159ec56f576b64c165040f8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/RAFAELIA/HCPM/CORE/venv_rafaelia/bin/pip
MIME: text/plain
----- INÍCIO DO CONTEÚDO (texto detectado: text/plain) -----