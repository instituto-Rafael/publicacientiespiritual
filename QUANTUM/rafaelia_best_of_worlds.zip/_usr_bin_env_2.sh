#!/usr/bin/env python3
import functools
import itertools
import logging
import os
import posixpath
import re
import urllib.parse
from dataclasses import dataclass
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Mapping,
    NamedTuple,
    Optional,
    Tuple,
    Union,
)

from pip._internal.utils.deprecation import deprecated
from pip._internal.utils.filetypes import WHEEL_EXTENSION
from pip._internal.utils.hashes import Hashes
from pip._internal.utils.misc import (
    pairwise,
    redact_auth_from_url,
    split_auth_from_netloc,
    splitext,
)
from pip._internal.utils.urls import path_to_url, url_to_path

if TYPE_CHECKING:
    from pip._internal.index.collector import IndexContent

logger = logging.getLogger(__name__)


# Order matters, earlier hashes have a precedence over later hashes for what
# we will pick to use.
_SUPPORTED_HASHES = ("sha512", "sha384", "sha256", "sha224", "sha1", "md5")


@dataclass(frozen=True)
class LinkHash:
    """Links to content may have embedded hash values. This class parses those.

    `name` must be any member of `_SUPPORTED_HASHES`.

    This class can be converted to and from `ArchiveInfo`. While ArchiveInfo intends to
    be JSON-serializable to conform to PEP 610, this class contains the logic for
    parsing a hash name and value for correctness, and then checking whether that hash
    conforms to a schema with `.is_hash_allowed()`."""

    name: str
    value: str

    _hash_url_fragment_re = re.compile(
        # NB: we do not validate that the second group (.*) is a valid hex
        # digest. Instead, we simply keep that string in this class, and then check it
        # against Hashes when hash-checking is needed. This is easier to debug than
        # proactively discarding an invalid hex digest, as we handle incorrect hashes
        # and malformed hashes in the same place.
        r"[#&]({choices})=([^&]*)".format(
            choices="|".join(re.escape(hash_name) for hash_name in _SUPPORTED_HASHES)
        ),
    )

    def __post_init__(self) -> None:
        assert self.name in _SUPPORTED_HASHES

    @classmethod
    @functools.lru_cache(maxsize=None)
    def find_hash_url_fragment(cls, url: str) -> Optional["LinkHash"]:
        """Search a string for a checksum algorithm name and encoded output value."""
        match = cls._hash_url_fragment_re.search(url)
        if match is None:
            return None
        name, value = match.groups()
        return cls(name=name, value=value)

    def as_dict(self) -> Dict[str, str]:
        return {self.name: self.value}

    def as_hashes(self) -> Hashes:
        """Return a Hashes instance which checks only for the current hash."""
        return Hashes({self.name: [self.value]})

    def is_hash_allowed(self, hashes: Optional[Hashes]) -> bool:
        """
        Return True if the current hash is allowed by `hashes`.
        """
        if hashes is None:
            return False
        return hashes.is_hash_allowed(self.name, hex_digest=self.value)


@dataclass(frozen=True)
class MetadataFile:
    """Information about a core metadata file associated with a distribution."""

    hashes: Optional[Dict[str, str]]

    def __post_init__(self) -> None:
        if self.hashes is not None:
            assert all(name in _SUPPORTED_HASHES for name in self.hashes)


def supported_hashes(hashes: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
    # Remove any unsupported hash types from the mapping. If this leaves no
    # supported hashes, return None
    if hashes is None:
        return None
    hashes = {n: v for n, v in hashes.items() if n in _SUPPORTED_HASHES}
    if not hashes:
        return None
    return hashes


def _clean_url_path_part(part: str) -> str:
    """
    Clean a "part" of a URL path (i.e. after splitting on "@" characters).
    """
    # We unquote prior to quoting to make sure nothing is double quoted.
    return urllib.parse.quote(urllib.parse.unquote(part))


def _clean_file_url_path(part: str) -> str:
    """
    Clean the first part of a URL path that corresponds to a local
    filesystem path (i.e. the first part after splitting on "@" characters).
    """
    # We unquote prior to quoting to make sure nothing is double quoted.
    # Also, on Windows the path part might contain a drive letter which
    # should not be quoted. On Linux where drive letters do not
    # exist, the colon should be quoted. We rely on urllib.request
    # to do the right thing here.
    return urllib.request.pathname2url(urllib.request.url2pathname(part))


# percent-encoded:                   /
_reserved_chars_re = re.compile("(@|%2F)", re.IGNORECASE)


def _clean_url_path(path: str, is_local_path: bool) -> str:
    """
    Clean the path portion of a URL.
    """
    if is_local_path:
        clean_func = _clean_file_url_path
    else:
        clean_func = _clean_url_path_part

    # Split on the reserved characters prior to cleaning so that
    # revision strings in VCS URLs are properly preserved.
    parts = _reserved_chars_re.split(path)

    cleaned_parts = []
    for to_clean, reserved in pairwise(itertools.chain(parts, [""])):
        cleaned_parts.append(clean_func(to_clean))
        # Normalize %xx escapes (e.g. %2f -> %2F)
        cleaned_parts.append(reserved.upper())

    return "".join(cleaned_parts)


def _ensure_quoted_url(url: str) -> str:
    """
    Make sure a link is fully quoted.
    For example, if ' ' occurs in the URL, it will be replaced with "%20",
    and without double-quoting other characters.
    """
    # Split the URL into parts according to the general structure
    # `scheme://netloc/path?query#fragment`.
    result = urllib.parse.urlsplit(url)
    # If the netloc is empty, then the URL refers to a local filesystem path.
    is_local_path = not result.netloc
    path = _clean_url_path(result.path, is_local_path=is_local_path)
    return urllib.parse.urlunsplit(result._replace(path=path))


def _absolute_link_url(base_url: str, url: str) -> str:
    """
    A faster implementation of urllib.parse.urljoin with a shortcut
    for absolute http/https URLs.
    """
    if url.startswith(("https://", "http://")):
        return url
    else:
        return urllib.parse.urljoin(base_url, url)


@functools.total_ordering
class Link:
    """Represents a parsed link from a Package Index's simple URL"""

    __slots__ = [
        "_parsed_url",
        "_url",
        "_path",
        "_hashes",
        "comes_from",
        "requires_python",
        "yanked_reason",
        "metadata_file_data",
        "cache_link_parsing",
        "egg_fragment",
    ]

    def __init__(
        self,
        url: str,
        comes_from: Optional[Union[str, "IndexContent"]] = None,
        requires_python: Optional[str] = None,
        yanked_reason: Optional[str] = None,
        metadata_file_data: Optional[MetadataFile] = None,
        cache_link_parsing: bool = True,
        hashes: Optional[Mapping[str, str]] = None,
    ) -> None:
        """
        :param url: url of the resource pointed to (href of the link)
        :param comes_from: instance of IndexContent where the link was found,
            or string.
        :param requires_python: String containing the `Requires-Python`
            metadata field, specified in PEP 345. This may be specified by
            a data-requires-python attribute in the HTML link tag, as
            described in PEP 503.
        :param yanked_reason: the reason the file has been yanked, if the
            file has been yanked, or None if the file hasn't been yanked.
            This is the value of the "data-yanked" attribute, if present, in
            a simple repository HTML link. If the file has been yanked but
            no reason was provided, this should be the empty string. See
            PEP 592 for more information and the specification.
        :param metadata_file_data: the metadata attached to the file, or None if
            no such metadata is provided. This argument, if not None, indicates
            that a separate metadata file exists, and also optionally supplies
            hashes for that file.
        :param cache_link_parsing: A flag that is used elsewhere to determine
            whether resources retrieved from this link should be cached. PyPI
            URLs should generally have this set to False, for example.
        :param hashes: A mapping of hash names to digests to allow us to
            determine the validity of a download.
        """

        # The comes_from, requires_python, and metadata_file_data arguments are
        # only used by classmethods of this class, and are not used in client
        # code directly.

        # url can be a UNC windows share
        if url.startswith("\\\\"):
            url = path_to_url(url)

        self._parsed_url = urllib.parse.urlsplit(url)
        # Store the url as a private attribute to prevent accidentally
        # trying to set a new value.
        self._url = url
        # The .path property is hot, so calculate its value ahead of time.
        self._path = urllib.parse.unquote(self._parsed_url.path)

        link_hash = LinkHash.find_hash_url_fragment(url)
        hashes_from_link = {} if link_hash is None else link_hash.as_dict()
        if hashes is None:
            self._hashes = hashes_from_link
        else:
            self._hashes = {**hashes, **hashes_from_link}

        self.comes_from = comes_from
        self.requires_python = requires_python if requires_python else None
        self.yanked_reason = yanked_reason
        self.metadata_file_data = metadata_file_data

        self.cache_link_parsing = cache_link_parsing
        self.egg_fragment = self._egg_fragment()

    @classmethod
    def from_json(
        cls,
        file_data: Dict[str, Any],
        page_url: str,
    ) -> Optional["Link"]:
        """
        Convert an pypi json document from a simple repository page into a Link.
        """
        file_url = file_data.get("url")
        if file_url is None:
            return None

        url = _ensure_quoted_url(_absolute_link_url(page_url, file_url))
        pyrequire = file_data.get("requires-python")
        yanked_reason = file_data.get("yanked")
        hashes = file_data.get("hashes", {})

        # PEP 714: Indexes must use the name core-metadata, but
        # clients should support the old name as a fallback for compatibility.
        metadata_info = file_data.get("core-metadata")
        if metadata_info is None:
            metadata_info = file_data.get("dist-info-metadata")

        # The metadata info value may be a boolean, or a dict of hashes.
        if isinstance(metadata_info, dict):
            # The file exists, and hashes have been supplied
            metadata_file_data = MetadataFile(supported_hashes(metadata_info))
        elif metadata_info:
            # The file exists, but there are no hashes
            metadata_file_data = MetadataFile(None)
        else:
            # False or not present: the file does not exist
            metadata_file_data = None

        # The Link.yanked_reason expects an empty string instead of a boolean.
        if yanked_reason and not isinstance(yanked_reason, str):
            yanked_reason = ""
        # The Link.yanked_reason expects None instead of False.
        elif not yanked_reason:
            yanked_reason = None

        return cls(
            url,
            comes_from=page_url,
            requires_python=pyrequire,
            yanked_reason=yanked_reason,
            hashes=hashes,
            metadata_file_data=metadata_file_data,
        )

    @classmethod
    def from_element(
        cls,
        anchor_attribs: Dict[str, Optional[str]],
        page_url: str,
        base_url: str,
    ) -> Optional["Link"]:
        """
        Convert an anchor element's attributes in a simple repository page to a Link.
        """
        href = anchor_attribs.get("href")
        if not href:
            return None

        url = _ensure_quoted_url(_absolute_link_url(base_url, href))
        pyrequire = anchor_attribs.get("data-requires-python")
        yanked_reason = anchor_attribs.get("data-yanked")

        # PEP 714: Indexes must use the name data-core-metadata, but
        # clients should support the old name as a fallback for compatibility.
        metadata_info = anchor_attribs.get("data-core-metadata")
        if metadata_info is None:
            metadata_info = anchor_attribs.get("data-dist-info-metadata")
        # The metadata info value may be the string "true", or a string of
        # the form "hashname=hashval"
        if metadata_info == "true":
            # The file exists, but there are no hashes
            metadata_file_data = MetadataFile(None)
        elif metadata_info is None:
            # The file does not exist
            metadata_file_data = None
        else:
            # The file exists, and hashes have been supplied
            hashname, sep, hashval = metadata_info.partition("=")
            if sep == "=":
                metadata_file_data = MetadataFile(supported_hashes({hashname: hashval}))
            else:
                # Error - data is wrong. Treat as no hashes supplied.
                logger.debug(
                    "Index returned invalid data-dist-info-metadata value: %s",
                    metadata_info,
                )
                metadata_file_data = MetadataFile(None)

        return cls(
            url,
            comes_from=page_url,
            requires_python=pyrequire,
            yanked_reason=yanked_reason,
            metadata_file_data=metadata_file_data,
        )

    def __str__(self) -> str:
        if self.requires_python:
            rp = f" (requires-python:{self.requires_python})"
        else:
            rp = ""
        if self.comes_from:
            return f"{self.redacted_url} (from {self.comes_from}){rp}"
        else:
            return self.redacted_url

    def __repr__(self) -> str:
        return f"<Link {self}>"

    def __hash__(self) -> int:
        return hash(self.url)

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, Link):
            return NotImplemented
        return self.url == other.url

    def __lt__(self, other: Any) -> bool:
        if not isinstance(other, Link):
            return NotImplemented
        return self.url < other.url

    @property
    def url(self) -> str:
        return self._url

    @property
    def redacted_url(self) -> str:
        return redact_auth_from_url(self.url)

    @property
    def filename(self) -> str:
        path = self.path.rstrip("/")
        name = posixpath.basename(path)
        if not name:
            # Make sure we don't leak auth information if the netloc
            # includes a username and password.
            netloc, user_pass = split_auth_from_netloc(self.netloc)
            return netloc

        name = urllib.parse.unquote(name)
        assert name, f"URL {self._url!r} produced no filename"
        return name

    @property
    def file_path(self) -> str:
        return url_to_path(self.url)

    @property
    def scheme(self) -> str:
        return self._parsed_url.scheme

    @property
    def netloc(self) -> str:
        """
        This can contain auth information.
        """
        return self._parsed_url.netloc

    @property
    def path(self) -> str:
        return self._path

    def splitext(self) -> Tuple[str, str]:
        return splitext(posixpath.basename(self.path.rstrip("/")))

    @property
    def ext(self) -> str:
        return self.splitext()[1]

    @property
    def url_without_fragment(self) -> str:
        scheme, netloc, path, query, fragment = self._parsed_url
        return urllib.parse.urlunsplit((scheme, netloc, path, query, ""))

    _egg_fragment_re = re.compile(r"[#&]egg=([^&]*)")

    # Per PEP 508.
    _project_name_re = re.compile(
        r"^([A-Z0-9]|[A-Z0-9][A-Z0-9._-]*[A-Z0-9])$", re.IGNORECASE
    )

    def _egg_fragment(self) -> Optional[str]:
        match = self._egg_fragment_re.search(self._url)
        if not match:
            return None

        # An egg fragment looks like a PEP 508 project name, along with
        # an optional extras specifier. Anything else is invalid.
        project_name = match.group(1)
        if not self._project_name_re.match(project_name):
            deprecated(
                reason=f"{self} contains an egg fragment with a non-PEP 508 name.",
                replacement="to use the req @ url syntax, and remove the egg fragment",
                gone_in="25.2",
                issue=13157,
            )

        return project_name

    _subdirectory_fragment_re = re.compile(r"[#&]subdirectory=([^&]*)")

    @property
    def subdirectory_fragment(self) -> Optional[str]:
        match = self._subdirectory_fragment_re.search(self._url)
        if not match:
            return None
        return match.group(1)

    def metadata_link(self) -> Optional["Link"]:
        """Return a link to the associated core metadata file (if any)."""
        if self.metadata_file_data is None:
            return None
        metadata_url = f"{self.url_without_fragment}.metadata"
        if self.metadata_file_data.hashes is None:
            return Link(metadata_url)
        return Link(metadata_url, hashes=self.metadata_file_data.hashes)

    def as_hashes(self) -> Hashes:
        return Hashes({k: [v] for k, v in self._hashes.items()})

    @property
    def hash(self) -> Optional[str]:
        return next(iter(self._hashes.values()), None)

    @property
    def hash_name(self) -> Optional[str]:
        return next(iter(self._hashes), None)

    @property
    def show_url(self) -> str:
        return posixpath.basename(self._url.split("#", 1)[0].split("?", 1)[0])

    @property
    def is_file(self) -> bool:
        return self.scheme == "file"

    def is_existing_dir(self) -> bool:
        return self.is_file and os.path.isdir(self.file_path)

    @property
    def is_wheel(self) -> bool:
        return self.ext == WHEEL_EXTENSION

    @property
    def is_vcs(self) -> bool:
        from pip._internal.vcs import vcs

        return self.scheme in vcs.all_schemes

    @property
    def is_yanked(self) -> bool:
        return self.yanked_reason is not None

    @property
    def has_hash(self) -> bool:
        return bool(self._hashes)

    def is_hash_allowed(self, hashes: Optional[Hashes]) -> bool:
        """
        Return True if the link has a hash and it is allowed by `hashes`.
        """
        if hashes is None:
            return False
        return any(hashes.is_hash_allowed(k, v) for k, v in self._hashes.items())


class _CleanResult(NamedTuple):
    """Convert link for equivalency check.

    This is used in the resolver to check whether two URL-specified requirements
    likely point to the same distribution and can be considered equivalent. This
    equivalency logic avoids comparing URLs literally, which can be too strict
    (e.g. "a=1&b=2" vs "b=2&a=1") and produce conflicts unexpecting to users.

    Currently this does three things:

    1. Drop the basic auth part. This is technically wrong since a server can
       serve different content based on auth, but if it does that, it is even
       impossible to guarantee two URLs without auth are equivalent, since
       the user can input different auth information when prompted. So the
       practical solution is to assume the auth doesn't affect the response.
    2. Parse the query to avoid the ordering issue. Note that ordering under the
       same key in the query are NOT cleaned; i.e. "a=1&a=2" and "a=2&a=1" are
       still considered different.
    3. Explicitly drop most of the fragment part, except ``subdirectory=`` and
       hash values, since it should have no impact the downloaded content. Note
       that this drops the "egg=" part historically used to denote the requested
       project (and extras), which is wrong in the strictest sense, but too many
       people are supplying it inconsistently to cause superfluous resolution
       conflicts, so we choose to also ignore them.
    """

    parsed: urllib.parse.SplitResult
    query: Dict[str, List[str]]
    subdirectory: str
    hashes: Dict[str, str]


def _clean_link(link: Link) -> _CleanResult:
    parsed = link._parsed_url
    netloc = parsed.netloc.rsplit("@", 1)[-1]
    # According to RFC 8089, an empty host in file: means localhost.
    if parsed.scheme == "file" and not netloc:
        netloc = "localhost"
    fragment = urllib.parse.parse_qs(parsed.fragment)
    if "egg" in fragment:
        logger.debug("Ignoring egg= fragment in %s", link)
    try:
        # If there are multiple subdirectory values, use the first one.
        # This matches the behavior of Link.subdirectory_fragment.
        subdirectory = fragment["subdirectory"][0]
    except (IndexError, KeyError):
        subdirectory = ""
    # If there are multiple hash values under the same algorithm, use the
    # first one. This matches the behavior of Link.hash_value.
    hashes = {k: fragment[k][0] for k in _SUPPORTED_HASHES if k in fragment}
    return _CleanResult(
        parsed=parsed._replace(netloc=netloc, query="", fragment=""),
        query=urllib.parse.parse_qs(parsed.query),
        subdirectory=subdirectory,
        hashes=hashes,
    )


@functools.lru_cache(maxsize=None)
def links_equivalent(link1: Link, link2: Link) -> bool:
    return _clean_link(link1) == _clean_link(link2)

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/link.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 294 2025-06-01 01:28:18.587978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/__init__.cpython-312.pyc
c1dbb3df452d74ba08fa5a27527ebeb825ba4fce84c5b725921e8511e4f9f634  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 3e 00 00 00  |.........x3h>...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 08 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  79 01 29 02 7a 37 41 20  70 61 63 6b 61 67 65 20  |y.).z7A package |
00000040  74 68 61 74 20 63 6f 6e  74 61 69 6e 73 20 6d 6f  |that contains mo|
00000050  64 65 6c 73 20 74 68 61  74 20 72 65 70 72 65 73  |dels that repres|
00000060  65 6e 74 20 65 6e 74 69  74 69 65 73 2e 4e 29 01  |ent entities.N).|
00000070  da 07 5f 5f 64 6f 63 5f  5f a9 00 f3 00 00 00 00  |..__doc__.......|
00000080  fa 7f 2f 64 61 74 61 2f  64 61 74 61 2f 63 6f 6d  |../data/data/com|
00000090  2e 74 65 72 6d 75 78 2f  66 69 6c 65 73 2f 68 6f  |.termux/files/ho|
000000a0  6d 65 2f 52 41 46 41 45  4c 49 41 2f 48 43 50 4d  |me/RAFAELIA/HCPM|
000000b0  2f 43 4f 52 45 2f 76 65  6e 76 5f 72 61 66 61 65  |/CORE/venv_rafae|
000000c0  6c 69 61 2f 6c 69 62 2f  70 79 74 68 6f 6e 33 2e  |lia/lib/python3.|
000000d0  31 32 2f 73 69 74 65 2d  70 61 63 6b 61 67 65 73  |12/site-packages|
000000e0  2f 70 69 70 2f 5f 69 6e  74 65 72 6e 61 6c 2f 6d  |/pip/_internal/m|
000000f0  6f 64 65 6c 73 2f 5f 5f  69 6e 69 74 5f 5f 2e 70  |odels/__init__.p|
00000100  79 da 08 3c 6d 6f 64 75  6c 65 3e 72 06 00 00 00  |y..<module>r....|
00000110  01 00 00 00 73 08 00 00  00 f0 03 01 01 01 da 00  |....s...........|
00000120  3d 72 04 00 00 00                                 |=r....|
00000126
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/candidate.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.6K 2025-06-01 01:28:18.743978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/candidate.cpython-312.pyc
8d1ffa9a917004087e6392ff2861ef49646f4a89aa178a934c0d351c222b8327  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/candidate.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 f1 02 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 60 00  00 00 97 00 64 00 64 01  |......`.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 6d 03  |l.m.Z...d.d.l.m.|
00000040  5a 03 01 00 64 00 64 03  6c 02 6d 04 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 00 64 04 6c 06 6d 07  5a 07 01 00 02 00 65 01  |d.d.l.m.Z.....e.|
00000060  64 05 ac 06 ab 01 00 00  00 00 00 00 02 00 47 00  |d.............G.|
00000070  64 07 84 00 64 08 ab 02  00 00 00 00 00 00 ab 00  |d...d...........|
00000080  00 00 00 00 00 00 5a 08  79 09 29 0a e9 00 00 00  |......Z.y.).....|
00000090  00 29 01 da 09 64 61 74  61 63 6c 61 73 73 29 01  |.)...dataclass).|
000000a0  da 07 56 65 72 73 69 6f  6e 29 01 da 05 70 61 72  |..Version)...par|
000000b0  73 65 29 01 da 04 4c 69  6e 6b 54 29 01 da 06 66  |se)...LinkT)...f|
000000c0  72 6f 7a 65 6e 63 00 00  00 00 00 00 00 00 00 00  |rozenc..........|
000000d0  00 00 08 00 00 00 00 00  00 00 f3 5c 00 00 00 97  |...........\....|
000000e0  00 65 00 5a 01 64 00 5a  02 55 00 64 01 5a 03 67  |.e.Z.d.Z.U.d.Z.g|
000000f0  00 64 02 a2 01 5a 04 65  05 65 06 64 03 3c 00 00  |.d...Z.e.e.d.<..|
00000100  00 65 07 65 06 64 04 3c  00 00 00 65 08 65 06 64  |.e.e.d.<...e.e.d|
00000110  05 3c 00 00 00 64 03 65  05 64 04 65 05 64 05 65  |.<...d.e.d.e.d.e|
00000120  08 64 06 64 07 66 08 64  08 84 04 5a 09 64 06 65  |.d.d.f.d...Z.d.e|
00000130  05 66 02 64 09 84 04 5a  0a 79 07 29 0a da 15 49  |.f.d...Z.y.)...I|
00000140  6e 73 74 61 6c 6c 61 74  69 6f 6e 43 61 6e 64 69  |nstallationCandi|
00000150  64 61 74 65 7a 34 52 65  70 72 65 73 65 6e 74 73  |datez4Represents|
00000160  20 61 20 70 6f 74 65 6e  74 69 61 6c 20 22 63 61  | a potential "ca|
00000170  6e 64 69 64 61 74 65 22  20 66 6f 72 20 69 6e 73  |ndidate" for ins|
00000180  74 61 6c 6c 61 74 69 6f  6e 2e a9 03 da 04 6e 61  |tallation.....na|
00000190  6d 65 da 07 76 65 72 73  69 6f 6e da 04 6c 69 6e  |me..version..lin|
000001a0  6b 72 0b 00 00 00 72 0c  00 00 00 72 0d 00 00 00  |kr....r....r....|
000001b0  da 06 72 65 74 75 72 6e  4e 63 04 00 00 00 00 00  |..returnNc......|
000001c0  00 00 00 00 00 00 07 00  00 00 03 00 00 00 f3 a0  |................|
000001d0  00 00 00 97 00 74 00 00  00 00 00 00 00 00 00 6a  |.....t.........j|
000001e0  03 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001f0  00 00 00 7c 00 64 01 7c  01 ab 03 00 00 00 00 00  |...|.d.|........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/candidate.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/direct_url.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 11K 2025-06-01 01:28:18.903978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/direct_url.cpython-312.pyc
67e2d679fe127e37e550e0c85421f6e64780dcff5f3fd595fb53543b55d55523  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/direct_url.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 b0 19 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0c 00 00  |................|
00000020  00 00 00 00 00 f3 d0 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 04  64 01 64 03 6c 05 6d 06  |d.d.l.Z.d.d.l.m.|
00000050  5a 06 01 00 64 01 64 04  6c 07 6d 08 5a 08 6d 09  |Z...d.d.l.m.Z.m.|
00000060  5a 09 6d 0a 5a 0a 6d 0b  5a 0b 6d 0c 5a 0c 6d 0d  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 01 00 67 00 64 05  |Z.m.Z.m.Z...g.d.|
00000080  a2 01 5a 10 02 00 65 0e  64 06 ab 01 00 00 00 00  |..Z...e.d.......|
00000090  00 00 5a 11 64 07 5a 12  02 00 65 02 6a 26 00 00  |..Z.d.Z...e.j&..|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  64 08 ab 01 00 00 00 00  00 00 5a 14 02 00 47 00  |d.........Z...G.|
000000c0  64 09 84 00 64 0a 65 15  ab 03 00 00 00 00 00 00  |d...d.e.........|
000000d0  5a 16 09 00 64 1f 64 0b  65 0a 65 17 65 08 66 02  |Z...d.d.e.e.e.f.|
000000e0  19 00 00 00 64 0c 65 0d  65 11 19 00 00 00 64 0d  |....d.e.e.....d.|
000000f0  65 17 64 0e 65 0c 65 11  19 00 00 00 64 0f 65 0c  |e.d.e.e.....d.e.|
00000100  65 11 19 00 00 00 66 0a  64 10 84 05 5a 18 09 00  |e.....f.d...Z...|
00000110  64 1f 64 0b 65 0a 65 17  65 08 66 02 19 00 00 00  |d.d.e.e.e.f.....|
00000120  64 0c 65 0d 65 11 19 00  00 00 64 0d 65 17 64 0e  |d.e.e.....d.e.d.|
00000130  65 0c 65 11 19 00 00 00  64 0f 65 11 66 0a 64 11  |e.e.....d.e.f.d.|
00000140  84 05 5a 19 64 12 65 0b  65 0c 64 13 19 00 00 00  |..Z.d.e.e.d.....|
00000150  19 00 00 00 64 0f 64 13  66 04 64 14 84 04 5a 1a  |....d.d.f.d...Z.|
00000160  64 15 65 08 64 0f 65 0a  65 17 65 08 66 02 19 00  |d.e.d.e.e.e.f...|
00000170  00 00 66 04 64 16 84 04  5a 1b 65 06 02 00 47 00  |..f.d...Z.e...G.|
00000180  64 17 84 00 64 18 ab 02  00 00 00 00 00 00 ab 00  |d...d...........|
00000190  00 00 00 00 00 00 5a 1c  02 00 47 00 64 19 84 00  |......Z...G.d...|
000001a0  64 1a ab 02 00 00 00 00  00 00 5a 1d 65 06 02 00  |d.........Z.e...|
000001b0  47 00 64 1b 84 00 64 1c  ab 02 00 00 00 00 00 00  |G.d...d.........|
000001c0  ab 00 00 00 00 00 00 00  5a 1e 65 0f 65 1d 65 1e  |........Z.e.e.e.|
000001d0  65 1c 66 03 19 00 00 00  5a 1f 65 06 02 00 47 00  |e.f.....Z.e...G.|
000001e0  64 1d 84 00 64 1e ab 02  00 00 00 00 00 00 ab 00  |d...d...........|
000001f0  00 00 00 00 00 00 5a 20  79 02 29 20 7a 07 50 45  |......Z y.) z.PE|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/direct_url.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/format_control.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.2K 2025-06-01 01:28:19.059978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/format_control.cpython-312.pyc
c186762a8ba4c56269f597be71fa0e15de32415eea133e400b179a9f971a3620  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/format_control.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 b6 09 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 44 00  00 00 97 00 64 00 64 01  |......D.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 6d 03 5a 03 01 00  |l.m.Z.m.Z.m.Z...|
00000040  64 00 64 02 6c 04 6d 05  5a 05 01 00 64 00 64 03  |d.d.l.m.Z...d.d.|
00000050  6c 06 6d 07 5a 07 01 00  02 00 47 00 64 04 84 00  |l.m.Z.....G.d...|
00000060  64 05 ab 02 00 00 00 00  00 00 5a 08 79 06 29 07  |d.........Z.y.).|
00000070  e9 00 00 00 00 29 03 da  09 46 72 6f 7a 65 6e 53  |.....)...FrozenS|
00000080  65 74 da 08 4f 70 74 69  6f 6e 61 6c da 03 53 65  |et..Optional..Se|
00000090  74 29 01 da 11 63 61 6e  6f 6e 69 63 61 6c 69 7a  |t)...canonicaliz|
000000a0  65 5f 6e 61 6d 65 29 01  da 0c 43 6f 6d 6d 61 6e  |e_name)...Comman|
000000b0  64 45 72 72 6f 72 63 00  00 00 00 00 00 00 00 00  |dErrorc.........|
000000c0  00 00 00 09 00 00 00 00  00 00 00 f3 b2 00 00 00  |................|
000000d0  97 00 65 00 5a 01 64 00  5a 02 64 01 5a 03 64 02  |..e.Z.d.Z.d.Z.d.|
000000e0  64 03 67 02 5a 04 09 00  09 00 64 10 64 02 65 05  |d.g.Z.....d.d.e.|
000000f0  65 06 65 07 19 00 00 00  19 00 00 00 64 03 65 05  |e.e.........d.e.|
00000100  65 06 65 07 19 00 00 00  19 00 00 00 64 05 64 04  |e.e.........d.d.|
00000110  66 06 64 06 84 05 5a 08  64 07 65 09 64 05 65 0a  |f.d...Z.d.e.d.e.|
00000120  66 04 64 08 84 04 5a 0b  64 05 65 07 66 02 64 09  |f.d...Z.d.e.f.d.|
00000130  84 04 5a 0c 65 0d 64 0a  65 07 64 0b 65 06 65 07  |..Z.e.d.e.d.e.e.|
00000140  19 00 00 00 64 07 65 06  65 07 19 00 00 00 64 05  |....d.e.e.....d.|
00000150  64 04 66 08 64 0c 84 04  ab 00 00 00 00 00 00 00  |d.f.d...........|
00000160  5a 0e 64 0d 65 07 64 05  65 0f 65 07 19 00 00 00  |Z.d.e.d.e.e.....|
00000170  66 04 64 0e 84 04 5a 10  64 11 64 0f 84 04 5a 11  |f.d...Z.d.d...Z.|
00000180  79 04 29 12 da 0d 46 6f  72 6d 61 74 43 6f 6e 74  |y.)...FormatCont|
00000190  72 6f 6c 7a 42 48 65 6c  70 65 72 20 66 6f 72 20  |rolzBHelper for |
000001a0  6d 61 6e 61 67 69 6e 67  20 66 6f 72 6d 61 74 73  |managing formats|
000001b0  20 66 72 6f 6d 20 77 68  69 63 68 20 61 20 70 61  | from which a pa|
000001c0  63 6b 61 67 65 20 63 61  6e 20 62 65 20 69 6e 73  |ckage can be ins|
000001d0  74 61 6c 6c 65 64 2e da  09 6e 6f 5f 62 69 6e 61  |talled...no_bina|
000001e0  72 79 da 0b 6f 6e 6c 79  5f 62 69 6e 61 72 79 4e  |ry..only_binaryN|
000001f0  da 06 72 65 74 75 72 6e  63 03 00 00 00 00 00 00  |..returnc.......|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/format_control.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/index.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.7K 2025-06-01 01:28:19.219978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/index.cpython-312.pyc
b13cd31332bb1896184a08271d1536113ad32d0ec1757f1f3555ed4865b7e316  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/index.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 06 04 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 48 00  00 00 97 00 64 00 64 01  |......H.....d.d.|
00000030  6c 00 5a 01 02 00 47 00  64 02 84 00 64 03 ab 02  |l.Z...G.d...d...|
00000040  00 00 00 00 00 00 5a 02  02 00 65 02 64 04 64 05  |......Z...e.d.d.|
00000050  ac 06 ab 02 00 00 00 00  00 00 5a 03 02 00 65 02  |..........Z...e.|
00000060  64 07 64 08 ac 06 ab 02  00 00 00 00 00 00 5a 04  |d.d...........Z.|
00000070  79 01 29 09 e9 00 00 00  00 4e 63 00 00 00 00 00  |y.)......Nc.....|
00000080  00 00 00 00 00 00 00 06  00 00 00 00 00 00 00 f3  |................|
00000090  48 00 00 00 87 00 97 00  65 00 5a 01 64 00 5a 02  |H.......e.Z.d.Z.|
000000a0  64 01 5a 03 67 00 64 02  a2 01 5a 04 64 03 65 05  |d.Z.g.d...Z.d.e.|
000000b0  64 04 65 05 64 05 64 06  66 06 88 00 66 01 64 07  |d.e.d.d.f...f.d.|
000000c0  84 0c 5a 06 64 08 65 05  64 05 65 05 66 04 64 09  |..Z.d.e.d.e.f.d.|
000000d0  84 04 5a 07 88 00 78 01  5a 08 53 00 29 0a da 0c  |..Z...x.Z.S.)...|
000000e0  50 61 63 6b 61 67 65 49  6e 64 65 78 7a 42 52 65  |PackageIndexzBRe|
000000f0  70 72 65 73 65 6e 74 73  20 61 20 50 61 63 6b 61  |presents a Packa|
00000100  67 65 20 49 6e 64 65 78  20 61 6e 64 20 70 72 6f  |ge Index and pro|
00000110  76 69 64 65 73 20 65 61  73 69 65 72 20 61 63 63  |vides easier acc|
00000120  65 73 73 20 74 6f 20 65  6e 64 70 6f 69 6e 74 73  |ess to endpoints|
00000130  29 05 da 03 75 72 6c da  06 6e 65 74 6c 6f 63 da  |)...url..netloc.|
00000140  0a 73 69 6d 70 6c 65 5f  75 72 6c da 08 70 79 70  |.simple_url..pyp|
00000150  69 5f 75 72 6c da 13 66  69 6c 65 5f 73 74 6f 72  |i_url..file_stor|
00000160  61 67 65 5f 64 6f 6d 61  69 6e 72 05 00 00 00 72  |age_domainr....r|
00000170  09 00 00 00 da 06 72 65  74 75 72 6e 4e 63 03 00  |......returnNc..|
00000180  00 00 00 00 00 00 00 00  00 00 03 00 00 00 03 00  |................|
00000190  00 00 f3 f2 00 00 00 95  01 97 00 74 00 00 00 00  |...........t....|
000001a0  00 00 00 00 00 89 03 7c  00 8d 05 00 00 ab 00 00  |.......|........|
000001b0  00 00 00 00 00 01 00 7c  01 7c 00 5f 02 00 00 00  |.......|.|._....|
000001c0  00 00 00 00 00 74 06 00  00 00 00 00 00 00 00 6a  |.....t.........j|
000001d0  08 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001e0  00 00 00 6a 0b 00 00 00  00 00 00 00 00 00 00 00  |...j............|
000001f0  00 00 00 00 00 00 00 7c  01 ab 01 00 00 00 00 00  |.......|........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/index.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/installation_report.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 2.3K 2025-06-01 01:28:19.375978179 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/installation_report.cpython-312.pyc
357f2316ed385e4b8ea78b1498610b56bdd7e17ae8be7b24d7df3320a1669e9a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/installation_report.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 02 0b 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 50 00  00 00 97 00 64 00 64 01  |......P.....d.d.|
00000030  6c 00 6d 01 5a 01 6d 02  5a 02 6d 03 5a 03 01 00  |l.m.Z.m.Z.m.Z...|
00000040  64 00 64 02 6c 04 6d 05  5a 05 01 00 64 00 64 03  |d.d.l.m.Z...d.d.|
00000050  6c 06 6d 07 5a 07 01 00  64 00 64 04 6c 08 6d 09  |l.m.Z...d.d.l.m.|
00000060  5a 09 01 00 02 00 47 00  64 05 84 00 64 06 ab 02  |Z.....G.d...d...|
00000070  00 00 00 00 00 00 5a 0a  79 07 29 08 e9 00 00 00  |......Z.y.).....|
00000080  00 29 03 da 03 41 6e 79  da 04 44 69 63 74 da 08  |.)...Any..Dict..|
00000090  53 65 71 75 65 6e 63 65  29 01 da 13 64 65 66 61  |Sequence)...defa|
000000a0  75 6c 74 5f 65 6e 76 69  72 6f 6e 6d 65 6e 74 29  |ult_environment)|
000000b0  01 da 0b 5f 5f 76 65 72  73 69 6f 6e 5f 5f 29 01  |...__version__).|
000000c0  da 12 49 6e 73 74 61 6c  6c 52 65 71 75 69 72 65  |..InstallRequire|
000000d0  6d 65 6e 74 63 00 00 00  00 00 00 00 00 00 00 00  |mentc...........|
000000e0  00 07 00 00 00 00 00 00  00 f3 58 00 00 00 97 00  |..........X.....|
000000f0  65 00 5a 01 64 00 5a 02  64 01 65 03 65 04 19 00  |e.Z.d.Z.d.e.e...|
00000100  00 00 66 02 64 02 84 04  5a 05 65 06 64 03 65 04  |..f.d...Z.e.d.e.|
00000110  64 04 65 07 65 08 65 09  66 02 19 00 00 00 66 04  |d.e.e.e.f.....f.|
00000120  64 05 84 04 ab 00 00 00  00 00 00 00 5a 0a 64 04  |d...........Z.d.|
00000130  65 07 65 08 65 09 66 02  19 00 00 00 66 02 64 06  |e.e.e.f.....f.d.|
00000140  84 04 5a 0b 79 07 29 08  da 12 49 6e 73 74 61 6c  |..Z.y.)...Instal|
00000150  6c 61 74 69 6f 6e 52 65  70 6f 72 74 da 14 69 6e  |lationReport..in|
00000160  73 74 61 6c 6c 5f 72 65  71 75 69 72 65 6d 65 6e  |stall_requiremen|
00000170  74 73 63 02 00 00 00 00  00 00 00 00 00 00 00 02  |tsc.............|
00000180  00 00 00 03 00 00 00 f3  12 00 00 00 97 00 7c 01  |..............|.|
00000190  7c 00 5f 00 00 00 00 00  00 00 00 00 79 00 29 01  ||._.........y.).|
000001a0  4e 29 01 da 15 5f 69 6e  73 74 61 6c 6c 5f 72 65  |N)..._install_re|
000001b0  71 75 69 72 65 6d 65 6e  74 73 29 02 da 04 73 65  |quirements)...se|
000001c0  6c 66 72 0b 00 00 00 73  02 00 00 00 20 20 fa 8a  |lfr....s....  ..|
000001d0  2f 64 61 74 61 2f 64 61  74 61 2f 63 6f 6d 2e 74  |/data/data/com.t|
000001e0  65 72 6d 75 78 2f 66 69  6c 65 73 2f 68 6f 6d 65  |ermux/files/home|
000001f0  2f 52 41 46 41 45 4c 49  41 2f 48 43 50 4d 2f 43  |/RAFAELIA/HCPM/C|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/installation_report.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/link.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 27K 2025-06-01 01:28:19.535978178 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/link.cpython-312.pyc
8e71ea15ecf2d98038147009df0ca4d00aa7ce442ace9a8fb5050e59fd776261  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/link.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  52 05 35 68 1e 54 00 00  |........R.5h.T..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 07 00 00  |................|
00000020  00 00 00 00 00 f3 aa 02  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 5a 07 64 00 64 02  6c 08 6d 09 5a 09 01 00  |l.Z.d.d.l.m.Z...|
00000070  64 00 64 03 6c 0a 6d 0b  5a 0b 6d 0c 5a 0c 6d 0d  |d.d.l.m.Z.m.Z.m.|
00000080  5a 0d 6d 0e 5a 0e 6d 0f  5a 0f 6d 10 5a 10 6d 11  |Z.m.Z.m.Z.m.Z.m.|
00000090  5a 11 6d 12 5a 12 6d 13  5a 13 01 00 64 00 64 04  |Z.m.Z.m.Z...d.d.|
000000a0  6c 14 6d 15 5a 15 01 00  64 00 64 05 6c 16 6d 17  |l.m.Z...d.d.l.m.|
000000b0  5a 17 01 00 64 00 64 06  6c 18 6d 19 5a 19 01 00  |Z...d.d.l.m.Z...|
000000c0  64 00 64 07 6c 1a 6d 1b  5a 1b 6d 1c 5a 1c 6d 1d  |d.d.l.m.Z.m.Z.m.|
000000d0  5a 1d 6d 1e 5a 1e 01 00  64 00 64 08 6c 1f 6d 20  |Z.m.Z...d.d.l.m |
000000e0  5a 20 6d 21 5a 21 01 00  65 0b 72 06 64 00 64 09  |Z m!Z!..e.r.d.d.|
000000f0  6c 22 6d 23 5a 23 01 00  02 00 65 02 6a 48 00 00  |l"m#Z#....e.jH..|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000110  65 25 ab 01 00 00 00 00  00 00 5a 26 64 0a 5a 27  |e%........Z&d.Z'|
00000120  02 00 65 09 64 0b ac 0c  ab 01 00 00 00 00 00 00  |..e.d...........|
00000130  02 00 47 00 64 0d 84 00  64 0e ab 02 00 00 00 00  |..G.d...d.......|
00000140  00 00 ab 00 00 00 00 00  00 00 5a 28 02 00 65 09  |..........Z(..e.|
00000150  64 0b ac 0c ab 01 00 00  00 00 00 00 02 00 47 00  |d.............G.|
00000160  64 0f 84 00 64 10 ab 02  00 00 00 00 00 00 ab 00  |d...d...........|
00000170  00 00 00 00 00 00 5a 29  64 11 65 11 65 0d 65 2a  |......Z)d.e.e.e*|
00000180  65 2a 66 02 19 00 00 00  19 00 00 00 64 12 65 11  |e*f.........d.e.|
00000190  65 0d 65 2a 65 2a 66 02  19 00 00 00 19 00 00 00  |e.e*e*f.........|
000001a0  66 04 64 13 84 04 5a 2b  64 14 65 2a 64 12 65 2a  |f.d...Z+d.e*d.e*|
000001b0  66 04 64 15 84 04 5a 2c  64 14 65 2a 64 12 65 2a  |f.d...Z,d.e*d.e*|
000001c0  66 04 64 16 84 04 5a 2d  02 00 65 05 6a 5c 00 00  |f.d...Z-..e.j\..|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001e0  64 17 65 05 6a 5e 00 00  00 00 00 00 00 00 00 00  |d.e.j^..........|
000001f0  00 00 00 00 00 00 00 00  ab 02 00 00 00 00 00 00  |................|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/link.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/pylock.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 7.9K 2025-06-01 01:28:19.695978178 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/pylock.cpython-312.pyc
065709eb8be0618ebf34812fefe094a53af60e6a92e6c0fff7c7eccd4d170fa1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/pylock.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 34 18 00 00  |.........x3h4...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 cc 01  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 00 6d 02 5a 02 01 00  64 00 64 03 6c 03 6d 04  |l.m.Z...d.d.l.m.|
00000050  5a 04 01 00 64 00 64 04  6c 05 6d 06 5a 06 6d 07  |Z...d.d.l.m.Z.m.|
00000060  5a 07 6d 08 5a 08 6d 09  5a 09 6d 0a 5a 0a 6d 0b  |Z.m.Z.m.Z.m.Z.m.|
00000070  5a 0b 01 00 64 00 64 05  6c 0c 6d 0d 5a 0d 01 00  |Z...d.d.l.m.Z...|
00000080  64 00 64 06 6c 0e 6d 0f  5a 0f 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
00000090  6c 10 6d 11 5a 11 6d 12  5a 12 6d 13 5a 13 01 00  |l.m.Z.m.Z.m.Z...|
000000a0  64 00 64 08 6c 14 6d 15  5a 15 01 00 64 00 64 09  |d.d.l.m.Z...d.d.|
000000b0  6c 16 6d 17 5a 17 01 00  64 00 64 0a 6c 18 6d 19  |l.m.Z...d.d.l.m.|
000000c0  5a 19 01 00 02 00 65 01  6a 34 00 00 00 00 00 00  |Z.....e.j4......|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 64 0b ab 01  |............d...|
000000e0  00 00 00 00 00 00 5a 1b  64 0c 65 04 64 0d 65 1c  |......Z.d.e.d.e.|
000000f0  66 04 64 0e 84 04 5a 1d  64 0f 65 09 65 0b 65 1e  |f.d...Z.d.e.e.e.|
00000100  65 06 66 02 19 00 00 00  19 00 00 00 64 0d 65 07  |e.f.........d.e.|
00000110  65 1e 65 06 66 02 19 00  00 00 66 04 64 10 84 04  |e.e.f.....f.d...|
00000120  5a 1f 65 02 02 00 47 00  64 11 84 00 64 12 ab 02  |Z.e...G.d...d...|
00000130  00 00 00 00 00 00 ab 00  00 00 00 00 00 00 5a 20  |..............Z |
00000140  65 02 02 00 47 00 64 13  84 00 64 14 ab 02 00 00  |e...G.d...d.....|
00000150  00 00 00 00 ab 00 00 00  00 00 00 00 5a 21 65 02  |............Z!e.|
00000160  02 00 47 00 64 15 84 00  64 16 ab 02 00 00 00 00  |..G.d...d.......|
00000170  00 00 ab 00 00 00 00 00  00 00 5a 22 65 02 02 00  |..........Z"e...|
00000180  47 00 64 17 84 00 64 18  ab 02 00 00 00 00 00 00  |G.d...d.........|
00000190  ab 00 00 00 00 00 00 00  5a 23 65 02 02 00 47 00  |........Z#e...G.|
000001a0  64 19 84 00 64 1a ab 02  00 00 00 00 00 00 ab 00  |d...d...........|
000001b0  00 00 00 00 00 00 5a 24  65 02 02 00 47 00 64 1b  |......Z$e...G.d.|
000001c0  84 00 64 1c ab 02 00 00  00 00 00 00 ab 00 00 00  |..d.............|
000001d0  00 00 00 00 5a 25 65 02  02 00 47 00 64 1d 84 00  |....Z%e...G.d...|
000001e0  64 1e ab 02 00 00 00 00  00 00 ab 00 00 00 00 00  |d...............|
000001f0  00 00 5a 26 79 01 29 1f  e9 00 00 00 00 4e 29 01  |..Z&y.)......N).|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/pylock.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/scheme.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.1K 2025-06-01 01:28:19.851978178 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/scheme.cpython-312.pyc
f0139416631f4dd561c98d1934f036ace6de4b0916b9166189266b2f467824cf  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/scheme.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 3f 02 00 00  |.........x3h?...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 48 00  00 00 97 00 64 00 5a 00  |......H.....d.Z.|
00000030  64 01 64 02 6c 01 6d 02  5a 02 01 00 67 00 64 03  |d.d.l.m.Z...g.d.|
00000040  a2 01 5a 03 02 00 65 02  64 04 ac 05 ab 01 00 00  |..Z...e.d.......|
00000050  00 00 00 00 02 00 47 00  64 06 84 00 64 07 ab 02  |......G.d...d...|
00000060  00 00 00 00 00 00 ab 00  00 00 00 00 00 00 5a 04  |..............Z.|
00000070  79 08 29 09 7a ba 0a 46  6f 72 20 74 79 70 65 73  |y.).z..For types|
00000080  20 61 73 73 6f 63 69 61  74 65 64 20 77 69 74 68  | associated with|
00000090  20 69 6e 73 74 61 6c 6c  61 74 69 6f 6e 20 73 63  | installation sc|
000000a0  68 65 6d 65 73 2e 0a 0a  46 6f 72 20 61 20 67 65  |hemes...For a ge|
000000b0  6e 65 72 61 6c 20 6f 76  65 72 76 69 65 77 20 6f  |neral overview o|
000000c0  66 20 61 76 61 69 6c 61  62 6c 65 20 73 63 68 65  |f available sche|
000000d0  6d 65 73 20 61 6e 64 20  74 68 65 69 72 20 63 6f  |mes and their co|
000000e0  6e 74 65 78 74 2c 20 73  65 65 0a 68 74 74 70 73  |ntext, see.https|
000000f0  3a 2f 2f 64 6f 63 73 2e  70 79 74 68 6f 6e 2e 6f  |://docs.python.o|
00000100  72 67 2f 33 2f 69 6e 73  74 61 6c 6c 2f 69 6e 64  |rg/3/install/ind|
00000110  65 78 2e 68 74 6d 6c 23  61 6c 74 65 72 6e 61 74  |ex.html#alternat|
00000120  65 2d 69 6e 73 74 61 6c  6c 61 74 69 6f 6e 2e 0a  |e-installation..|
00000130  e9 00 00 00 00 29 01 da  09 64 61 74 61 63 6c 61  |.....)...datacla|
00000140  73 73 29 05 da 07 70 6c  61 74 6c 69 62 da 07 70  |ss)...platlib..p|
00000150  75 72 65 6c 69 62 da 07  68 65 61 64 65 72 73 da  |urelib..headers.|
00000160  07 73 63 72 69 70 74 73  da 04 64 61 74 61 54 29  |.scripts..dataT)|
00000170  01 da 06 66 72 6f 7a 65  6e 63 00 00 00 00 00 00  |...frozenc......|
00000180  00 00 00 00 00 00 03 00  00 00 00 00 00 00 f3 48  |...............H|
00000190  00 00 00 97 00 65 00 5a  01 64 00 5a 02 55 00 64  |.....e.Z.d.Z.U.d|
000001a0  01 5a 03 65 04 5a 05 65  06 65 07 64 02 3c 00 00  |.Z.e.Z.e.e.d.<..|
000001b0  00 65 06 65 07 64 03 3c  00 00 00 65 06 65 07 64  |.e.e.d.<...e.e.d|
000001c0  04 3c 00 00 00 65 06 65  07 64 05 3c 00 00 00 65  |.<...e.e.d.<...e|
000001d0  06 65 07 64 06 3c 00 00  00 79 07 29 08 da 06 53  |.e.d.<...y.)...S|
000001e0  63 68 65 6d 65 7a 74 41  20 53 63 68 65 6d 65 20  |chemeztA Scheme |
000001f0  68 6f 6c 64 73 20 70 61  74 68 73 20 77 68 69 63  |holds paths whic|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/scheme.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/search_scope.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 5.0K 2025-06-01 01:28:20.003978178 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/search_scope.cpython-312.pyc
8ad702488781e52a1a7a3db18fb0eb58e1b509f1ffc8758ec55f04243602d809  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_internal/models/__pycache__/search_scope.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 78 33 68 b3 11 00 00  |.........x3h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 c8 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 05 64 00 64 02  6c 06 6d 07 5a 07 01 00  |l.Z.d.d.l.m.Z...|
00000060  64 00 64 03 6c 08 6d 09  5a 09 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000070  6c 0a 6d 0b 5a 0b 01 00  64 00 64 05 6c 0c 6d 0d  |l.m.Z...d.d.l.m.|
00000080  5a 0d 01 00 64 00 64 06  6c 0e 6d 0f 5a 0f 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 07 6c 10 6d 11  5a 11 6d 12 5a 12 01 00  |d.d.l.m.Z.m.Z...|
000000a0  02 00 65 01 6a 26 00 00  00 00 00 00 00 00 00 00  |..e.j&..........|
000000b0  00 00 00 00 00 00 00 00  65 14 ab 01 00 00 00 00  |........e.......|
000000c0  00 00 5a 15 02 00 65 07  64 08 ac 09 ab 01 00 00  |..Z...e.d.......|
000000d0  00 00 00 00 02 00 47 00  64 0a 84 00 64 0b ab 02  |......G.d...d...|
000000e0  00 00 00 00 00 00 ab 00  00 00 00 00 00 00 5a 16  |..............Z.|
000000f0  79 01 29 0c e9 00 00 00  00 4e 29 01 da 09 64 61  |y.)......N)...da|
00000100  74 61 63 6c 61 73 73 29  01 da 04 4c 69 73 74 29  |taclass)...List)|
00000110  01 da 11 63 61 6e 6f 6e  69 63 61 6c 69 7a 65 5f  |...canonicalize_|
00000120  6e 61 6d 65 29 01 da 04  50 79 50 49 29 01 da 07  |name)...PyPI)...|
00000130  68 61 73 5f 74 6c 73 29  02 da 0e 6e 6f 72 6d 61  |has_tls)...norma|
00000140  6c 69 7a 65 5f 70 61 74  68 da 14 72 65 64 61 63  |lize_path..redac|
00000150  74 5f 61 75 74 68 5f 66  72 6f 6d 5f 75 72 6c 54  |t_auth_from_urlT|
00000160  29 01 da 06 66 72 6f 7a  65 6e 63 00 00 00 00 00  |)...frozenc.....|
00000170  00 00 00 00 00 00 00 09  00 00 00 00 00 00 00 f3  |................|
00000180  94 00 00 00 97 00 65 00  5a 01 64 00 5a 02 55 00  |......e.Z.d.Z.U.|
00000190  64 01 5a 03 67 00 64 02  a2 01 5a 04 65 05 65 06  |d.Z.g.d...Z.e.e.|