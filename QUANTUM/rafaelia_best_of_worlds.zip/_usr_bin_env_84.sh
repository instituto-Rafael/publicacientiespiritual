#!/usr/bin/env python3
# https://github.com/python/mypy/issues/16936
# mypy: disable-error-code="has-type"
"""Integration tests for setuptools that focus on building packages via pip.

The idea behind these tests is not to exhaustively check all the possible
combinations of packages, operating systems, supporting libraries, etc, but
rather check a limited number of popular packages and how they interact with
the exposed public API. This way if any change in API is introduced, we hope to
identify backward compatibility problems before publishing a release.

The number of tested packages is purposefully kept small, to minimise duration
and the associated maintenance cost (changes in the way these packages define
their build process may require changes in the tests).
"""

import json
import os
import shutil
import sys
from enum import Enum
from glob import glob
from hashlib import md5
from urllib.request import urlopen

import pytest
from packaging.requirements import Requirement

from .helpers import Archive, run

pytestmark = pytest.mark.integration


(LATEST,) = Enum("v", "LATEST")  # type: ignore[misc] # https://github.com/python/mypy/issues/16936
"""Default version to be checked"""
# There are positive and negative aspects of checking the latest version of the
# packages.
# The main positive aspect is that the latest version might have already
# removed the use of APIs deprecated in previous releases of setuptools.


# Packages to be tested:
# (Please notice the test environment cannot support EVERY library required for
# compiling binary extensions. In Ubuntu/Debian nomenclature, we only assume
# that `build-essential`, `gfortran` and `libopenblas-dev` are installed,
# due to their relevance to the numerical/scientific programming ecosystem)
EXAMPLES = [
    ("pip", LATEST),  # just in case...
    ("pytest", LATEST),  # uses setuptools_scm
    ("mypy", LATEST),  # custom build_py + ext_modules
    # --- Popular packages: https://hugovk.github.io/top-pypi-packages/ ---
    ("botocore", LATEST),
    ("kiwisolver", LATEST),  # build_ext
    ("brotli", LATEST),  # not in the list but used by urllib3
    ("pyyaml", LATEST),  # cython + custom build_ext + custom distclass
    ("charset-normalizer", LATEST),  # uses mypyc, used by aiohttp
    ("protobuf", LATEST),
    # ("requests", LATEST),  # XXX: https://github.com/psf/requests/pull/6920
    ("celery", LATEST),
    # When adding packages to this list, make sure they expose a `__version__`
    # attribute, or modify the tests below
]


# Some packages have "optional" dependencies that modify their build behaviour
# and are not listed in pyproject.toml, others still use `setup_requires`
EXTRA_BUILD_DEPS = {
    "pyyaml": ("Cython<3.0",),  # constraint to avoid errors
    "charset-normalizer": ("mypy>=1.4.1",),  # no pyproject.toml available
}

EXTRA_ENV_VARS = {
    "pyyaml": {"PYYAML_FORCE_CYTHON": "1"},
    "charset-normalizer": {"CHARSET_NORMALIZER_USE_MYPYC": "1"},
}

IMPORT_NAME = {
    "pyyaml": "yaml",
    "protobuf": "google.protobuf",
}


VIRTUALENV = (sys.executable, "-m", "virtualenv")


# By default, pip will try to build packages in isolation (PEP 517), which
# means it will download the previous stable version of setuptools.
# `pip` flags can avoid that (the version of setuptools under test
# should be the one to be used)
INSTALL_OPTIONS = (
    "--ignore-installed",
    "--no-build-isolation",
    # Omit "--no-binary :all:" the sdist is supplied directly.
    # Allows dependencies as wheels.
)
# The downside of `--no-build-isolation` is that pip will not download build
# dependencies. The test script will have to also handle that.


@pytest.fixture
def venv_python(tmp_path):
    run([*VIRTUALENV, str(tmp_path / ".venv")])
    possible_path = (str(p.parent) for p in tmp_path.glob(".venv/*/python*"))
    return shutil.which("python", path=os.pathsep.join(possible_path))


@pytest.fixture(autouse=True)
def _prepare(tmp_path, venv_python, monkeypatch):
    download_path = os.getenv("DOWNLOAD_PATH", str(tmp_path))
    os.makedirs(download_path, exist_ok=True)

    # Environment vars used for building some of the packages
    monkeypatch.setenv("USE_MYPYC", "1")

    yield

    # Let's provide the maximum amount of information possible in the case
    # it is necessary to debug the tests directly from the CI logs.
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("Temporary directory:")
    map(print, tmp_path.glob("*"))
    print("Virtual environment:")
    run([venv_python, "-m", "pip", "freeze"])


@pytest.mark.parametrize(("package", "version"), EXAMPLES)
@pytest.mark.uses_network
def test_install_sdist(package, version, tmp_path, venv_python, setuptools_wheel):
    venv_pip = (venv_python, "-m", "pip")
    sdist = retrieve_sdist(package, version, tmp_path)
    deps = build_deps(package, sdist)
    if deps:
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("Dependencies:", deps)
        run([*venv_pip, "install", *deps])

    # Use a virtualenv to simulate PEP 517 isolation
    # but install fresh setuptools wheel to ensure the version under development
    env = EXTRA_ENV_VARS.get(package, {})
    run([*venv_pip, "install", "--force-reinstall", setuptools_wheel])
    run([*venv_pip, "install", *INSTALL_OPTIONS, sdist], env)

    # Execute a simple script to make sure the package was installed correctly
    pkg = IMPORT_NAME.get(package, package).replace("-", "_")
    script = f"import {pkg}; print(getattr({pkg}, '__version__', 0))"
    run([venv_python, "-c", script])


# ---- Helper Functions ----


def retrieve_sdist(package, version, tmp_path):
    """Either use cached sdist file or download it from PyPI"""
    # `pip download` cannot be used due to
    # https://github.com/pypa/pip/issues/1884
    # https://discuss.python.org/t/pep-625-file-name-of-a-source-distribution/4686
    # We have to find the correct distribution file and download it
    download_path = os.getenv("DOWNLOAD_PATH", str(tmp_path))
    dist = retrieve_pypi_sdist_metadata(package, version)

    # Remove old files to prevent cache to grow indefinitely
    for file in glob(os.path.join(download_path, f"{package}*")):
        if dist["filename"] != file:
            os.unlink(file)

    dist_file = os.path.join(download_path, dist["filename"])
    if not os.path.exists(dist_file):
        download(dist["url"], dist_file, dist["md5_digest"])
    return dist_file


def retrieve_pypi_sdist_metadata(package, version):
    # https://warehouse.pypa.io/api-reference/json.html
    id_ = package if version is LATEST else f"{package}/{version}"
    with urlopen(f"https://pypi.org/pypi/{id_}/json") as f:
        metadata = json.load(f)

    if metadata["info"]["yanked"]:
        raise ValueError(f"Release for {package} {version} was yanked")

    version = metadata["info"]["version"]
    release = metadata["releases"][version] if version is LATEST else metadata["urls"]
    (sdist,) = filter(lambda d: d["packagetype"] == "sdist", release)
    return sdist


def download(url, dest, md5_digest):
    with urlopen(url) as f:
        data = f.read()

    assert md5(data).hexdigest() == md5_digest

    with open(dest, "wb") as f:
        f.write(data)

    assert os.path.exists(dest)


def build_deps(package, sdist_file):
    """Find out what are the build dependencies for a package.

    "Manually" install them, since pip will not install build
    deps with `--no-build-isolation`.
    """
    # delay importing, since pytest discovery phase may hit this file from a
    # testenv without tomli
    from setuptools.compat.py310 import tomllib

    archive = Archive(sdist_file)
    info = tomllib.loads(_read_pyproject(archive))
    deps = info.get("build-system", {}).get("requires", [])
    deps += EXTRA_BUILD_DEPS.get(package, [])
    # Remove setuptools from requirements (and deduplicate)
    requirements = {Requirement(d).name: d for d in deps}
    return [v for k, v in requirements.items() if k != "setuptools"]


def _read_pyproject(archive):
    contents = (
        archive.get_content(member)
        for member in archive
        if os.path.basename(archive.get_name(member)) == "pyproject.toml"
    )
    return next(contents, "")

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/test_pip_install_sdist.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pip_install_sdist.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 9.0K 2025-06-01 01:30:22.959978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pip_install_sdist.cpython-312.pyc
aa277f957693003f6566b306b36ce30e2f25454dc51c314a5c5f4211d2a67e98  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pip_install_sdist.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 40 20 00 00  |..........8h@ ..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0b 00 00  |................|
00000020  00 00 00 00 00 f3 32 02  00 00 97 00 64 00 5a 00  |......2.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 03 6c 05 6d 06  5a 06 01 00 64 01 64 04  |d.d.l.m.Z...d.d.|
00000060  6c 07 6d 07 5a 07 01 00  64 01 64 05 6c 08 6d 09  |l.m.Z...d.d.l.m.|
00000070  5a 09 01 00 64 01 64 06  6c 0a 6d 0b 5a 0b 01 00  |Z...d.d.l.m.Z...|
00000080  64 01 64 02 6c 0c 5a 0c  64 01 64 07 6c 0d 6d 0e  |d.d.l.Z.d.d.l.m.|
00000090  5a 0e 01 00 64 08 64 09  6c 0f 6d 10 5a 10 6d 11  |Z...d.d.l.m.Z.m.|
000000a0  5a 11 01 00 65 0c 6a 24  00 00 00 00 00 00 00 00  |Z...e.j$........|
000000b0  00 00 00 00 00 00 00 00  00 00 6a 26 00 00 00 00  |..........j&....|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 5a 14  |..............Z.|
000000d0  02 00 65 06 64 0a 64 0b  ab 02 00 00 00 00 00 00  |..e.d.d.........|
000000e0  5c 01 00 00 5a 15 09 00  64 0c 65 15 66 02 64 0d  |\...Z...d.e.f.d.|
000000f0  65 15 66 02 64 0e 65 15  66 02 64 0f 65 15 66 02  |e.f.d.e.f.d.e.f.|
00000100  64 10 65 15 66 02 64 11  65 15 66 02 64 12 65 15  |d.e.f.d.e.f.d.e.|
00000110  66 02 64 13 65 15 66 02  64 14 65 15 66 02 64 15  |f.d.e.f.d.e.f.d.|
00000120  65 15 66 02 67 0a 5a 16  64 16 64 17 64 18 9c 02  |e.f.g.Z.d.d.d...|
00000130  5a 17 64 19 64 1a 69 01  64 1b 64 1a 69 01 64 18  |Z.d.d.i.d.d.i.d.|
00000140  9c 02 5a 18 64 1c 64 1d  64 1e 9c 02 5a 19 65 04  |..Z.d.d.d...Z.e.|
00000150  6a 34 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j4..............|
00000160  00 00 00 00 64 1f 64 20  66 03 5a 1b 64 21 5a 1c  |....d.d f.Z.d!Z.|
00000170  65 0c 6a 3a 00 00 00 00  00 00 00 00 00 00 00 00  |e.j:............|
00000180  00 00 00 00 00 00 64 22  84 00 ab 00 00 00 00 00  |......d"........|
00000190  00 00 5a 1e 02 00 65 0c  6a 3a 00 00 00 00 00 00  |..Z...e.j:......|
000001a0  00 00 00 00 00 00 00 00  00 00 00 00 64 23 ac 24  |............d#.$|
000001b0  ab 01 00 00 00 00 00 00  64 25 84 00 ab 00 00 00  |........d%......|
000001c0  00 00 00 00 5a 1f 65 0c  6a 24 00 00 00 00 00 00  |....Z.e.j$......|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 6a 41 00 00  |............jA..|
000001e0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000001f0  64 26 65 16 ab 02 00 00  00 00 00 00 65 0c 6a 24  |d&e.........e.j$|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pip_install_sdist.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 232 2025-06-01 01:30:22.491978091 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/__init__.cpython-312.pyc
ff0ac82f420b8db53ddd8a1644be519e8fb93299b65ba4872b84865af96986a1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 00 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000020  00 00 00 00 00 f3 04 00  00 00 97 00 79 00 29 01  |............y.).|
00000030  4e a9 00 72 02 00 00 00  f3 00 00 00 00 fa 87 2f  |N..r.........../|
00000040  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000050  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000060  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
00000070  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
00000080  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
00000090  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000000a0  74 75 70 74 6f 6f 6c 73  2f 74 65 73 74 73 2f 69  |tuptools/tests/i|
000000b0  6e 74 65 67 72 61 74 69  6f 6e 2f 5f 5f 69 6e 69  |ntegration/__ini|
000000c0  74 5f 5f 2e 70 79 da 08  3c 6d 6f 64 75 6c 65 3e  |t__.py..<module>|
000000d0  72 05 00 00 00 01 00 00  00 73 05 00 00 00 f1 03  |r........s......|
000000e0  01 01 01 72 03 00 00 00                           |...r....|
000000e8
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/helpers.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.6K 2025-06-01 01:30:22.647978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/helpers.cpython-312.pyc
461a1b9e2fe361306767a71a7d93e77a72497189bdaa14c95628254f052e80f1  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/helpers.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 da 09 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 60 00  00 00 97 00 64 00 5a 00  |......`.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 01 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 0a 64 05 84 01 5a 08  02 00 47 00 64 06 84 00  |d.d...Z...G.d...|
00000070  64 07 ab 02 00 00 00 00  00 00 5a 09 64 08 84 00  |d.........Z.d...|
00000080  5a 0a 64 09 84 00 5a 0b  79 02 29 0b 7a fd 52 65  |Z.d...Z.y.).z.Re|
00000090  75 73 61 62 6c 65 20 66  75 6e 63 74 69 6f 6e 73  |usable functions|
000000a0  20 61 6e 64 20 63 6c 61  73 73 65 73 20 66 6f 72  | and classes for|
000000b0  20 64 69 66 66 65 72 65  6e 74 20 74 79 70 65 73  | different types|
000000c0  20 6f 66 20 69 6e 74 65  67 72 61 74 69 6f 6e 20  | of integration |
000000d0  74 65 73 74 73 2e 0a 0a  46 6f 72 20 65 78 61 6d  |tests...For exam|
000000e0  70 6c 65 20 60 60 41 72  63 68 69 76 65 60 60 20  |ple ``Archive`` |
000000f0  63 61 6e 20 62 65 20 75  73 65 64 20 74 6f 20 63  |can be used to c|
00000100  68 65 63 6b 20 74 68 65  20 63 6f 6e 74 65 6e 74  |heck the content|
00000110  73 20 6f 66 20 64 69 73  74 72 69 62 75 74 69 6f  |s of distributio|
00000120  6e 20 62 75 69 6c 74 0a  77 69 74 68 20 73 65 74  |n built.with set|
00000130  75 70 74 6f 6f 6c 73 2c  20 61 6e 64 20 60 60 72  |uptools, and ``r|
00000140  75 6e 60 60 20 77 69 6c  6c 20 61 6c 77 61 79 73  |un`` will always|
00000150  20 74 72 79 20 74 6f 20  62 65 20 61 73 20 76 65  | try to be as ve|
00000160  72 62 6f 73 65 20 61 73  20 70 6f 73 73 69 62 6c  |rbose as possibl|
00000170  65 20 74 6f 0a 66 61 63  69 6c 69 74 61 74 65 20  |e to.facilitate |
00000180  64 65 62 75 67 67 69 6e  67 2e 0a e9 00 00 00 00  |debugging.......|
00000190  4e 29 01 da 04 50 61 74  68 29 01 da 07 5a 69 70  |N)...Path)...Zip|
000001a0  46 69 6c 65 63 02 00 00  00 00 00 00 00 00 00 00  |Filec...........|
000001b0  00 09 00 00 00 03 00 00  00 f3 7a 01 00 00 97 00  |..........z.....|
000001c0  74 01 00 00 00 00 00 00  00 00 6a 02 00 00 00 00  |t.........j.....|
000001d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 7c 00  |..............|.|
000001e0  64 01 64 01 64 02 69 00  74 04 00 00 00 00 00 00  |d.d.d.i.t.......|
000001f0  00 00 6a 06 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/helpers.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pbr.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 882 2025-06-01 01:30:22.791978090 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pbr.cpython-312.pyc
0b3e424ac002762f4daf1ab9f7a18fb85063d68a9b66b9d8d341471d2057a378  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pbr.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 b0 01 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 4c 00  00 00 97 00 64 00 64 01  |......L.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 65 01 6a 04  |l.Z.d.d.l.Z.e.j.|
00000040  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000050  00 00 6a 06 00 00 00 00  00 00 00 00 00 00 00 00  |..j.............|
00000060  00 00 00 00 00 00 64 02  84 00 ab 00 00 00 00 00  |......d.........|
00000070  00 00 5a 04 79 01 29 03  e9 00 00 00 00 4e 63 02  |..Z.y.)......Nc.|
00000080  00 00 00 00 00 00 00 00  00 00 00 07 00 00 00 03  |................|
00000090  00 00 00 f3 8a 00 00 00  97 00 64 01 64 02 64 03  |..........d.d.d.|
000000a0  64 04 64 05 64 06 7c 00  67 07 7d 02 7c 01 6a 01  |d.d.d.|.g.}.|.j.|
000000b0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000c0  00 00 7c 02 74 02 00 00  00 00 00 00 00 00 6a 04  |..|.t.........j.|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  00 00 ac 07 ab 02 00 00  00 00 00 00 01 00 7c 01  |..............|.|
000000f0  6a 01 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000100  00 00 00 00 67 00 64 08  a2 01 ab 01 00 00 00 00  |....g.d.........|
00000110  00 00 7d 03 64 09 7c 03  76 00 73 02 4a 00 82 01  |..}.d.|.v.s.J...|
00000120  79 0a 29 0b 7a 1c 45 6e  73 75 72 65 20 70 62 72  |y.).z.Ensure pbr|
00000130  20 70 61 63 6b 61 67 65  73 20 69 6e 73 74 61 6c  | packages instal|
00000140  6c 2e da 06 70 79 74 68  6f 6e 7a 02 2d 6d da 03  |l...pythonz.-m..|
00000150  70 69 70 7a 02 2d 76 da  07 69 6e 73 74 61 6c 6c  |pipz.-v..install|
00000160  7a 14 2d 2d 6e 6f 2d 62  75 69 6c 64 2d 69 73 6f  |z.--no-build-iso|
00000170  6c 61 74 69 6f 6e 29 01  da 06 73 74 64 65 72 72  |lation)...stderr|
00000180  29 03 72 04 00 00 00 7a  02 2d 63 7a 12 69 6d 70  |).r....z.-cz.imp|
00000190  6f 72 74 20 6d 79 70 6b  67 2e 68 65 6c 6c 6f 7a  |ort mypkg.helloz|
000001a0  0c 48 65 6c 6c 6f 20 77  6f 72 6c 64 21 4e 29 03  |.Hello world!N).|
000001b0  da 03 72 75 6e da 0a 73  75 62 70 72 6f 63 65 73  |..run..subproces|
000001c0  73 da 06 53 54 44 4f 55  54 29 04 da 0b 70 62 72  |s..STDOUT)...pbr|
000001d0  5f 70 61 63 6b 61 67 65  da 04 76 65 6e 76 da 03  |_package..venv..|
000001e0  63 6d 64 da 03 6f 75 74  73 04 00 00 00 20 20 20  |cmd..outs....   |
000001f0  20 fa 87 2f 64 61 74 61  2f 64 61 74 61 2f 63 6f  | ../data/data/co|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/integration/__pycache__/test_pbr.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_deprecations.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.6K 2025-06-01 01:30:14.899978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_deprecations.cpython-312.pyc
c58521157b6dccde1cb18b55c5627b641e084a622715018d15c75e5ae300a60a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_deprecations.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 07 03 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 04 01  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 03 6c 02 6d 03  |d.d.l.Z.d.d.l.m.|
00000040  5a 03 01 00 64 01 64 02  6c 04 5a 04 64 01 64 04  |Z...d.d.l.Z.d.d.|
00000050  6c 05 6d 06 5a 06 01 00  64 01 64 05 6c 07 6d 08  |l.m.Z...d.d.l.m.|
00000060  5a 08 01 00 65 04 6a 12  00 00 00 00 00 00 00 00  |Z...e.j.........|
00000070  00 00 00 00 00 00 00 00  00 00 6a 15 00 00 00 00  |..........j.....|
00000080  00 00 00 00 00 00 00 00  00 00 00 00 00 00 65 01  |..............e.|
00000090  6a 16 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000a0  00 00 00 00 64 06 6b 28  00 00 64 07 ac 08 ab 02  |....d.k(..d.....|
000000b0  00 00 00 00 00 00 65 04  6a 12 00 00 00 00 00 00  |......e.j.......|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 6a 19 00 00  |............j...|
000000d0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000e0  64 09 ac 08 ab 01 00 00  00 00 00 00 02 00 65 03  |d.............e.|
000000f0  6a 1a 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000100  00 00 00 00 64 0a ab 01  00 00 00 00 00 00 64 0b  |....d.........d.|
00000110  84 00 ab 00 00 00 00 00  00 00 ab 00 00 00 00 00  |................|
00000120  00 00 ab 00 00 00 00 00  00 00 5a 0e 79 02 29 0c  |..........Z.y.).|
00000130  7a 0d 64 65 76 65 6c 6f  70 20 74 65 73 74 73 e9  |z.develop tests.|
00000140  00 00 00 00 4e 29 01 da  04 6d 6f 63 6b 29 01 da  |....N)...mock)..|
00000150  1c 53 65 74 75 70 74 6f  6f 6c 73 44 65 70 72 65  |.SetuptoolsDepre|
00000160  63 61 74 69 6f 6e 57 61  72 6e 69 6e 67 29 01 da  |cationWarning)..|
00000170  0c 44 69 73 74 72 69 62  75 74 69 6f 6e da 05 77  |.Distribution..w|
00000180  69 6e 33 32 7a 10 6e 6f  6e 2d 57 69 6e 64 6f 77  |in32z.non-Window|
00000190  73 20 6f 6e 6c 79 29 01  da 06 72 65 61 73 6f 6e  |s only)...reason|
000001a0  7a 38 62 64 69 73 74 5f  72 70 6d 20 69 73 20 6c  |z8bdist_rpm is l|
000001b0  6f 6e 67 20 64 65 70 72  65 63 61 74 65 64 2c 20  |ong deprecated, |
000001c0  73 68 6f 75 6c 64 20 77  65 20 72 65 6d 6f 76 65  |should we remove|
000001d0  20 69 74 3f 20 23 31 39  38 38 7a 25 64 69 73 74  | it? #1988z%dist|
000001e0  75 74 69 6c 73 2e 63 6f  6d 6d 61 6e 64 2e 62 64  |utils.command.bd|
000001f0  69 73 74 5f 72 70 6d 2e  62 64 69 73 74 5f 72 70  |ist_rpm.bdist_rp|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_deprecations.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/__init__.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 729 2025-06-01 01:30:13.639978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/__init__.cpython-312.pyc
169e65d23493cdc4eec23ac8904fb23f5e8b3ab33eec21a6a79fb98a8edaead8  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/__init__.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 4f 01 00 00  |..........8hO...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 cc 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 02 67 01  5a 03 65 01 6a 08 00 00  |l.Z.d.g.Z.e.j...|
00000050  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000060  64 03 6b 5c 00 00 72 12  02 00 65 00 6a 0a 00 00  |d.k\..r...e.j...|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000080  ab 00 00 00 00 00 00 00  5a 06 6e 12 02 00 65 00  |........Z.n...e.|
00000090  6a 0e 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000a0  00 00 00 00 64 04 ab 01  00 00 00 00 00 00 5a 06  |....d.........Z.|
000000b0  65 06 64 05 6b 28 00 00  5a 08 65 02 6a 12 00 00  |e.d.k(..Z.e.j...|
000000c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000d0  6a 15 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000e0  00 00 00 00 65 08 64 06  ac 07 ab 02 00 00 00 00  |....e.d.........|
000000f0  00 00 5a 0b 79 01 29 08  e9 00 00 00 00 4e da 0d  |..Z.y.)......N..|
00000100  66 61 69 6c 5f 6f 6e 5f  61 73 63 69 69 29 02 e9  |fail_on_ascii)..|
00000110  03 00 00 00 e9 0b 00 00  00 46 7a 0e 41 4e 53 49  |.........Fz.ANSI|
00000120  5f 58 33 2e 34 2d 31 39  36 38 7a 19 54 65 73 74  |_X3.4-1968z.Test|
00000130  20 66 61 69 6c 73 20 69  6e 20 74 68 69 73 20 6c  | fails in this l|
00000140  6f 63 61 6c 65 29 01 da  06 72 65 61 73 6f 6e 29  |ocale)...reason)|
00000150  0c da 06 6c 6f 63 61 6c  65 da 03 73 79 73 da 06  |...locale..sys..|
00000160  70 79 74 65 73 74 da 07  5f 5f 61 6c 6c 5f 5f da  |pytest..__all__.|
00000170  0c 76 65 72 73 69 6f 6e  5f 69 6e 66 6f da 0b 67  |.version_info..g|
00000180  65 74 65 6e 63 6f 64 69  6e 67 da 0f 6c 6f 63 61  |etencoding..loca|
00000190  6c 65 5f 65 6e 63 6f 64  69 6e 67 da 14 67 65 74  |le_encoding..get|
000001a0  70 72 65 66 65 72 72 65  64 65 6e 63 6f 64 69 6e  |preferredencodin|
000001b0  67 da 08 69 73 5f 61 73  63 69 69 da 04 6d 61 72  |g..is_ascii..mar|
000001c0  6b da 05 78 66 61 69 6c  72 03 00 00 00 a9 00 f3  |k..xfailr.......|
000001d0  00 00 00 00 fa 7b 2f 64  61 74 61 2f 64 61 74 61  |.....{/data/data|
000001e0  2f 63 6f 6d 2e 74 65 72  6d 75 78 2f 66 69 6c 65  |/com.termux/file|
000001f0  73 2f 68 6f 6d 65 2f 52  41 46 41 45 4c 49 41 2f  |s/home/RAFAELIA/|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/__init__.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/contexts.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 6.5K 2025-06-01 01:30:13.799978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/contexts.cpython-312.pyc
c87ad0e2a05c48ab49bb49f57189e9bd554936406ac04cfd2c781668405ffd67  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/contexts.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 5e 0c 00 00  |..........8h^...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |................|
00000020  00 00 00 00 00 f3 74 01  00 00 97 00 64 00 64 01  |......t.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 5a 06 64 00 64 02  6c 07 6d 08 5a 08 01 00  |l.Z.d.d.l.m.Z...|
00000070  65 00 6a 12 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000080  00 00 00 00 00 00 64 03  84 00 66 01 64 04 84 01  |......d...f.d...|
00000090  ab 00 00 00 00 00 00 00  5a 0a 65 00 6a 12 00 00  |........Z.e.j...|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  64 05 84 00 ab 00 00 00  00 00 00 00 5a 0b 65 00  |d...........Z.e.|
000000c0  6a 12 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
000000d0  00 00 00 00 64 06 84 00  ab 00 00 00 00 00 00 00  |....d...........|
000000e0  5a 0c 65 00 6a 12 00 00  00 00 00 00 00 00 00 00  |Z.e.j...........|
000000f0  00 00 00 00 00 00 00 00  64 07 84 00 ab 00 00 00  |........d.......|
00000100  00 00 00 00 5a 0d 65 00  6a 12 00 00 00 00 00 00  |....Z.e.j.......|
00000110  00 00 00 00 00 00 00 00  00 00 00 00 64 08 84 00  |............d...|
00000120  ab 00 00 00 00 00 00 00  5a 0e 64 09 84 00 5a 0f  |........Z.d...Z.|
00000130  65 00 6a 12 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000140  00 00 00 00 00 00 64 0a  84 00 ab 00 00 00 00 00  |......d.........|
00000150  00 00 5a 10 65 00 6a 12  00 00 00 00 00 00 00 00  |..Z.e.j.........|
00000160  00 00 00 00 00 00 00 00  00 00 64 0b 84 00 ab 00  |..........d.....|
00000170  00 00 00 00 00 00 5a 11  65 00 6a 12 00 00 00 00  |......Z.e.j.....|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 0c  |..............d.|
00000190  84 00 ab 00 00 00 00 00  00 00 5a 12 79 01 29 0d  |..........Z.y.).|
000001a0  e9 00 00 00 00 4e 29 01  da 08 46 69 6c 65 4c 6f  |.....N)...FileLo|
000001b0  63 6b 63 01 00 00 00 00  00 00 00 00 00 00 00 00  |ckc.............|
000001c0  00 00 00 03 00 00 00 f3  04 00 00 00 97 00 79 00  |..............y.|
000001d0  a9 01 4e a9 00 29 01 da  03 64 69 72 73 01 00 00  |..N..)...dirs...|
000001e0  00 20 fa 7b 2f 64 61 74  61 2f 64 61 74 61 2f 63  |. .{/data/data/c|
000001f0  6f 6d 2e 74 65 72 6d 75  78 2f 66 69 6c 65 73 2f  |om.termux/files/|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/contexts.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/environment.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 3.5K 2025-06-01 01:30:13.955978097 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/environment.cpython-312.pyc
91a470acc37bdb8b251205f18f27feca4e99b95e800684e113233b566f6a2b7b  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/environment.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 1e 0c 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 88 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000050  6c 01 6d 04 5a 05 6d 06  5a 07 01 00 64 00 64 01  |l.m.Z.m.Z...d.d.|
00000060  6c 08 5a 09 02 00 47 00  64 03 84 00 64 04 65 09  |l.Z...G.d...d.e.|
00000070  6a 14 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000080  00 00 00 00 6a 16 00 00  00 00 00 00 00 00 00 00  |....j...........|
00000090  00 00 00 00 00 00 00 00  ab 03 00 00 00 00 00 00  |................|
000000a0  5a 0b 64 05 84 00 5a 0c  64 07 64 06 84 01 5a 0d  |Z.d...Z.d.d...Z.|
000000b0  79 01 29 08 e9 00 00 00  00 4e 29 02 da 04 50 49  |y.)......N)...PI|
000000c0  50 45 da 05 50 6f 70 65  6e 63 00 00 00 00 00 00  |PE..Popenc......|
000000d0  00 00 00 00 00 00 01 00  00 00 00 00 00 00 f3 1c  |................|
000000e0  00 00 00 97 00 65 00 5a  01 64 00 5a 02 64 01 5a  |.....e.Z.d.Z.d.Z|
000000f0  03 64 02 67 01 5a 04 64  03 84 00 5a 05 79 04 29  |.d.g.Z.d...Z.y.)|
00000100  05 da 0a 56 69 72 74 75  61 6c 45 6e 76 7a 04 2e  |...VirtualEnvz..|
00000110  65 6e 76 7a 0f 2d 2d 6e  6f 2d 73 65 74 75 70 74  |envz.--no-setupt|
00000120  6f 6f 6c 73 63 02 00 00  00 00 00 00 00 00 00 00  |oolsc...........|
00000130  00 05 00 00 00 0f 00 00  00 f3 de 00 00 00 97 00  |................|
00000140  7c 00 6a 01 00 00 00 00  00 00 00 00 00 00 00 00  ||.j.............|
00000150  00 00 00 00 00 00 7c 01  64 01 19 00 00 00 ab 01  |......|.d.......|
00000160  00 00 00 00 00 00 67 01  7c 01 64 02 64 00 1a 00  |......g.|.d.d...|
00000170  7a 00 00 00 7d 01 7c 00  6a 02 00 00 00 00 00 00  |z...}.|.j.......|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 64 03 64 04  |............d.d.|
00000190  9c 02 7c 03 a5 01 7d 03  64 05 7c 03 76 01 72 25  |..|...}.d.|.v.r%|
000001a0  74 05 00 00 00 00 00 00  00 00 74 06 00 00 00 00  |t.........t.....|
000001b0  00 00 00 00 6a 08 00 00  00 00 00 00 00 00 00 00  |....j...........|
000001c0  00 00 00 00 00 00 00 00  ab 01 00 00 00 00 00 00  |................|
000001d0  7d 04 64 06 7c 04 76 00  72 03 7c 04 64 06 3d 00  |}.d.|.v.r.|.d.=.|
000001e0  7c 04 7c 03 64 05 3c 00  00 00 74 0b 00 00 00 00  ||.|.d.<...t.....|
000001f0  00 00 00 00 6a 0c 00 00  00 00 00 00 00 00 00 00  |....j...........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/environment.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/fixtures.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 15K 2025-06-01 01:30:14.115978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/fixtures.cpython-312.pyc
605ee8176a2a60ac2e19aca413b565887b85113c7d8ef4a9d81321b8cd61e705  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/fixtures.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 b9 2d 00 00  |..........8h.-..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 06 00 00  |................|
00000020  00 00 00 00 00 f3 72 02  00 00 97 00 64 00 64 01  |......r.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 5a 06 64 00 64 02  6c 07 6d 08 5a 08 01 00  |l.Z.d.d.l.m.Z...|
00000070  64 00 64 01 6c 09 5a 0a  64 00 64 01 6c 0b 5a 0b  |d.d.l.Z.d.d.l.Z.|
00000080  64 00 64 01 6c 0c 5a 0c  64 00 64 03 6c 0d 6d 0e  |d.d.l.Z.d.d.l.m.|
00000090  5a 0e 01 00 64 04 64 05  6c 0f 6d 10 5a 10 6d 11  |Z...d.d.l.m.Z.m.|
000000a0  5a 11 01 00 64 04 64 06  6c 12 6d 13 5a 13 01 00  |Z...d.d.l.m.Z...|
000000b0  65 0c 6a 28 00 00 00 00  00 00 00 00 00 00 00 00  |e.j(............|
000000c0  00 00 00 00 00 00 64 07  84 00 ab 00 00 00 00 00  |......d.........|
000000d0  00 00 5a 15 65 0c 6a 28  00 00 00 00 00 00 00 00  |..Z.e.j(........|
000000e0  00 00 00 00 00 00 00 00  00 00 64 08 84 00 ab 00  |..........d.....|
000000f0  00 00 00 00 00 00 5a 16  02 00 65 0c 6a 28 00 00  |......Z...e.j(..|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000110  64 09 64 0a ac 0b ab 02  00 00 00 00 00 00 64 0c  |d.d...........d.|
00000120  84 00 ab 00 00 00 00 00  00 00 5a 17 65 0c 6a 28  |..........Z.e.j(|
00000130  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000140  00 00 64 0d 84 00 ab 00  00 00 00 00 00 00 5a 18  |..d...........Z.|
00000150  65 0c 6a 28 00 00 00 00  00 00 00 00 00 00 00 00  |e.j(............|
00000160  00 00 00 00 00 00 64 0e  84 00 ab 00 00 00 00 00  |......d.........|
00000170  00 00 5a 19 64 0f 84 00  5a 1a 02 00 65 0c 6a 28  |..Z.d...Z...e.j(|
00000180  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000190  00 00 64 0a ac 10 ab 01  00 00 00 00 00 00 64 11  |..d...........d.|
000001a0  84 00 ab 00 00 00 00 00  00 00 5a 1b 02 00 65 0c  |..........Z...e.|
000001b0  6a 28 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j(..............|
000001c0  00 00 00 00 64 0a ac 10  ab 01 00 00 00 00 00 00  |....d...........|
000001d0  64 12 84 00 ab 00 00 00  00 00 00 00 5a 1c 65 0c  |d...........Z.e.|
000001e0  6a 28 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j(..............|
000001f0  00 00 00 00 64 13 84 00  ab 00 00 00 00 00 00 00  |....d...........|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/fixtures.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/mod_with_constant.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 255 2025-06-01 01:30:14.263978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/mod_with_constant.cpython-312.pyc
1d9eb0033b23ef5191ae0cf0bc2ce6a1edb9117210ed68f290727de188dd356f  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/mod_with_constant.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 16 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 08 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  79 01 29 02 7a 0b 74 68  72 65 65 2c 20 73 69 72  |y.).z.three, sir|
00000040  21 4e 29 01 da 05 76 61  6c 75 65 a9 00 f3 00 00  |!N)...value.....|
00000050  00 00 fa 84 2f 64 61 74  61 2f 64 61 74 61 2f 63  |..../data/data/c|
00000060  6f 6d 2e 74 65 72 6d 75  78 2f 66 69 6c 65 73 2f  |om.termux/files/|
00000070  68 6f 6d 65 2f 52 41 46  41 45 4c 49 41 2f 48 43  |home/RAFAELIA/HC|
00000080  50 4d 2f 43 4f 52 45 2f  76 65 6e 76 5f 72 61 66  |PM/CORE/venv_raf|
00000090  61 65 6c 69 61 2f 6c 69  62 2f 70 79 74 68 6f 6e  |aelia/lib/python|
000000a0  33 2e 31 32 2f 73 69 74  65 2d 70 61 63 6b 61 67  |3.12/site-packag|
000000b0  65 73 2f 73 65 74 75 70  74 6f 6f 6c 73 2f 74 65  |es/setuptools/te|
000000c0  73 74 73 2f 6d 6f 64 5f  77 69 74 68 5f 63 6f 6e  |sts/mod_with_con|
000000d0  73 74 61 6e 74 2e 70 79  da 08 3c 6d 6f 64 75 6c  |stant.py..<modul|
000000e0  65 3e 72 06 00 00 00 01  00 00 00 73 0a 00 00 00  |e>r........s....|
000000f0  f0 03 01 01 01 d8 08 15  81 05 72 04 00 00 00     |..........r....|
000000ff
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/mod_with_constant.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/namespaces.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.2K 2025-06-01 01:30:14.419978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/namespaces.cpython-312.pyc
73527a94aa28ed1d47c9d0e5687c2928e73e25eba0fdecac7f5698170e640974  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/namespaces.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 d6 0a 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 02 00 00  |................|
00000020  00 00 00 00 00 f3 42 00  00 00 97 00 64 00 64 01  |......B.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 02  6c 03 6d 04 5a 04 01 00  |l.Z.d.d.l.m.Z...|
00000050  64 03 84 00 5a 05 64 07  64 04 84 01 5a 06 64 05  |d...Z.d.d...Z.d.|
00000060  84 00 5a 07 64 06 84 00  5a 08 79 01 29 08 e9 00  |..Z.d...Z.y.)...|
00000070  00 00 00 4e 29 01 da 04  50 61 74 68 63 01 00 00  |...N)...Pathc...|
00000080  00 00 00 00 00 00 00 00  00 07 00 00 00 23 00 00  |.............#..|
00000090  00 f3 92 00 00 00 4b 00  01 00 97 00 7c 00 6a 01  |......K.....|.j.|
000000a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000000b0  00 00 64 01 ab 01 00 00  00 00 00 00 7d 01 74 03  |..d.........}.t.|
000000c0  00 00 00 00 00 00 00 00  74 05 00 00 00 00 00 00  |........t.......|
000000d0  00 00 7c 01 ab 01 00 00  00 00 00 00 ab 01 00 00  |..|.............|
000000e0  00 00 00 00 44 00 5d 1b  00 00 7d 02 64 01 6a 07  |....D.]...}.d.j.|
000000f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000100  00 00 7c 01 64 00 7c 02  64 02 7a 00 00 00 1a 00  |..|.d.|.d.z.....|
00000110  ab 01 00 00 00 00 00 00  96 01 97 01 01 00 8c 1d  |................|
00000120  04 00 79 00 ad 03 77 01  29 03 4e da 01 2e e9 01  |..y...w.).N.....|
00000130  00 00 00 29 04 da 05 73  70 6c 69 74 da 05 72 61  |...)...split..ra|
00000140  6e 67 65 da 03 6c 65 6e  da 04 6a 6f 69 6e 29 03  |nge..len..join).|
00000150  da 09 6e 61 6d 65 73 70  61 63 65 da 05 70 61 72  |..namespace..par|
00000160  74 73 da 01 69 73 03 00  00 00 20 20 20 fa 7d 2f  |ts..is....   .}/|
00000170  64 61 74 61 2f 64 61 74  61 2f 63 6f 6d 2e 74 65  |data/data/com.te|
00000180  72 6d 75 78 2f 66 69 6c  65 73 2f 68 6f 6d 65 2f  |rmux/files/home/|
00000190  52 41 46 41 45 4c 49 41  2f 48 43 50 4d 2f 43 4f  |RAFAELIA/HCPM/CO|
000001a0  52 45 2f 76 65 6e 76 5f  72 61 66 61 65 6c 69 61  |RE/venv_rafaelia|
000001b0  2f 6c 69 62 2f 70 79 74  68 6f 6e 33 2e 31 32 2f  |/lib/python3.12/|
000001c0  73 69 74 65 2d 70 61 63  6b 61 67 65 73 2f 73 65  |site-packages/se|
000001d0  74 75 70 74 6f 6f 6c 73  2f 74 65 73 74 73 2f 6e  |tuptools/tests/n|
000001e0  61 6d 65 73 70 61 63 65  73 2e 70 79 da 13 69 74  |amespaces.py..it|
000001f0  65 72 5f 6e 61 6d 65 73  70 61 63 65 5f 70 6b 67  |er_namespace_pkg|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/namespaces.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/script-with-bom.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 249 2025-06-01 01:30:14.575978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/script-with-bom.cpython-312.pyc
5994ba00cdd5d3ae1ff5a4618b73cd6a273d24b788657e4db923d98a1315d15d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/script-with-bom.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 12 00 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 01 00 00  |................|
00000020  00 00 00 00 00 f3 08 00  00 00 97 00 64 00 5a 00  |............d.Z.|
00000030  79 01 29 02 da 06 70 61  73 73 65 64 4e 29 01 da  |y.)...passedN)..|
00000040  06 72 65 73 75 6c 74 a9  00 f3 00 00 00 00 fa 82  |.result.........|
00000050  2f 64 61 74 61 2f 64 61  74 61 2f 63 6f 6d 2e 74  |/data/data/com.t|
00000060  65 72 6d 75 78 2f 66 69  6c 65 73 2f 68 6f 6d 65  |ermux/files/home|
00000070  2f 52 41 46 41 45 4c 49  41 2f 48 43 50 4d 2f 43  |/RAFAELIA/HCPM/C|
00000080  4f 52 45 2f 76 65 6e 76  5f 72 61 66 61 65 6c 69  |ORE/venv_rafaeli|
00000090  61 2f 6c 69 62 2f 70 79  74 68 6f 6e 33 2e 31 32  |a/lib/python3.12|
000000a0  2f 73 69 74 65 2d 70 61  63 6b 61 67 65 73 2f 73  |/site-packages/s|
000000b0  65 74 75 70 74 6f 6f 6c  73 2f 74 65 73 74 73 2f  |etuptools/tests/|
000000c0  73 63 72 69 70 74 2d 77  69 74 68 2d 62 6f 6d 2e  |script-with-bom.|
000000d0  70 79 da 08 3c 6d 6f 64  75 6c 65 3e 72 07 00 00  |py..<module>r...|
000000e0  00 01 00 00 00 73 0a 00  00 00 f0 03 01 01 01 d8  |.....s..........|
000000f0  09 11 81 06 72 05 00 00  00                       |....r....|
000000f9
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/script-with-bom.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_archive_util.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.9K 2025-06-01 01:30:14.735978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_archive_util.cpython-312.pyc
398eaf31344fc3243552e867f33521f9a572d93b72c8c54f9da8766cf5b062f2  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_archive_util.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 4d 03 00 00  |..........8hM...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 03 00 00  |................|
00000020  00 00 00 00 00 f3 90 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 02  6c 03 6d 04 5a 04 01 00  |l.Z.d.d.l.m.Z...|
00000050  65 02 6a 0a 00 00 00 00  00 00 00 00 00 00 00 00  |e.j.............|
00000060  00 00 00 00 00 00 64 03  84 00 ab 00 00 00 00 00  |......d.........|
00000070  00 00 5a 06 65 02 6a 0e  00 00 00 00 00 00 00 00  |..Z.e.j.........|
00000080  00 00 00 00 00 00 00 00  00 00 6a 11 00 00 00 00  |..........j.....|
00000090  00 00 00 00 00 00 00 00  00 00 00 00 00 00 64 04  |..............d.|
000000a0  ac 05 ab 01 00 00 00 00  00 00 64 06 84 00 ab 00  |..........d.....|
000000b0  00 00 00 00 00 00 5a 09  79 01 29 07 e9 00 00 00  |......Z.y.).....|
000000c0  00 4e 29 01 da 0c 61 72  63 68 69 76 65 5f 75 74  |.N)...archive_ut|
000000d0  69 6c 63 01 00 00 00 00  00 00 00 00 00 00 00 07  |ilc.............|
000000e0  00 00 00 03 00 00 00 f3  e6 01 00 00 97 00 74 01  |..............t.|
000000f0  00 00 00 00 00 00 00 00  6a 02 00 00 00 00 00 00  |........j.......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 ab 00 00 00  |................|
00000110  00 00 00 00 7d 01 74 05  00 00 00 00 00 00 00 00  |....}.t.........|
00000120  6a 06 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000130  00 00 00 00 7c 01 64 01  ac 02 ab 02 00 00 00 00  |....|.d.........|
00000140  00 00 35 00 7d 02 64 03  7d 03 64 04 7d 04 74 05  |..5.}.d.}.d.}.t.|
00000150  00 00 00 00 00 00 00 00  6a 08 00 00 00 00 00 00  |........j.......|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 7c 04 ab 01  |............|...|
00000170  00 00 00 00 00 00 7d 05  74 0b 00 00 00 00 00 00  |......}.t.......|
00000180  00 00 7c 03 ab 01 00 00  00 00 00 00 7c 05 5f 06  |..|.........|._.|
00000190  00 00 00 00 00 00 00 00  7c 02 6a 0f 00 00 00 00  |........|.j.....|
000001a0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 7c 05  |..............|.|
000001b0  74 01 00 00 00 00 00 00  00 00 6a 02 00 00 00 00  |t.........j.....|
000001c0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 7c 03  |..............|.|
000001d0  ab 01 00 00 00 00 00 00  ab 02 00 00 00 00 00 00  |................|
000001e0  01 00 64 05 64 05 64 05  ab 02 00 00 00 00 00 00  |..d.d.d.........|
000001f0  01 00 7c 00 64 06 7a 0b  00 00 7d 06 74 07 00 00  |..|.d.z...}.t...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_archive_util.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_config_discovery.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 30K 2025-06-01 01:30:16.215978095 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_config_discovery.cpython-312.pyc
57d3eea8a0a7c9b6cd6ba43f9a7c4497377cc27bda42aa315716c14337475764  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_config_discovery.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 34 58 00 00  |..........8h4X..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 6c 01  00 00 97 00 64 00 64 01  |......l.....d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 02  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 6d 03 5a 03 01 00  64 00 64 03 6c 04 6d 05  |l.m.Z...d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 01 6c 08 5a 09  64 00 64 01 6c 0a 5a 0a  |d.d.l.Z.d.d.l.Z.|
00000070  64 00 64 05 6c 0b 6d 0c  5a 0c 01 00 64 00 64 01  |d.d.l.m.Z...d.d.|
00000080  6c 0d 5a 0d 64 00 64 06  6c 0e 6d 0f 5a 0f 01 00  |l.Z.d.d.l.m.Z...|
00000090  64 00 64 07 6c 10 6d 11  5a 11 6d 12 5a 12 01 00  |d.d.l.m.Z.m.Z...|
000000a0  64 00 64 08 6c 13 6d 14  5a 14 01 00 64 00 64 09  |d.d.l.m.Z...d.d.|
000000b0  6c 15 6d 16 5a 16 01 00  64 0a 64 0b 6c 17 6d 18  |l.m.Z...d.d.l.m.|
000000c0  5a 18 01 00 64 0a 64 0c  6c 19 6d 1a 5a 1a 6d 1b  |Z...d.d.l.m.Z.m.|
000000d0  5a 1b 6d 1c 5a 1c 01 00  64 0a 64 0d 6c 1d 6d 1e  |Z.m.Z...d.d.l.m.|
000000e0  5a 1e 01 00 64 00 64 01  6c 1f 5a 20 02 00 47 00  |Z...d.d.l.Z ..G.|
000000f0  64 0e 84 00 64 0f ab 02  00 00 00 00 00 00 5a 21  |d...d.........Z!|
00000100  02 00 47 00 64 10 84 00  64 11 ab 02 00 00 00 00  |..G.d...d.......|
00000110  00 00 5a 22 02 00 47 00  64 12 84 00 64 13 ab 02  |..Z"..G.d...d...|
00000120  00 00 00 00 00 00 5a 23  02 00 47 00 64 14 84 00  |......Z#..G.d...|
00000130  64 15 ab 02 00 00 00 00  00 00 5a 24 02 00 47 00  |d.........Z$..G.|
00000140  64 16 84 00 64 17 ab 02  00 00 00 00 00 00 5a 25  |d...d.........Z%|
00000150  02 00 47 00 64 18 84 00  64 19 ab 02 00 00 00 00  |..G.d...d.......|
00000160  00 00 5a 26 64 1a 84 00  5a 27 64 1b 84 00 5a 28  |..Z&d...Z'd...Z(|
00000170  64 1c 84 00 5a 29 64 1d  84 00 5a 2a 64 1e 84 00  |d...Z)d...Z*d...|
00000180  5a 2b 64 1f 84 00 5a 2c  64 20 84 00 5a 2d 64 21  |Z+d...Z,d ..Z-d!|
00000190  84 00 5a 2e 79 01 29 22  e9 00 00 00 00 4e 29 01  |..Z.y.)".....N).|
000001a0  da 0c 43 6f 6e 66 69 67  50 61 72 73 65 72 29 01  |..ConfigParser).|
000001b0  da 07 70 72 6f 64 75 63  74 29 01 da 04 63 61 73  |..product)...cas|
000001c0  74 29 01 da 04 50 61 74  68 29 01 da 05 73 64 69  |t)...Path)...sdi|
000001d0  73 74 29 02 da 11 66 69  6e 64 5f 70 61 63 6b 61  |st)...find_packa|
000001e0  67 65 5f 70 61 74 68 da  13 66 69 6e 64 5f 70 61  |ge_path..find_pa|
000001f0  72 65 6e 74 5f 70 61 63  6b 61 67 65 29 01 da 0c  |rent_package)...|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_config_discovery.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_egg.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.1K 2025-06-01 01:30:15.043978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_egg.cpython-312.pyc
f2017eefc83a5a14ad74b9b86f40e41b3ba5e9e0eeb6b284e8513e7baf7b26f2  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_egg.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 a5 07 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 7c 00  00 00 97 00 64 00 5a 00  |......|.....d.Z.|
00000030  64 01 64 02 6c 01 5a 01  64 01 64 02 6c 02 5a 02  |d.d.l.Z.d.d.l.Z.|
00000040  64 01 64 02 6c 03 5a 03  64 01 64 02 6c 04 5a 04  |d.d.l.Z.d.d.l.Z.|
00000050  64 01 64 03 6c 05 6d 06  5a 06 01 00 64 04 64 05  |d.d.l.m.Z...d.d.|
00000060  6c 07 6d 08 5a 08 01 00  64 06 5a 09 65 04 6a 14  |l.m.Z...d.Z.e.j.|
00000070  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000080  00 00 64 07 84 00 ab 00  00 00 00 00 00 00 5a 0b  |..d...........Z.|
00000090  02 00 47 00 64 08 84 00  64 09 ab 02 00 00 00 00  |..G.d...d.......|
000000a0  00 00 5a 0c 79 02 29 0a  7a 0d 64 65 76 65 6c 6f  |..Z.y.).z.develo|
000000b0  70 20 74 65 73 74 73 e9  00 00 00 00 4e 29 01 da  |p tests.....N)..|
000000c0  0c 44 69 73 74 72 69 62  75 74 69 6f 6e e9 01 00  |.Distribution...|
000000d0  00 00 29 01 da 08 63 6f  6e 74 65 78 74 73 7a 37  |..)...contextsz7|
000000e0  66 72 6f 6d 20 73 65 74  75 70 74 6f 6f 6c 73 20  |from setuptools |
000000f0  69 6d 70 6f 72 74 20 73  65 74 75 70 0a 0a 73 65  |import setup..se|
00000100  74 75 70 28 70 79 5f 6d  6f 64 75 6c 65 73 3d 5b  |tup(py_modules=[|
00000110  27 68 69 27 5d 29 0a 63  01 00 00 00 00 00 00 00  |'hi']).c........|
00000120  00 00 00 00 06 00 00 00  23 00 00 00 f3 4e 01 00  |........#....N..|
00000130  00 4b 00 01 00 97 00 7c  00 64 01 7a 0b 00 00 6a  |.K.....|.d.z...j|
00000140  01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000150  00 00 00 64 02 ab 01 00  00 00 00 00 00 35 00 7d  |...d.........5.}|
00000160  01 7c 01 6a 03 00 00 00  00 00 00 00 00 00 00 00  |.|.j............|
00000170  00 00 00 00 00 00 00 74  04 00 00 00 00 00 00 00  |.......t........|
00000180  00 ab 01 00 00 00 00 00  00 01 00 64 00 64 00 64  |...........d.d.d|
00000190  00 ab 02 00 00 00 00 00  00 01 00 7c 00 64 03 7a  |...........|.d.z|
000001a0  0b 00 00 6a 01 00 00 00  00 00 00 00 00 00 00 00  |...j............|
000001b0  00 00 00 00 00 00 00 64  02 ab 01 00 00 00 00 00  |.......d........|
000001c0  00 35 00 7d 01 7c 01 6a  03 00 00 00 00 00 00 00  |.5.}.|.j........|
000001d0  00 00 00 00 00 00 00 00  00 00 00 64 04 ab 01 00  |...........d....|
000001e0  00 00 00 00 00 01 00 64  00 64 00 64 00 ab 02 00  |.......d.d.d....|
000001f0  00 00 00 00 00 01 00 7c  00 6a 07 00 00 00 00 00  |.......|.j......|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_egg.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_wheel.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 33K 2025-06-01 01:30:15.231978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_wheel.cpython-312.pyc
a5658828ed9934bf76bde2e93b606cec81a1ba2fc750ce8f00d22953040f2cb3  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_wheel.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 2b 5a 00 00  |..........8h+Z..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0c 00 00  |................|
00000020  00 00 00 00 01 f3 38 05  00 00 97 00 64 00 64 01  |......8.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 02 6c 04 5a 05  |d.d.l.Z.d.d.l.Z.|
00000050  64 00 64 02 6c 06 5a 06  64 00 64 02 6c 07 5a 07  |d.d.l.Z.d.d.l.Z.|
00000060  64 00 64 02 6c 08 5a 08  64 00 64 02 6c 09 5a 09  |d.d.l.Z.d.d.l.Z.|
00000070  64 00 64 02 6c 0a 5a 0a  64 00 64 02 6c 0b 5a 0b  |d.d.l.Z.d.d.l.Z.|
00000080  64 00 64 03 6c 0c 6d 0d  5a 0d 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000090  6c 0e 6d 0f 5a 0f 01 00  64 00 64 05 6c 10 6d 11  |l.m.Z...d.d.l.m.|
000000a0  5a 11 01 00 64 00 64 02  6c 12 5a 13 64 00 64 02  |Z...d.d.l.Z.d.d.|
000000b0  6c 14 5a 14 64 00 64 06  6c 15 6d 16 5a 16 01 00  |l.Z.d.d.l.m.Z...|
000000c0  64 00 64 02 6c 17 5a 17  64 00 64 07 6c 18 6d 19  |d.d.l.Z.d.d.l.m.|
000000d0  5a 19 6d 1a 5a 1a 01 00  64 00 64 08 6c 1b 6d 1c  |Z.m.Z...d.d.l.m.|
000000e0  5a 1c 01 00 64 00 64 09  6c 1d 6d 1e 5a 1e 01 00  |Z...d.d.l.m.Z...|
000000f0  64 00 64 0a 6c 1f 6d 20  5a 20 01 00 68 00 64 0b  |d.d.l.m Z ..h.d.|
00000100  a3 01 5a 21 68 00 64 0c  a3 01 5a 22 64 0d 64 0e  |..Z!h.d...Z"d.d.|
00000110  68 02 5a 23 64 0f 5a 24  65 24 64 10 64 11 69 01  |h.Z#d.Z$e$d.d.i.|
00000120  64 12 9c 02 65 25 6a 4d  00 00 00 00 00 00 00 00  |d...e%jM........|
00000130  00 00 00 00 00 00 00 00  00 00 65 22 65 23 7a 07  |..........e"e#z.|
00000140  00 00 64 11 ab 02 00 00  00 00 00 00 a5 01 02 00  |..d.............|
00000150  65 0f 64 13 ab 01 00 00  00 00 00 00 64 11 64 14  |e.d.........d.d.|
00000160  9c 02 02 00 65 0f 64 15  ab 01 00 00 00 00 00 00  |....e.d.........|
00000170  64 16 64 17 69 01 64 18  9c 02 02 00 65 0f 64 19  |d.d.i.d.....e.d.|
00000180  ab 01 00 00 00 00 00 00  64 11 64 11 64 1a 9c 03  |........d.d.d...|
00000190  02 00 65 0f 64 1b ab 01  00 00 00 00 00 00 64 11  |..e.d.........d.|
000001a0  64 11 64 11 64 1c 9c 02  64 1d 9c 02 64 1e 64 16  |d.d.d...d...d.d.|
000001b0  64 11 69 01 69 01 64 1f  9c 03 02 00 65 0f 64 20  |d.i.i.d.....e.d |
000001c0  ab 01 00 00 00 00 00 00  64 11 64 11 64 21 9c 02  |........d.d.d!..|
000001d0  64 22 9c 02 02 00 65 0f  64 23 ab 01 00 00 00 00  |d"....e.d#......|
000001e0  00 00 64 24 64 25 9c 02  02 00 65 0f 64 26 ab 01  |..d$d%....e.d&..|
000001f0  00 00 00 00 00 00 64 11  64 27 64 28 64 11 69 01  |......d.d'd(d.i.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_bdist_wheel.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 1.6K 2025-06-01 01:30:15.391978096 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build.cpython-312.pyc
a270ae27f719bbb1f880528c6c6358a2e6bdb650ee2d3e16de54d4faadeb343a  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 1e 03 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 05 00 00  |................|
00000020  00 00 00 00 00 f3 44 00  00 00 97 00 64 00 64 01  |......D.....d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 6d 03  |l.m.Z...d.d.l.m.|
00000040  5a 03 01 00 64 00 64 03  6c 04 6d 05 5a 05 01 00  |Z...d.d.l.m.Z...|
00000050  64 04 84 00 5a 06 02 00  47 00 64 05 84 00 64 06  |d...Z...G.d...d.|
00000060  65 01 ab 03 00 00 00 00  00 00 5a 07 79 07 29 08  |e.........Z.y.).|
00000070  e9 00 00 00 00 29 01 da  07 43 6f 6d 6d 61 6e 64  |.....)...Command|
00000080  29 01 da 05 62 75 69 6c  64 29 01 da 0c 44 69 73  |)...build)...Dis|
00000090  74 72 69 62 75 74 69 6f  6e 63 01 00 00 00 00 00  |tributionc......|
000000a0  00 00 00 00 00 00 09 00  00 00 03 00 00 00 f3 7e  |...............~|
000000b0  00 00 00 97 00 74 01 00  00 00 00 00 00 00 00 74  |.....t.........t|
000000c0  03 00 00 00 00 00 00 00  00 64 01 64 02 67 01 67  |.........d.d.g.g|
000000d0  00 64 03 64 04 67 01 69  01 ac 05 ab 04 00 00 00  |.d.d.g.i........|
000000e0  00 00 00 ab 01 00 00 00  00 00 00 7d 01 74 05 00  |...........}.t..|
000000f0  00 00 00 00 00 00 00 7c  01 6a 07 00 00 00 00 00  |.......|.j......|
00000100  00 00 00 00 00 00 00 00  00 00 00 00 00 64 02 ab  |.............d..|
00000110  01 00 00 00 00 00 00 74  08 00 00 00 00 00 00 00  |.......t........|
00000120  00 ab 02 00 00 00 00 00  00 73 02 4a 00 82 01 79  |.........s.J...y|
00000130  06 29 07 7a 5f 0a 20 20  20 20 43 68 65 63 6b 20  |.).z_.    Check |
00000140  74 68 61 74 20 74 68 65  20 73 65 74 75 70 74 6f  |that the setupto|
00000150  6f 6c 73 20 44 69 73 74  72 69 62 75 74 69 6f 6e  |ols Distribution|
00000160  20 75 73 65 73 20 74 68  65 0a 20 20 20 20 73 65  | uses the.    se|
00000170  74 75 70 74 6f 6f 6c 73  20 73 70 65 63 69 66 69  |tuptools specifi|
00000180  63 20 62 75 69 6c 64 20  6f 62 6a 65 63 74 2e 0a  |c build object..|
00000190  20 20 20 20 7a 08 73 65  74 75 70 2e 70 79 72 04  |    z.setup.pyr.|
000001a0  00 00 00 da 00 7a 06 70  61 74 68 2f 2a 29 04 da  |.....z.path/*)..|
000001b0  0b 73 63 72 69 70 74 5f  6e 61 6d 65 da 0b 73 63  |.script_name..sc|
000001c0  72 69 70 74 5f 61 72 67  73 da 08 70 61 63 6b 61  |ript_args..packa|
000001d0  67 65 73 da 0c 70 61 63  6b 61 67 65 5f 64 61 74  |ges..package_dat|
000001e0  61 4e 29 05 72 05 00 00  00 da 04 64 69 63 74 da  |aN).r......dict.|
000001f0  0a 69 73 69 6e 73 74 61  6e 63 65 da 0f 67 65 74  |.isinstance..get|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_clib.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 4.1K 2025-06-01 01:30:15.551978095 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_clib.cpython-312.pyc
a67b6c2db01d3550e033a0bd5ae645983ad1ad9b86e1461a8214afbcdeab1d7d  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_clib.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 33 0c 00 00  |..........8h3...|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 00 f3 58 00  00 00 97 00 64 00 64 01  |......X.....d.d.|
00000030  6c 00 5a 00 64 00 64 02  6c 01 6d 02 5a 02 01 00  |l.Z.d.d.l.m.Z...|
00000040  64 00 64 01 6c 03 5a 03  64 00 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 05 01 00 64 00 64 04  6c 06 6d 07 5a 07 01 00  |Z...d.d.l.m.Z...|
00000060  64 00 64 05 6c 08 6d 09  5a 09 01 00 02 00 47 00  |d.d.l.m.Z.....G.|
00000070  64 06 84 00 64 07 ab 02  00 00 00 00 00 00 5a 0a  |d...d.........Z.|
00000080  79 01 29 08 e9 00 00 00  00 4e 29 01 da 04 6d 6f  |y.)......N)...mo|
00000090  63 6b 29 01 da 0a 62 75  69 6c 64 5f 63 6c 69 62  |ck)...build_clib|
000000a0  29 01 da 0c 44 69 73 74  72 69 62 75 74 69 6f 6e  |)...Distribution|
000000b0  29 01 da 13 44 69 73 74  75 74 69 6c 73 53 65 74  |)...DistutilsSet|
000000c0  75 70 45 72 72 6f 72 63  00 00 00 00 00 00 00 00  |upErrorc........|
000000d0  00 00 00 00 03 00 00 00  00 00 00 00 f3 6c 00 00  |.............l..|
000000e0  00 97 00 65 00 5a 01 64  00 5a 02 02 00 65 03 6a  |...e.Z.d.Z...e.j|
000000f0  08 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000100  00 00 00 64 01 ab 01 00  00 00 00 00 00 64 02 84  |...d.........d..|
00000110  00 ab 00 00 00 00 00 00  00 5a 05 02 00 65 03 6a  |.........Z...e.j|
00000120  08 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000130  00 00 00 64 01 ab 01 00  00 00 00 00 00 64 03 84  |...d.........d..|
00000140  00 ab 00 00 00 00 00 00  00 5a 06 79 04 29 05 da  |.........Z.y.)..|
00000150  0d 54 65 73 74 42 75 69  6c 64 43 4c 69 62 7a 32  |.TestBuildCLibz2|
00000160  73 65 74 75 70 74 6f 6f  6c 73 2e 63 6f 6d 6d 61  |setuptools.comma|
00000170  6e 64 2e 62 75 69 6c 64  5f 63 6c 69 62 2e 6e 65  |nd.build_clib.ne|
00000180  77 65 72 5f 70 61 69 72  77 69 73 65 5f 67 72 6f  |wer_pairwise_gro|
00000190  75 70 63 02 00 00 00 00  00 00 00 00 00 00 00 06  |upc.............|
000001a0  00 00 00 03 00 00 00 f3  d2 04 00 00 97 00 74 01  |..............t.|
000001b0  00 00 00 00 00 00 00 00  ab 00 00 00 00 00 00 00  |................|
000001c0  7d 02 74 03 00 00 00 00  00 00 00 00 7c 02 ab 01  |}.t.........|...|
000001d0  00 00 00 00 00 00 7d 03  64 01 64 02 64 03 69 01  |......}.d.d.d.i.|
000001e0  66 02 67 01 7d 04 74 05  00 00 00 00 00 00 00 00  |f.g.}.t.........|
000001f0  6a 06 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |j...............|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_clib.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_ext.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 14K 2025-06-01 01:30:15.715978095 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_ext.cpython-312.pyc
6aa8818b783aea62a5b180e7510fe71ec64c233b73948ae4d281171a0e789f35  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_ext.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 73 27 00 00  |..........8hs'..|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 04 00 00  |................|
00000020  00 00 00 00 01 f3 f4 00  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 6d 01 5a 01 01 00  64 00 64 02 6c 02 5a 02  |l.m.Z...d.d.l.Z.|
00000040  64 00 64 02 6c 03 5a 03  64 00 64 03 6c 04 6d 05  |d.d.l.Z.d.d.l.m.|
00000050  5a 06 01 00 64 00 64 02  6c 07 5a 07 64 00 64 04  |Z...d.d.l.Z.d.d.|
00000060  6c 08 6d 09 5a 09 01 00  64 00 64 05 6c 0a 6d 0b  |l.m.Z...d.d.l.m.|
00000070  5a 0b 6d 0c 5a 0c 01 00  64 00 64 06 6c 0d 6d 0e  |Z.m.Z...d.d.l.m.|
00000080  5a 0e 01 00 64 00 64 07  6c 0f 6d 10 5a 10 01 00  |Z...d.d.l.m.Z...|
00000090  64 00 64 08 6c 11 6d 12  5a 12 01 00 64 09 64 0a  |d.d.l.m.Z...d.d.|
000000a0  6c 13 6d 14 5a 14 01 00  64 09 64 0b 6c 15 6d 16  |l.m.Z...d.d.l.m.|
000000b0  5a 16 01 00 64 00 64 02  6c 17 6d 18 63 02 01 00  |Z...d.d.l.m.c...|
000000c0  6d 0b 5a 19 01 00 64 00  64 0c 6c 1a 6d 1b 5a 1b  |m.Z...d.d.l.m.Z.|
000000d0  01 00 64 0d 65 03 6a 38  00 00 00 00 00 00 00 00  |..d.e.j8........|
000000e0  00 00 00 00 00 00 00 00  00 00 76 00 5a 1d 02 00  |..........v.Z...|
000000f0  47 00 64 0e 84 00 64 0f  ab 02 00 00 00 00 00 00  |G.d...d.........|
00000100  5a 1e 02 00 47 00 64 10  84 00 64 11 ab 02 00 00  |Z...G.d...d.....|
00000110  00 00 00 00 5a 1f 64 12  84 00 5a 20 79 02 29 13  |....Z.d...Z y.).|
00000120  e9 00 00 00 00 29 01 da  0b 61 6e 6e 6f 74 61 74  |.....)...annotat|
00000130  69 6f 6e 73 4e 29 01 da  11 63 61 63 68 65 5f 66  |ionsN)...cache_f|
00000140  72 6f 6d 5f 73 6f 75 72  63 65 29 01 da 04 70 61  |rom_source)...pa|
00000150  74 68 29 02 da 09 62 75  69 6c 64 5f 65 78 74 da  |th)...build_ext.|
00000160  0f 67 65 74 5f 61 62 69  33 5f 73 75 66 66 69 78  |.get_abi3_suffix|
00000170  29 01 da 0c 44 69 73 74  72 69 62 75 74 69 6f 6e  |)...Distribution|
00000180  29 01 da 0c 43 6f 6d 70  69 6c 65 45 72 72 6f 72  |)...CompileError|
00000190  29 01 da 09 45 78 74 65  6e 73 69 6f 6e e9 01 00  |)...Extension...|
000001a0  00 00 29 01 da 0b 65 6e  76 69 72 6f 6e 6d 65 6e  |..)...environmen|
000001b0  74 29 01 da 04 44 41 4c  53 29 01 da 0e 67 65 74  |t)...DALS)...get|
000001c0  5f 63 6f 6e 66 69 67 5f  76 61 72 da 08 5f 5f 70  |_config_var..__p|
000001d0  79 70 79 5f 5f 63 00 00  00 00 00 00 00 00 00 00  |ypy__c..........|
000001e0  00 00 01 00 00 00 00 00  00 01 f3 30 00 00 00 97  |...........0....|
000001f0  00 65 00 5a 01 64 00 5a  02 64 01 84 00 5a 03 64  |.e.Z.d.Z.d...Z.d|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_ext.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_meta.cpython-312.pyc
-rwxrwxrwx. 1 u0_a292 u0_a292 43K 2025-06-01 01:30:15.879978095 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_meta.cpython-312.pyc
5107bac5687cd2040536cba046fb26e666c09e259c9005f191a5162691d22ce7  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_meta.cpython-312.pyc
MIME: application/x-bytecode.python
----- ARQUIVO BINÁRIO / NÃO-TEXTO - hexdump (primeiros 512 bytes) -----
00000000  cb 0d 0d 0a 00 00 00 00  dc 98 38 68 09 82 00 00  |..........8h....|
00000010  e3 00 00 00 00 00 00 00  00 00 00 00 00 0a 00 00  |................|
00000020  00 00 00 00 00 f3 d0 02  00 00 97 00 64 00 64 01  |............d.d.|
00000030  6c 00 5a 00 64 00 64 01  6c 01 5a 01 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000040  6c 02 5a 02 64 00 64 01  6c 03 5a 03 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000050  6c 04 5a 04 64 00 64 01  6c 05 5a 05 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000060  6c 06 5a 06 64 00 64 01  6c 07 5a 07 64 00 64 01  |l.Z.d.d.l.Z.d.d.|
00000070  6c 08 5a 08 64 00 64 02  6c 09 6d 0a 5a 0a 01 00  |l.Z.d.d.l.m.Z...|
00000080  64 00 64 03 6c 0b 6d 0c  5a 0c 01 00 64 00 64 04  |d.d.l.m.Z...d.d.|
00000090  6c 0d 6d 0e 5a 0e 6d 0f  5a 0f 01 00 64 00 64 05  |l.m.Z.m.Z...d.d.|
000000a0  6c 10 6d 11 5a 11 01 00  64 00 64 01 6c 12 5a 12  |l.m.Z...d.d.l.Z.|
000000b0  64 00 64 06 6c 13 6d 14  5a 14 01 00 64 00 64 07  |d.d.l.m.Z...d.d.|
000000c0  6c 15 6d 16 5a 16 01 00  64 00 64 08 6c 17 6d 18  |l.m.Z...d.d.l.m.|
000000d0  5a 18 01 00 64 09 64 0a  6c 19 6d 1a 5a 1a 01 00  |Z...d.d.l.m.Z...|
000000e0  64 0b 5a 1b 02 00 65 1c  02 00 65 02 6a 3a 00 00  |d.Z...e...e.j:..|
000000f0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000100  64 0c 64 0d ab 02 00 00  00 00 00 00 ab 01 00 00  |d.d.............|
00000110  00 00 00 00 5a 1e 64 0e  65 06 6a 3e 00 00 00 00  |....Z.d.e.j>....|
00000120  00 00 00 00 00 00 00 00  00 00 00 00 00 00 76 00  |..............v.|
00000130  5a 20 65 12 6a 42 00 00  00 00 00 00 00 00 00 00  |Z e.jB..........|
00000140  00 00 00 00 00 00 00 00  6a 45 00 00 00 00 00 00  |........jE......|
00000150  00 00 00 00 00 00 00 00  00 00 00 00 65 06 6a 46  |............e.jF|
00000160  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00000170  00 00 64 0f 6b 28 00 00  78 01 72 02 01 00 65 20  |..d.k(..x.r...e |
00000180  64 10 ac 11 ab 02 00 00  00 00 00 00 5a 24 02 00  |d...........Z$..|
00000190  47 00 64 12 84 00 64 13  ab 02 00 00 00 00 00 00  |G.d...d.........|
000001a0  5a 25 02 00 47 00 64 14  84 00 64 15 65 25 ab 03  |Z%..G.d...d.e%..|
000001b0  00 00 00 00 00 00 5a 26  02 00 47 00 64 16 84 00  |......Z&..G.d...|
000001c0  64 17 65 25 ab 03 00 00  00 00 00 00 5a 27 02 00  |d.e%........Z'..|
000001d0  65 1a 64 18 ab 01 00 00  00 00 00 00 02 00 65 1a  |e.d...........e.|
000001e0  64 19 ab 01 00 00 00 00  00 00 64 1a 9c 02 02 00  |d.........d.....|
000001f0  65 1a 64 1b ab 01 00 00  00 00 00 00 02 00 65 1a  |e.d...........e.|
00000200
----- FIM hexdump: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_meta.cpython-312.pyc -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/setuptools/tests/__pycache__/test_build_py.cpython-312.pyc