#!/usr/bin/env python3
# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.

__title__ = "packaging"
__summary__ = "Core utilities for Python packages"
__uri__ = "https://github.com/pypa/packaging"

__version__ = "25.0"

__author__ = "Donald Stufft and individual contributors"
__email__ = "donald@stufft.io"

__license__ = "BSD-2-Clause or Apache-2.0"
__copyright__ = f"2014 {__author__}"

----- FIM DO CONTEÚDO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/__init__.py -----

========================================
ARQUIVO: /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/markers.py
-rwxrwxrwx. 1 u0_a292 u0_a292 12K 2025-06-02 22:55:13.514164468 -0300 /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/markers.py
a5f96a0692b4226d4519fceb4c2cf73a5967b5af7280db3c6a695c7071d38e77  /data/data/com.termux/files/home/RAFAELIA/HCPM/CORE/venv_rafaelia/lib/python3.12/site-packages/pip/_vendor/packaging/markers.py
MIME: text/x-script.python
----- INÍCIO DO CONTEÚDO (extensão: .py) -----