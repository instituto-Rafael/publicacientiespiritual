
# -*- coding: utf-8 -*-
def r_real(moid_au, dtheta_deg, dmag,
           w1=0.8, w2=0.1, w3=0.1,
           moid_ref=0.05, dtheta_max=10.0, dmag_max=1.0):
    """Índice ∆§Risco ∈ [0,1]. Menor = mais seguro.
    - moid_au: distância mínima em UA (ou proxy/escala relativa)
    - dtheta_deg: desvio angular da cauda vs. anti-solar
    - dmag: variação fotométrica (surto/fragmentação)
    """
    orbital = (moid_ref / float(moid_au)) ** 2
    tail    = min(1.0, abs(float(dtheta_deg)) / dtheta_max)
    photo   = min(1.0, abs(float(dmag)) / dmag_max)
    return w1*orbital + w2*tail + w3*photo
