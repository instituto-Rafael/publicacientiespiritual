
# -*- coding: utf-8 -*-
"""
Extrai recursivamente XAPK/ZIP e lista APKs internos.
Sem dependências externas (usa zipfile).
"""
from pathlib import Path
import zipfile, shutil

def extract_recursive(archive_path, out_dir):
    ap = Path(archive_path)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    stack = [(ap, out)]
    extracted_apks = []
    while stack:
        src, dst = stack.pop()
        if zipfile.is_zipfile(src):
            with zipfile.ZipFile(src, 'r') as z:
                inner_dir = dst / (src.stem + "_unz")
                inner_dir.mkdir(exist_ok=True)
                z.extractall(inner_dir)
                for info in z.infolist():
                    p = inner_dir / info.filename
                    if p.is_file():
                        low = p.name.lower()
                        if low.endswith((".zip",".xapk",".apk",".apks",".obb")):
                            stack.append((p, inner_dir))
                        if low.endswith(".apk"):
                            extracted_apks.append(p)
    return extracted_apks

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("archive", help="Arquivo .xapk/.zip")
    ap.add_argument("--out", default="data/apks", help="Pasta de saída")
    args = ap.parse_args()
    apks = extract_recursive(args.archive, args.out)
    print("APKs encontrados:", len(apks))
    for a in apks: print(a)
