
# -*- coding: utf-8 -*-
"""
Configurações comuns para as duas frentes (A: Astronomia, B: APK/XAPK).
Edite conforme sua máquina local.
"""
from pathlib import Path

# Diretórios
DATA_DIR   = Path("./data")          # onde baixar/armazenar dados
FITS_DIR   = DATA_DIR / "fits"       # imagens astronômicas
TLE_DIR    = DATA_DIR / "tle"        # TLEs de satélites, se usar debris masking
APK_DIR    = DATA_DIR / "apks"       # apks extraídos
OUT_DIR    = Path("./out")           # relatórios

# Fontes públicas sugeridas (acesse com requests/aria2/wget na sua máquina)
NEOCC_SEARCH = "https://neo.ssa.esa.int/image-database"   # portal humano (faça seleção e download)
ESO_ARCHIVE  = "https://archive.eso.org/"
MAST_PORTAL  = "https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html"

# Arquivo de pesos/limiares para risco
RISK_CFG = {
    "weights": {"w1_orbital": 0.8, "w2_tail": 0.1, "w3_photometry": 0.1},
    "thresholds": {
        "moid_ref_au": 0.05,
        "dtheta_max_deg": 10.0,
        "dm_max_mag": 1.0,
        "promote_dtheta_deg": 3.0,
        "promote_dm_mag": 0.3
    }
}
