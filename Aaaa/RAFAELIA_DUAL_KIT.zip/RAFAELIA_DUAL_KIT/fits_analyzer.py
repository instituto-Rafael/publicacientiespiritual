
# -*- coding: utf-8 -*-
"""
Analisador de FITS (esqueleto): lê imagens, pré-processa, mede Δθ/Δm e aplica ∆§Risco.
Requer: astropy, numpy, scipy, scikit-image, matplotlib (opcional)
Instale localmente: pip install astropy numpy scipy scikit-image matplotlib
"""
import os, math, json
from pathlib import Path
import numpy as np

try:
    from astropy.io import fits
except Exception as e:
    fits = None

from risk_calc import r_real

def load_fits(path):
    if fits is None:
        raise RuntimeError("astropy não disponível. Instale localmente: pip install astropy")
    with fits.open(path) as hdul:
        data = hdul[0].data.astype(np.float32)
        hdr  = hdul[0].header
    return data, hdr

def preprocess(img):
    # Remoção de NaN e normalização simples
    x = np.nan_to_num(img, nan=0.0, posinf=0.0, neginf=0.0)
    x = x - np.median(x)
    mad = np.median(np.abs(x))
    x = x / (mad + 1e-6)
    x = np.clip(x, -10, 10)
    return x

def estimate_tail_angle(img):
    # Placeholder: usa gradiente global para estimar orientação dominante (proxy de cauda)
    gy, gx = np.gradient(img)
    angles = np.degrees(np.arctan2(gy, gx)).flatten()
    # Moda aproximada
    hist, edges = np.histogram(angles, bins=180, range=(-180,180))
    ang = float((edges[np.argmax(hist)] + edges[np.argmax(hist)+1]) / 2.0)
    return ang

def estimate_dmag(seq):
    # seq = lista de fluxos integrados (já corrigidos por seeing/airmass se possível)
    if not seq: return 0.0
    return float(np.max(seq) - np.min(seq))

def analyze_folder(fits_dir, out_csv):
    from csv import DictWriter
    fits_dir = Path(fits_dir)
    rows = []
    files = sorted([p for p in fits_dir.glob("*.fits")])
    # referência tosca de ângulo anti-solar (placeholder)
    anti_solar_ref = 0.0
    for f in files:
        try:
            img, hdr = load_fits(f)
            x = preprocess(img)
            theta = estimate_tail_angle(x)
            dtheta = float(theta - anti_solar_ref)
            # sem série temporal real, usamos dmag=0 como baseline
            dmag = 0.0
            moid = 1.8  # proxy (ajuste depois com efemérides reais)
            R = r_real(moid, dtheta, dmag)
            rows.append({"file": f.name, "theta_deg": theta, "DeltaTheta_deg": dtheta, "DeltaMag": dmag, "MOID_AU": moid, "R_real": R})
        except Exception as e:
            rows.append({"file": f.name, "error": str(e)})
    # salvar csv
    with open(out_csv, "w", newline="", encoding="utf-8") as g:
        w = DictWriter(g, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return rows

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("fits_dir", help="Pasta com arquivos .fits")
    ap.add_argument("--out", default="out/fits_report.csv", help="CSV de saída")
    args = ap.parse_args()
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    analyze_folder(args.fits_dir, args.out)
    print("OK:", args.out)
