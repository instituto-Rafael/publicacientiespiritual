
# -*- coding: utf-8 -*-
"""
Hook para mascaramento de trilhas de satélites com base em TLE.
Requer: skyfield, numpy
pip install skyfield numpy
"""
from pathlib import Path
import numpy as np

def project_sat_trails(tle_path, exposure_start_utc, exposure_seconds, wcs=None):
    """
    Placeholder: retorne segmentos previstos no campo a partir de TLEs.
    Na prática: use skyfield para propagar e converter para RA/Dec, depois WCS->pixels.
    """
    trails = []  # [(x1,y1,x2,y2), ...]
    # Implementar na sua máquina (sem internet aqui)
    return np.array(trails, dtype=float)

def apply_mask(image, trails, thickness=2):
    img = image.copy()
    # Placeholder: desenha máscaras onde as trilhas passariam
    return img
