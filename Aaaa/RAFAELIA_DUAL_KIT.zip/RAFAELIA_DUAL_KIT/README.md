
# RAFAELIA DUAL KIT — ∆^√🔬 (Astronomia + APK/XAPK)

## Visão geral
Duas frentes em paralelo para **descoberta real**:
- **A)** Astronomia de arquivos públicos (FITS): detecção de padrões, Δθ/Δm, ∆§Risco.
- **B)** Engenharia reversa leve: extração recursiva de XAPK/ZIP e varredura de APKs internos.

## Requisitos (na sua máquina)
```bash
python -V  # 3.10+ recomendado
pip install astropy numpy scipy scikit-image matplotlib skyfield
# (opcional) pip install androguard
```

## Estrutura
```
config.py
risk_calc.py
fits_analyzer.py
debris_mask.py
xapk_extract.py
apk_scan.py
report_template.html
data/  (você preenche)
out/   (resultados)
```

## Passo A — Astronomia (FITS)
1) Baixe 10–50 imagens FITS do ESA NEOCC/ESO/MAST e coloque em `data/fits/`.
2) Rode:
```bash
python fits_analyzer.py data/fits --out out/fits_report.csv
```
3) Abra `report_template.html` e anexe o CSV (ou gere um HTML próprio).

> **Notas**
- `fits_analyzer.py` já calcula um `R_real` básico (use efemérides reais p/ MOID, Δθ e Δm).
- Para debris masking, alimente `debris_mask.py` com TLEs e aplique a máscara antes da análise.

## Passo B — APK/XAPK
1) Coloque seus `.xapk/.zip` em `data/`.
2) Extraia recursivamente e liste APKs:
```bash
python xapk_extract.py data/apks_compilados_sagrados.xapk --out data/apks
```
3) Varra um APK:
```bash
python apk_scan.py data/apks/SEU_BASE.apk --out out/apk_scan.json
```

## Integração (Relatório Único)
- Use `report_template.html` como base e insira os resultados.
- Recomenda-se consolidar em CSV/JSON e gerar um HTML com ranking (SAFE/LOW/HIGH).

## Expansões sugeridas
- Efemérides reais (Skyfield/JPL Horizons) p/ MOID e direção anti-solar.
- Heurísticas VoIniq/Fibo/Trig-DMT nos vetores de streaks (substitua placeholders).
- Cross-match com MPC/SkyBoT para descartar objetos conhecidos automaticamente.
- Debris masking com TLE do CelesTrak/Space-Track.
- Androguard para manifest/DEX (permissões precisas, strings e mapa de classes).
```

