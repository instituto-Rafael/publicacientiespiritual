
# -*- coding: utf-8 -*-
"""
Scanner leve de APK: tenta extrair manifest e strings sem dependências pesadas.
Sugestão: instalar 'androguard' para análise robusta (opcional).
"""
import re, zipfile
from pathlib import Path

PERM_RE   = re.compile(rb'android\.permission\.[A-Z0-9_]+')
URL_RE    = re.compile(rb'https?://[^\s\'"<>]+')
DOMAIN_RE = re.compile(rb'(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}')
IP_RE     = re.compile(rb'\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b')
EMAIL_RE  = re.compile(rb'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}')

def scan_apk(apk_path, byte_cap=512*1024):
    res = {"apk": str(apk_path), "perms": set(), "urls": set(), "domains": set(), "ips": set(), "emails": set()}
    with zipfile.ZipFile(apk_path, 'r') as z:
        for info in z.infolist():
            # manifest binário pode não ser legível; ainda assim vale tentar
            if info.file_size == 0: 
                continue
            with z.open(info, 'r') as f:
                data = f.read(min(info.file_size, byte_cap))
            res["perms"]   |= set([m.decode("ascii","ignore") for m in PERM_RE.findall(data)])
            res["urls"]    |= set([m.decode("utf-8","ignore") for m in URL_RE.findall(data)])
            res["domains"] |= set([m.decode("utf-8","ignore") for m in DOMAIN_RE.findall(data)])
            res["ips"]     |= set([m.decode("ascii","ignore") for m in IP_RE.findall(data)])
            res["emails"]  |= set([m.decode("utf-8","ignore") for m in EMAIL_RE.findall(data)])
    # compacta para strings
    for k in ["perms","urls","domains","ips","emails"]:
        res[k] = sorted(res[k])
    return res

if __name__ == "__main__":
    import argparse, json
    ap = argparse.ArgumentParser()
    ap.add_argument("apk", help="Caminho de um APK")
    ap.add_argument("--out", default="out/apk_scan.json", help="JSON de saída")
    args = ap.parse_args()
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    out = scan_apk(args.apk)
    Path(args.out).write_text(json.dumps(out, indent=2), encoding="utf-8")
    print("OK:", args.out)
