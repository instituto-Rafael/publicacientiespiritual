import hashlib, sys
from pathlib import Path
def sha256(p): 
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda:f.read(1<<20),b''): h.update(c)
    return h.hexdigest()
for folder in ['CODE','DATA/RAW','DATA/PROC','DOCS']:
    for p in Path(folder).rglob('*'):
        if p.is_file(): print(p, sha256(p))
