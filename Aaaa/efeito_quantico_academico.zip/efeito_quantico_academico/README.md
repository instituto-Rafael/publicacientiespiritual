# Efeito Quântico em Circuitos Elétricos — Protocolo Acadêmico

Este repositório contém dados, código e manuscrito LaTeX para evidenciar regime quântico (MQT e quantização de níveis) em circuitos supercondutores.

## Como reproduzir
```bash
conda env update -f ENV/environment.yml
make all
```
