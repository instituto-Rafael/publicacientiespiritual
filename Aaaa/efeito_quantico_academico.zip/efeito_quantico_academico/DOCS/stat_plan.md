# Statistical Analysis Plan

Detalhes de ajustes TA vs MQT, testes Bayesianos e critérios.