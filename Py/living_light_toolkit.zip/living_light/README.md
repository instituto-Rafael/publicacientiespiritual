
# Living‑Light Toolkit

Author: Rafael Melo Reis  
DOI: 10.5281/zenodo.17188138  

## Contents
* **pipeline.py** – vector pipeline (metrics ΔS/JS/cosθ/Ω + physical flags)
* **retro_feed.py** – infinite fractal feedback loop demo using RafBit logic.

## Quick start
```bash
python -m pip install numpy scipy
python living_light/retro_feed.py
```
