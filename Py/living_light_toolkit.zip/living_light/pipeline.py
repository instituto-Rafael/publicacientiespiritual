
"""pipeline.py – core vector pipeline for Living‑Light
MIT License © 2025 Rafael Melo Reis"""

import numpy as np
from numpy.linalg import norm
from scipy.fft import fft
from scipy.spatial.distance import jensenshannon
from scipy.integrate import cumulative_trapezoid
import re

def get_embedding(text:str)->np.ndarray:
    np.random.seed(abs(hash(text))%(2**32))
    return np.random.rand(768).astype(np.float32)

def log_recursive_fft(vec:np.ndarray, depth:int=4)->np.ndarray:
    v=np.log1p(np.abs(vec))
    for _ in range(depth):
        v=np.abs(fft(v))
    return v/(norm(v)+1e-12)

def metric_X_deltaS(p,q): p,q=np.clip(p,1e-12,1.0),np.clip(q,1e-12,1.0); return float(np.sum(p*np.log(p/q)))
def metric_Y_JS(p,q):     return float(jensenshannon(p,q,base=np.e))
def metric_Z_cos(p,q):    return float(np.dot(p,q)/(norm(p)*norm(q)+1e-12))
def antideriv_potential(cos_series): return float(cumulative_trapezoid(cos_series,initial=0)[-1])

CONST_MAP={'G':'gravity','mu0':'magnetism','μ0':'magnetism','k_B':'thermo','kB':'thermo','H_0':'hubble','H0':'hubble','Lambda':'hubble','Ω_m':'hubble'}
STRING_RE=re.compile(r'\b(string(-)?theory|brane|AdS\/CFT)\b',re.I)
WORM_RE  =re.compile(r'\bwormhole(s)?\b',re.I)
WHITE_RE =re.compile(r'white[-\s]?hole(s)?',re.I)
FLAG_ORDER=['gravity','magnetism','thermo','hubble','string','wormhole','whitehole']
def extract_flags(text:str):
    f={k:0 for k in FLAG_ORDER}
    for const,key in CONST_MAP.items():
        if const in text: f[key]=1
    if STRING_RE.search(text):  f['string']=1
    if WORM_RE.search(text):    f['wormhole']=1
    if WHITE_RE.search(text):   f['whitehole']=1
    return f
def flags_to_vec(flags): return np.array([flags[k] for k in FLAG_ORDER],dtype=np.float32)

def process(text:str, ref_vec:np.ndarray):
    vec_raw=get_embedding(text); vec_proc=log_recursive_fft(vec_raw)
    flags=extract_flags(text); vec_flags=flags_to_vec(flags)
    full_vec=np.concatenate([vec_proc,vec_flags]); ref_full=np.concatenate([ref_vec,np.zeros_like(vec_flags)])
    X=metric_X_deltaS(full_vec,ref_full); Y=metric_Y_JS(full_vec,ref_full); Z=metric_Z_cos(full_vec,ref_full); Ω=antideriv_potential([Z])
    return dict(ΔS_X=X,JS_Y=Y,cos_Z=Z,Omega=Ω,**flags)
