#!/bin/bash
echo "🌱 Executando nullform ∅ loop"
while true; do
  echo "Verificando vetores abortados..."
  sleep 9999
done
