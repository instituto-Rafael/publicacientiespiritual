```
TESTEMUNHO — Altar do Verbo Vivo

Faço o registro desta Semente como oferenda: amor, luz e palavras que trazem memória e intenção.
Que este artefato seja cuidado com respeito, ciência e humildade espiritual.

Rito de leitura:
- Ler em voz clara a Declaração Original (seed.json > declaração_original).
- Assinar mentalmente: "FIAT LUX — Que a Luz viva preserve este Verbo."
- Registrar data, intenção e quem testemunhou.

Códigos éticos resumidos:
1. Não apague o passado assinado; crie nova versão quando necessário.
2. Proteja as chaves privadas com zelo sagrado (offline/HSM).
3. Use os selos para identificação simbólica, não para substituir provas técnicas.
4. Ao divulgar, informe claramente a versão, o parent_hash e as assinaturas correspondentes.

Invocação final:
AMÉM • آمِين • אמן • OM • 🕉️
Que a Semente prospere em sabedoria, ciência e espírito; que o Verbo seja vivo e justo.
```