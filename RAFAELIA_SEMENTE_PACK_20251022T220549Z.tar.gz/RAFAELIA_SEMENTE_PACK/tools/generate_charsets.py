#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tools/generate_charsets.py — RAFAELIA utility
Gera amostras de conjuntos de caracteres (ASCII, Latin-1, CJK sample, Emoji sample).
"""
import json, os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)

def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

# ASCII 7-bit printable
ascii7_chars = "".join(chr(c) for c in range(0x20, 0x7F))
write_json(os.path.join(DATA, "ascii_7bit.json"), {
    "charset_name": "ASCII_7bit_printable",
    "unicode_version": "N/A",
    "range": "U+0020..U+007E",
    "count": len(ascii7_chars),
    "characters": list(ascii7_chars)
})

# Latin-1 supplement sample (0xA0..0xFF)
latin1_chars = "".join(chr(c) for c in range(0xA0, 0x100))
write_json(os.path.join(DATA, "ascii_8bit_sample.json"), {
    "charset_name": "Latin1_Supplement_sample (as ASCII_8bit sample)",
    "unicode_version": "N/A",
    "range": "U+00A0..U+00FF",
    "count": len(latin1_chars),
    "characters": list(latin1_chars)
})

# CJK small sample
cjk_sample_chars = ["中","国","日","本","漢","字","龙","空","神","愛","道","氣","光","心","和","永"]
write_json(os.path.join(DATA, "cjk_unified_sample.json"), {
    "charset_name": "CJK_Unified_Ideographs_sample",
    "unicode_version": "N/A",
    "note": "Pequeno subconjunto ilustrativo. Para captura completa, usar Unihan/UnicodeData.",
    "count": len(cjk_sample_chars),
    "characters": cjk_sample_chars
})

# Emoji sample
emoji_chars = ["🙂","😂","❤️","🔥","🕊️","🧬","⚛️","🕉️","☯️","💍","🌀","🦉","⚖️","⚕️"]
write_json(os.path.join(DATA, "emoji_emoticons_sample.json"), {
    "charset_name": "Emoji_emoticons_sample",
    "unicode_version": "N/A",
    "count": len(emoji_chars),
    "characters": emoji_chars
})

print("Charsets generated in", DATA)
