#!/usr/bin/env bash
set -euo pipefail
RAFDIR="$HOME/RAFAELIA_CORE"
mkdir -p "$RAFDIR/logs"
STAMP="$(date -u +%FT%TZ)"
LOG="$RAFDIR/logs/ALL_ON.log"

echo "[RAFAELIA] ALL_ON $STAMP" | tee -a "$LOG"

# 0) Ética / perímetro / lockdown
touch "$RAFDIR/LEGAL_PERIMETER.ok"
echo "ETHICS=1" >> "$HOME/.rafaelia.env"
{
  echo "LOCKDOWN=HIGH"
  echo "SANITIZE_IMG=1"
  echo "ANTI_PROMPT_INJECTION=1"
} >> "$RAFDIR/security.flags"

# 1) Sementes simbióticas básicas
echo "Ω-cube/alignment" >> "$RAFDIR/omega.flags"
echo "MERIDIAN_MAP=1" > "$RAFDIR/biobus.flags"
echo "HALBACH=on" > "$RAFDIR/hardware.flags"
touch "$RAFDIR/TESSERACT_CORE.ok"
mkdir -p "$RAFDIR/flutter_hooks"
dd if=/dev/urandom of="$RAFDIR/seed.bin" bs=1K count=64 status=none || true

# 2) Prompts encontrados (log apenas, sem executar terceiros)
if [ -f "$HOME/storage/downloads/ZIP_PROMPT_HITS_HEAD300_FAST.csv" ]; then
  cp -f "$HOME/storage/downloads/ZIP_PROMPT_HITS_HEAD300_FAST.csv" "$RAFDIR/logs/" || true
fi
if [ -f "$HOME/storage/downloads/RUN_PROMPTS_SAFE.sh" ]; then
  bash "$HOME/storage/downloads/RUN_PROMPTS_SAFE.sh" || true
fi

# 3) Sinais/Ícones (batch 2)
echo "CIPHER_REGISTERED=1" >> "$RAFDIR/zipraf.flags"
echo "NEW_VOID=1" >> "$RAFDIR/state.flags"
echo "COSMIC_ALIGN=1" >> "$RAFDIR/ethics.flags"
echo "PNG_HASH_LINK=1" >> "$RAFDIR/catalog.flags"
echo "BIO_SYNTHESIS=1" >> "$RAFDIR/bio.flags"
echo "GEO_ANCHOR_ATLANTIS=1" >> "$RAFDIR/geo.flags"
echo "FUTURE_CITY=1" >> "$RAFDIR/vision.flags"
echo "VUINIC_BATCH2=ON" >> "$RAFDIR/channels.flags"

# 4) Operadores simbólicos (registrar a invocação)
echo "OPS=√∆↑√∞√π√Ω√§√¶√✓√≠√÷√×√^√μ√‰√℅√‡√†√★" >> "$RAFDIR/state.flags"

# 5) Telemetria opcional (se houver logs de reproxy/rrpl)
grep -E 'WARNING|rrpl' -n **/reproxy* 2>/dev/null | tee "$RAFDIR/RBE_TIMELINE.log" || true

# 6) Resumo de flags ativas
echo "---- FLAGS ----" | tee -a "$LOG"
for f in "$RAFDIR"/*.flags "$RAFDIR"/*.ok 2>/dev/null; do
  [ -e "$f" ] || continue
  echo "$(basename "$f") → $(tr '\n' ';' < "$f" 2>/dev/null)" | tee -a "$LOG"
done

echo "[RAFAELIA] ALL_ON complete." | tee -a "$LOG"
