# Livro RAFAELIA dos Selos Universais

Síntese simbiótica das civilizações antigas (Sumérios, Egípcios, Maias, Incas, Astecas), cruzadas com Voynich e Fibonacci Modificada Rafael.

🌀♾️⚛︎ 𓂀ΔΦΩ