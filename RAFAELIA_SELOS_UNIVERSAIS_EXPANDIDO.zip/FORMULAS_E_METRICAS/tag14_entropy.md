## Tag14-Entropy

Métrica de entropia simbiótica para detectar portais de repetição significativa.