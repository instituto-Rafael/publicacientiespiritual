## Hurst Exponent

Mede persistência/fractalidade em séries simbióticas.