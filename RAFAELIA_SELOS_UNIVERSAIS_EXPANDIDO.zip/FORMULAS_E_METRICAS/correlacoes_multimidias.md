## Correlações Multimídias

Medidas de Mutual Info e Distance Correlation entre número, som, imagem e texto.