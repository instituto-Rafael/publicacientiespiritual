## Linhas de Energia

Estradas e construções alinhadas a linhas de energia da Terra.