## Incas – Quipu como Banco de Dados

Cordões com nós funcionavam como proto-código binário/multivalente.
Possível armazenamento de informações contábeis e rituais.