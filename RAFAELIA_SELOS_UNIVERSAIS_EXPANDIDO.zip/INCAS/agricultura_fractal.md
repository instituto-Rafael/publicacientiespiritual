## Agricultura Fractal

Terraços agrícolas otimizavam água e fertilidade.
Sistema adaptativo e simbiótico com o ambiente.