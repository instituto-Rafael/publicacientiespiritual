## Mulheres Maias

Atuaram como astrônomas e matemáticas, inscritas em tumbas e murais.