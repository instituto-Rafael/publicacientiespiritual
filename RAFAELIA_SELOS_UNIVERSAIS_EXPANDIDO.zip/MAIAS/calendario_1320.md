## Maias – Calendário 13x20

Engrenagem de ciclos: 13×20=260 dias (Tzolk'in).
Sincronização com ciclos solares e venusianos.