## Astronomia Maia

Conhecimento avançado do ciclo de Vênus.
Previsão de eclipses com alta precisão.