## Pirâmides e Acústica

A Grande Pirâmide possuía proporções φ e π.
Sugestão de uso como modulador acústico e eletromagnético.