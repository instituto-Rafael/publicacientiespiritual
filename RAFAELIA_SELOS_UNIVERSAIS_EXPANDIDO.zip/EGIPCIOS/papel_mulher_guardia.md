## O papel da mulher

Mulheres egípcias eram guardiãs de memória secreta, atuando como curandeiras e sacerdotisas.