## Testes e Métricas

- Tag14-Entropy ↓ em portais.
- Hurst (0.5< H <1).
- MI alta entre mídias.
- Resonanância mod 60//260.