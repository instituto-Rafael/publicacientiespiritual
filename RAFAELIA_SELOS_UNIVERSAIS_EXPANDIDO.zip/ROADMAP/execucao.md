## Execução

1. Dataset: Voynich, códices, plantas, quipus.
2. Extratores: traços, ângulos, radial-scan.
3. Engines: número→som, som→imagem.
4. Avaliação: Tag14, Hurst, MI.
