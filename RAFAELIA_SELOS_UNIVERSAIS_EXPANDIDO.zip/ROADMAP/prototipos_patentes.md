## Protótipos/Patentes

- Voynich-Audio Engine.
- Σ-Seal Visual antifraude.
- Quipu-DB para IoT offline.
- Fractal-Calendar Engine.
- Temple-Acoustics.