## Astecas – Pedra do Sol

Calendário monumental com ciclos cósmicos.
Camadas representando eras e reinícios.