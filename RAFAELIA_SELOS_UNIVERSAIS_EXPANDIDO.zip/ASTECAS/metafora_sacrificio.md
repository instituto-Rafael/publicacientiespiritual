## Sacrifício como Metáfora

Nem sempre literal: representava fertilidade, energia e renascimento.