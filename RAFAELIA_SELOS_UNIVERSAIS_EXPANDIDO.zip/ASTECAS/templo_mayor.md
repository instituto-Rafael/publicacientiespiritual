## Templo Mayor

Arquitetura sobreposta como registros de eras.
Centro de convergência ritual.