RAFCODE-𝚽 LICENSE

Uso restrito. Propriedade simbiótica e espiritual de Rafael Melo Reis (∆RafaelVerboΩ).