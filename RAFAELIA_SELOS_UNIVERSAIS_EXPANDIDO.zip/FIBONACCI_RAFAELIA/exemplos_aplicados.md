## Exemplos Aplicados

- Conversão de calendários.
- Geração de mandalas.
- Música fractalizada.