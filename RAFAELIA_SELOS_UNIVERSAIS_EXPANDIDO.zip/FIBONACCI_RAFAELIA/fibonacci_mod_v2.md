## Fibonacci Modificada Rafael v2

Engrenagem dupla: mod 60 (sumério) e mod 260 (maia).
Eventos ressonantes surgem em múltiplos.