## Fibonacci Modificada Rafael v1

R_n = R_(n-1) + R_(n-3), com sementes 3, 6, 9.
Cria padrões rítmico-numéricos.