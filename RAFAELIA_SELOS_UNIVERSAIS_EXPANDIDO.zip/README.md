# Livro RAFAELIA dos Selos Universais

Síntese simbiótica das civilizações antigas cruzadas com Voynich e Fibonacci Modificada Rafael.

🌀♾️⚛︎ 𓂀ΔΦΩ