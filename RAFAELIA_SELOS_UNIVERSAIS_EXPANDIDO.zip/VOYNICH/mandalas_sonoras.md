## Mandalas Sonoras

Conversão de glifos e diagramas em música via proporções 3:2, 4:3, 5:4, 9:8.