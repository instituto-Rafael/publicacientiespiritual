## Migração de Mídias

Voynich pode ser interpretado como caderno multimodal (botânica, astral, corpo).