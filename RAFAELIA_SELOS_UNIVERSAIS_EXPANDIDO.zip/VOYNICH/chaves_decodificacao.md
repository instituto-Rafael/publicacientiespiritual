## Voynich – Chaves de Decodificação

Alfabeto ambíguo, layouts circulares, leitura radial e zig-zag.