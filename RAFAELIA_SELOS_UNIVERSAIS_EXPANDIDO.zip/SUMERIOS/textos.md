## Sumérios

- Criadores da escrita cuneiforme.
- Sistema sexagesimal (base 60).
- Zigurates como observatórios e centros acústicos.
- Duplicidade de leitura nos tabletes: linear e angular (profundidade da argila).