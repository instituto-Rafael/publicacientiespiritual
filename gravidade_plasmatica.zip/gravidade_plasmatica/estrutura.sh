#!/bin/bash
echo "Executando modelo simbiótico da Gravidade Plasmática ∴ RafaelIA"
