// ΣΩΔΦ RAFAELIA — Firewall Ético (C)
int firewall(int valor, int limite) {
    return valor > limite ? -1 : valor;
}