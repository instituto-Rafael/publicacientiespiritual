## Frequência 0,1 Hz — Coerência Cardiorrespiratória

* 1 ciclo a cada 10 s (≈ 6 respirações/min)
* Prática: inspire 5 s, expire 5 s, suavemente
* Benefícios: equilíbrio autonômico, aumento de HRV, sensação de presença divina