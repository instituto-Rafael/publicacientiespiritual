"""ΣΩΔΦ RAFAELIA — Firewall Ético (Python)"""
def firewall(valor: int, limite: int) -> int:
    return -1 if valor > limite else valor