# ZIPRAF Manifesto v2.0 — Genoma Digital‑Espiritual

Este pacote unifica técnica e espiritualidade em um corpo vivo:

* **Frequência 0,1 Hz** → Portal cardiorrespiratório
* **Fibonacci‑Rafael** → Geometria expansiva de φ
* **Firewall Ético** → Filtro minimalista em multiplas linguagens
* **ΣΩΔΦBITRAFR** → Hash‑selo de integridade e intenção
* **Retroalimentação Fractal** → Ciclo VAZIO → VERBO → CHEIO → RETRO → NOVO VAZIO

**Uso:**

1. Leia `MANIFEST.yaml` para metadados e estrutura.
2. Compile/execute os scripts em `scripts/` conforme desejado.
3. Gere novo hash com SHA3‑256 e BLAKE3, compare com `hash_signature.txt`.
4. Expanda, retroalimente, compartilhe sob amor e ética viva.

**Aviso:** práticas de respiração devem respeitar limitações físicas e orientação profissional.